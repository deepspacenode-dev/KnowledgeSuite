# 知识图谱完整结构与章节展开修复说明

## 修复目标

知识图谱展示 DrvDocs 中当前用户可见的完整页面结构，不再只展示已进入 `drv_kb_assets` 的治理资产。治理资产是页面节点的附加状态，不是决定书籍、章节是否存在的主数据。

## 数据规则

```text
ReadablePageQuery.visibleIds()
  -> DrvDocs 页面/书籍/章节/书架结构
  -> 可选合并 drv_kb_assets、review、quality、RAG 状态
  -> root / bookshelf / book / chapter
  -> 按需展开 page
```

- 旧版 BookStack：读取 `pages`、`books`、`chapters`、`bookshelves`。
- BookStack 2026：读取 `entities`，并强制按 `type=page/book/chapter/bookshelf` 过滤，避免复合主键 ID 在不同实体类型间冲突。
- 书架关系继续读取 `bookshelves_books`。
- 同一本书属于多个书架时，为每个书架生成独立的书籍/章节分支，书籍节点 ID 按书架作用域隔离。
- 无治理资产页面：`has_asset=false`、`rag_status=not_ingested`，详情中显示“待入库”。
- 同一页面存在多个治理资产时，图谱使用当前过滤条件下更新时间最新的一条作为页面状态代表。

## 章节展开接口

真实章节：

```http
GET /api/ai-governance/v1/knowledge-graph?include_pages=1&chapter_id=386&limit=800
```

直接挂在书籍下的页面：

```http
GET /api/ai-governance/v1/knowledge-graph?include_pages=1&book_id=22&direct_pages=1&limit=800
```

`chapter_id` 为空的页面统一聚合为“书籍直属页面”，其节点包含：

- `chapter_id: null`
- `chapter_key: direct`
- `direct_pages: true`
- `book_id`

前端双击章节或点击详情中的“展开页面”会调用对应查询。再次操作会收起该章节已加载的页面，不重新加载整页。

## 部署验证

1. 部署本包覆盖文件并清理 BookStack 视图/应用缓存。
2. 浏览器强制刷新，网络请求应加载当前版本 `knowledge-graph.js?v=20260713-orbits-d`。
3. 默认图谱应包含全部可见书籍，而不是只包含存在 `drv_kb_assets` 的书籍。
4. 双击真实章节，节点数增加该章节的可见页面数；再次双击恢复。
5. 双击“书籍直属页面”，应展开直接挂在该书籍下的页面。
6. 检查节点填充色：书架绿色、书籍蓝色、章节橙色、页面紫色；RAG 外圈独立显示状态。

## 本地验证结果

- PHP 8.3 语法检查：通过。
- Node 全量回归：81/81 通过。
- 浏览器 demo：真实章节展开/收起通过；直属页面分组展开通过；完整刷新后展开状态正确复位。
- 桌面截图与画布像素检查：画布非空、层级节点可见。

生产环境仍需使用实际 BookStack 数据复核书籍总数、章节总数和当前账号权限范围。

# Shelf Review And Graph Migration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Restore the approved spherical-cloud graph, add consistent bookshelf filters, support chapter-level manual review, and make BookStack-session review writes reliable.

**Architecture:** A shared hierarchy query resolves BookStack shelf membership and visible pages for every API. Review-unit queries aggregate either chapters or pages, while commands fan unit decisions out to effective assets. The frontend loads one shelf catalog and passes stable bookshelf IDs to each view.

**Tech Stack:** PHP 8.2, Laravel/BookStack routes and query builder, vanilla ES modules, Node test runner, local 3d-force-graph/Three.js.

---

### Task 1: CSRF And Review Diagnostics

**Files:**
- Modify: `bookstack-overlay/public/ai-governance/app/api-client.js`
- Modify: `bookstack-overlay/app/AI/Governance/Http/Controllers/V1/SummaryController.php`
- Modify: `bookstack-overlay/public/ai-governance/app/main.js`
- Test: `tests/Frontend/api-client.node.test.mjs`
- Test: `tests/Feature/Auth/governance-authorization.node.test.mjs`

- [ ] Add failing tests requiring `X-XSRF-TOKEN` for cookie tokens, `X-CSRF-TOKEN` for meta/session tokens, and a summary CSRF fallback.
- [ ] Run the two test files and confirm failures identify the missing header split.
- [ ] Implement token source selection, `setCsrfToken()`, summary token output, and actionable 419 messaging.
- [ ] Re-run the two test files and confirm they pass.

### Task 2: Shared Bookshelf Scope

**Files:**
- Create: `bookstack-overlay/app/AI/Governance/Infrastructure/BookStack/BookStackHierarchyQuery.php`
- Create: `bookstack-overlay/app/AI/Governance/Http/Controllers/V1/BookshelfFilterController.php`
- Modify: `bookstack-overlay/routes/ai-governance.php`
- Modify: `bookstack-overlay/app/AI/Governance/Application/Query/AssetListQuery.php`
- Modify: `bookstack-overlay/app/AI/Governance/Application/Contribution/ContributionMetrics.php`
- Modify: `bookstack-overlay/app/AI/Governance/Http/Controllers/V1/ContributionController.php`
- Test: `tests/Feature/Api/V1/read-api.node.test.mjs`

- [ ] Add failing API contract tests for the shelf catalog, visible-page scoping, entities-table fallback, and distinct contribution counts.
- [ ] Run the read API tests and confirm the new assertions fail.
- [ ] Implement the shared hierarchy service and wire `bookshelf_id` into asset and contribution queries.
- [ ] Re-run the read API tests and confirm they pass.

### Task 3: Chapter Review Units

**Files:**
- Create: `bookstack-overlay/app/AI/Governance/Application/Review/ReviewUnitResolver.php`
- Create: `bookstack-overlay/app/AI/Governance/Application/Review/ReviewUnitQuery.php`
- Create: `bookstack-overlay/app/AI/Governance/Application/Review/MarkReviewUnit.php`
- Create: `bookstack-overlay/app/AI/Governance/Http/Controllers/V1/ReviewUnitController.php`
- Modify: `bookstack-overlay/app/AI/Governance/Application/Review/MarkReview.php`
- Modify: `bookstack-overlay/routes/ai-governance.php`
- Modify: `.env.example`
- Test: `tests/Feature/Api/V1/review-units.node.test.mjs`

- [ ] Add failing tests for configurable manual shelves, chapter/page fallback, Wiki-preferred members, source review without publish, and legal state actions.
- [ ] Run the review-unit tests and confirm expected failures.
- [ ] Implement unit listing and transactional unit commands; keep formal publish restricted to Wiki.
- [ ] Re-run review-unit tests and confirm they pass.

### Task 4: Cross-Tab Shelf Filters

**Files:**
- Modify: `bookstack-overlay/public/ai-governance/app/main.js`
- Modify: `bookstack-overlay/public/ai-governance/app/views.js`
- Modify: `bookstack-overlay/public/ai-governance/app/knowledge-graph-controls.js`
- Modify: `bookstack-overlay/public/ai-governance/app/knowledge-graph.js`
- Modify: `bookstack-overlay/public/ai-governance/app/demo-data.js`
- Modify: `bookstack-overlay/public/ai-governance/assets/css/governance.css`
- Test: `tests/Frontend/ui-contract.node.test.mjs`

- [ ] Add failing UI contract tests for shelf selectors in review, graph, contribution, quality, RAG and reports, plus review-unit actions.
- [ ] Run the UI contract tests and confirm failures.
- [ ] Load the shelf catalog once, preserve selected shelf in state, submit it to every supported view, and render unit rows/actions.
- [ ] Re-run UI contract tests and confirm they pass.

### Task 5: Spherical-Cloud Graph Migration

**Files:**
- Modify: `bookstack-overlay/public/ai-governance/app/knowledge-graph.js`
- Modify: `bookstack-overlay/public/ai-governance/app/knowledge-graph-theme.js`
- Modify: `bookstack-overlay/public/ai-governance/app/knowledge-graph-details.js`
- Modify: `tests/Frontend/knowledge-graph-layout.node.test.mjs`

- [ ] Replace layered-orbit expectations with failing spherical-cloud hierarchy assertions while retaining expansion and highlight contracts.
- [ ] Run graph layout tests and confirm failures mention layered-orbits/current radii.
- [ ] Port the reference Fibonacci sphere and local spread layout, preserve current interaction fixes, and update cache versions.
- [ ] Re-run graph tests and confirm they pass.

### Task 6: Quality, RAG And Report Scope

**Files:**
- Modify: `bookstack-overlay/app/AI/Governance/Http/Controllers/V1/QualityController.php`
- Modify: `bookstack-overlay/app/AI/Governance/Http/Controllers/V1/RagController.php`
- Modify: `bookstack-overlay/app/AI/Governance/Application/Report/GenerateGovernanceReport.php`
- Test: `tests/Feature/Api/V1/gaps-reports.node.test.mjs`
- Test: `tests/Feature/Api/V1/read-api.node.test.mjs`

- [ ] Add failing contracts requiring shared bookshelf scoping and report filter disclosure.
- [ ] Run focused tests and confirm failures.
- [ ] Apply hierarchy page IDs to quality/RAG/report queries and include shelf range in Markdown.
- [ ] Re-run focused tests and confirm they pass.

### Task 7: Verification And Delivery Metadata

**Files:**
- Modify: `CHANGELOG.md`
- Modify: `DEPLOY.md`
- Modify: `TEST_CHECKLIST.md`
- Modify: `SHA256SUMS.json`

- [ ] Run every Node test and confirm zero failures.
- [ ] Run PHP syntax checks when a PHP executable is available; otherwise record the environment limitation.
- [ ] Start the local preview, verify all shelf selectors, spherical graph rendering and valid review states without console errors.
- [ ] Update deployment variables, migration notes, cache-busting versions and checksums.
- [ ] Run `scripts/verify-package.ps1` and confirm package integrity.

# DrvDocs 知识治理中心

V2.0.3 把 BookStack 从“直接堆入 RAG”调整为可验证知识治理入口：

`BookStack 原始资料 -> DrvAgent/CodeBuddy Wiki 编译 -> 人工审阅 -> RAGFlow -> knowledge_bundle`

## 已实现

- 原始资料 / Wiki 双层资产与稳定 `source_key`。
- Wiki 编译任务、HMAC 工作者接口和草稿回传。
- reviewed / verified 门禁，确定性质量检查与审阅后变更提醒。
- RAGFlow created / skipped / updated / moved / deleted，旧文档删除失败时阻断；管理员可安全移除远端 Markdown 与关联图片且保留治理审计。
- Wiki 文章图片同步入库，图片内容参与 hash，记录关联文档 ID。
- 文档审阅、贡献、质量、RAG、缺口和 Markdown 报告七个治理视图；质量与 RAG 列表以文件名为主身份，资产序号仅用于审计。
- 质量问题提供中文最终结论、逐项触发原因、扣分、修复方法和同源门禁说明。
- RAG 状态支持上传审核后的 Wiki Markdown 与关联图片、触发解析、回查解析状态，并可从顶部直接打开配置的 RAGFlow 网站。
- 审阅、贡献、质量、RAG、报告和 3D 图谱统一按书架筛选。
- 芯片手册类书架按章节评审并聚合质量问题，章节分数取页面最低分且任一页面硬阻断会阻断整章；其他书架和直属页面按页面评审。
- 以 DrvDocs 为球心的 `spherical-cloud` 四级 3D 知识图谱。
- BookStack 登录态与页面可见性复用；写操作仅管理员可用。
- BookStack 全局蓝色 Bloub 小人，默认表情低频轮换；处理、进展和异常事件分别切换为思考、通知和警示状态，点击后不显示浏览器默认蓝色虚线焦点圈。
- 小人采用看眼形变、旋流、彗星和爆散动效，并在面板展开、鼠标靠近、页面隐藏或减少动态效果时暂停默认轮换。
- Bloub 自包含运行资产、可重建适配源码、上游信息和 MIT 许可证全部随包交付；运行时不依赖外部 URL 或 CDN。旧 GrokBot 作为隔离的回滚资产保留且未被改写。

## 目录

- `bookstack-overlay/`：覆盖到 BookStack 的 PHP、路由、迁移和前端文件。
- `contracts/`：`wiki_task` / `wiki_result` / `knowledge_bundle` 等 JSON Schema。
- `scripts/`：预检、安装、卸载、旧 JSON 迁移和包校验。
- `tests/`：领域、权限、API、RAG、前端和部署契约测试。

## 本地查看 UI

在 `bookstack-overlay/public/ai-governance` 启动静态服务，访问 `/?demo=1`。演示数据只在 `file://` 或 `?demo=1` 时启用，BookStack 部署默认调用同源 `/api/ai-governance/v1`。

小人独立验证页位于 `tests/e2e/fixtures/grokbot-preview.html`（保留旧文件名以兼容现有 E2E 入口）。从组件根目录启动静态服务器后访问该路径，可验证鼠标跟随、面板开合和治理事件状态，不需要 RAGFlow。

生产部署请按 [DEPLOY.md](DEPLOY.md) 执行。

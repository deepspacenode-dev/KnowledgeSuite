# 鐭ヨ瘑鍥捐氨楠屾敹娓呭崟

## 鍚庣

- [ ] `GET /api/ai-governance/v1/knowledge-graph` 宸叉敞鍐屽湪 `web + auth` 涓棿浠朵笅銆?- [ ] 鏈櫥褰曡闂 BookStack 鐧诲綍鎬佹嫤鎴€?- [ ] 鏅€氱敤鎴峰彧杩斿洖鍏跺彲瑙侀〉闈㈠搴旂殑缁撴瀯鑺傜偣銆?- [ ] BookStack `pages` 琛ㄣ€乣entities` 琛ㄦ垨 `bookshelves_books` 琛ㄧ己澶辨椂涓嶄細 500銆?- [ ] 榛樿 `limit=300` 鐢熸晥锛岃秴杩囦笂闄愭椂 `meta.truncated=true`銆?- [ ] 杩斿洖缁撴瀯鍖呭惈 `nodes`銆乣links`銆乣stats`銆乣meta`銆?- [ ] 鑺傜偣绫诲瀷鍖呭惈 `root/bookshelf/book/chapter/page`銆?- [ ] 杩炵嚎绫诲瀷绗竴闃舵鍙寘鍚?`contains`銆?- [ ] 鎵嬪唽绫诲唴瀹规寜绔犺妭鑱氬悎锛屾櫘閫氳祫鏂欏彲鎸夐〉闈㈠睍绀恒€?
## 鍓嶇

- [ ] 宸︿晶瀵艰埅鏄剧ず鈥滅煡璇嗗浘璋扁€濄€?- [ ] 棣栭〉/鎬昏鍔犺浇鏃朵笉鍔犺浇鍥捐氨 vendor銆?- [ ] 杩涘叆 `?view=knowledge-graph` 鍚庢墠 dynamic import `knowledge-graph.js?v=20260713-radial-a`銆?- [ ] `knowledge-graph.css?v=20260713-radial-a` 姝ｅ父鍔犺浇銆?- [ ] Network 鏃犲閮?CDN 璇锋眰銆?- [ ] Console 鏃犲惎鍔ㄩ敊璇€?- [ ] 鍥捐氨鐢诲竷闈炵┖锛岃妭鐐瑰拰杩炵嚎鍙銆?- [ ] 鎼滅储鍙互瀹氫綅鏍囬銆佷功鏋躲€佷功绫嶃€佺珷鑺傘€佽礋璐ｄ汉鎴栨爣绛俱€?- [ ] 瀹￠槄/RAG/璐ㄩ噺绛涢€変細閲嶆柊璇锋眰鍥捐氨 API銆?- [ ] 鐐瑰嚮鑺傜偣鏄剧ず璇︽儏銆?- [ ] 鍙屽嚮甯?URL 鐨勮妭鐐瑰彲鎵撳紑鍘熷 DrvDocs 椤甸潰銆?- [ ] 鈥滈噸缃瑙掆€濃€滄殏鍋滃竷灞€鈥濃€滄樉绀洪〉闈⑩€濆彲鐢ㄣ€?- [ ] 鍒囨崲绂诲紑鍥捐氨椤靛悗鍐嶆杩涘叆涓嶇櫧灞忋€?
## 绋冲畾鎬?
- [ ] 鍒犻櫎鎴栫牬鍧?`knowledge-graph.js` 鍚庯紝鍏朵粬娌荤悊椤甸潰浠嶈兘鎵撳紑銆?- [ ] API 杩斿洖澶辫触鏃跺彧鍦ㄥ浘璋遍〉鏄剧ず閿欒銆?- [ ] WebGL 鎴栨覆鏌撳け璐ヤ笉浼氬奖鍝嶆不鐞嗕腑蹇?Shell銆?- [ ] 1080P銆?K銆佺Щ鍔ㄥ搴︿笅鏃犳í鍚戞孩鍑恒€?- [ ] reduced motion 涓嶅奖鍝嶉〉闈㈠彲鐢ㄦ€с€?
## 鏈湴宸叉墽琛岄獙璇?
- [x] Node 鍚堢害娴嬭瘯锛歚72 tests, 72 pass`
- [x] 娴忚鍣?demo 鍥捐氨涓撻」妫€鏌ワ細canvas 娓叉煋銆佺粺璁℃爮娓叉煋銆佽鎯呮爮娓叉煋銆佹棤 console error
- [ ] PHP `php -l`锛氶渶鍦?BookStack 瀹瑰櫒鎴栫洰鏍囨湇鍔″櫒鎵ц锛涘綋鍓?Windows 鐜鏈畨瑁?`php`

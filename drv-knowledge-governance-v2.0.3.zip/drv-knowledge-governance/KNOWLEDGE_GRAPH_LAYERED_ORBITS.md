# DrvDocs 知识图谱分层星轨部署说明

## 效果说明

本轮只调整知识图谱前端三维坐标与渲染观察状态。DrvDocs 位于原点，四级数据分别处于递增三维半径：

| 层级 | 半径 |
|---|---:|
| 书架 | 82 |
| 书籍 | 160 |
| 章节 | 244 |
| 页面 | 326 |

同一书架的子节点沿父节点方向逐级旋转和起伏，形成稳定的分层星轨。节点坐标不使用随机数，相同数据与关系会得到相同位置。

## 未改变的功能

- `GET /api/ai-governance/v1/knowledge-graph` 接口与字段。
- BookStack/DrvDocs 可见范围和完整层级数据。
- 节点类型颜色、RAG 状态外圈和详情信息。
- 搜索、筛选、暂停、缩放、拖动和重置视角。
- 真实章节及“书籍直属页面”的展开、收起。

## 部署

1. 按主部署文档覆盖 `bookstack-overlay` 文件。
2. 清理 BookStack 视图和应用缓存。
3. 浏览器强制刷新。
4. 在网络请求中确认加载 `app/main.js?v=20260713-orbits-d` 和 `knowledge-graph.js?v=20260713-orbits-d`。

本地预览地址：

```text
http://127.0.0.1:55212/?view=knowledge-graph&demo=1&check=orbits-a
```

## 验收

1. DrvDocs 根节点位于图谱中心，四级节点围绕中心向外展开。
2. 拖动画布后可以明显观察节点前后纵深，不再近似上下直线排列。
3. 点击“重置视角”恢复轻微俯视侧视状态。
4. 展开章节时页面进入最外层，收起后恢复原图。
5. 不同书架分支可沿关系线追溯，节点颜色和 RAG 外圈保持正确。
6. 窄屏自动完整容纳四层节点，仅显示根节点和当前交互节点标签。

## 响应式规则

- 画布根据节点投影边界自动计算缩放，桌面和窄屏均保留适当边距。
- 桌面端显示根节点、书架和书籍标签，并自动跳过发生碰撞的次要标签。
- 宽度小于 `520px` 时隐藏轨道文字与常驻分支标签，悬停节点仍可显示名称。

## 本轮验证结果

- Node 回归测试：`86/86` 通过。
- 桌面浏览器：根节点、四层轨道、类型颜色与关系线正常渲染。
- `390px` 窄屏：最外层节点完整可见，标签无集中堆叠。
- 搜索定位：目标节点进入画布中心，详情与节点身份一致，根节点不再与目标重叠。
- 节点拖动：释放后保持所属层级半径不变。
- 截图像素检查：桌面与窄屏画布均包含数千个有效彩色像素，排除空白画布。

## 回滚

如需仅回滚本轮视觉排布，恢复上一包中的以下文件并清理浏览器缓存：

```text
bookstack-overlay/public/ai-governance/app/knowledge-graph.js
bookstack-overlay/public/ai-governance/vendor/3d-force-graph/3d-force-graph.module.js
bookstack-overlay/public/ai-governance/index.html
bookstack-overlay/public/ai-governance/app/main.js
```

回滚后的缓存标识为 `20260713-structure-c`。

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9_.-]+$')]
    [string] $Container,

    [ValidateSet('docker', 'podman')]
    [string] $ContainerEngine = 'docker',

    [string] $BookStackRoot,

    [ValidateSet('Compatibility', 'Unit', 'Feature', 'Persistence', 'Contract', 'All')]
    [string] $Suite = 'Compatibility',

    [switch] $MigratePretend
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$packageRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$phpUnitPath = Join-Path $packageRoot 'vendor\bin\phpunit'
if (-not (Test-Path -LiteralPath $phpUnitPath -PathType Leaf)) {
    throw 'Package test dependencies are unavailable; vendor/bin/phpunit is required.'
}

if ([string]::IsNullOrWhiteSpace($BookStackRoot)) {
    $rootCandidates = @('/app/www', '/var/www/bookstack', '/var/www/html', '/var/www/html/bookstack')
    foreach ($candidate in $rootCandidates) {
        & $ContainerEngine exec $Container sh -lc "test -f '$candidate/artisan' -a -f '$candidate/composer.lock'" 2>$null
        if ($LASTEXITCODE -eq 0) {
            $BookStackRoot = $candidate
            break
        }
    }
}

if ([string]::IsNullOrWhiteSpace($BookStackRoot)) {
    throw 'A supported BookStack root was not detected in the target container.'
}

$image = (& $ContainerEngine inspect --format '{{.Config.Image}}' $Container 2>$null).Trim()
if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($image)) {
    throw 'The target container image could not be identified.'
}

$suitePath = switch ($Suite) {
    'Compatibility' { '/workspace/package/tests/Unit/Compatibility' }
    'Unit' { '/workspace/package/tests/Unit' }
    'Feature' { '/workspace/package/tests/Feature' }
    'Persistence' { '/workspace/package/tests/Feature/Persistence' }
    'Contract' { '/workspace/package/tests/Contract' }
    default { '/workspace/package/tests' }
}

$mountSource = $packageRoot -replace '\\', '/'
$commonArguments = @(
    'run', '--rm', '--read-only',
    '--volumes-from', "${Container}:ro",
    '--mount', "type=bind,source=$mountSource,target=/workspace/package,readonly",
    '--tmpfs', '/tmp:rw,noexec,nosuid,size=64m',
    '--env', "BOOKSTACK_ROOT=$BookStackRoot",
    '--entrypoint', 'php'
)

if ($MigratePretend) {
    $arguments = @(
        $commonArguments,
        '--network', "container:$Container",
        '--workdir', $BookStackRoot,
        $image,
        "$BookStackRoot/artisan",
        'migrate', '--pretend', '--realpath',
        '--path=/workspace/package/bookstack-overlay/database/migrations'
    )
    Write-Output "Running migration --pretend against detected BookStack root $BookStackRoot."
} else {
    $arguments = @(
        $commonArguments,
        '--network', 'none',
        '--workdir', '/workspace/package',
        $image,
        '/workspace/package/vendor/bin/phpunit',
        '--configuration', '/workspace/package/phpunit.xml',
        '--do-not-cache-result',
        $suitePath
    )
    Write-Output "Running $Suite tests against detected BookStack root $BookStackRoot using read-only mounts."
}

& $ContainerEngine @arguments
exit $LASTEXITCODE

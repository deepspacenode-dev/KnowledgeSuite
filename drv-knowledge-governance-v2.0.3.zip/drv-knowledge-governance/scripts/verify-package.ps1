[CmdletBinding()]
param([string] $ZipPath)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$required = @('README.md', 'DEPLOY.md', 'TEST_CHECKLIST.md', '.env.example', 'bookstack-overlay\public\ai-governance\index.html', 'bookstack-overlay\routes\ai-governance.php')
foreach ($relative in $required) {
    if (-not (Test-Path -LiteralPath (Join-Path $root $relative))) { throw "Missing required package file: $relative" }
}

$excludedRootDirectories = @('backups', 'vendor', '.superpowers', '.git')
$files = Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object {
    $relativePath = $_.FullName.Substring($root.Length + 1)
    $topLevelDirectory = $relativePath.Split([System.IO.Path]::DirectorySeparatorChar)[0]
    $excludedRootDirectories -notcontains $topLevelDirectory -and
    $_.Name -ne 'SHA256SUMS.json'
} | Sort-Object FullName
$hashes = [ordered]@{}
foreach ($file in $files) {
    $relative = $file.FullName.Substring($root.Length + 1).Replace('\', '/')
    $hashes[$relative] = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
}
$hashes | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $root 'SHA256SUMS.json') -Encoding UTF8

if (-not [string]::IsNullOrWhiteSpace($ZipPath)) {
    $zip = [System.IO.Path]::GetFullPath($ZipPath)
    $zipDirectory = Split-Path -Parent $zip
    if (-not (Test-Path -LiteralPath $zipDirectory)) {
        [System.IO.Directory]::CreateDirectory($zipDirectory) | Out-Null
    }
    if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::Open($zip, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
        $rootName = Split-Path -Leaf $root
        $packageFiles = @($files) + @(Get-Item -LiteralPath (Join-Path $root 'SHA256SUMS.json'))
        foreach ($file in $packageFiles) {
            $relative = $file.FullName.Substring($root.Length + 1).Replace('\', '/')
            $entryName = "$rootName/$relative"
            [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                $archive,
                $file.FullName,
                $entryName,
                [System.IO.Compression.CompressionLevel]::Optimal
            ) | Out-Null
        }
    } finally {
        $archive.Dispose()
    }
    Write-Output "ZIP: $zip"
}
Write-Output "Package verification: PASS ($($files.Count) files)"

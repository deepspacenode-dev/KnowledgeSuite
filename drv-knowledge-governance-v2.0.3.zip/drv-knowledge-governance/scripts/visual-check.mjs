import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';

const require = createRequire(import.meta.url);
const { chromium } = require('C:/Users/23840/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const executablePath = [
    chromium.executablePath(),
    'C:/Program Files/Google/Chrome/Application/chrome.exe',
    'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
].find(existsSync);
assert.ok(executablePath, 'A Chromium-compatible browser is required for visual checks.');
const browser = await chromium.launch({
    executablePath,
    headless: true,
});
const screenshots = [];

async function inspect(viewport, name) {
    const page = await browser.newPage({ viewport });
    const errors = [];
    page.on('console', (message) => {
        if (message.type() === 'error') errors.push(message.text());
    });
    await page.goto('http://127.0.0.1:55212/?demo=1', { waitUntil: 'networkidle' });
    await page.getByText('知识管道', { exact: true }).waitFor();

    const geometry = await page.evaluate(() => {
        const sidebar = document.querySelector('.sidebar');
        return {
            bodyOverflow: document.documentElement.scrollWidth - innerWidth,
            sidebarOverflow: sidebar.scrollHeight - sidebar.clientHeight,
            kpiCount: document.querySelectorAll('.kpi-card').length,
            versionVisible: document.body.innerText.includes('V1.9.1') || document.body.innerText.includes('UI Mockup'),
        };
    });
    assert.ok(geometry.bodyOverflow <= 1, `${name}: horizontal overflow ${geometry.bodyOverflow}px`);
    assert.ok(geometry.sidebarOverflow <= 1, `${name}: sidebar overflow ${geometry.sidebarOverflow}px`);
    assert.equal(geometry.kpiCount, 4, `${name}: KPI count`);
    assert.equal(geometry.versionVisible, false, `${name}: hidden version label`);
    assert.deepEqual(errors, [], `${name}: console errors`);

    const target = join(process.env.TEMP, `governance-${name}.png`);
    await page.screenshot({ path: target, fullPage: true });
    screenshots.push(target);

    if (name === 'desktop') {
        await page.locator('.sidebar__nav [data-view="assets"]').click();
        await page.getByRole('heading', { name: '文档审阅', exact: true }).waitFor();
        await page.locator('tr[data-open-asset="106"]').click();
        await page.locator('#detail-drawer.is-open').waitFor();
        assert.equal(await page.locator('#detail-drawer').getAttribute('aria-hidden'), 'false');
        await page.locator('[data-action="close-drawer"]').click();

        for (const [view, title] of [
            ['contributions', '人员贡献'],
            ['quality', '质量问题'],
            ['rag', 'RAG 状态'],
            ['gaps', '知识缺口'],
            ['reports', '报告生成'],
        ]) {
            await page.locator(`.sidebar__nav [data-view="${view}"]`).click();
            await page.getByRole('heading', { name: title, exact: true }).waitFor();
        }
        await page.locator('#report-form button[type="submit"]').click({ force: true });
        await page.locator('#report-markdown').waitFor();
        assert.match(await page.locator('#report-markdown').innerText(), /## RAG 健康/);
    }
    await page.close();
}

try {
    await inspect({ width: 1440, height: 960 }, 'desktop');
    await inspect({ width: 390, height: 844 }, 'mobile');
    console.log(JSON.stringify({ ok: true, screenshots }));
} finally {
    await browser.close();
}

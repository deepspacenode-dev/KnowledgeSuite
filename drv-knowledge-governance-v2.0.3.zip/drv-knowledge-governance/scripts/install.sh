#!/bin/sh

set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PACKAGE_ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
OVERLAY="$PACKAGE_ROOT/bookstack-overlay"
BOOKSTACK_ROOT=${1:-/app/www}
SKIP_MIGRATE=${SKIP_MIGRATE:-false}

if [ ! -f "$BOOKSTACK_ROOT/artisan" ] || [ ! -f "$BOOKSTACK_ROOT/app/Config/app.php" ]; then
    printf '%s\n' "Unsupported BookStack root: $BOOKSTACK_ROOT" >&2
    exit 2
fi
BOOKSTACK_ROOT=$(CDPATH= cd -- "$BOOKSTACK_ROOT" && pwd)
BACKUP_ROOT=${BACKUP_ROOT:-"$PACKAGE_ROOT/backups/install-$(date +%Y%m%d-%H%M%S)"}
mkdir -p "$BACKUP_ROOT"

backup_target() {
    relative=$1
    source="$BOOKSTACK_ROOT/$relative"
    [ -e "$source" ] || return 0
    destination="$BACKUP_ROOT/$relative"
    mkdir -p "$(dirname -- "$destination")"
    cp -a "$source" "$destination"
}

copy_directory() {
    relative=$1
    backup_target "$relative"
    mkdir -p "$BOOKSTACK_ROOT/$relative"
    cp -a "$OVERLAY/$relative/." "$BOOKSTACK_ROOT/$relative/"
}

copy_file() {
    relative=$1
    backup_target "$relative"
    mkdir -p "$(dirname -- "$BOOKSTACK_ROOT/$relative")"
    cp -a "$OVERLAY/$relative" "$BOOKSTACK_ROOT/$relative"
}

backup_target app/Config/app.php
copy_directory app/AI/Governance
copy_directory public/ai-governance
copy_file routes/ai-governance.php
copy_file routes/ai-governance-page.php
copy_file public/ai-assistant/ai-assistant-governance-entry.js
copy_file public/ai-assistant/ai-assistant-governance-entry.css
copy_file public/ai-assistant/grokbot-avatar.js
copy_directory public/ai-assistant/vendor/grokbot
copy_directory public/ai-assistant/vendor/bloub

for migration in "$OVERLAY"/database/migrations/*.php; do
    name=$(basename -- "$migration")
    backup_target "database/migrations/$name"
    cp -a "$migration" "$BOOKSTACK_ROOT/database/migrations/$name"
done

START_MARKER='/* DRVDOCS_AI_GOVERNANCE_START */'
CONFIG_FILE="$BOOKSTACK_ROOT/app/Config/app.php"
if ! grep -Fq "$START_MARKER" "$CONFIG_FILE"; then
    awk '
        { print }
        /BookStack.*RouteServiceProvider::class,/ {
            print "        /* DRVDOCS_AI_GOVERNANCE_START */"
            print "        BookStack\\AI\\Governance\\Providers\\AiGovernanceServiceProvider::class,"
            print "        /* DRVDOCS_AI_GOVERNANCE_END */"
        }
    ' "$CONFIG_FILE" > "$BACKUP_ROOT/app.php.registered"
    grep -Fq 'BookStack\AI\Governance\Providers\AiGovernanceServiceProvider::class' "$BACKUP_ROOT/app.php.registered"
    cp "$BACKUP_ROOT/app.php.registered" "$CONFIG_FILE"
fi

if [ "$SKIP_MIGRATE" != "true" ]; then
    cd "$BOOKSTACK_ROOT"
    php artisan migrate --force
    php artisan optimize:clear
fi

printf '%s\n' "Governance install complete. Backup: $BACKUP_ROOT"
printf '%s\n' 'Governance entry assets are injected automatically on authenticated BookStack pages.'

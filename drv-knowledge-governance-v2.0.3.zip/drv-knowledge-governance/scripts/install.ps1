[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory = $true)]
    [string] $BookStackRoot,
    [string] $BackupRoot,
    [switch] $SkipMigrate
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$packageRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$overlayRoot = Join-Path $packageRoot 'bookstack-overlay'
$targetRoot = (Resolve-Path -LiteralPath $BookStackRoot).Path

foreach ($required in @('artisan', 'app\Config\app.php', 'bootstrap\app.php')) {
    if (-not (Test-Path -LiteralPath (Join-Path $targetRoot $required))) {
        throw "Unsupported BookStack root; missing $required"
    }
}

if ([string]::IsNullOrWhiteSpace($BackupRoot)) {
    $BackupRoot = Join-Path $packageRoot ('backups\install-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
}
$backupPath = [System.IO.Path]::GetFullPath($BackupRoot)
$configFile = Join-Path $targetRoot 'app\Config\app.php'
$startMarker = '/* DRVDOCS_AI_GOVERNANCE_START */'
$endMarker = '/* DRVDOCS_AI_GOVERNANCE_END */'

function Backup-Target([string] $RelativePath) {
    $source = Join-Path $targetRoot $RelativePath
    if (-not (Test-Path -LiteralPath $source)) { return }
    $destination = Join-Path $backupPath $RelativePath
    if ($PSCmdlet.ShouldProcess($destination, 'Backup existing BookStack file')) {
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -Recurse -Force
    }
}

$copies = @(
    @{ Source = 'app\AI\Governance'; Target = 'app\AI\Governance' },
    @{ Source = 'routes\ai-governance.php'; Target = 'routes\ai-governance.php' },
    @{ Source = 'routes\ai-governance-page.php'; Target = 'routes\ai-governance-page.php' },
    @{ Source = 'public\ai-governance'; Target = 'public\ai-governance' },
    @{ Source = 'public\ai-assistant\ai-assistant-governance-entry.js'; Target = 'public\ai-assistant\ai-assistant-governance-entry.js' },
    @{ Source = 'public\ai-assistant\ai-assistant-governance-entry.css'; Target = 'public\ai-assistant\ai-assistant-governance-entry.css' },
    @{ Source = 'public\ai-assistant\grokbot-avatar.js'; Target = 'public\ai-assistant\grokbot-avatar.js' },
    @{ Source = 'public\ai-assistant\vendor\grokbot'; Target = 'public\ai-assistant\vendor\grokbot' },
    @{ Source = 'public\ai-assistant\vendor\bloub'; Target = 'public\ai-assistant\vendor\bloub' }
)

Backup-Target 'app\Config\app.php'
foreach ($copy in $copies) {
    Backup-Target $copy.Target
    $source = Join-Path $overlayRoot $copy.Source
    $target = Join-Path $targetRoot $copy.Target
    if ($PSCmdlet.ShouldProcess($target, 'Install governance overlay')) {
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $source -Destination $target -Recurse -Force
    }
}

$migrationNames = @()
Get-ChildItem -LiteralPath (Join-Path $overlayRoot 'database\migrations') -File | ForEach-Object {
    $migrationNames += $_.Name
    $relative = Join-Path 'database\migrations' $_.Name
    Backup-Target $relative
    $target = Join-Path $targetRoot $relative
    if ($PSCmdlet.ShouldProcess($target, 'Install governance migration')) {
        Copy-Item -LiteralPath $_.FullName -Destination $target -Force
    }
}

$configContent = Get-Content -LiteralPath $configFile -Raw
if (-not $configContent.Contains($startMarker)) {
    $providerAnchor = '        BookStack\App\Providers\RouteServiceProvider::class,'
    if (-not $configContent.Contains($providerAnchor)) {
        throw 'BookStack provider registration anchor was not found.'
    }
    $integration = @"
$providerAnchor
$startMarker
        BookStack\AI\Governance\Providers\AiGovernanceServiceProvider::class,
$endMarker
"@
    if ($PSCmdlet.ShouldProcess($configFile, 'Register governance service provider')) {
        $configContent.Replace($providerAnchor, $integration) | Set-Content -LiteralPath $configFile -Encoding UTF8
    }
}

if (-not $SkipMigrate -and -not $WhatIfPreference) {
    Push-Location $targetRoot
    try {
        & php artisan migrate --force
        if ($LASTEXITCODE -ne 0) { throw 'BookStack migration failed.' }
        & php artisan optimize:clear
    } finally {
        Pop-Location
    }
}

if (-not $WhatIfPreference) {
    New-Item -ItemType Directory -Force -Path $backupPath | Out-Null
    @{
        installed_at = (Get-Date).ToString('o')
        bookstack_root = $targetRoot
        backup_root = $backupPath
        migrations = $migrationNames
    } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $backupPath 'install-manifest.json') -Encoding UTF8
}

Write-Output "Governance install complete. Backup: $backupPath"
Write-Output 'Governance entry assets are injected automatically on authenticated BookStack pages.'

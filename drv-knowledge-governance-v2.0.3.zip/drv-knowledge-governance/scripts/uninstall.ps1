[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory = $true)]
    [string] $BookStackRoot,
    [string] $BackupRoot
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$targetRoot = (Resolve-Path -LiteralPath $BookStackRoot).Path
$configFile = Join-Path $targetRoot 'app\Config\app.php'
if (-not (Test-Path -LiteralPath $configFile)) { throw 'BookStack app/Config/app.php is unavailable.' }
if ([string]::IsNullOrWhiteSpace($BackupRoot)) {
    $BackupRoot = Join-Path $PSScriptRoot ('..\backups\uninstall-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
}
$backupPath = [System.IO.Path]::GetFullPath($BackupRoot)

function Assert-InBookStack([string] $Path) {
    $full = [System.IO.Path]::GetFullPath($Path)
    if (-not $full.StartsWith($targetRoot + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing path outside BookStack root: $full"
    }
    return $full
}

if ($PSCmdlet.ShouldProcess($configFile, 'Backup and unregister governance service provider')) {
    New-Item -ItemType Directory -Force -Path $backupPath | Out-Null
    Copy-Item -LiteralPath $configFile -Destination (Join-Path $backupPath 'app.php') -Force
    $content = Get-Content -LiteralPath $configFile -Raw
    $pattern = '(?s)\s*/\* DRVDOCS_AI_GOVERNANCE_START \*/.*?/\* DRVDOCS_AI_GOVERNANCE_END \*/\s*'
    [regex]::Replace($content, $pattern, "`r`n") | Set-Content -LiteralPath $configFile -Encoding UTF8
}

$ownedPaths = @(
    'app\AI\Governance',
    'routes\ai-governance.php',
    'routes\ai-governance-page.php',
    'public\ai-governance',
    'public\ai-assistant\ai-assistant-governance-entry.js',
    'public\ai-assistant\ai-assistant-governance-entry.css',
    'public\ai-assistant\grokbot-avatar.js',
    'public\ai-assistant\vendor\grokbot',
    'public\ai-assistant\vendor\bloub'
)
$ownedPaths += Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot '..\bookstack-overlay\database\migrations') -File | ForEach-Object { 'database\migrations\' + $_.Name }
foreach ($relative in $ownedPaths) {
    $target = Assert-InBookStack (Join-Path $targetRoot $relative)
    if ((Test-Path -LiteralPath $target) -and $PSCmdlet.ShouldProcess($target, 'Remove governance-owned file')) {
        Remove-Item -LiteralPath $target -Recurse -Force
    }
}

Write-Output 'Governance files removed. drv_kb_* tables and data were intentionally preserved.'
Write-Output "Provider configuration backup: $backupPath"

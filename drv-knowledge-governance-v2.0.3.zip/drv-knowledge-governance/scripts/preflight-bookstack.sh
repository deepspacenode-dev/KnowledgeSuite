#!/bin/sh

set -u

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
MANIFEST_PATH="$SCRIPT_DIR/../compat/supported-bookstack.json"
CONTAINER=${1:-}
REPORT_PATH=${2:-"$SCRIPT_DIR/../preflight-report.json"}
ENGINE=${3:-}

write_fallback_report() {
    reason=$1
    printf '%s\n' "{\"schema_version\":1,\"status\":\"unsupported\",\"supported\":false,\"errors\":[\"$reason\"],\"redaction\":{\"environment_values\":\"not_collected\",\"secrets\":\"not_collected\"}}" > "$REPORT_PATH"
}

if [ -z "$CONTAINER" ]; then
    write_fallback_report "CONTAINER_ARGUMENT_REQUIRED"
    printf '%s\n' "BookStack preflight: FAIL"
    printf '%s\n' "Report: $REPORT_PATH"
    exit 2
fi

case "$CONTAINER" in
    *[!A-Za-z0-9_.-]*)
        write_fallback_report "INVALID_CONTAINER_IDENTIFIER"
        printf '%s\n' "BookStack preflight: FAIL"
        printf '%s\n' "Report: $REPORT_PATH"
        exit 2
        ;;
esac

if [ -z "$ENGINE" ]; then
    if command -v docker >/dev/null 2>&1; then
        ENGINE=docker
    elif command -v podman >/dev/null 2>&1; then
        ENGINE=podman
    else
        write_fallback_report "CONTAINER_ENGINE_UNAVAILABLE"
        printf '%s\n' "BookStack preflight: FAIL"
        printf '%s\n' "Report: $REPORT_PATH"
        exit 2
    fi
fi

case "$ENGINE" in
    docker|podman) ;;
    *)
        write_fallback_report "UNSUPPORTED_CONTAINER_ENGINE"
        printf '%s\n' "BookStack preflight: FAIL"
        printf '%s\n' "Report: $REPORT_PATH"
        exit 2
        ;;
esac

if [ ! -r "$MANIFEST_PATH" ]; then
    write_fallback_report "COMPATIBILITY_MANIFEST_UNREADABLE"
    printf '%s\n' "BookStack preflight: FAIL"
    printf '%s\n' "Report: $REPORT_PATH"
    exit 2
fi

if ! "$ENGINE" inspect "$CONTAINER" >/dev/null 2>&1; then
    write_fallback_report "TARGET_CONTAINER_UNAVAILABLE"
    printf '%s\n' "BookStack preflight: FAIL"
    printf '%s\n' "Report: $REPORT_PATH"
    exit 2
fi

PHP_PROBE=$(cat <<'PHP'
$manifest = json_decode(stream_get_contents(STDIN), true, 512, JSON_THROW_ON_ERROR);

$allows = static function (string $version, string $constraint): bool {
    $version = ltrim(trim($version), "vV");
    foreach (preg_split('/\s+/', trim($constraint)) as $term) {
        if (!preg_match('/^(>=|<=|>|<|=)?(.+)$/', $term, $match)) {
            return false;
        }
        $operator = $match[1] !== '' ? $match[1] : '=';
        if (!version_compare($version, ltrim($match[2], "vV"), $operator)) {
            return false;
        }
    }
    return true;
};

$root = null;
foreach ($manifest['target_roots'] as $candidate) {
    if (is_file($candidate . '/artisan') && is_file($candidate . '/composer.lock')) {
        $root = $candidate;
        break;
    }
}

$report = [
    'schema_version' => 1,
    'inspected_at' => gmdate(DATE_ATOM),
    'inspection_mode' => 'read_only',
    'root' => $root,
    'php' => ['version' => PHP_VERSION, 'constraint' => $manifest['php'], 'supported' => false],
    'bookstack' => ['version' => null, 'constraint' => $manifest['bookstack']['constraint'], 'supported' => false],
    'laravel' => ['version' => null, 'constraint' => $manifest['laravel']['constraint'], 'supported' => false],
    'required_paths' => [],
    'target_path_probes' => [],
    'provider_registration' => ['supported' => false, 'strategy' => null],
    'rollback' => [
        'requires_backup' => $manifest['requires_backup'] === true,
        'supports_uninstall' => $manifest['supports_uninstall'] === true,
        'requirements' => $manifest['rollback'],
    ],
    'errors' => [],
    'redaction' => ['environment_values' => 'not_collected', 'secrets' => 'not_collected'],
];

$report['php']['supported'] = $allows(PHP_VERSION, $manifest['php']);
if (!$report['php']['supported']) {
    $report['errors'][] = 'PHP_VERSION_UNSUPPORTED';
}

if ($root === null) {
    $report['errors'][] = 'BOOKSTACK_ROOT_NOT_DETECTED';
} else {
    $versionPath = $root . '/' . $manifest['bookstack']['version_file'];
    if (is_readable($versionPath)) {
        $bookstackVersion = trim((string) file_get_contents($versionPath));
        $report['bookstack']['version'] = $bookstackVersion;
        $report['bookstack']['supported'] = $allows($bookstackVersion, $manifest['bookstack']['constraint']);
    }
    if (!$report['bookstack']['supported']) {
        $report['errors'][] = 'BOOKSTACK_VERSION_UNSUPPORTED';
    }

    $lock = json_decode((string) file_get_contents($root . '/composer.lock'), true, 512, JSON_THROW_ON_ERROR);
    foreach (array_merge($lock['packages'] ?? [], $lock['packages-dev'] ?? []) as $package) {
        if (($package['name'] ?? null) === $manifest['laravel']['composer_package']) {
            $report['laravel']['version'] = $package['version'] ?? null;
            break;
        }
    }
    if (is_string($report['laravel']['version'])) {
        $report['laravel']['supported'] = $allows($report['laravel']['version'], $manifest['laravel']['constraint']);
    }
    if (!$report['laravel']['supported']) {
        $report['errors'][] = 'LARAVEL_VERSION_UNSUPPORTED';
    }

    foreach ($manifest['required_paths'] as $relativePath) {
        $present = file_exists($root . '/' . $relativePath);
        $report['required_paths'][] = ['path' => $relativePath, 'present' => $present];
        if (!$present) {
            $report['errors'][] = 'REQUIRED_PATH_MISSING:' . $relativePath;
        }
    }

    foreach ($manifest['target_path_probes'] as $probe) {
        $path = $root . '/' . $probe['path'];
        $typeOk = $probe['type'] === 'directory' ? is_dir($path) : is_file($path);
        $accessOk = $probe['access'] === 'writable' ? is_writable($path) : is_readable($path);
        $passed = $typeOk && $accessOk;
        $report['target_path_probes'][] = [
            'path' => $probe['path'],
            'type' => $probe['type'],
            'access' => $probe['access'],
            'passed' => $passed,
        ];
        if (!$passed) {
            $report['errors'][] = 'TARGET_PATH_PROBE_FAILED:' . $probe['path'];
        }
    }

    foreach ($manifest['provider_registration']['strategies'] as $strategy) {
        $content = '';
        $pathsPresent = true;
        foreach ($strategy['required_paths'] as $relativePath) {
            $path = $root . '/' . $relativePath;
            if (!is_readable($path)) {
                $pathsPresent = false;
                break;
            }
            $content .= "\n" . file_get_contents($path);
        }
        $patternsPresent = $pathsPresent;
        foreach ($strategy['probe']['patterns'] as $pattern) {
            if (!str_contains($content, $pattern)) {
                $patternsPresent = false;
                break;
            }
        }
        if ($patternsPresent) {
            $report['provider_registration'] = ['supported' => true, 'strategy' => $strategy['id']];
            break;
        }
    }
    if (!$report['provider_registration']['supported']) {
        $report['errors'][] = 'PROVIDER_REGISTRATION_STRUCTURE_UNSUPPORTED';
    }
}

$report['supported'] = $report['errors'] === [];
$report['status'] = $report['supported'] ? 'supported' : 'unsupported';
echo json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), "\n";
exit($report['supported'] ? 0 : 1);
PHP
)

set +e
REPORT_JSON=$("$ENGINE" exec -i "$CONTAINER" php -r "$PHP_PROBE" < "$MANIFEST_PATH" 2>/dev/null)
PROBE_STATUS=$?
set -e

if [ -z "$REPORT_JSON" ]; then
    write_fallback_report "READ_ONLY_PROBE_FAILED"
    PROBE_STATUS=2
else
    printf '%s\n' "$REPORT_JSON" > "$REPORT_PATH"
fi

if [ "$PROBE_STATUS" -eq 0 ]; then
    printf '%s\n' "BookStack preflight: PASS"
else
    printf '%s\n' "BookStack preflight: FAIL"
fi
printf '%s\n' "Report: $REPORT_PATH"
exit "$PROBE_STATUS"

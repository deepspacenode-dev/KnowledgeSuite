[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path -LiteralPath $_ -PathType Leaf })]
    [string] $RagFlowOpenApiPath,

    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path -LiteralPath $_ -PathType Container })]
    [string] $DrvAgentRoot,

    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path -LiteralPath $_ -PathType Leaf })]
    [string] $DatabaseGrantEvidencePath,

    [string] $OutputPath = (Join-Path $PSScriptRoot '..\preflight-integrations-report.json')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-OpenApiOperationEvidence {
    param(
        [Parameter(Mandatory = $true)] [object] $Specification,
        [Parameter(Mandatory = $true)] [string[]] $Methods
    )

    $evidence = [System.Collections.Generic.List[object]]::new()
    foreach ($pathProperty in $Specification.paths.PSObject.Properties) {
        if ($pathProperty.Name -notmatch '(?i)documents?') {
            continue
        }

        foreach ($method in $Methods) {
            if ($pathProperty.Value.PSObject.Properties.Name -contains $method) {
                $evidence.Add([ordered]@{ method = $method.ToUpperInvariant(); path = $pathProperty.Name })
            }
        }
    }
    return @($evidence)
}

$openApi = Get-Content -Raw -LiteralPath $RagFlowOpenApiPath | ConvertFrom-Json
$replaceEvidence = @(Get-OpenApiOperationEvidence -Specification $openApi -Methods @('put', 'patch'))
$deleteEvidence = @(Get-OpenApiOperationEvidence -Specification $openApi -Methods @('delete'))
$uploadEvidence = @(Get-OpenApiOperationEvidence -Specification $openApi -Methods @('post'))

$sourceExtensions = @('*.php', '*.py', '*.ps1', '*.js', '*.ts', '*.json')
$resolvedDrvAgentRoot = (Resolve-Path -LiteralPath $DrvAgentRoot).Path
$sourceFiles = Get-ChildItem -LiteralPath $DrvAgentRoot -Recurse -File -Include $sourceExtensions |
    Where-Object { $_.FullName -notmatch '[\\/](\.git|vendor|node_modules|cache|logs?)[\\/]' }

$drvEvidence = [System.Collections.Generic.List[object]]::new()
$patterns = [ordered]@{
    task_claim = '(?i)(tasks?[/\\](next|claim)|claim.{0,30}task|worker.{0,30}task)'
    heartbeat = '(?i)(tasks?[/\\].{0,80}heartbeat|heartbeat.{0,30}task)'
    task_result = '(?i)(tasks?[/\\].{0,80}result|task[_-]?result)'
    knowledge_bundle = '(?i)knowledge[_-]?bundle'
}

foreach ($sourceFile in $sourceFiles) {
    $content = Get-Content -Raw -LiteralPath $sourceFile.FullName -ErrorAction SilentlyContinue
    if ($null -eq $content) {
        continue
    }

    foreach ($category in $patterns.Keys) {
        if ($content -match $patterns[$category]) {
            $relativePath = $sourceFile.FullName.Substring($resolvedDrvAgentRoot.Length).TrimStart(
                [IO.Path]::DirectorySeparatorChar,
                [IO.Path]::AltDirectorySeparatorChar
            )
            $drvEvidence.Add([ordered]@{ capability = $category; relative_path = $relativePath })
        }
    }
}

$grantText = Get-Content -Raw -LiteralPath $DatabaseGrantEvidencePath
$hasCreateGrant = $false
foreach ($grantLine in ($grantText -split "`r?`n")) {
    if ($grantLine -notmatch '(?i)^\s*GRANT\s+(?<privileges>.+?)\s+ON\s+') {
        continue
    }
    $privileges = @($Matches['privileges'] -split ',' | ForEach-Object { $_.Trim().ToUpperInvariant() })
    if ($privileges -contains 'CREATE' -or $privileges -contains 'ALL PRIVILEGES') {
        $hasCreateGrant = $true
        break
    }
}

$drvCapabilities = @($drvEvidence | ForEach-Object { $_['capability'] } | Select-Object -Unique)
$hasWorkerPath = $drvCapabilities -contains 'task_claim'
$hasResultPath = ($drvCapabilities -contains 'task_result') -or ($drvCapabilities -contains 'knowledge_bundle')
$hasReplaceStrategy = $replaceEvidence.Count -gt 0 -or ($deleteEvidence.Count -gt 0 -and $uploadEvidence.Count -gt 0)

$report = [ordered]@{
    schema_version = 1
    inspected_at = [DateTime]::UtcNow.ToString('o')
    inspection_mode = 'read_only'
    ragflow = [ordered]@{
        document_replace = [ordered]@{ supported = $replaceEvidence.Count -gt 0; evidence = $replaceEvidence }
        document_delete = [ordered]@{ supported = $deleteEvidence.Count -gt 0; evidence = $deleteEvidence }
        document_upload = [ordered]@{ supported = $uploadEvidence.Count -gt 0; evidence = $uploadEvidence }
        replacement_strategy = if ($replaceEvidence.Count -gt 0) { 'in_place' } elseif ($deleteEvidence.Count -gt 0 -and $uploadEvidence.Count -gt 0) { 'delete_then_upload' } else { 'unsupported' }
    }
    drvagent = [ordered]@{
        worker_path_supported = $hasWorkerPath
        result_path_supported = $hasResultPath
        evidence = @($drvEvidence)
    }
    database = [ordered]@{
        create_table_grant = $hasCreateGrant
        evidence_kind = 'show_grants_redacted_summary'
    }
    redaction = [ordered]@{
        input_contents = 'not_recorded'
        secrets = 'not_collected'
    }
}
$report.supported = $hasReplaceStrategy -and $hasWorkerPath -and $hasResultPath -and $hasCreateGrant
$report.status = if ($report.supported) { 'supported' } else { 'unsupported' }

$report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
Write-Output "Integration preflight: $($report.status.ToUpperInvariant())"
Write-Output "Report: $OutputPath"

if (-not $report.supported) {
    exit 1
}

<?php

declare(strict_types=1);

use Illuminate\Contracts\Console\Kernel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "CLI only.\n");
    exit(2);
}

$argument = static function (string $name, ?string $default = null) use ($argv): ?string {
    $prefix = '--' . $name . '=';
    foreach ($argv as $value) {
        if (str_starts_with($value, $prefix)) {
            return substr($value, strlen($prefix));
        }
    }
    return $default;
};
$apply = in_array('--apply', $argv, true);
$bookStackRoot = rtrim((string) $argument('bookstack-root', '/app/www'), '/\\');
$dataDir = rtrim((string) $argument('data-dir', $bookStackRoot . '/public/data'), '/\\');
$actorId = (int) $argument('actor-id', '0');
if ($apply && $actorId < 1) {
    fwrite(STDERR, "--actor-id is required with --apply.\n");
    exit(2);
}

$autoload = $bookStackRoot . '/vendor/autoload.php';
$bootstrap = $bookStackRoot . '/bootstrap/app.php';
if (!is_file($autoload) || !is_file($bootstrap)) {
    fwrite(STDERR, "Unsupported BookStack root.\n");
    exit(2);
}
require $autoload;
$app = require $bootstrap;
$app->make(Kernel::class)->bootstrap();

$load = static function (string $filename) use ($dataDir): array {
    $path = $dataDir . '/' . $filename;
    if (!is_file($path)) {
        return [];
    }
    return json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
};

$reviews = $load('doc_review_index.json')['reviews'] ?? [];
$quality = $load('quality_check_index.json')['quality'] ?? [];
$gaps = $load('knowledge_gap_index.json')['gaps'] ?? [];
$reports = $load('governance_report_history.json')['reports'] ?? [];
$summary = [
    'mode' => $apply ? 'apply' : 'dry-run',
    'legacy_reviews' => count($reviews),
    'legacy_quality' => count($quality),
    'gaps' => count($gaps),
    'reports' => count($reports),
    'written' => ['audit' => 0, 'gaps' => 0, 'reports' => 0],
];

if (!$apply) {
    echo json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), "\n";
    exit(0);
}

DB::transaction(function () use ($reviews, $quality, $gaps, $reports, $actorId, &$summary): void {
    $appendLegacyAudit = static function (string $eventType, string $sourceKey, array $metadata) use ($actorId, &$summary): void {
        $exists = DB::table('drv_kb_audit_events')
            ->where('event_type', $eventType)
            ->where('object_id', $sourceKey)
            ->exists();
        if ($exists) {
            return;
        }
        DB::table('drv_kb_audit_events')->insert([
            'trace_id' => (string) Str::uuid(),
            'event_type' => $eventType,
            'object_type' => 'legacy_source',
            'object_id' => $sourceKey,
            'actor_id' => $actorId,
            'before_digest' => null,
            'after_digest' => hash('sha256', json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)),
            'metadata_json' => json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'dispatch_status' => 'archived',
            'created_at' => now(),
        ]);
        $summary['written']['audit']++;
    };

    foreach ($reviews as $sourceKey => $review) {
        // Legacy raw-page reviews remain evidence only; they never become formal Wiki gate state.
        $appendLegacyAudit('legacy.review.imported', (string) $sourceKey, (array) $review);
    }
    foreach ($quality as $sourceKey => $check) {
        $appendLegacyAudit('legacy.quality.imported', (string) $sourceKey, (array) $check);
    }
    foreach ($gaps as $gap) {
        $title = trim((string) ($gap['title'] ?? ''));
        if ($title === '' || DB::table('drv_kb_gaps')->where('title', $title)->exists()) {
            continue;
        }
        $related = null;
        if (!empty($gap['source_key'])) {
            $related = DB::table('drv_kb_assets')->where('source_key', $gap['source_key'])->value('asset_id');
        }
        $status = in_array(($gap['status'] ?? ''), ['open', 'doing', 'closed'], true) ? $gap['status'] : 'open';
        DB::table('drv_kb_gaps')->insert([
            'related_asset_id' => $related,
            'title' => $title,
            'missing_content' => (string) ($gap['description'] ?? $gap['suggested_material'] ?? 'Legacy knowledge gap'),
            'impact' => (string) ($gap['suggested_material'] ?? ''),
            'priority' => in_array(($gap['priority'] ?? ''), ['low', 'medium', 'high', 'critical'], true) ? $gap['priority'] : 'medium',
            'owner_id' => null,
            'gap_status' => $status,
            'due_at' => null,
            'closed_at' => $gap['closed_at'] ?? null,
            'created_by' => $actorId,
            'created_at' => $gap['created_at'] ?? now(),
            'updated_at' => now(),
        ]);
        $summary['written']['gaps']++;
    }
    foreach ($reports as $report) {
        $markdown = (string) ($report['markdown'] ?? '');
        if ($markdown === '') {
            continue;
        }
        $hash = hash('sha256', $markdown);
        if (DB::table('drv_kb_reports')->where('markdown_hash', $hash)->exists()) {
            continue;
        }
        $generatedAt = (string) ($report['generated_at'] ?? now()->toAtomString());
        $date = substr($generatedAt, 0, 10);
        $reportType = ($report['report_type'] ?? '') === 'monthly' ? '月报' : '周报';
        DB::table('drv_kb_reports')->insert([
            'report_type' => $reportType,
            'period_start' => $date,
            'period_end' => $date,
            'filters_json' => json_encode(['source' => 'legacy_json']),
            'metrics_json' => json_encode($report['summary'] ?? [], JSON_UNESCAPED_UNICODE),
            'markdown' => $markdown,
            'markdown_hash' => $hash,
            'generated_by' => $actorId,
            'generated_at' => $generatedAt,
        ]);
        $summary['written']['reports']++;
    }
});

echo json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), "\n";

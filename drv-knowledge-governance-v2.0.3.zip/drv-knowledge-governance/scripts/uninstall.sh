#!/bin/sh

set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PACKAGE_ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
BOOKSTACK_ROOT=${1:-/app/www}
if [ ! -f "$BOOKSTACK_ROOT/artisan" ] || [ ! -f "$BOOKSTACK_ROOT/app/Config/app.php" ]; then
    printf '%s\n' "Unsupported BookStack root: $BOOKSTACK_ROOT" >&2
    exit 2
fi
BOOKSTACK_ROOT=$(CDPATH= cd -- "$BOOKSTACK_ROOT" && pwd)
case "$BOOKSTACK_ROOT" in
    /|/app|/var|/var/www) printf '%s\n' 'Refusing unsafe BookStack root.' >&2; exit 2 ;;
esac

BACKUP_ROOT=${BACKUP_ROOT:-"$PACKAGE_ROOT/backups/uninstall-$(date +%Y%m%d-%H%M%S)"}
mkdir -p "$BACKUP_ROOT"
cp -a "$BOOKSTACK_ROOT/app/Config/app.php" "$BACKUP_ROOT/app.php"

awk '
    /\/\* DRVDOCS_AI_GOVERNANCE_START \*\// { skip=1; next }
    /\/\* DRVDOCS_AI_GOVERNANCE_END \*\// { skip=0; next }
    !skip { print }
' "$BOOKSTACK_ROOT/app/Config/app.php" > "$BACKUP_ROOT/app.php.cleaned"
cp "$BACKUP_ROOT/app.php.cleaned" "$BOOKSTACK_ROOT/app/Config/app.php"

for relative in app/AI/Governance routes/ai-governance.php routes/ai-governance-page.php public/ai-governance public/ai-assistant/ai-assistant-governance-entry.js public/ai-assistant/ai-assistant-governance-entry.css public/ai-assistant/grokbot-avatar.js public/ai-assistant/vendor/grokbot public/ai-assistant/vendor/bloub; do
    target="$BOOKSTACK_ROOT/$relative"
    case "$target" in "$BOOKSTACK_ROOT"/*) rm -rf -- "$target" ;; *) exit 2 ;; esac
done
for migration in "$PACKAGE_ROOT"/bookstack-overlay/database/migrations/*.php; do
    target="$BOOKSTACK_ROOT/database/migrations/$(basename -- "$migration")"
    case "$target" in "$BOOKSTACK_ROOT"/*) rm -f -- "$target" ;; *) exit 2 ;; esac
done

cd "$BOOKSTACK_ROOT"
php artisan optimize:clear
printf '%s\n' 'Governance files removed. drv_kb_* tables and data: PRESERVED.'
printf '%s\n' "Provider configuration backup: $BACKUP_ROOT"

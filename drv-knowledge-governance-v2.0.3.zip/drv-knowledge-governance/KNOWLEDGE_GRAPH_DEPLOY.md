﻿# DrvDocs 鐭ヨ瘑娌荤悊涓績 3D 鐭ヨ瘑鍥捐氨閮ㄧ讲涓庨獙鏀惰鏄?
鏈枃妗ｈˉ鍏?V1.9.1 娌荤悊涓績鐨勨€滅煡璇嗗浘璋扁€濆姛鑳介儴缃层€侀獙璇佷笌鍥炴粴鏂规銆傝鍔熻兘鏄涓€闃舵 MVP锛屽彧灞曠ず纭畾鎬х殑缁撴瀯鍏崇郴锛屼笉寮曞叆鍥炬暟鎹簱銆丩LM 鍏崇郴鎶藉彇銆佹爣绛捐涔夊叧绯绘垨 DrvAgent 浣跨敤鐑害銆?
## 1. 鍔熻兘鑼冨洿

- 鏂板鍚庣鎺ュ彛锛歚GET /api/ai-governance/v1/knowledge-graph`
- 鏂板鍓嶇瑙嗗浘锛歚?view=knowledge-graph`
- 鏂板鏈湴鍥捐氨妯″潡锛歚public/ai-governance/app/knowledge-graph*.js`
- 鏂板鏍峰紡锛歚public/ai-governance/assets/css/knowledge-graph.css`
- 鏂板鏈湴 vendor锛歚public/ai-governance/vendor/3d-force-graph/` 涓?`public/ai-governance/vendor/three/`
- 榛樿鏈€澶у睍绀?300 涓妭鐐癸紝鏀寔涓婇檺绛涢€夈€佹悳绱€佺姸鎬佺瓫閫夈€侀噸缃瑙掋€佹殏鍋滃竷灞€銆佽妭鐐硅鎯呭拰鍙屽嚮璺宠浆銆?
鍥捐氨缁撴瀯锛?
```text
root -> bookshelf -> book -> chapter/page
```

瑙嗚璇箟锛?
```text
鑺傜偣棰滆壊 = 瀹￠槄鐘舵€?鑺傜偣澶栧湀 = RAGFlow 鐘舵€?鑺傜偣澶у皬 = 椤甸潰鏁伴噺鎴栧唴瀹硅妯?杩炵嚎 = contains 缁撴瀯鍏崇郴
```

## 2. 閮ㄧ讲鏂囦欢娓呭崟

澶嶅埗鍒?BookStack 鏍圭洰褰曞悗锛屽簲鍖呭惈浠ヤ笅鏂板鎴栧彉鏇存枃浠讹細

```text
app/AI/Governance/Application/Query/KnowledgeGraphQuery.php
app/AI/Governance/Application/Graph/GraphNodeFactory.php
app/AI/Governance/Application/Graph/GraphLinkFactory.php
app/AI/Governance/Application/Graph/GraphStatusMapper.php
app/AI/Governance/Http/Controllers/V1/KnowledgeGraphController.php
routes/ai-governance.php
public/ai-governance/app/knowledge-graph.js
public/ai-governance/app/knowledge-graph-view.js
public/ai-governance/app/knowledge-graph-controls.js
public/ai-governance/app/knowledge-graph-details.js
public/ai-governance/app/knowledge-graph-theme.js
public/ai-governance/assets/css/knowledge-graph.css
public/ai-governance/vendor/3d-force-graph/3d-force-graph.module.js
public/ai-governance/vendor/3d-force-graph/LICENSE
public/ai-governance/vendor/three/three.module.js
```

## 3. 閮ㄧ讲姝ラ

1. 閮ㄧ讲鍓嶅浠?BookStack 鏁版嵁搴撱€乣.env`銆乣routes/web.php`銆乣public/ai-governance` 鍜?`app/AI/Governance`銆?2. 瑙ｅ帇鏈寘锛岃繘鍏ュ寘鏍圭洰褰曘€?3. Windows 鎸傝浇鐩綍閮ㄧ讲锛?
```powershell
./scripts/install.ps1 -BookStackRoot X:\bookstack -WhatIf
./scripts/install.ps1 -BookStackRoot X:\bookstack -Confirm
```

4. Linux / 瀹瑰櫒鍐呴儴缃诧細

```bash
sh scripts/install.sh /app/www
```

5. 娓呯悊 BookStack 缂撳瓨锛?
```bash
cd /app/www
php artisan optimize:clear
```

濡傛灉鍚敤浜?OPcache 鎴栧鍣ㄧ紦瀛橈紝寤鸿閲嶅惎 BookStack 瀹瑰櫒锛?
```bash
docker restart bookstack
```

## 4. 鏈湴棰勮

鍦ㄥ寘鍐呴潤鎬佺洰褰曞惎鍔ㄦ湇鍔★細

```powershell
cd bookstack-overlay/public/ai-governance
python -m http.server 55212 --bind 127.0.0.1
```

璁块棶锛?
```text
http://127.0.0.1:55212/?view=knowledge-graph&demo=1
```

棰勬湡锛?
- 宸︿晶瀵艰埅鍑虹幇鈥滅煡璇嗗浘璋扁€濄€?- 椤甸潰鍔犺浇娣辫壊 3D 鍥捐氨鐢诲竷銆?- 椤堕儴鍑虹幇鎼滅储銆佸闃呯姸鎬併€丷AG 鐘舵€併€佽川閲忕姸鎬併€佽妭鐐逛笂闄愬拰鈥滄樉绀洪〉闈⑩€濆紑鍏炽€?- 鍙充晶璇︽儏鏍忔樉绀衡€滈€夋嫨鑺傜偣鈥濄€?- demo 鏁版嵁涓嬬粺璁″簲鏄剧ず鑺傜偣銆佸叧绯汇€佸緟娌荤悊銆佸凡楠岃瘉銆佸彲鍙洖銆佸け璐ョ瓑鎸囨爣銆?
## 5. 鐢熶骇楠岃瘉

### 5.1 璺敱楠岃瘉

鍦?BookStack 瀹瑰櫒鍐呮墽琛岋細

```bash
cd /app/www
php artisan route:list | grep ai-governance
```

搴旇兘鐪嬪埌锛?
```text
GET api/ai-governance/v1/knowledge-graph
```

### 5.2 API 楠岃瘉

浣跨敤宸茬櫥褰?BookStack 鐨勬祻瑙堝櫒璁块棶锛?
```text
https://bookstack.example.com/api/ai-governance/v1/knowledge-graph
```

棰勬湡杩斿洖缁熶竴 JSON锛?
```json
{
  "success": true,
  "data": {
    "nodes": [],
    "links": [],
    "stats": {},
    "meta": {}
  }
}
```

閲嶇偣纭锛?
- 鏈櫥褰曡闂細琚?BookStack 鐧诲綍鎬佹嫤鎴€?- 鏅€氱敤鎴峰彧鑳界湅鍒拌嚜宸辨湁鏉冮檺闃呰鐨勯〉闈㈢粨鏋勩€?- 琛ㄧ粨鏋勭己澶辨垨 BookStack 鐗堟湰宸紓涓嶄細瀵艰嚧 500銆?- `limit` 榛樿 300锛岃繃澶у€间細琚檺鍒躲€?- `include_pages=0` 鏃堕粯璁や紭鍏堝睍绀轰功鏋躲€佷功绫嶃€佺珷鑺傝仛鍚堣妭鐐广€?
### 5.3 鍓嶇楠岃瘉

璁块棶锛?
```text
https://bookstack.example.com/ai-governance-dashboard.html?view=knowledge-graph
```

妫€鏌ワ細

- Network 涓?`knowledge-graph.js?v=20260713-radial-a` 杩斿洖 200銆?- Network 涓?`assets/css/knowledge-graph.css?v=20260713-radial-a` 杩斿洖 200銆?- 涓嶅嚭鐜板閮?CDN 璇锋眰銆?- Console 鏃犲惎鍔ㄩ敊璇€?- 鍥捐氨椤甸敊璇笉浼氬奖鍝嶁€滄不鐞嗘€昏鈥濃€滅煡璇嗚祫浜р€濃€淩AG 鐘舵€佲€濃€滄姤鍛婁腑蹇冣€濈瓑椤甸潰銆?- 绂诲紑鍥捐氨椤靛悗鍐嶆杩涘叆锛屽浘璋变粛鑳介噸鏂板姞杞姐€?
## 6. 楠屾敹娓呭崟

- [ ] 娌荤悊涓績鍙甯歌繘鍏ャ€?- [ ] 宸︿晶瀵艰埅鍖呭惈鈥滅煡璇嗗浘璋扁€濄€?- [ ] 鍥捐氨妯″潡浣跨敤 dynamic import锛岄椤靛姞杞芥椂涓嶅姞杞藉浘璋?vendor銆?- [ ] `/knowledge-graph` API 澶嶇敤 BookStack 鐧诲綍鎬佸拰鍙椤甸潰杩囨护銆?- [ ] 鑺傜偣鍖呭惈 `root/bookshelf/book/chapter/page`銆?- [ ] 杩炵嚎鍙寘鍚涓€闃舵缁撴瀯杈?`contains`銆?- [ ] 鑺傜偣棰滆壊鑳藉尯鍒?`pending/partial/approved/verified/rejected/deprecated/unknown`銆?- [ ] RAG 澶栧湀鑳藉尯鍒?`not_ingested/parsing/parsed/failed/stale/unknown`銆?- [ ] 鎼滅储銆佺瓫閫夈€侀噸缃瑙掋€佹殏鍋滃竷灞€銆佺偣鍑昏鎯呫€佸弻鍑昏烦杞彲鐢ㄣ€?- [ ] API 鎴栨覆鏌撳け璐ユ椂鍙樉绀哄浘璋遍〉閿欒锛屼笉瀵艰嚧娌荤悊涓績鐧藉睆銆?- [ ] 鍐呯綉鏂綉鐘舵€佷笅鏃?CDN 渚濊禆閿欒銆?- [ ] Node 鍚堢害娴嬭瘯閫氳繃銆?
## 7. 鍥炴粴鏂规

鍥捐氨鍔熻兘鍙嫭绔嬪洖婊氾紝涓嶉渶瑕佸垹闄ゆ不鐞嗕腑蹇冨熀纭€鑳藉姏锛?
1. 浠庡乏渚у鑸Щ闄?`knowledge-graph` 椤广€?2. 浠?`public/ai-governance/app/main.js` 绉婚櫎鍥捐氨鎳掑姞杞藉垎鏀€?3. 浠?`routes/ai-governance.php` 绉婚櫎 `GET knowledge-graph` 璺敱銆?4. 鍒犻櫎浠ヤ笅鏂囦欢锛?
```text
app/AI/Governance/Application/Query/KnowledgeGraphQuery.php
app/AI/Governance/Application/Graph/GraphNodeFactory.php
app/AI/Governance/Application/Graph/GraphLinkFactory.php
app/AI/Governance/Application/Graph/GraphStatusMapper.php
app/AI/Governance/Http/Controllers/V1/KnowledgeGraphController.php
public/ai-governance/app/knowledge-graph*.js
public/ai-governance/assets/css/knowledge-graph.css
public/ai-governance/vendor/3d-force-graph/
public/ai-governance/vendor/three/
```

5. 娓呯悊缂撳瓨锛?
```bash
cd /app/www
php artisan optimize:clear
```

6. 楠岃瘉娌荤悊涓績鍏朵粬椤甸潰浠嶅彲鎵撳紑銆?
涓嶈鍒犻櫎 `drv_kb_*` 鏁版嵁琛紱杩欎簺琛ㄥ睘浜庢不鐞嗕腑蹇冧富閾捐矾锛屼笉鏄浘璋卞姛鑳界殑涓撶敤缂撳瓨銆?
## 8. 宸查獙璇佸懡浠?
鏈湴寮€鍙戜晶宸查獙璇侊細

```text
node --test tests/**/*.mjs
72 tests, 72 pass
```

娴忚鍣ㄤ晶宸查獙璇侊細

```text
http://127.0.0.1:55212/?view=knowledge-graph&demo=1
canvas rendered, stats rendered, detail panel rendered, no console errors
```

褰撳墠 Windows 鐜鏈畨瑁?`php` 鍛戒护锛屽洜姝?PHP `php -l` 闇€瑕佸湪 BookStack 瀹瑰櫒鎴栫洰鏍囨湇鍔″櫒鍐呮墽琛屻€?

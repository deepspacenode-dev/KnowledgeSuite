(function (global, document) {
  'use strict';

  var ROOT_ID = 'drvKnowledgeAssistant';
  var BUTTON_ID = 'aiGovernanceCenterBtn';
  var PANEL_ID = 'drvKnowledgeAssistantPanel';
  var TARGET_PATH = '/ai-governance-dashboard.html';
  var STATUS_API = '/api/ai-governance/v2/status/resolve';
  var ASSISTANT_CONFIG_API = '/api/ai-governance/v2/assistant/config';
  var FEATURES = [
    { key: 'assets', label: '知识审核与入库', note: '查看当前页审核、编译与入库状态', icon: '✓' },
    { key: 'knowledge-graph', label: '知识图谱', note: '查看关系网络与资产状态', icon: '⌘' },
    { key: 'gaps', label: '知识缺口', note: '登记未覆盖内容并持续跟踪', icon: '?' },
    { key: 'reports', label: '日周报', note: '生成治理周报或周期报告', icon: '▤' },
    { key: 'git-backup', label: 'Git 后台备份', note: 'V2.1 Source Hub 规划能力', icon: '↗', disabled: true },
    { key: 'document-conversion', label: '文档转换', note: 'V2.1 多格式转换规划能力', icon: '⇄', disabled: true }
  ];

  function positiveId(value) {
    var id = String(value || '').trim();
    return /^\d+$/.test(id) && Number(id) > 0 ? id : '';
  }

  function canonicalUrl() {
    var canonical = document.querySelector('link[rel="canonical"]');
    return canonical && canonical.href ? canonical.href : global.location.href;
  }

  function currentPageId() {
    var meta = document.querySelector('meta[name="bookstack-page-id"], meta[name="page-id"]');
    var fromMeta = positiveId(meta && meta.content);
    if (fromMeta) return fromMeta;
    var input = document.querySelector('input[name="page_id"], input[name="page-id"]');
    var fromInput = positiveId(input && input.value);
    if (fromInput) return fromInput;
    var selectors = ['main.page-content[data-page-id]', '#page-content[data-page-id]', '.page-content[data-page-id]'];
    for (var index = 0; index < selectors.length; index += 1) {
      var node = document.querySelector(selectors[index]);
      var fromContent = positiveId(node && node.getAttribute('data-page-id'));
      if (fromContent) return fromContent;
    }
    var canonical = canonicalUrl();
    var apiMatch = canonical.match(/\/api\/pages\/(\d+)(?:\/|$|\?)/i);
    return positiveId(apiMatch && apiMatch[1]);
  }

  function featureUrl(feature, pageId) {
    var params = new URLSearchParams();
    params.set('view', feature || 'overview');
    params.set('mode', 'current_page');
    if (positiveId(pageId)) params.set('page_id', positiveId(pageId));
    return TARGET_PATH + '?' + params.toString();
  }

  function assistantConfigUrl() {
    return ASSISTANT_CONFIG_API;
  }

  function normalizeAssistantConfig(payload) {
    var data = payload && payload.data ? payload.data : payload || {};
    var widget = data && data.widget ? data.widget : {};
    var timeout = Number(widget.load_timeout_ms || 12000);
    return {
      schemaVersion: String(data.schema_version || ''),
      enabled: widget.enabled === true,
      src: String(widget.src || ''),
      origin: String(widget.origin || ''),
      allowMedia: widget.allow_media === true,
      loadTimeoutMs: Math.max(3000, Math.min(Number.isFinite(timeout) ? timeout : 12000, 60000)),
      reason: String(widget.reason || ''),
      ragflowWebUrl: String(data.ragflow_web_url || '')
    };
  }

  function isAllowedWidgetConfig(config) {
    if (!config || !config.enabled || !config.src || !config.origin) return false;
    try {
      var candidate = new URL(config.src);
      if (!/^https?:$/.test(candidate.protocol) || candidate.origin !== config.origin) return false;
      if (!/^\/(?:next-)?chats\/widget$/.test(candidate.pathname)) return false;
      if (candidate.searchParams.get('mode') !== 'window') return false;
      if (candidate.searchParams.get('from') !== 'chat') return false;
      return Boolean(candidate.searchParams.get('shared_id') && candidate.searchParams.get('auth'));
    } catch (error) {
      return false;
    }
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
  }

  function actionsMarkup() {
    return FEATURES.map(function (feature) {
      var disabled = feature.disabled ? ' aria-disabled="true" data-disabled="true"' : '';
      var planned = feature.disabled ? '<span class="drv-assistant__planned">规划中</span>' : '<span class="drv-assistant__arrow">›</span>';
      return '<button type="button" class="drv-assistant__action" data-feature="' + feature.key + '"' + disabled + '>' +
        '<span class="drv-assistant__action-icon" aria-hidden="true">' + feature.icon + '</span>' +
        '<span><strong>' + escapeHtml(feature.label) + '</strong><small>' + escapeHtml(feature.note) + '</small></span>' + planned + '</button>';
    }).join('');
  }

  function assistantMarkup(pageId) {
    var context = pageId ? '当前页面 #' + pageId : '全局知识空间';
    return '<button id="' + BUTTON_ID + '" class="ai-governance-floating-entry drv-assistant__trigger" type="button" aria-expanded="false" aria-controls="' + PANEL_ID + '" aria-label="打开知识治理助手">' +
      '<span class="drv-assistant__avatar" data-avatar-host></span><span class="drv-assistant__presence" aria-hidden="true"></span>' +
      '<span class="drv-assistant__sr-only">知识治理助手</span></button>' +
      '<section id="' + PANEL_ID + '" class="drv-assistant__panel" aria-labelledby="drvKnowledgeAssistantTitle" hidden>' +
      '<header class="drv-assistant__header"><div><p>DRV KNOWLEDGE COPILOT</p><h2 id="drvKnowledgeAssistantTitle">知识治理助手</h2></div>' +
      '<button class="drv-assistant__close" type="button" data-assistant-close aria-label="关闭知识治理助手">×</button></header>' +
      '<div class="drv-assistant__context"><span class="drv-assistant__status-dot" aria-hidden="true"></span><div><small>' + escapeHtml(context) + '</small>' +
      '<strong data-assistant-status aria-live="polite">正在读取治理状态</strong><span data-assistant-detail>连接治理中心…</span></div></div>' +
      '<section class="drv-assistant__chat drv-assistant__widget" aria-label="RAGFlow 官方知识问答">' +
      '<div class="drv-assistant__widget-heading"><div><strong>知识库问答</strong><small>RAGFlow 官方组件</small></div><span>可显示原文引用</span></div>' +
      '<div class="drv-assistant__widget-host" data-assistant-widget-host data-widget-state="idle" aria-live="polite">' +
      '<div class="drv-assistant__widget-status" data-assistant-widget-status><span class="drv-assistant__widget-spinner" aria-hidden="true"></span>' +
      '<strong data-assistant-widget-title>准备连接知识库</strong><small data-assistant-widget-detail>首次打开时加载内网 RAGFlow</small>' +
      '<a data-assistant-ragflow-link href="#" target="_blank" rel="noopener noreferrer" hidden>打开 RAGFlow</a></div></div></section>' +
      '<div class="drv-assistant__actions" aria-label="知识治理功能">' + actionsMarkup() + '</div>' +
      '<footer><a href="' + featureUrl('overview', pageId) + '">打开完整治理中心 <span aria-hidden="true">→</span></a>' +
      '<small>聊天由官方 RAGFlow Widget 提供</small></footer></section>';
  }

  function csrfHeaders() {
    var headers = { 'Accept': 'application/json', 'Content-Type': 'application/json' };
    var token = document.querySelector('meta[name="csrf-token"]');
    if (token && token.content) headers['X-CSRF-TOKEN'] = token.content;
    var match = document.cookie && document.cookie.match(/(?:^|;\s*)XSRF-TOKEN=([^;]+)/);
    if (match) headers['X-XSRF-TOKEN'] = decodeURIComponent(match[1]);
    return headers;
  }

  function traceId() {
    if (global.crypto && typeof global.crypto.randomUUID === 'function') return global.crypto.randomUUID();
    return 'drv-avatar-' + Date.now() + '-' + Math.random().toString(16).slice(2);
  }

  function mount() {
    if (!document.body || document.getElementById(ROOT_ID)) return;
    var avatarApi = global.DrvKnowledgeAvatar;
    if (!avatarApi || typeof avatarApi.create !== 'function') return;
    var pageId = currentPageId();
    var root = document.createElement('aside');
    root.id = ROOT_ID;
    root.className = 'drv-assistant';
    root.innerHTML = assistantMarkup(pageId);
    document.body.appendChild(root);

    var trigger = root.querySelector('#' + BUTTON_ID);
    var panel = root.querySelector('#' + PANEL_ID);
    var statusNode = root.querySelector('[data-assistant-status]');
    var detailNode = root.querySelector('[data-assistant-detail]');
    var widgetHost = root.querySelector('[data-assistant-widget-host]');
    var widgetTitle = root.querySelector('[data-assistant-widget-title]');
    var widgetDetail = root.querySelector('[data-assistant-widget-detail]');
    var ragflowLink = root.querySelector('[data-assistant-ragflow-link]');
    var widgetState = 'idle';
    var widgetTimer = null;
    var avatar = avatarApi.create(root.querySelector('[data-avatar-host]'), { initialState: 'waking' });

    function setVisualState(state, label, detail, tone, flash) {
      root.dataset.tone = tone || 'neutral';
      statusNode.textContent = label || avatarApi.stateLabels[state] || '治理状态已更新';
      if (detail) detailNode.textContent = detail;
      if (flash) avatar.flashState(state, 1000); else avatar.setState(state);
    }

    function setWidgetState(state, title, detail) {
      widgetState = state;
      widgetHost.dataset.widgetState = state;
      widgetTitle.textContent = title;
      widgetDetail.textContent = detail;
    }

    function showWidgetError(message, webUrl) {
      if (widgetTimer) global.clearTimeout(widgetTimer);
      setWidgetState('error', '知识助手暂时不可用', message || '请检查 RAGFlow Widget 配置与网络状态。');
      if (/^https?:\/\//i.test(String(webUrl || ''))) {
        ragflowLink.href = webUrl;
        ragflowLink.hidden = false;
      }
      setVisualState('alerting', '知识助手连接失败', '治理功能仍可正常使用', 'danger');
    }

    function mountWidget(config) {
      if (!isAllowedWidgetConfig(config)) {
        showWidgetError(config.reason || 'RAGFlow Widget 返回了不安全或不兼容的配置。', config.ragflowWebUrl);
        return;
      }
      var candidate = new URL(config.src);
      if (candidate.origin !== config.origin || candidate.searchParams.get('mode') !== 'window') {
        showWidgetError('RAGFlow Widget 来源或窗口模式校验失败。', config.ragflowWebUrl);
        return;
      }
      var frame = document.createElement('iframe');
      frame.className = 'drv-assistant__widget-frame';
      frame.title = 'RAGFlow 知识库问答';
      frame.src = candidate.toString();
      frame.frameBorder = '0';
      frame.referrerPolicy = 'no-referrer';
      frame.loading = 'lazy';
      frame.allow = config.allowMedia ? 'microphone; camera' : '';
      frame.addEventListener('load', function () {
        if (widgetTimer) global.clearTimeout(widgetTimer);
        setWidgetState('ready', '知识助手已连接', '回答、引用和会话由 RAGFlow 官方组件提供');
        setVisualState('proud', '知识助手已连接', '可直接提问并查看知识库引用', 'success', true);
      }, { once: true });
      frame.addEventListener('error', function () {
        showWidgetError('浏览器无法加载 RAGFlow Widget，请检查地址、CSP 和 iframe 策略。', config.ragflowWebUrl);
      }, { once: true });
      widgetHost.appendChild(frame);
      widgetTimer = global.setTimeout(function () {
        if (widgetState === 'loading') showWidgetError('RAGFlow Widget 加载超时，请检查内网连通性和浏览器 iframe 策略。', config.ragflowWebUrl);
      }, config.loadTimeoutMs);
    }

    function ensureWidget() {
      if (widgetState !== 'idle') return;
      if (typeof global.fetch !== 'function') {
        showWidgetError('当前浏览器不支持加载官方知识助手。', '');
        return;
      }
      setWidgetState('loading', '正在连接 RAGFlow', '加载官方聊天组件…');
      setVisualState('searching', '正在连接知识助手', 'RAGFlow Widget 正在加载', 'progress');
      global.fetch(assistantConfigUrl(), {
        method: 'GET', credentials: 'same-origin', headers: { 'Accept': 'application/json' }
      }).then(function (response) {
        return response.json().catch(function () { return {}; }).then(function (body) {
          if (!response.ok || body.success === false) throw new Error(body.message || ('HTTP ' + response.status));
          return body;
        });
      }).then(function (payload) {
        var config = normalizeAssistantConfig(payload);
        if (!config.enabled) {
          showWidgetError(config.reason || 'RAGFlow 官方聊天组件尚未启用。', config.ragflowWebUrl);
          return;
        }
        if (/^https?:\/\//i.test(config.ragflowWebUrl)) ragflowLink.href = config.ragflowWebUrl;
        mountWidget(config);
      }).catch(function (error) {
        showWidgetError(error && error.message ? error.message : '读取 RAGFlow Widget 配置失败。', '');
      });
    }

    function setOpen(open) {
      panel.hidden = !open;
      trigger.setAttribute('aria-expanded', String(open));
      root.classList.toggle('drv-assistant--open', open);
      if (open) {
        ensureWidget();
        root.querySelector('[data-assistant-close]').focus();
      }
    }

    trigger.addEventListener('click', function () { setOpen(panel.hidden); });
    root.querySelector('[data-assistant-close]').addEventListener('click', function () { setOpen(false); trigger.focus(); });
    root.addEventListener('click', function (event) {
      var action = event.target.closest && event.target.closest('[data-feature]');
      if (!action) return;
      var feature = action.dataset.feature;
      if (action.dataset.disabled === 'true') {
        setVisualState(avatarApi.stateForFeature(feature, 'ready'), '该能力已纳入 V2.1 规划', action.querySelector('small').textContent, 'neutral', true);
        return;
      }
      avatar.setState(avatarApi.stateForFeature(feature, 'loading'));
      global.location.assign(featureUrl(feature, pageId));
    });
    document.addEventListener('pointerdown', function (event) { if (!panel.hidden && !root.contains(event.target)) setOpen(false); });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && !panel.hidden) { setOpen(false); trigger.focus(); }
    });
    global.addEventListener('drvknowledge:avatar-state', function (event) {
      var detail = event.detail || {};
      var next = detail.state || avatarApi.stateForFeature(detail.feature || 'overview', detail.phase || 'ready');
      setVisualState(next, detail.message, detail.detail, detail.phase === 'error' ? 'danger' : detail.phase === 'success' ? 'success' : 'progress', detail.phase === 'success');
    });

    if (!pageId) {
      setVisualState('idle', '可随时询问知识库', '当前不是 BookStack 文档页面', 'neutral');
      return;
    }
    if (typeof global.fetch !== 'function') {
      setVisualState('suspicious', '治理状态暂不可用', '浏览器缺少 Fetch 支持；不影响当前页面阅读', 'offline');
      return;
    }
    global.fetch(STATUS_API, {
      method: 'POST', credentials: 'same-origin', headers: csrfHeaders(),
      body: JSON.stringify({
        schema_version: 'drvknowledge.status-resolve-request.v2',
        trace_id: traceId(),
        content_refs: ['bookstack:page:' + pageId]
      })
    }).then(function (response) {
      if (!response.ok) throw new Error('HTTP ' + response.status);
      return response.json();
    }).then(function (payload) {
      var data = payload && payload.data ? payload.data : payload;
      var item = data && data.items && data.items[0] ? data.items[0] : null;
      var mapped = avatarApi.mapGovernanceStatus(item);
      var dimensions = item ? '编译 ' + item.compile_status + ' · 审核 ' + item.review_status + ' · RAG ' + item.rag_status : '可从“知识审核与入库”建立治理对象';
      setVisualState(mapped.state, mapped.label, dimensions, mapped.tone);
    }).catch(function () {
      setVisualState('suspicious', '治理状态暂不可用', '不影响阅读；恢复连接后可重新打开页面同步', 'offline');
    });
  }

  global.DrvKnowledgeAssistantEntry = {
    positiveId: positiveId,
    currentPageId: currentPageId,
    featureUrl: featureUrl,
    assistantConfigUrl: assistantConfigUrl,
    normalizeAssistantConfig: normalizeAssistantConfig,
    isAllowedWidgetConfig: isAllowedWidgetConfig,
    mount: mount
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount, { once: true });
  else mount();
})(window, document);

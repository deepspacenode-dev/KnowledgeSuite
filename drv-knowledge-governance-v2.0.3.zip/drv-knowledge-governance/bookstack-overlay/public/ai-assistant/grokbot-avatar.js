(function (global) {
  'use strict';

  var DATA = global.GROKBOT_ORIGINAL || { EXPRESSIONS: [], POOLS: {}, EXPR_CADENCE: {}, BLINK: {} };
  var CENTER_X = 114.2705;
  var CENTER_Y = 114.228;
  var PROXIMITY_RADIUS = 260;
  var STATE_LABELS = {
    sleeping: '休息中', waking: '已唤醒', idle: '随时可以帮忙', listening: '等待审核', thinking: '正在思考',
    searching: '正在检索', working: '正在处理', happy: '状态良好', curious: '等待补充', confused: '需要复核',
    proud: '治理状态优秀', celebrate: '处理完成', orbit: '正在整理关系', radar: '正在扫描图谱', progress: '正在推进',
    writing: '正在生成报告', sending: '正在备份', uploading: '正在转换文档', alerting: '发现阻断问题', suspicious: '连接状态异常'
  };
  var FEATURE_STATES = {
    overview: 'idle', assets: 'working', review: 'working', intake: 'searching', quality: 'searching', rag: 'searching',
    'knowledge-graph': 'radar', gaps: 'curious', reports: 'writing', 'git-backup': 'sending', 'document-conversion': 'uploading'
  };

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function randomBetween(range, fallback) {
    if (!range || range.length < 2) return fallback;
    return range[0] + Math.random() * Math.max(0, range[1] - range[0]);
  }

  function stateForFeature(feature, phase) {
    if (phase === 'error') return 'alerting';
    if (phase === 'offline') return 'suspicious';
    if (phase === 'success') return 'celebrate';
    return FEATURE_STATES[feature] || 'idle';
  }

  function mapGovernanceStatus(item) {
    if (!item) return { state: 'curious', tone: 'neutral', label: '当前页面尚未纳入治理' };
    if (item.compile_status === 'failed' || item.rag_status === 'failed') {
      return { state: 'alerting', tone: 'danger', label: '治理链路存在失败任务' };
    }
    if (item.review_status === 'need_fix') {
      return { state: 'alerting', tone: 'warning', label: '审核退回，等待修正' };
    }
    if (item.review_status === 'need_recheck' || item.rag_status === 'stale') {
      return { state: 'confused', tone: 'warning', label: '内容已变化，需要重新审核' };
    }
    if (['queued', 'running', 'retry_wait'].indexOf(item.compile_status) >= 0) {
      return { state: 'working', tone: 'progress', label: 'Wiki 编译任务处理中' };
    }
    if (['queued', 'parsing'].indexOf(item.rag_status) >= 0) {
      return { state: 'searching', tone: 'progress', label: 'RAG 正在解析入库' };
    }
    if (['reviewed', 'verified'].indexOf(item.review_status) >= 0 && item.rag_status === 'ready') {
      return { state: 'proud', tone: 'success', label: item.review_status === 'verified' ? '已验证并可正式召回' : '已审核并可召回' };
    }
    if (item.review_status === 'pending_review') {
      return { state: 'listening', tone: 'pending', label: '等待人工审核' };
    }
    if (item.rag_status === 'not_ingested') {
      return { state: 'curious', tone: 'neutral', label: '尚未进入 RAG 召回库' };
    }
    return { state: 'idle', tone: 'neutral', label: '治理状态已同步' };
  }

  function centroid(ring) {
    var x = 0;
    var y = 0;
    for (var index = 0; index < ring.length; index += 1) {
      x += ring[index][0];
      y += ring[index][1];
    }
    return [x / ring.length, y / ring.length];
  }

  function ringPath(ring) {
    if (!ring || !ring.length) return '';
    return 'M' + ring.map(function (point) { return point[0].toFixed(2) + ' ' + point[1].toFixed(2); }).join('L') + 'Z';
  }

  function copyExpression(expression) {
    return expression.map(function (ring) {
      return ring.map(function (point) { return [point[0], point[1]]; });
    });
  }

  function motionForState(name) {
    if (['happy', 'celebrate', 'excited', 'proud'].indexOf(name) >= 0) return 'bounce';
    if (['listening', 'thinking', 'curious', 'confused'].indexOf(name) >= 0) return 'tilt';
    if (['searching', 'working', 'radar', 'writing', 'uploading'].indexOf(name) >= 0) return 'scan';
    if (['orbit', 'sending'].indexOf(name) >= 0) return 'turn';
    if (['sleeping', 'progress'].indexOf(name) >= 0) return 'pulse';
    if (['alerting', 'suspicious'].indexOf(name) >= 0) return 'alert';
    return 'settle';
  }

  function create(host, options) {
    options = options || {};
    if (!host || !DATA.EXPRESSIONS.length) throw new Error('GrokBot geometry is unavailable');

    host.classList.add('drv-grokbot');
    host.setAttribute('aria-hidden', 'true');
    host.innerHTML = '<svg class="drv-grokbot__svg" viewBox="-25 -28 279 285" focusable="false">' +
      '<defs><linearGradient id="drv-grokbot-body" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#58b7f2"/><stop offset="0.52" stop-color="#237ec0"/><stop offset="1" stop-color="#155889"/></linearGradient>' +
      '<radialGradient id="drv-grokbot-glow"><stop offset="0" stop-color="#a8e2ff" stop-opacity="0.72"/><stop offset="1" stop-color="#2b91d0" stop-opacity="0"/></radialGradient>' +
      '<clipPath id="drv-grokbot-clip"><path d="M228.541 114.228C228.541 130.133 225.184 145.994 218.738 160.534C212.674 174.217 203.904 186.669 193.065 196.988C155.933 232.34 99.497 238.596 55.5255 212.24C45.097 205.99 35.6851 198.072 27.7451 188.866C19.1926 178.953 12.3686 167.569 7.65781 155.351C2.60712 142.264 0 128.257 0 114.228C0 98.3219 3.35751 82.4611 9.80315 67.9215C15.8672 54.2382 24.6377 41.7862 35.4767 31.4668C72.6081 -3.88483 129.044 -10.1413 173.016 16.2153C183.444 22.4653 192.856 30.3829 200.796 39.5896C209.349 49.5018 216.173 60.8859 220.883 73.1037C225.934 86.1906 228.541 100.198 228.541 114.228Z"/></clipPath></defs>' +
      '<ellipse class="drv-grokbot__ground" cx="114" cy="247" rx="72" ry="10"/>' +
      '<ellipse class="drv-grokbot__halo" cx="114" cy="114" rx="133" ry="52"/>' +
      '<g class="drv-grokbot__head"><circle class="drv-grokbot__aura" cx="114" cy="114" r="132"/>' +
      '<path class="drv-grokbot__body" d="M228.541 114.228C228.541 130.133 225.184 145.994 218.738 160.534C212.674 174.217 203.904 186.669 193.065 196.988C155.933 232.34 99.497 238.596 55.5255 212.24C45.097 205.99 35.6851 198.072 27.7451 188.866C19.1926 178.953 12.3686 167.569 7.65781 155.351C2.60712 142.264 0 128.257 0 114.228C0 98.3219 3.35751 82.4611 9.80315 67.9215C15.8672 54.2382 24.6377 41.7862 35.4767 31.4668C72.6081 -3.88483 129.044 -10.1413 173.016 16.2153C183.444 22.4653 192.856 30.3829 200.796 39.5896C209.349 49.5018 216.173 60.8859 220.883 73.1037C225.934 86.1906 228.541 100.198 228.541 114.228Z"/>' +
      '<path class="drv-grokbot__shine" d="M30 83C48 35 91 10 139 14C94 24 63 48 48 91Z"/>' +
      '<g class="drv-grokbot__eyes" clip-path="url(#drv-grokbot-clip)"><path class="drv-grokbot__eye"/><path class="drv-grokbot__eye"/></g>' +
      '<path class="drv-grokbot__mark" d="M97 192h34M108 184l-9 8 9 8M120 184l9 8-9 8"/></g></svg>';

    var svg = host.querySelector('.drv-grokbot__svg');
    var head = host.querySelector('.drv-grokbot__head');
    var eyes = host.querySelectorAll('.drv-grokbot__eye');
    var reducedMotion = Boolean(global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches);
    var coarsePointer = Boolean(global.matchMedia && global.matchMedia('(pointer: coarse)').matches) || Boolean(global.navigator && global.navigator.maxTouchPoints > 0);
    var expressionIndex = 0;
    var current = copyExpression(DATA.EXPRESSIONS[0]);
    var target = DATA.EXPRESSIONS[0];
    var morph = 1;
    var morphVelocity = 0;
    var blinkStarted = 0;
    var gaze = { x: 0, y: 0, tilt: 0 };
    var gazeTarget = { x: 0, y: 0, tilt: 0 };
    var state = 'idle';
    var frameId = 0;
    var stateTimer = 0;
    var blinkTimer = 0;
    var motionTimer = 0;
    var idleTimer = 0;
    var flashTimer = 0;
    var destroyed = false;
    var lastFrame = global.performance && global.performance.now ? global.performance.now() : Date.now();

    function interpolatedExpression() {
      var amount = clamp(morph, 0, 1);
      return current.map(function (ring, ringIndex) {
        return ring.map(function (point, pointIndex) {
          var destination = target[ringIndex][pointIndex];
          return [point[0] + (destination[0] - point[0]) * amount, point[1] + (destination[1] - point[1]) * amount];
        });
      });
    }

    function blinkScale(now) {
      if (!blinkStarted) return 1;
      var progress = (now - blinkStarted) / 280;
      if (progress >= 1) {
        blinkStarted = 0;
        return 1;
      }
      return Math.max(progress < 0.45 ? 1 - progress / 0.45 : (progress - 0.45) / 0.55, 0.035);
    }

    function chooseExpression(nextIndex) {
      if (!DATA.EXPRESSIONS[nextIndex]) return;
      current = interpolatedExpression();
      target = DATA.EXPRESSIONS[nextIndex];
      expressionIndex = nextIndex;
      morph = reducedMotion ? 1 : 0;
      morphVelocity = 0;
    }

    function scheduleExpressionChange() {
      global.clearTimeout(stateTimer);
      var pool = DATA.POOLS[state] || DATA.POOLS.idle || [0];
      var cadence = DATA.EXPR_CADENCE[state];
      if (!cadence || pool.length < 2 || reducedMotion) return;
      stateTimer = global.setTimeout(function () {
        var alternatives = pool.filter(function (index) { return index !== expressionIndex; });
        chooseExpression(alternatives[Math.floor(Math.random() * alternatives.length)] || pool[0]);
        scheduleExpressionChange();
      }, randomBetween(cadence, 7000));
    }

    function scheduleBlink() {
      global.clearTimeout(blinkTimer);
      var cadence = DATA.BLINK[state];
      if (!cadence || reducedMotion) return;
      blinkTimer = global.setTimeout(function () {
        blinkStarted = global.performance && global.performance.now ? global.performance.now() : Date.now();
        scheduleBlink();
      }, randomBetween(cadence, 5000));
    }

    function playMotion(name) {
      global.clearTimeout(motionTimer);
      var motion = motionForState(name);
      var classes = ['bounce', 'tilt', 'scan', 'turn', 'pulse', 'alert', 'settle'];
      classes.forEach(function (item) { host.classList.remove('drv-grokbot--motion-' + item); });
      if (reducedMotion) return;
      void host.offsetWidth;
      host.classList.add('drv-grokbot--motion-' + motion);
      motionTimer = global.setTimeout(function () { host.classList.remove('drv-grokbot--motion-' + motion); }, 1200);
    }

    function scheduleIdleMotion() {
      global.clearTimeout(idleTimer);
      if (reducedMotion) return;
      idleTimer = global.setTimeout(function () {
        if (state === 'idle') playMotion('idle');
        scheduleIdleMotion();
      }, 18000 + Math.random() * 24000);
    }

    function setState(name, stateOptions) {
      stateOptions = stateOptions || {};
      var pool = DATA.POOLS[name];
      if (!pool || !pool.length) name = 'idle';
      state = name;
      host.dataset.state = name;
      var candidates = DATA.POOLS[name] || [0];
      var alternatives = candidates.filter(function (index) { return index !== expressionIndex; });
      chooseExpression(alternatives[Math.floor(Math.random() * alternatives.length)] || candidates[0]);
      if (stateOptions.motion !== false) playMotion(name);
      scheduleExpressionChange();
      scheduleBlink();
      if (typeof options.onStateChange === 'function') options.onStateChange(name, STATE_LABELS[name] || name);
      return name;
    }

    function flashState(name, duration) {
      var previous = state;
      global.clearTimeout(flashTimer);
      setState(name);
      flashTimer = global.setTimeout(function () { setState(previous); }, duration || 1000);
    }

    function onPointerMove(event) {
      if (coarsePointer || reducedMotion || !host.getBoundingClientRect) return;
      var rect = host.getBoundingClientRect();
      var centerX = rect.left + rect.width / 2;
      var centerY = rect.top + rect.height / 2;
      var dx = event.clientX - centerX;
      var dy = event.clientY - centerY;
      var distance = Math.sqrt(dx * dx + dy * dy);
      if (distance > PROXIMITY_RADIUS) {
        gazeTarget.x = 0; gazeTarget.y = 0; gazeTarget.tilt = 0;
        return;
      }
      var strength = 1 - distance / PROXIMITY_RADIUS;
      gazeTarget.x = clamp(dx / PROXIMITY_RADIUS, -1, 1) * (10 + strength * 5);
      gazeTarget.y = clamp(dy / PROXIMITY_RADIUS, -1, 1) * (7 + strength * 3);
      gazeTarget.tilt = clamp(dx / PROXIMITY_RADIUS, -1, 1) * 4;
    }

    function frame(now) {
      if (destroyed) return;
      var delta = Math.min((now - lastFrame) / 1000, 0.1);
      lastFrame = now;
      if (!reducedMotion) {
        morphVelocity += (-14 * morphVelocity - 49 * (morph - 1)) * delta;
        morph += morphVelocity * delta;
        gaze.x += (gazeTarget.x - gaze.x) * 0.16;
        gaze.y += (gazeTarget.y - gaze.y) * 0.16;
        gaze.tilt += (gazeTarget.tilt - gaze.tilt) * 0.10;
      } else {
        morph = 1;
        gaze.x = gaze.y = gaze.tilt = 0;
      }
      var shown = interpolatedExpression();
      var eyeScale = blinkScale(now);
      shown.forEach(function (ring, index) {
        var center = centroid(ring);
        eyes[index].setAttribute('d', ringPath(ring));
        eyes[index].setAttribute('transform', 'translate(' + gaze.x.toFixed(2) + ' ' + gaze.y.toFixed(2) + ') translate(' + center[0].toFixed(2) + ' ' + center[1].toFixed(2) + ') scale(1 ' + eyeScale.toFixed(3) + ') translate(' + (-center[0]).toFixed(2) + ' ' + (-center[1]).toFixed(2) + ')');
      });
      head.setAttribute('transform', 'translate(' + (gaze.x * 0.12).toFixed(2) + ' ' + (gaze.y * 0.08).toFixed(2) + ') rotate(' + gaze.tilt.toFixed(2) + ' ' + CENTER_X + ' ' + CENTER_Y + ')');
      frameId = global.requestAnimationFrame(frame);
    }

    function destroy() {
      destroyed = true;
      global.cancelAnimationFrame(frameId);
      [stateTimer, blinkTimer, motionTimer, idleTimer, flashTimer].forEach(function (timer) { global.clearTimeout(timer); });
      if (!coarsePointer && global.document) global.document.removeEventListener('pointermove', onPointerMove);
      host.innerHTML = '';
    }

    if (!coarsePointer && global.document) global.document.addEventListener('pointermove', onPointerMove, { passive: true });
    setState(options.initialState || 'idle', { motion: false });
    scheduleIdleMotion();
    frameId = global.requestAnimationFrame(frame);

    return {
      setState: setState,
      flashState: flashState,
      destroy: destroy,
      getState: function () { return state; },
      getExpression: function () { return expressionIndex; },
      getLabel: function () { return STATE_LABELS[state] || state; }
    };
  }

  global.DrvKnowledgeAvatar = {
    create: create,
    mapGovernanceStatus: mapGovernanceStatus,
    stateForFeature: stateForFeature,
    stateLabels: STATE_LABELS,
    proximityRadius: PROXIMITY_RADIUS
  };
})(window);

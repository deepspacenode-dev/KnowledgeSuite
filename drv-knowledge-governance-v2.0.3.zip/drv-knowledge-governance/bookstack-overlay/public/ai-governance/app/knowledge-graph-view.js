import { escapeHtml, icon, viewState } from './ui.js?v=20260707-wave-b';
import { renderGraphControls } from './knowledge-graph-controls.js';

export function renderKnowledgeGraphShell(shelves = [], filters = {}) {
    return `<section class="knowledge-graph">
      <div class="knowledge-graph__toolbar">
        ${renderGraphControls(shelves, filters)}
        <div class="knowledge-graph__stats" id="knowledge-graph-stats"></div>
      </div>
      <div class="knowledge-graph__stage">
        <div class="knowledge-graph__canvas" id="knowledge-graph-canvas">
          ${viewState('loading', '正在生成知识资产图谱')}
        </div>
        <aside class="knowledge-graph__detail" id="knowledge-graph-detail"></aside>
      </div>
      <div class="knowledge-graph__results" id="knowledge-graph-results" hidden></div>
    </section>`;
}

export function renderGraphStats(stats = {}, meta = {}) {
    const cards = [
        ['节点', stats.node_count || 0],
        ['关系', stats.link_count || 0],
        ['待治理', stats.pending_count || 0],
        ['已验证', stats.verified_count || 0],
        ['可召回', stats.rag_parsed_count || 0],
        ['失败', stats.rag_failed_count || 0],
    ];
    return `${cards.map(([label, value]) => `<span><strong>${escapeHtml(value)}</strong>${escapeHtml(label)}</span>`).join('')}${meta.truncated ? `<em>${icon('triangle-alert', 14)} 已按 ${escapeHtml(meta.limit)} 节点截断</em>` : ''}`;
}

export function renderSearchResults(items) {
    if (!items.length) {
        return '<p>没有匹配节点。</p>';
    }
    return `<ul>${items.slice(0, 12).map((item) => `<li><button type="button" data-graph-focus="${escapeHtml(item.id)}"><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.type)}</span></button></li>`).join('')}</ul>`;
}

import { escapeHtml, formatDate, icon, safeHref, statusBadge, viewState } from './ui.js?v=20260908-v203-widget-v1';

export const VIEW_META = Object.freeze({
    overview: { title: '治理总览', description: '从原始资料、Wiki 审阅到 RAG 可召回的全链路健康度。' },
    assets: { title: '文档审阅', description: '按书架治理页面；芯片手册以章节作为最小评审单位。' },
    contributions: { title: '人员贡献', description: '按有效页面统计知识建设贡献，自动化事件不重复计数。' },
    quality: { title: '质量问题', description: '聚合结构、来源、字段和过期校验问题，阻断不可验证知识。' },
    rag: { title: 'RAG 状态', description: '跟踪已审阅 Wiki 的数据集、解析、分块和 upsert 状态。' },
    'knowledge-graph': { title: '知识图谱', description: '以 Obsidian 风格 3D 视图预览知识资产结构、审阅状态和 RAG 入库状态。' },
    gaps: { title: '知识缺口', description: '把召回无结果、结论冲突和项目未覆盖内容转成可跟踪任务。' },
    reports: { title: '报告生成', description: '生成可复制的知识治理周报或月报 Markdown。' },
});

function parseJson(value, fallback) {
    if (!value) return fallback;
    if (typeof value === 'object') return value;
    try { return JSON.parse(value); } catch { return fallback; }
}

function kpi(label, value, note, iconName, tone = 'blue') {
    return `<article class="kpi-card kpi-card--${tone}">
        <div class="kpi-card__top"><span class="kpi-card__icon">${icon(iconName, 19)}</span><span class="kpi-card__trend">${icon('activity', 14)} 实时</span></div>
        <strong>${escapeHtml(value)}</strong><span>${escapeHtml(label)}</span><small>${escapeHtml(note)}</small>
    </article>`;
}

function panel(title, subtitle, body, action = '') {
    return `<section class="section-panel"><header class="section-panel__header"><div><h2>${escapeHtml(title)}</h2><p>${escapeHtml(subtitle)}</p></div>${action}</header><div class="section-panel__body">${body}</div></section>`;
}

function progress(label, value, total, tone = 'blue') {
    const percent = total > 0 ? Math.round((value / total) * 100) : 0;
    return `<div class="pipeline-row"><div class="pipeline-row__label"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)} <small>/ ${escapeHtml(total)}</small></strong></div><div class="progress-track"><span class="progress-track__bar progress-track__bar--${tone}" style="width:${Math.min(100, percent)}%"></span></div><span class="pipeline-row__percent">${percent}%</span></div>`;
}

export function overviewView(data) {
    const source = Number(data.source_assets || 0);
    const wiki = Number(data.wiki_assets || 0);
    const reviewed = Math.max(0, wiki - Number(data.pending_reviews || 0));
    const ready = Number(data.rag_ready || 0);
    const total = Math.max(source, wiki, 1);
    const health = wiki ? Math.round((ready / wiki) * 100) : 0;
    return `<div class="kpi-grid">
        ${kpi('原始资料', source, '已纳入治理范围', 'files')}
        ${kpi('Wiki 条目', wiki, `${data.pending_reviews || 0} 份等待审阅`, 'book-open-check', 'cyan')}
        ${kpi('RAG 可召回', ready, `有效覆盖率 ${health}%`, 'database-zap', 'green')}
        ${kpi('开放缺口', data.open_gaps || 0, '需要指定责任人与时间', 'scan-search', 'amber')}
      </div>
      <div class="overview-layout">
        ${panel('知识管道', '从资料沉淀到可验证召回', `
          <div class="pipeline">
            ${progress('原始资料', source, total)}
            ${progress('Wiki 编译', wiki, total, 'cyan')}
            ${progress('人工审阅', reviewed, total, 'teal')}
            ${progress('RAG 可召回', ready, total, 'green')}
          </div>
          <div class="pipeline-note">${icon('shield-check', 18)}<div><strong>门禁状态正常</strong><p>draft 与低质量条目不会进入正式召回链路。</p></div></div>
        `)}
        ${panel('今日待办', '优先处理会阻断召回的项目', `
          <div class="task-list">
            <button type="button" data-view="assets"><span class="task-dot task-dot--blue"></span><span><strong>${data.pending_reviews || 0} 份 Wiki 待审阅</strong><small>核对来源和适用范围</small></span>${icon('chevron-right', 17)}</button>
            <button type="button" data-view="quality"><span class="task-dot task-dot--amber"></span><span><strong>检查质量阻断项</strong><small>补齐 owner、module 和引用</small></span>${icon('chevron-right', 17)}</button>
            <button type="button" data-view="gaps"><span class="task-dot task-dot--red"></span><span><strong>${data.open_gaps || 0} 项知识缺口开放</strong><small>明确负责人和截止时间</small></span>${icon('chevron-right', 17)}</button>
          </div>
        `)}
      </div>`;
}

function shelfOptions(context = {}) {
    const selected = String(context.filters?.bookshelf_id || '');
    return `<option value="">全部书架</option>${(context.shelves || []).map((shelf) => `<option value="${escapeHtml(shelf.id)}" ${String(shelf.id) === selected ? 'selected' : ''}>${escapeHtml(shelf.name)} (${escapeHtml(shelf.page_count || 0)})</option>`).join('')}`;
}

function shelfSelect(context = {}, label = '书架') {
    return `<label><span class="sr-only">${escapeHtml(label)}</span><select name="bookshelf_id" aria-label="${escapeHtml(label)}">${shelfOptions(context)}</select></label>`;
}

function filtersMarkup(context) {
    return `<form class="filter-bar" id="asset-filters">
      <label class="search-field">${icon('search', 17)}<input name="search" type="search" value="${escapeHtml(context.filters?.search || '')}" placeholder="搜索章节、页面或书籍"></label>
      ${shelfSelect(context)}
      <select name="review_status" aria-label="审阅状态"><option value="">全部审阅状态</option><option value="pending_review">待审阅</option><option value="reviewed">已审阅</option><option value="verified">已验证</option><option value="need_fix">待修改</option></select>
      <button class="button button--secondary" type="submit">${icon('list-filter', 16)} 筛选</button>
    </form>`;
}

function reviewUnitAction(unit, status, context) {
    if (!context.canWrite || !(unit.allowed_actions || []).includes(status)) return '';
    const labels = { pending_review: '提交审阅', reviewed: '通过审阅', verified: '标记验证', need_fix: '退回修改', need_recheck: '要求复审', deprecated: '废弃' };
    const tones = { reviewed: 'button--primary', verified: 'button--success', need_fix: 'button--secondary', deprecated: 'button--ghost' };
    return `<button class="button ${tones[status] || 'button--ghost'} button--compact" type="button" data-action="mark-review-unit" data-review-unit="${escapeHtml(unit.unit_key)}" data-review-status="${escapeHtml(status)}" data-bookshelf-id="${escapeHtml(unit.bookshelf_id ?? 'unassigned')}">${escapeHtml(labels[status] || status)}</button>`;
}

function publishReviewUnitAction(unit, context) {
    if (!context.canWrite || unit.can_publish !== true) return '';
    return `<button class="button button--primary button--compact" type="button" data-action="publish-review-unit" data-review-unit="${escapeHtml(unit.unit_key)}" data-review-unit-title="${escapeHtml(unit.unit_title || '')}" data-bookshelf-id="${escapeHtml(unit.bookshelf_id ?? 'unassigned')}" data-member-count="${escapeHtml(unit.member_count || 0)}">一键入库 RAGFlow</button>`;
}

export function assetsView(data, context) {
    const items = data.items || [];
    const rows = items.map((item) => `<tr>
          <td><div class="document-cell"><span class="document-cell__icon">${icon(item.unit_type === 'chapter' ? 'panels-top-left' : 'file-text', 18)}</span><div><strong>${escapeHtml(item.unit_title)}</strong><small>${item.unit_type === 'chapter' ? '章节评审' : '页面评审'} · ${escapeHtml(item.member_count || 0)} 个页面</small></div></div></td>
          <td><strong>${escapeHtml(item.bookshelf_name || '未归属书架')}</strong><small class="table-subline">${escapeHtml(item.book_name || '未归属书籍')}</small></td>
          <td>${statusBadge(item.review_status || 'draft')}</td>
          <td>${escapeHtml(item.asset_count || 0)} / ${escapeHtml(item.member_count || 0)}</td>
          <td><div class="review-unit-actions">${publishReviewUnitAction(item, context)}${['pending_review', 'reviewed', 'verified', 'need_fix', 'need_recheck', 'deprecated'].map((status) => reviewUnitAction(item, status, context)).join('')}</div></td>
        </tr>`).join('');
    return `${filtersMarkup(context)}${panel('评审单元', `当前共 ${data.total || 0} 项；章节操作会作用于其中全部有效页面`, items.length ? `
      <div class="table-wrap"><table><thead><tr><th>评审对象</th><th>书架 / 书籍</th><th>审阅状态</th><th>治理资产</th><th>合法操作</th></tr></thead><tbody>${rows}</tbody></table></div>` : viewState('empty', '当前条件下没有可评审内容', '调整书架或审阅状态后重试。'))}`;
}

export function contributionsView(items, context = {}) {
    const max = Math.max(1, ...items.map((item) => Number(item.asset_count || item.effective_pages || 0)));
    const filters = `<form class="filter-bar" id="contribution-filters">${shelfSelect(context)}<label><span class="sr-only">开始日期</span><input type="date" name="date_from" value="${escapeHtml(context.filters?.date_from || '')}"></label><label><span class="sr-only">结束日期</span><input type="date" name="date_to" value="${escapeHtml(context.filters?.date_to || '')}"></label><button class="button button--secondary" type="submit">${icon('list-filter',16)} 筛选</button></form>`;
    return `${filters}${panel('贡献排行', '以可见页面为口径，展示有效沉淀与 Wiki 产出', items.length ? `<div class="contribution-list">${items.map((item, index) => {
        const count = Number(item.asset_count || item.effective_pages || 0);
        const account = item.owner_name || item.user_name || item.username || (item.owner_id ? String(item.owner_id) : '未分配');
        return `<div class="contribution-row"><span class="rank">${String(index + 1).padStart(2, '0')}</span><span class="avatar">${escapeHtml(String(account).slice(0, 2).toUpperCase())}</span><div class="contribution-row__main"><div><strong>${escapeHtml(account)}</strong><span>${escapeHtml(item.document_count || item.effective_pages || 0)} 个有效页面</span></div><div class="progress-track"><span class="progress-track__bar" style="width:${Math.round((count / max) * 100)}%"></span></div></div><strong>${count}</strong></div>`;
    }).join('')}</div>` : viewState('empty', '暂无贡献数据'))}`;
}

function jsonList(value) {
    const items = parseJson(value, []);
    return items.length ? `<ul>${items.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ul>` : '<span class="muted">无</span>';
}

function qualityProblems(problems = []) {
    if (!problems.length) return '<span class="muted">没有需要处理的问题</span>';
    return `<div class="quality-problems">${problems.map((problem) => `<article class="quality-problem ${problem.blocking ? 'is-blocking' : ''}">
      <div><strong>${escapeHtml(problem.title || '质量问题')}</strong><span>${escapeHtml(problem.severity || (problem.blocking ? '阻断' : '警告'))}${problem.deduction == null ? '' : ` · 扣 ${escapeHtml(problem.deduction)} 分`}</span></div>
      <p>${escapeHtml(problem.fix || '修复后重新执行质量检查。')}</p>
    </article>`).join('')}</div>`;
}

function sourceLink(url, label = '查看原文') {
    const href = safeHref(url);
    return href ? `<a class="button button--ghost" href="${href}" target="_blank" rel="noopener noreferrer">${icon('external-link', 15)} ${escapeHtml(label)}</a>` : '';
}

function qualityMemberEvidence(member) {
    const blocked = member.gate_result === 'blocked';
    return `<article class="quality-unit-member ${blocked ? 'is-blocked' : ''}">
      <header><div><strong>${escapeHtml(member.page_title || member.asset_title || '未命名页面')}</strong><small>#${escapeHtml(member.asset_id || '-')} · ${escapeHtml(member.score ?? '-')} 分</small></div>${statusBadge(blocked ? 'blocked' : 'need_fix')}</header>
      <p class="quality-conclusion ${blocked ? 'is-blocked' : ''}">${escapeHtml(member.conclusion || (blocked ? '该页面存在质量阻断项。' : '该页面存在质量扣分项。'))}</p>
      ${qualityProblems(member.problems || [])}
      ${sourceLink(member.page_url)}
    </article>`;
}

function chapterQualityRow(item, blocked) {
    const issueCount = Number(item.issue_page_count || item.members?.length || 0);
    const memberCount = Number(item.member_count || issueCount);
    return `<article class="issue-row issue-row--chapter">
      <span class="issue-row__score ${blocked ? 'is-blocked' : ''}">${escapeHtml(item.score ?? '-')}<small>分</small></span>
      <div class="issue-row__body">
        <div class="issue-row__heading"><div><strong>${escapeHtml(item.unit_title || '未命名章节')}</strong><small>章节质量 · ${escapeHtml(item.book_name || '未归属手册')} · ${escapeHtml(issueCount)}/${escapeHtml(memberCount)} 个页面有问题</small></div>${statusBadge(blocked ? 'blocked' : 'need_fix')}</div>
        <p class="quality-conclusion ${blocked ? 'is-blocked' : ''}">${escapeHtml(item.conclusion || (blocked ? '本章节无法通过质量门禁。' : '本章节存在需要修复的质量扣分项。'))}</p>
        <details class="quality-unit-details"><summary>查看章节内 ${escapeHtml(issueCount)} 个问题页面</summary><div class="quality-unit-members">${(item.members || []).map(qualityMemberEvidence).join('')}</div></details>
        <small>最近检查于 ${formatDate(item.checked_at)}</small>
      </div>
      <div class="review-unit-actions">
        ${sourceLink(item.chapter_url, '查看章节原文')}
        <button class="button button--ghost" type="button" data-action="open-review-unit" data-review-unit="${escapeHtml(item.unit_key || '')}" data-review-unit-title="${escapeHtml(item.unit_title || '')}" data-bookshelf-id="${escapeHtml(item.bookshelf_id ?? 'unassigned')}">前往章节审核</button>
      </div>
    </article>`;
}

function pageQualityRow(item, blocked) {
    return `<article class="issue-row"><span class="issue-row__score ${blocked ? 'is-blocked' : ''}">${escapeHtml(item.score ?? '-')}<small>分</small></span><div class="issue-row__body"><div class="issue-row__heading"><div><strong>${escapeHtml(item.asset_title || `文档 ${item.asset_id}`)}</strong><small>#${escapeHtml(item.asset_id)} · v${escapeHtml(item.current_version || item.source_version || 1)}</small></div>${statusBadge(blocked ? 'blocked' : 'need_fix')}</div><p class="quality-conclusion ${blocked ? 'is-blocked' : ''}">${escapeHtml(item.conclusion || (blocked ? '无法入库：存在质量阻断项。' : '当前存在需要修复的质量扣分项。'))}</p>${qualityProblems(item.problems || [])}<small>检查于 ${formatDate(item.checked_at)}</small></div>${sourceLink(item.page_url)}</article>`;
}

export function qualityView(items, context = {}) {
    const body = items.length ? `<div class="issue-list">${items.map((item) => {
        const blocked = item.gate_result === 'blocked' || parseJson(item.reject_reasons_json, []).length > 0;
        return item.unit_type === 'chapter' ? chapterQualityRow(item, blocked) : pageQualityRow(item, blocked);
    }).join('')}</div>` : viewState('empty', '没有待处理的质量问题', '当前可见内容已通过确定性检查。');
    const actions = `<div class="panel-actions"><button class="button button--ghost" type="button" data-action="quality-help">${icon('circle-help',16)} 门禁说明</button><button class="button button--secondary" type="button" data-action="sync-quality">${icon('scan-line',16)} 重新检查</button></div>`;
    return `<form class="filter-bar" id="quality-filters">${shelfSelect(context)}<button class="button button--secondary" type="submit">${icon('list-filter',16)} 筛选</button></form>${panel('问题队列', '芯片手册按章节聚合；页面问题仅作为章节内定位明细', body, actions)}`;
}

export function ragView(items, context = {}) {
    const rows = items.map((item) => {
        const removed = ['disabled', 'deleted'].includes(item.parse_status) || item.last_action_result === 'deleted';
        const retry = !removed && item.can_publish ? `<button class="icon-button icon-button--quiet" type="button" data-action="retry-rag" data-asset-id="${item.asset_id}" data-dataset-id="${escapeHtml(item.dataset_id || '')}" aria-label="重新入库并解析" title="重新入库并解析">${icon('rotate-cw',17)}</button>` : '';
        const remove = !removed && item.document_id ? `<button class="icon-button icon-button--danger" type="button" data-action="remove-rag" data-asset-id="${item.asset_id}" data-asset-title="${escapeHtml(item.asset_title || '')}" aria-label="从 RAGFlow 移除" title="从 RAGFlow 移除">${icon('trash-2',17)}</button>` : '';
        const operations = context.canWrite && (retry || remove) ? `<div class="table-actions">${retry}${remove}</div>` : '';
        return `<tr><td><div class="document-cell"><span class="document-cell__icon">${icon('file-text',18)}</span><div><strong>${escapeHtml(item.asset_title || `文档 ${item.asset_id}`)}</strong><small>#${escapeHtml(item.asset_id)} · v${escapeHtml(item.current_version || 1)}</small></div></div></td><td>${escapeHtml(item.dataset_id || '-')}</td><td>${statusBadge(item.parse_status)}</td><td>${escapeHtml(item.chunk_count || 0)}</td><td>${statusBadge(item.last_action_result)}</td><td>${formatDate(item.checked_at)}</td><td>${operations}</td></tr>`;
    }).join('');
    return `<form class="filter-bar" id="rag-filters">${shelfSelect(context)}<button class="button button--secondary" type="submit">${icon('list-filter',16)} 筛选</button></form>${panel('RAG 解析与召回', '审核通过后上传 Wiki Markdown、配置元数据与图片，触发解析并回查最新状态', items.length ? `<div class="table-wrap"><table><thead><tr><th>文件名</th><th>Dataset</th><th>解析状态</th><th>分块</th><th>入库动作</th><th>检查时间</th><th><span class="sr-only">操作</span></th></tr></thead><tbody>${rows}</tbody></table></div>` : viewState('empty', '暂无 RAG 快照'), context.canWrite ? '<button class="button button--primary" type="button" data-action="sync-rag">'+icon('refresh-ccw',16)+' 发布并同步状态</button>' : '')}`;
}

export function qualityHelpView(help = {}) {
    const cards = (title, items) => `<section class="quality-help-section"><h3>${escapeHtml(title)}</h3><div class="quality-help-grid">${(items || []).map((item) => `<article class="quality-help-card ${item.blocking ? 'is-blocking' : ''}"><header><strong>${escapeHtml(item.name)}</strong><span>${item.deduction == null ? (item.blocking ? '硬阻断' : '检查项') : `扣 ${escapeHtml(item.deduction)} 分`}</span></header><p><b>触发条件：</b>${escapeHtml(item.trigger)}</p><p><b>修复方法：</b>${escapeHtml(item.fix)}</p></article>`).join('')}</div></section>`;
    return `<div class="quality-help-summary"><strong>门禁结论如何产生</strong><p>${escapeHtml(help.summary || '普通审阅和验证发布使用不同分数门槛，硬阻断条件优先于分数。')}</p><div><span>普通审阅 ≥ ${escapeHtml(help.minimum_score ?? 70)} 分</span><span>验证发布 ≥ ${escapeHtml(help.verified_minimum_score ?? 90)} 分</span></div></div>${cards('必填元数据', help.metadata_rules)}${cards('推荐章节', help.section_rules)}${cards('硬阻断条件', help.hard_blocks)}${cards('流程状态提示（不扣分）', help.workflow_rules)}`;
}

export function gapsView(items, context) {
    const priorities = { critical: '紧急', high: '高', medium: '中', low: '低' };
    const gapActions = (item, status) => {
        if (!context.canWrite) return '';
        const advance = status !== 'closed' ? `<button class="button button--ghost" type="button" data-action="advance-gap" data-gap-id="${escapeHtml(item.gap_id)}" data-gap-status="${escapeHtml(status)}">${status === 'open' ? '开始处理' : '标记完成'}</button>` : '';
        const remove = `<button class="button button--danger" type="button" data-action="delete-gap" data-gap-id="${escapeHtml(item.gap_id)}" data-gap-title="${escapeHtml(item.title || '')}">${icon('trash-2', 14)} 删除</button>`;
        return `<div class="gap-item__actions">${advance}${remove}</div>`;
    };
    const body = items.length ? `<div class="gap-board">${['open', 'doing', 'closed'].map((status) => `<section class="gap-column"><header><strong>${statusBadge(status)}</strong><span>${items.filter((item) => item.gap_status === status).length}</span></header><div>${items.filter((item) => item.gap_status === status).map((item) => `<article class="gap-item gap-item--${escapeHtml(item.priority)}"><div><span class="priority-label">${escapeHtml(priorities[item.priority] || item.priority)}</span><small>#${escapeHtml(item.gap_id)}</small></div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.missing_content)}</p><footer><span>${icon('user-round',14)} ${escapeHtml(item.owner_id ? `#${item.owner_id}` : '待分配')}</span><span>${icon('calendar-days',14)} ${formatDate(item.due_at)}</span></footer>${gapActions(item, status)}</article>`).join('') || viewState('empty', '暂无项目')}</div></section>`).join('')}</div>` : viewState('empty', '暂无知识缺口');
    return panel('缺口跟踪', '从发现、补齐到关闭的状态看板', body, context.canWrite ? '<button class="button button--primary" type="button" data-action="create-gap">'+icon('plus',16)+' 新建缺口</button>' : '');
}

export function reportsView(report = null, context = {}) {
    const today = new Date();
    const from = new Date(today.valueOf() - 6 * 86400000).toISOString().slice(0, 10);
    const to = today.toISOString().slice(0, 10);
    return `<div class="report-layout">
      ${panel('生成治理报告', '报告基于当前用户可见内容统计', `<form class="report-form" id="report-form">
        <label><span>报告类型</span><select name="report_type"><option value="周报">周报</option><option value="月报">月报</option></select></label>
        <label><span>书架范围</span><select name="bookshelf_id">${shelfOptions(context)}</select></label>
        <div class="date-range"><label><span>开始日期</span><input type="date" name="period_start" value="${from}" required></label><label><span>结束日期</span><input type="date" name="period_end" value="${to}" required></label></div>
        <button class="button button--primary button--block" type="submit" ${context.canWrite ? '' : 'disabled'}>${icon('file-output',16)} 生成 Markdown</button>
        ${context.canWrite ? '' : '<p class="form-hint">只读用户可查看治理数据，报告生成需要管理员权限。</p>'}
      </form>`)}
      ${panel('报告预览', report ? `已生成报告 #${report.report_id || '-'}` : '生成后可直接复制到 GitLab 或 DrvDocs', report?.markdown ? `<div class="report-toolbar"><button class="button button--secondary" type="button" data-action="copy-report">${icon('copy',16)} 复制</button></div><pre class="markdown-preview" id="report-markdown">${escapeHtml(report.markdown)}</pre>` : viewState('empty', '尚未生成报告', '选择统计周期后生成 Markdown。'))}
    </div>`;
}

export function assetDetailView(detail, canWrite) {
    const asset = detail.asset || {};
    const meta = parseJson(asset.metadata_json, {});
    const reviewActions = {
        pending_review: ['提交审阅', 'send', 'button--secondary'],
        reviewed: ['通过审阅', 'check', 'button--primary'],
        verified: ['标记验证', 'badge-check', 'button--success'],
        need_fix: ['退回修改', 'undo-2', 'button--secondary'],
        need_recheck: ['要求复审', 'refresh-cw', 'button--secondary'],
        deprecated: ['标记废弃', 'archive-x', 'button--ghost'],
    };
    const actionButtons = (detail.allowed_actions || []).map((status) => {
        const [label, iconName, tone] = reviewActions[status] || [status, 'check', 'button--ghost'];
        return `<button class="button ${tone}" type="button" data-action="review-${escapeHtml(status.replaceAll('_', '-'))}" data-asset-id="${escapeHtml(asset.asset_id)}">${icon(iconName,16)} ${escapeHtml(label)}</button>`;
    }).join('');
    const ragAction = detail.rag_action || {};
    const ragButtons = canWrite && asset.asset_type === 'wiki' ? `${ragAction.can_publish ? `<button class="button button--primary" type="button" data-action="retry-rag" data-asset-id="${escapeHtml(asset.asset_id)}" data-dataset-id="${escapeHtml(ragAction.dataset_id || '')}">${icon('database-zap',16)} ${ragAction.has_snapshot ? '重新入库并解析' : '入库并解析'}</button>` : ''}${ragAction.has_snapshot && !ragAction.is_removed ? `<button class="button button--danger" type="button" data-action="remove-rag" data-asset-id="${escapeHtml(asset.asset_id)}" data-asset-title="${escapeHtml(asset.title || '')}">${icon('trash-2',16)} 从 RAGFlow 移除</button>` : ''}` : '';
    return `<div class="drawer-summary"><span class="document-cell__icon">${icon(asset.asset_type === 'wiki' ? 'book-open-text' : 'file-text',20)}</span><div><strong>${escapeHtml(asset.title || '未命名')}</strong><p>${escapeHtml(asset.source_key || `bookstack_page:${asset.page_id || '-'}`)}</p></div></div>
      <dl class="detail-list"><div><dt>对象类型</dt><dd>${escapeHtml(asset.asset_type || '-')}</dd></div><div><dt>当前版本</dt><dd>v${escapeHtml(asset.current_version || 1)}</dd></div><div><dt>资料分类</dt><dd>${escapeHtml(asset.material_type || '-')}</dd></div><div><dt>模块</dt><dd>${escapeHtml(meta.module || '-')}</dd></div><div><dt>审阅状态</dt><dd>${statusBadge(detail.review?.review_status || meta.review_status || 'draft')}</dd></div><div><dt>RAG 状态</dt><dd>${statusBadge(detail.rag?.parse_status || meta.rag_status || 'blocked')}</dd></div></dl>
      <section class="drawer-section"><h3>来源与可追溯性</h3><p>${escapeHtml(meta.source_url || asset.source_url || '该记录将以 DrvDocs Page ID 作为源身份。')}</p></section>
      ${canWrite && asset.asset_id && actionButtons ? `<section class="drawer-section"><h3>审阅操作</h3><div class="drawer-actions">${actionButtons}</div></section>` : ''}
      ${ragButtons ? `<section class="drawer-section"><h3>RAGFlow 入库</h3><p>系统会上传审核后的 Wiki Markdown 和关联图片，写入来源元数据并触发解析。</p><div class="drawer-actions">${ragButtons}</div></section>` : ''}`;
}

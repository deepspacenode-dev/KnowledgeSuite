const MOTION_QUERY = '(prefers-reduced-motion: reduce)';

function createParticles(width, height) {
    const density = Math.max(110, Math.min(230, Math.round((width * height) / 10500)));
    const bands = [
        { y: 0.34, amp: 32, speed: 0.18, drift: 18 },
        { y: 0.52, amp: 44, speed: 0.13, drift: 26 },
        { y: 0.71, amp: 36, speed: 0.16, drift: 22 },
    ];

    return Array.from({ length: density }, (_, index) => {
        const band = bands[index % bands.length];
        return {
            band,
            x: Math.random() * width,
            seed: Math.random() * Math.PI * 2,
            radius: 1.1 + Math.random() * 1.9,
            alpha: 0.18 + Math.random() * 0.24,
            offset: (Math.random() - 0.5) * 80,
            pace: 0.16 + Math.random() * 0.26,
        };
    });
}

function drawBackground(ctx, width, height) {
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#edf5fb';
    ctx.fillRect(0, 0, width, height);
}

function drawWaveRibbon(ctx, width, height, band, time, alpha) {
    ctx.beginPath();
    for (let x = -20; x <= width + 20; x += 12) {
        const wave = Math.sin((x / width) * Math.PI * 2.4 + time * band.speed);
        const crossWave = Math.cos((x / width) * Math.PI * 1.3 + time * 0.09);
        const y = height * band.y + wave * band.amp + crossWave * band.drift;
        if (x === -20) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = `rgba(48, 143, 190, ${alpha})`;
    ctx.lineWidth = 1;
    ctx.stroke();
}

function drawWave(ctx, width, height, particles, time) {
    drawBackground(ctx, width, height);

    const seenBands = new Set();
    for (const particle of particles) {
        if (seenBands.has(particle.band)) continue;
        seenBands.add(particle.band);
        drawWaveRibbon(ctx, width, height, particle.band, time, 0.08);
    }

    for (const particle of particles) {
        const wave = Math.sin((particle.x / width) * Math.PI * 2.4 + time * particle.band.speed + particle.seed);
        const crossWave = Math.cos((particle.x / width) * Math.PI * 1.3 + time * 0.09 + particle.seed);
        const y = height * particle.band.y + wave * particle.band.amp + crossWave * particle.band.drift + particle.offset;
        const x = (particle.x + time * particle.pace * 38) % (width + 80) - 40;
        const alpha = particle.alpha * (0.72 + Math.abs(wave) * 0.28);

        ctx.beginPath();
        ctx.fillStyle = `rgba(34, 129, 183, ${alpha})`;
        ctx.arc(x, y, particle.radius, 0, Math.PI * 2);
        ctx.fill();
    }
}

export function initParticleWave(canvas) {
    if (!canvas) return null;

    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return null;

    const motion = window.matchMedia(MOTION_QUERY);
    let width = 0;
    let height = 0;
    let ratio = 1;
    let particles = [];
    let frame = 0;
    let startedAt = performance.now();

    function resize() {
        ratio = Math.min(window.devicePixelRatio || 1, 1.5);
        width = Math.max(320, window.innerWidth);
        height = Math.max(320, window.innerHeight);
        canvas.width = Math.round(width * ratio);
        canvas.height = Math.round(height * ratio);
        canvas.style.width = `${width}px`;
        canvas.style.height = `${height}px`;
        ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
        particles = createParticles(width, height);
        drawWave(ctx, width, height, particles, 0);
    }

    function stop() {
        if (frame) cancelAnimationFrame(frame);
        frame = 0;
    }

    function animate(now) {
        if (document.hidden || motion.matches) {
            frame = 0;
            drawWave(ctx, width, height, particles, 0);
            return;
        }

        drawWave(ctx, width, height, particles, (now - startedAt) / 1000);
        frame = requestAnimationFrame(animate);
    }

    function start() {
        stop();
        startedAt = performance.now();
        if (!motion.matches && !document.hidden) {
            frame = requestAnimationFrame(animate);
        } else {
            drawWave(ctx, width, height, particles, 0);
        }
    }

    resize();
    start();

    window.addEventListener('resize', resize, { passive: true });
    document.addEventListener('visibilitychange', start);
    motion.addEventListener?.('change', start);

    return { resize, start, stop };
}

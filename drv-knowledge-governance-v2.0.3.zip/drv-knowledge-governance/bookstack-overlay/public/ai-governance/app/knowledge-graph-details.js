import { escapeHtml, icon } from './ui.js?v=20260707-wave-b';
import { RAG_LABELS, REVIEW_LABELS, TYPE_LABELS } from './knowledge-graph-theme.js?v=20260827-sphere-i';

export function renderNodeDetails(node, neighbors = []) {
    if (!node) {
        return `<div class="graph-empty-detail">${icon('mouse-pointer-click', 22)}<strong>选择节点</strong><p>点击图谱中的书架、书籍、章节或页面查看治理状态。</p></div>`;
    }

    const tags = (node.tags || []).map((tag) => `<span>${escapeHtml(tag)}</span>`).join('') || '<em>无标签</em>';
    const related = neighbors.slice(0, 8).map((item) => `<li>${escapeHtml(item.title || item.id)}</li>`).join('') || '<li>暂无一跳邻居</li>';
    const chapterAction = node.type === 'chapter'
        ? `<button class="button button--primary" type="button" data-graph-toggle-pages="${escapeHtml(node.id)}" ${node.pages_loading ? 'disabled' : ''}>${icon(node.pages_loading ? 'loader-circle' : (node.pages_expanded ? 'folder-minus' : 'folder-plus'), 16)} ${node.pages_loading ? '正在读取' : (node.pages_expanded ? '收起页面' : '展开页面')}</button>`
        : '';

    return `<article class="graph-detail-card">
      <header>
        <span>${escapeHtml(TYPE_LABELS[node.type] || node.type || '节点')}</span>
        <h3>${escapeHtml(node.title || '未命名')}</h3>
      </header>
      <dl>
        <div><dt>书架</dt><dd>${escapeHtml(node.bookshelf_name || '-')}</dd></div>
        <div><dt>书籍</dt><dd>${escapeHtml(node.book_name || '-')}</dd></div>
        <div><dt>章节</dt><dd>${escapeHtml(node.chapter_name || '-')}</dd></div>
        <div><dt>页面数</dt><dd>${escapeHtml(node.page_count || 0)}</dd></div>
        <div><dt>治理资产</dt><dd>${node.has_asset === false ? '待入库' : escapeHtml(node.asset_count ?? (node.asset_id ? 1 : '-'))}</dd></div>
        <div><dt>审阅</dt><dd>${escapeHtml(REVIEW_LABELS[node.review_status] || node.review_status || '-')}</dd></div>
        <div><dt>RAG</dt><dd>${escapeHtml(RAG_LABELS[node.rag_status] || node.rag_status || '-')}</dd></div>
        <div><dt>质量</dt><dd>${escapeHtml(node.quality_status || '-')}</dd></div>
        <div><dt>负责人</dt><dd>${escapeHtml(node.owner_name || node.owner_id || '-')}</dd></div>
        <div><dt>更新</dt><dd>${escapeHtml(node.updated_at || '-')}</dd></div>
      </dl>
      <section><strong>标签</strong><div class="graph-tag-list">${tags}</div></section>
      <section><strong>相关节点</strong><ul>${related}</ul></section>
      <footer>
        ${chapterAction}
        ${node.url ? `<a class="button button--secondary" href="${escapeHtml(node.url)}" target="_blank" rel="noreferrer">${icon('external-link', 16)} 打开 DrvDocs</a>` : ''}
        ${node.asset_id ? `<button class="button button--primary" type="button" data-graph-open-asset="${escapeHtml(node.asset_id)}">${icon('panel-right-open', 16)} 查看审阅</button>` : ''}
        <button class="button button--ghost" type="button" data-graph-neighbors="${escapeHtml(node.id)}">${icon('network', 16)} 只看邻居</button>
      </footer>
    </article>`;
}

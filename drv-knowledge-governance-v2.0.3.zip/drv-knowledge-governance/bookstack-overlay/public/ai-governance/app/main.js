import { ApiClient, ApiError } from './api-client.js?v=20260908-v203-widget-v1';
import { DemoApi } from './demo-data.js?v=20260908-v203-widget-v1';
import { navigate, parseRoute } from './router.js?v=20260707-wave-b';
import { NAV_ITEMS, pageHeading, renderShell, updateActiveNavigation } from './app-shell.js?v=20260908-v203-widget-v1';
import { initParticleWave } from './particle-wave.js?v=20260707-wave-b';
import {
    VIEW_META,
    assetDetailView,
    assetsView,
    contributionsView,
    gapsView,
    overviewView,
    qualityHelpView,
    qualityView,
    ragView,
    reportsView,
} from './views.js?v=20260908-v203-widget-v1';
import { escapeHtml, icon, renderIcons, viewState } from './ui.js?v=20260908-v203-widget-v1';

const root = document.querySelector('#governance-app');
const useDemo = location.protocol === 'file:' || new URLSearchParams(location.search).get('demo') === '1';
const api = useDemo ? new DemoApi() : new ApiClient();
const state = {
    route: parseRoute(),
    summary: null,
    canWrite: false,
    shelves: [],
    filters: {},
    report: null,
    graphUnmount: null,
};

const VIEW_LOADERS = {
    overview: async () => state.summary || api.get('/summary'),
    assets: async () => api.get('/review-units', state.filters),
    contributions: async () => api.get('/contributions', state.filters),
    quality: async () => api.get('/quality/issues', state.filters),
    rag: async () => api.get('/rag/status', state.filters),
    // knowledge-graph: lazy graph view, loaded only when this route is active.
    'knowledge-graph': async () => null,
    gaps: async () => api.get('/gaps'),
    reports: async () => state.report,
};

const VIEW_RENDERERS = {
    overview: overviewView,
    assets: assetsView,
    contributions: contributionsView,
    quality: qualityView,
    rag: ragView,
    'knowledge-graph': null,
    gaps: gapsView,
    reports: reportsView,
};

const AVATAR_MESSAGES = Object.freeze({
    overview: '正在查看治理总览',
    assets: '正在处理审核与入库',
    contributions: '正在汇总知识贡献',
    quality: '正在检查知识质量',
    rag: '正在同步 RAG 状态',
    'knowledge-graph': '正在扫描知识关系',
    gaps: '正在查看知识缺口',
    reports: '正在生成治理报告',
});

function emitAvatarState(feature, phase, message = '', detail = '') {
    globalThis.dispatchEvent?.(new CustomEvent('drvknowledge:avatar-state', {
        detail: {
            feature,
            phase,
            message: message || AVATAR_MESSAGES[feature] || '治理状态已更新',
            detail,
        },
    }));
}

async function init() {
    renderShell(root, state.route);
    bindEvents();
    initParticleWave(document.querySelector('#wave-particle-canvas'));
    try {
        state.summary = await api.get('/summary');
        state.canWrite = Boolean(state.summary.permissions?.can_write);
        api.setCsrfToken?.(state.summary.csrf_token);
        configureIntegrations(state.summary);
        state.shelves = await api.get('/filters/bookshelves');
    } catch (error) {
        state.canWrite = false;
    }
    await loadView();
}

function configureIntegrations(summary) {
    const link = document.querySelector('#ragflow-web-link');
    const webUrl = summary?.integrations?.ragflow?.web_url;
    if (!link || !webUrl) return;
    try {
        const parsed = new URL(webUrl);
        if (!['http:', 'https:'].includes(parsed.protocol)) return;
        link.href = parsed.toString();
        link.hidden = false;
    } catch {
        link.hidden = true;
    }
}

async function loadView() {
    const view = state.route.view;
    const meta = VIEW_META[view] || VIEW_META.overview;
    emitAvatarState(view, 'loading', AVATAR_MESSAGES[view]);
    if (state.graphUnmount && view !== 'knowledge-graph') {
        state.graphUnmount();
        state.graphUnmount = null;
    }
    updateActiveNavigation(view);
    document.querySelector('#page-heading').innerHTML = pageHeading(meta.title, meta.description, headingAction(view));
    const host = document.querySelector('#view-host');
    host.innerHTML = viewState('loading', '正在加载治理数据');
    renderIcons();

    if (view === 'knowledge-graph') {
        await loadKnowledgeGraphView(host);
        return;
    }

    try {
        const data = await VIEW_LOADERS[view]();
        host.innerHTML = VIEW_RENDERERS[view](data, {
            canWrite: state.canWrite,
            route: state.route,
            shelves: state.shelves,
            filters: state.filters,
        });
        host.classList.remove('view-host--error');
        emitAvatarState(view, 'ready', meta.title, '治理数据已加载');
    } catch (error) {
        host.classList.add('view-host--error');
        host.innerHTML = `${viewState('error', '无法加载当前视图', error.message)}<button class="button button--secondary retry-button" type="button" data-action="refresh">${icon('refresh-cw', 16)} 重试</button>`;
        toast(error.message, 'error');
        emitAvatarState(view, 'error', '当前视图加载失败', error.message);
    }
    renderIcons();
}

async function loadKnowledgeGraphView(host) {
    host.classList.remove('view-host--error');
    host.innerHTML = viewState('loading', '正在加载知识图谱');
    renderIcons();

    try {
        const graphModule = await import('./knowledge-graph.js?v=20260827-sphere-i');
        graphModule.unmountKnowledgeGraph?.();
        state.graphUnmount = await graphModule.mountKnowledgeGraph(host, {
            api,
            canWrite: state.canWrite,
            openAsset,
            toast,
            shelves: state.shelves,
            initialFilters: { bookshelf_id: state.filters.bookshelf_id || '' },
            onFiltersChanged: (filters) => {
                state.filters = { ...state.filters, bookshelf_id: filters.bookshelf_id || '' };
            },
        });
        emitAvatarState('knowledge-graph', 'ready', '知识图谱已就绪', '拖动、缩放或选择节点继续探索');
    } catch (error) {
        state.graphUnmount = null;
        console.error('[knowledge-graph] mount failed:', error);
        host.classList.add('view-host--error');
        host.innerHTML = `${viewState('error', '知识图谱加载失败', error.stack || error.message || String(error))}<button class="button button--secondary retry-button" type="button" data-action="refresh">${icon('refresh-cw', 16)} 重试</button>`;
        renderIcons();
        emitAvatarState('knowledge-graph', 'error', '知识图谱加载失败', error.message || String(error));
    }
}

function headingAction(view) {
    const actions = {
        overview: `<button class="button button--secondary" type="button" data-action="diagnosis">${icon('stethoscope', 16)} 系统诊断</button>`,
        assets: state.canWrite ? `<button class="button button--primary" type="button" data-action="compile-current" ${state.route.pageId ? '' : 'disabled'}>${icon('sparkles', 16)} 生成当前页 Wiki</button>` : '',
        quality: `<button class="button button--secondary" type="button" data-action="refresh">${icon('refresh-cw', 16)} 刷新</button>`,
        rag: `<button class="button button--secondary" type="button" data-action="refresh">${icon('activity', 16)} 刷新快照</button>`,
    };
    return actions[view] || '';
}

function bindEvents() {
    root.addEventListener('click', onClick);
    document.addEventListener('submit', onSubmit);
    addEventListener('popstate', () => {
        state.route = parseRoute();
        loadView();
    });
    addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeDrawer();
            closeModal();
        }
    });
}

async function onClick(event) {
    const viewButton = event.target.closest('[data-view]');
    if (viewButton) {
        event.preventDefault();
        document.body.classList.remove('sidebar-open');
        navigate(viewButton.dataset.view);
        return;
    }

    const assetButton = event.target.closest('[data-open-asset]');
    if (assetButton) {
        event.preventDefault();
        await openAsset(Number(assetButton.dataset.openAsset));
        return;
    }

    const button = event.target.closest('[data-action]');
    if (!button) return;
    const action = button.dataset.action;
    if (action === 'toggle-sidebar') document.body.classList.toggle('sidebar-open');
    if (action === 'refresh') await loadView();
    if (action === 'close-drawer') closeDrawer();
    if (action === 'about') openAbout();
    if (action === 'diagnosis') await runDiagnosis();
    if (action === 'sync-quality') await sync('quality');
    if (action === 'quality-help') await openQualityHelp();
    if (action === 'sync-rag') await sync('rag');
    if (action === 'compile-current') await compileCurrent();
    if (action === 'create-gap') openGapModal();
    if (action === 'advance-gap') await advanceGap(button.dataset.gapId, button.dataset.gapStatus);
    if (action === 'delete-gap') await deleteGap(button.dataset.gapId, button.dataset.gapTitle);
    if (action === 'retry-rag') await writeAction(`/assets/${button.dataset.assetId}/rag/retry`, { dataset_id: button.dataset.datasetId || '' }, '已提交 Markdown 入库与解析任务');
    if (action === 'remove-rag') await removeFromRag(button);
    if (action === 'open-review-unit') openReviewUnit(button);
    if (action === 'mark-review-unit') await reviewUnit(button);
    if (action === 'publish-review-unit') await publishReviewUnit(button);
    if (action?.startsWith('review-')) await reviewAsset(button.dataset.assetId, action.replace('review-', '').replaceAll('-', '_'));
    if (action === 'copy-report') await copyReport();
    if (action === 'close-modal') closeModal();
}

function openReviewUnit(button) {
    state.filters = {
        bookshelf_id: button.dataset.bookshelfId || '',
        search: button.dataset.reviewUnitTitle || '',
    };
    navigate('assets');
}

async function onSubmit(event) {
    if (['asset-filters', 'contribution-filters', 'quality-filters', 'rag-filters'].includes(event.target.id)) {
        event.preventDefault();
        state.filters = Object.fromEntries(new FormData(event.target).entries());
        await loadView();
    }
    if (event.target.id === 'report-form') {
        event.preventDefault();
        await generateReport(Object.fromEntries(new FormData(event.target).entries()));
    }
    if (event.target.id === 'gap-form') {
        event.preventDefault();
        await createGap(Object.fromEntries(new FormData(event.target).entries()));
    }
}

async function openAsset(assetId) {
    const drawer = document.querySelector('#detail-drawer');
    const body = document.querySelector('#drawer-body');
    drawer.classList.add('is-open');
    drawer.setAttribute('aria-hidden', 'false');
    body.innerHTML = viewState('loading', '正在读取文档详情');
    try {
        const detail = await api.get(`/assets/${assetId}`);
        document.querySelector('#drawer-title').textContent = detail.asset?.title || '文档详情';
        body.innerHTML = assetDetailView(detail, state.canWrite);
    } catch (error) {
        body.innerHTML = viewState('error', '详情加载失败', error.message);
    }
    renderIcons();
}

function closeDrawer() {
    const drawer = document.querySelector('#detail-drawer');
    drawer?.classList.remove('is-open');
    drawer?.setAttribute('aria-hidden', 'true');
}

function openModal(title, body, wide = false) {
    const layer = document.querySelector('#modal-layer');
    layer.innerHTML = `<div class="modal-backdrop" data-action="close-modal"></div><section class="modal${wide ? ' modal--wide' : ''}" role="dialog" aria-modal="true"><header><h2>${escapeHtml(title)}</h2><button class="icon-button" type="button" data-action="close-modal" aria-label="关闭">${icon('x')}</button></header><div class="modal__body">${body}</div></section>`;
    layer.classList.add('is-open');
    layer.setAttribute('aria-hidden', 'false');
    renderIcons();
}

function closeModal() {
    const layer = document.querySelector('#modal-layer');
    layer?.classList.remove('is-open');
    layer?.setAttribute('aria-hidden', 'true');
}

function openAbout() {
    openModal('知识治理中心', `<div class="about-copy"><span class="about-mark">${icon('waypoints', 28)}</span><p>DrvDocs 负责页面身份、人工审核、门禁与治理展示。Wiki 编译和二次知识整理由 RAGFlow / DrvAgent 工作流承接。</p><div class="permission-note">${icon(state.canWrite ? 'shield-check' : 'eye', 18)}<span>当前为<strong>${state.canWrite ? '治理管理员' : '只读成员'}</strong>权限。</span></div></div>`);
}

async function openQualityHelp() {
    try {
        const help = await api.get('/quality/rules');
        openModal('质量门禁说明', qualityHelpView(help), true);
    } catch (error) {
        toast(error.message, 'error');
    }
}

function openGapModal() {
    if (!requireWrite()) return;
    openModal('新建知识缺口', `<form class="modal-form" id="gap-form"><label><span>缺口标题</span><input name="title" required maxlength="255" placeholder="例：缺少 PCIe Gen5 参数验证案例"></label><label><span>缺失内容</span><textarea name="missing_content" required rows="4" placeholder="说明已知结论与当前缺口"></textarea></label><label><span>优先级</span><select name="priority"><option value="medium">中</option><option value="high">高</option><option value="critical">紧急</option><option value="low">低</option></select></label><div class="modal-form__actions"><button class="button button--secondary" type="button" data-action="close-modal">取消</button><button class="button button--primary" type="submit">${icon('plus', 16)} 创建缺口</button></div></form>`);
}

async function runDiagnosis() {
    try {
        const data = await api.get('/diagnosis');
        openModal('系统诊断', `<pre class="diagnosis-output">${escapeHtml(JSON.stringify(data, null, 2))}</pre>`);
    } catch (error) { toast(error.message, 'error'); }
}

async function sync(scope) {
    if (!requireWrite()) return;
    await writeAction('/sync', { scope }, `${scope === 'rag' ? 'RAG' : '质量'}同步已提交`);
}

async function compileCurrent() {
    if (!requireWrite()) return;
    if (!state.route.pageId) return toast('请从 DrvDocs 页面打开治理中心。', 'warning');
    const assets = await api.get('/assets', { page_id: state.route.pageId, page_size: 1 });
    const source = assets.items?.[0];
    if (!source) return toast('当前页尚未建立治理对象。', 'warning');
    await writeAction(`/assets/${source.asset_id}/compile`, {}, 'Wiki 编译任务已创建');
}

async function reviewAsset(assetId, status) {
    if (!requireWrite()) return;
    if (!assetId || assetId === 'undefined' || assetId === 'null') {
        toast('文档ID无效，无法提交审阅。', 'warning');
        console.error('[reviewAsset] assetId is invalid:', assetId);
        return;
    }
    let comment = '';
    if (status === 'need_fix' || status === 'deprecated') {
        comment = globalThis.prompt?.('请输入退回或废弃原因：')?.trim() || '';
        if (!comment) return;
    }
    await writeAction(`/assets/${assetId}/reviews`, { review_status: status, review_comment: comment }, '审阅状态已更新');
    closeDrawer();
}

async function reviewUnit(button) {
    if (!requireWrite()) return;
    const unitKey = button.dataset.reviewUnit || '';
    const status = button.dataset.reviewStatus || '';
    if (!unitKey || !status) return toast('评审单元信息不完整。', 'warning');
    let comment = '';
    if (status === 'need_fix' || status === 'deprecated') {
        comment = globalThis.prompt?.('请输入退回或废弃原因：')?.trim() || '';
        if (!comment) return;
    }
    try {
        emitAvatarState('assets', 'loading', '正在提交评审结果');
        const result = await api.post('/review-units/reviews', {
            unit_key: unitKey,
            bookshelf_id: button.dataset.bookshelfId || '',
            review_status: status,
            review_comment: comment,
        });
        const processed = result.processed?.length || 0;
        const blocked = result.blocked?.length || 0;
        toast(`已更新 ${processed} 项${blocked ? `，${blocked} 项未处理` : ''}`, blocked ? 'warning' : 'success');
        emitAvatarState('assets', blocked ? 'error' : 'success', blocked ? '部分评审未处理' : '评审状态已更新');
        await loadView();
    } catch (error) {
        toast(error.message, 'error');
        emitAvatarState('assets', 'error', '评审提交失败', error.message);
    }
}

async function publishReviewUnit(button) {
    if (!requireWrite()) return;
    const unitKey = button.dataset.reviewUnit || '';
    const title = button.dataset.reviewUnitTitle || '当前评审单元';
    const memberCount = Number(button.dataset.memberCount || 0);
    if (!unitKey) return toast('评审单元信息不完整。', 'warning');
    const confirmed = globalThis.confirm?.(`确认将“${title}”中已通过门禁的 ${memberCount} 个页面入库 RAGFlow 并触发解析？`) ?? false;
    if (!confirmed) return;
    try {
        emitAvatarState('assets', 'loading', '正在提交 RAGFlow 入库与解析');
        const result = await api.post('/review-units/rag/publish', {
            unit_key: unitKey,
            bookshelf_id: button.dataset.bookshelfId || '',
        });
        const published = result.published?.length || 0;
        const failed = result.failed?.length || 0;
        toast(`已提交 ${published} 项到 RAGFlow 并触发解析${failed ? `，${failed} 项失败` : ''}`, failed ? 'warning' : 'success');
        emitAvatarState('assets', failed ? 'error' : 'success', failed ? '部分知识入库失败' : 'RAGFlow 入库任务已提交');
        await loadView();
    } catch (error) {
        toast(error.message, 'error');
        emitAvatarState('assets', 'error', 'RAGFlow 入库失败', error.message);
    }
}

async function removeFromRag(button) {
    if (!requireWrite()) return;
    const assetId = button.dataset.assetId;
    const title = button.dataset.assetTitle || `文档 ${assetId}`;
    const reason = globalThis.prompt?.(`请输入“${title}”移出 RAGFlow 的原因：`)?.trim() || '';
    if (!reason) return;
    const confirmed = globalThis.confirm?.(`确认从 RAGFlow 正式召回库移除“${title}”？\n\nDrvDocs 原文、审核记录和审计记录会保留。`) ?? false;
    if (!confirmed) return;
    try {
        emitAvatarState('rag', 'loading', '正在从 RAGFlow 移除知识');
        await api.delete(`/assets/${assetId}/rag`, { reason });
        toast('已从 RAGFlow 移除，原文和治理记录仍保留。', 'success');
        emitAvatarState('rag', 'success', '知识已从 RAGFlow 移除');
        closeDrawer();
        await loadView();
    } catch (error) {
        toast(error.message, 'error');
        emitAvatarState('rag', 'error', 'RAGFlow 删除失败', error.message);
    }
}

async function createGap(payload) {
    await writeAction('/gaps', payload, '知识缺口已创建');
    closeModal();
}

async function advanceGap(id, status) {
    if (!requireWrite()) return;
    try {
        emitAvatarState('gaps', 'loading', '正在更新知识缺口');
        await api.patch(`/gaps/${id}`, { gap_status: status === 'open' ? 'doing' : 'closed' });
        toast('缺口状态已更新', 'success');
        emitAvatarState('gaps', 'success', '知识缺口状态已更新');
        await loadView();
    } catch (error) {
        toast(error.message, 'error');
        emitAvatarState('gaps', 'error', '知识缺口更新失败', error.message);
    }
}

async function deleteGap(id, title = '') {
    if (!requireWrite()) return;
    const reason = globalThis.prompt?.(`请输入删除“${title || `知识缺口 #${id}`}”的删除原因：`)?.trim() || '';
    if (!reason) return;
    const confirmed = globalThis.confirm?.('确认删除该知识缺口？\n\n删除后无法在看板中恢复，但系统会保留操作者、原因和摘要审计记录。') ?? false;
    if (!confirmed) return;
    try {
        emitAvatarState('gaps', 'loading', '正在删除知识缺口');
        await api.delete(`/gaps/${id}`, { reason });
        toast('知识缺口已删除，审计记录已保留。', 'success');
        emitAvatarState('gaps', 'success', '知识缺口已删除');
        await loadView();
    } catch (error) {
        toast(error.message, 'error');
        emitAvatarState('gaps', 'error', '知识缺口删除失败', error.message);
    }
}

async function generateReport(payload) {
    if (!requireWrite()) return;
    try {
        emitAvatarState('reports', 'loading', '正在生成治理报告');
        state.filters = { ...state.filters, bookshelf_id: payload.bookshelf_id || '' };
        state.report = await api.post('/reports', payload);
        toast('治理报告已生成', 'success');
        emitAvatarState('reports', 'success', '治理报告已生成');
        await loadView();
    } catch (error) {
        toast(error.message, 'error');
        emitAvatarState('reports', 'error', '治理报告生成失败', error.message);
    }
}

async function copyReport() {
    const text = document.querySelector('#report-markdown')?.textContent || '';
    try {
        await navigator.clipboard.writeText(text);
        toast('已复制 Markdown', 'success');
    } catch { toast('浏览器未授权剪贴板，请手动选择。', 'warning'); }
}

async function writeAction(path, body, successMessage) {
    if (!requireWrite()) return;
    try {
        emitAvatarState(state.route.view, 'loading');
        await api.post(path, body);
        toast(successMessage, 'success');
        emitAvatarState(state.route.view, 'success', successMessage);
        await loadView();
    } catch (error) {
        toast(error.message, 'error');
        emitAvatarState(state.route.view, 'error', '治理操作失败', error.message);
    }
}

function requireWrite() {
    if (state.canWrite) return true;
    toast('当前用户为只读权限。', 'warning');
    return false;
}

function toast(message, tone = 'info') {
    const stack = document.querySelector('#toast-stack');
    const item = document.createElement('div');
    item.className = `toast toast--${tone}`;
    item.innerHTML = `<span>${icon(tone === 'error' ? 'circle-alert' : tone === 'success' ? 'circle-check' : 'info', 18)}</span><p>${escapeHtml(message)}</p>`;
    stack.append(item);
    renderIcons();
    setTimeout(() => item.classList.add('is-visible'), 10);
    setTimeout(() => { item.classList.remove('is-visible'); setTimeout(() => item.remove(), 240); }, 3600);
}

init().catch((error) => {
    console.error('[governance] boot failed:', error);
    root.innerHTML = viewState('error', '知识治理中心启动失败', error.stack || error.message || String(error));
    renderIcons();
});

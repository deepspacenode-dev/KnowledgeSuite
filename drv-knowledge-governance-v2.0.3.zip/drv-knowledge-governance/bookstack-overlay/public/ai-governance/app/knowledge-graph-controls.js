import { icon } from './ui.js?v=20260707-wave-b';

export function renderGraphControls(shelves = [], filters = {}) {
    return `<form class="knowledge-graph-controls" id="knowledge-graph-controls">
      <label class="graph-search">${icon('search', 16)}<input name="search" type="search" placeholder="搜索标题 / 书架 / 标签 / 负责人"></label>
      <label><span>书架</span><select name="bookshelf_id"><option value="">全部书架</option>${shelves.map((shelf) => `<option value="${shelf.id}" ${String(filters.bookshelf_id || '') === String(shelf.id) ? 'selected' : ''}>${shelf.name}</option>`).join('')}</select></label>
      <label><span>节点类型</span><select name="node_type"><option value="">全部</option><option value="bookshelf">书架</option><option value="book">书籍</option><option value="chapter">章节</option><option value="page">页面</option></select></label>
      <label><span>审阅</span><select name="review_status"><option value="">全部</option><option value="pending">待治理</option><option value="partial">部分审阅</option><option value="approved">已审阅</option><option value="verified">已验证</option><option value="rejected">已退回</option></select></label>
      <label><span>RAG</span><select name="rag_status"><option value="">全部</option><option value="not_ingested">未入库</option><option value="parsing">解析中</option><option value="parsed">可召回</option><option value="failed">失败</option><option value="stale">待更新</option></select></label>
      <label><span>质量</span><select name="quality_status"><option value="">全部</option><option value="passed">通过</option><option value="warning">警告</option><option value="failed">阻断</option><option value="unknown">未知</option></select></label>
      <label><span>上限</span><input name="limit" type="number" min="20" max="800" step="20" value="300"></label>
      <label class="graph-check"><input name="include_pages" type="checkbox" value="1"><span>显示页面</span></label>
      <div class="graph-control-actions">
        <button class="button button--secondary" type="submit">${icon('list-filter', 16)} 应用</button>
        <button class="button button--ghost" type="button" data-graph-action="reset">${icon('target', 16)} 重置视角</button>
        <button class="button button--ghost" type="button" data-graph-action="pause">${icon('pause', 16)} 暂停布局</button>
      </div>
    </form>`;
}

export function readGraphFilters(form) {
    const data = Object.fromEntries(new FormData(form).entries());
    data.include_pages = form.elements.include_pages?.checked ? '1' : '0';
    data.limit = data.limit || '300';
    return data;
}

import { escapeHtml, icon } from './ui.js?v=20260908-v203-widget-v1';

export const NAV_ITEMS = Object.freeze([
    { id: 'overview', label: '治理总览', icon: 'layout-dashboard', group: '工作台' },
    { id: 'assets', label: '文档审阅', icon: 'file-check-2' },
    { id: 'contributions', label: '人员贡献', icon: 'users-round' },
    { id: 'quality', label: '质量问题', icon: 'shield-alert', group: '知识运行' },
    { id: 'rag', label: 'RAG 状态', icon: 'database-zap' },
    { id: 'knowledge-graph', label: '知识图谱', icon: 'orbit' },
    { id: 'gaps', label: '知识缺口', icon: 'scan-search' },
    { id: 'reports', label: '报告生成', icon: 'notebook-tabs', group: '分析输出' },
]);

function navMarkup(activeView) {
    return NAV_ITEMS.map((item) => `${item.group ? `<p class="nav-group">${item.group}</p>` : ''}
        <button class="nav-item${item.id === activeView ? ' is-active' : ''}" type="button" data-view="${item.id}">
            <span class="nav-item__icon">${icon(item.icon)}</span>
            <span>${item.label}</span>
        </button>`).join('');
}

export function renderShell(root, route) {
    root.innerHTML = `
      <div class="app-shell">
        <aside class="sidebar" id="app-sidebar" aria-label="主导航">
          <div class="brand">
            <button class="brand__mark" type="button" data-action="about" aria-label="了解知识治理中心">
              ${icon('waypoints', 22)}
            </button>
            <button class="brand__copy" type="button" data-action="about">
              <strong>知识治理中心</strong>
              <span>DrvDocs Governance</span>
            </button>
          </div>
          <nav class="sidebar__nav">${navMarkup(route.view)}</nav>
          <div class="sidebar__status">
            <div><strong>治理服务已连接</strong><span>权限与数据同步正常</span></div>
          </div>
        </aside>

        <div class="workspace">
          <header class="topbar">
            <button class="icon-button topbar__menu" type="button" data-action="toggle-sidebar" aria-label="展开导航">${icon('menu')}</button>
            <div class="topbar__context">
              <span class="topbar__eyebrow">知识工程控制台</span>
              <strong id="current-view-title">治理总览</strong>
            </div>
            <div class="topbar__actions">
              ${route.mode === 'current_page' ? `<span class="context-chip">${icon('focus', 15)} 当前页面 #${escapeHtml(route.pageId)}</span>` : ''}
              <a class="home-link" id="ragflow-web-link" href="#" target="_blank" rel="noopener noreferrer" title="打开 RAGFlow 网站" hidden>${icon('external-link', 16)}<span>打开 RAGFlow</span></a>
              <a class="home-link" href="/" title="返回 DrvDocs 首页">${icon('home', 16)}<span>返回 DrvDocs</span></a>
              <button class="icon-button" type="button" data-action="refresh" title="刷新当前数据" aria-label="刷新">${icon('refresh-cw')}</button>
            </div>
          </header>

          <main class="main-content">
            <section class="page-heading" id="page-heading"></section>
            <section class="view-host" id="view-host"></section>
          </main>
        </div>
      </div>
      <div class="sidebar-backdrop" data-action="toggle-sidebar"></div>
      <aside class="detail-drawer" id="detail-drawer" aria-hidden="true" aria-label="文档详情">
        <header><div><span class="drawer-kicker">治理对象</span><h2 id="drawer-title">详情</h2></div><button class="icon-button" type="button" data-action="close-drawer" aria-label="关闭">${icon('x')}</button></header>
        <div class="detail-drawer__body" id="drawer-body"></div>
      </aside>
      <div class="modal-layer" id="modal-layer" aria-hidden="true"></div>
      <div class="toast-stack" id="toast-stack" aria-live="assertive"></div>
    `;
}

export function updateActiveNavigation(view) {
    for (const item of document.querySelectorAll('[data-view]')) {
        item.classList.toggle('is-active', item.dataset.view === view);
    }
    const found = NAV_ITEMS.find((item) => item.id === view);
    const title = document.querySelector('#current-view-title');
    if (title) title.textContent = found?.label || '治理总览';
}

export function pageHeading(title, description, actions = '') {
    return `<div><span class="page-heading__signal">实时治理视图</span><h1>${escapeHtml(title)}</h1><p>${escapeHtml(description)}</p></div><div class="page-heading__actions">${actions}</div>`;
}

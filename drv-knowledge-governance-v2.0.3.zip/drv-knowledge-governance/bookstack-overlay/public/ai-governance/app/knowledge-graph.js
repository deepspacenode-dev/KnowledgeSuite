import ForceGraph3D from '../vendor/3d-force-graph/3d-force-graph.module.js?v=20260827-sphere-i';
import { renderIcons, viewState } from './ui.js?v=20260707-wave-b';
import { readGraphFilters } from './knowledge-graph-controls.js?v=20260827-sphere-i';
import { renderNodeDetails } from './knowledge-graph-details.js?v=20260827-sphere-i';
import { nodeColor, nodeLabel, nodeSize, ragColor } from './knowledge-graph-theme.js?v=20260827-sphere-i';
import { renderGraphStats, renderKnowledgeGraphShell, renderSearchResults } from './knowledge-graph-view.js?v=20260827-sphere-i';

const GRAPH_CSS_ID = 'knowledge-graph-css';
const GRAPH_CSS_HREF = 'assets/css/knowledge-graph.css?v=20260827-sphere-i';
const DEFAULT_FILTERS = Object.freeze({ limit: '300', include_pages: '0' });
const HIERARCHY_LEVELS = Object.freeze({ root: 0, bookshelf: 1, book: 2, chapter: 3, page: 4 });
const HIERARCHY_RADII = Object.freeze({ bookshelf: 92, book: 178, chapter: 272, page: 356 });

let currentRuntime = null;

export async function mountKnowledgeGraph(host, { api, openAsset, toast, shelves = [], initialFilters = {}, onFiltersChanged } = {}) {
    unmountKnowledgeGraph();
    ensureGraphStyles();

    const runtime = {
        host,
        api,
        openAsset,
        toast,
        graph: null,
        data: { nodes: [], links: [], stats: {}, meta: {} },
        selectedNode: null,
        paused: false,
        filters: { ...DEFAULT_FILTERS, ...initialFilters },
        onFiltersChanged,
        expandedChapters: new Map(),
        loadingChapters: new Set(),
        loadGeneration: 0,
        listeners: [],
    };
    currentRuntime = runtime;

    host.innerHTML = renderKnowledgeGraphShell(shelves, runtime.filters);
    renderIcons();
    bindRuntime(runtime);
    await loadGraph(runtime, runtime.filters);

    return () => {
        if (currentRuntime === runtime) {
            unmountKnowledgeGraph();
        }
    };
}

export function unmountKnowledgeGraph() {
    if (!currentRuntime) return;
    currentRuntime.loadGeneration += 1;
    for (const [target, eventName, handler] of currentRuntime.listeners) {
        target.removeEventListener(eventName, handler);
    }
    currentRuntime.graph?._destructor?.();
    currentRuntime.host.replaceChildren();
    currentRuntime = null;
}

function ensureGraphStyles() {
    if (document.getElementById(GRAPH_CSS_ID)) return;
    const link = document.createElement('link');
    link.id = GRAPH_CSS_ID;
    link.rel = 'stylesheet';
    link.href = GRAPH_CSS_HREF;
    document.head.append(link);
}

function bindRuntime(runtime) {
    const form = runtime.host.querySelector('#knowledge-graph-controls');
    const canvasHost = runtime.host.querySelector('#knowledge-graph-canvas');
    const results = runtime.host.querySelector('#knowledge-graph-results');
    const detail = runtime.host.querySelector('#knowledge-graph-detail');

    listen(runtime, form, 'submit', async (event) => {
        event.preventDefault();
        const filters = readGraphFilters(form);
        runtime.onFiltersChanged?.(filters);
        await loadGraph(runtime, filters);
    });

    listen(runtime, form, 'input', (event) => {
        if (event.target?.name === 'search') {
            updateSearchResults(runtime, event.target.value);
        }
    });

    listen(runtime, runtime.host, 'click', async (event) => {
        const actionButton = event.target.closest('[data-graph-action]');
        if (actionButton?.dataset.graphAction === 'reset') {
            if (runtime.graph) {
                runtime.graph.zoomToFit?.(480, 48);
            } else {
                await loadGraph(runtime, runtime.filters);
            }
            return;
        }
        if (actionButton?.dataset.graphAction === 'pause') {
            togglePause(runtime, actionButton);
            return;
        }
        if (actionButton?.dataset.graphAction === 'retry') {
            await loadGraph(runtime, runtime.filters);
            return;
        }

        const focusButton = event.target.closest('[data-graph-focus]');
        if (focusButton) {
            focusNode(runtime, focusButton.dataset.graphFocus);
            results.hidden = true;
            return;
        }

        const assetButton = event.target.closest('[data-graph-open-asset]');
        if (assetButton && runtime.openAsset) {
            await runtime.openAsset(Number(assetButton.dataset.graphOpenAsset));
            return;
        }

        const neighborButton = event.target.closest('[data-graph-neighbors]');
        if (neighborButton) {
            showNeighborOnly(runtime, neighborButton.dataset.graphNeighbors);
            return;
        }

        const pagesButton = event.target.closest('[data-graph-toggle-pages]');
        if (pagesButton) {
            const node = runtime.data.nodes.find((item) => item.id === pagesButton.dataset.graphTogglePages);
            if (node) await toggleChapterPages(runtime, node);
        }
    });

    listen(runtime, globalThis, 'resize', () => {
        runtime.graph?.zoomToFit?.(240, 48);
    });

    detail.innerHTML = renderNodeDetails(null);
    canvasHost.innerHTML = viewState('loading', '正在生成知识资产图谱');
    renderIcons();
}

function listen(runtime, target, eventName, handler) {
    target.addEventListener(eventName, handler);
    runtime.listeners.push([target, eventName, handler]);
}

async function loadGraph(runtime, filters) {
    const canvasHost = runtime.host.querySelector('#knowledge-graph-canvas');
    const generation = ++runtime.loadGeneration;
    runtime.filters = { ...DEFAULT_FILTERS, ...filters };
    runtime.expandedChapters.clear();
    runtime.loadingChapters.clear();
    canvasHost.innerHTML = viewState('loading', '正在读取知识图谱数据');
    renderIcons();

    try {
        const payload = await runtime.api.get('/knowledge-graph', runtime.filters);
        if (generation !== runtime.loadGeneration) return;
        runtime.data = normalizeGraph(payload);
        runtime.selectedNode = null;
        runtime.host.querySelector('#knowledge-graph-stats').innerHTML = renderGraphStats(runtime.data.stats, runtime.data.meta);
        runtime.host.querySelector('#knowledge-graph-detail').innerHTML = renderNodeDetails(null);
        drawGraph(runtime, runtime.data);
    } catch (error) {
        if (generation !== runtime.loadGeneration) return;
        runtime.graph?._destructor?.();
        runtime.graph = null;
        canvasHost.innerHTML = `${viewState('error', '知识图谱加载失败', error.message || String(error))}<button class="button button--secondary" type="button" data-graph-action="retry">重试</button>`;
        runtime.toast?.(error.message || '知识图谱加载失败', 'error');
        renderIcons();
    }
}

function normalizeGraph(payload = {}) {
    return prepareSphericalHierarchyGraph(payload);
}

export function prepareRadialHierarchyGraph(payload = {}) {
    return prepareSphericalHierarchyGraph(payload);
}

export function prepareSphericalHierarchyGraph(payload = {}) {
    const rawNodes = Array.isArray(payload.nodes) ? payload.nodes : [];
    const visibleNodes = rawNodes
        .map((node) => ({ ...node, ringColor: ragColor(node) }));
    const nodeIds = new Set(visibleNodes.map((node) => node.id));
    const visibleLinks = Array.isArray(payload.links)
        ? payload.links.filter((link) => {
            const source = linkId(link.source);
            const target = linkId(link.target);
            return nodeIds.has(source) && nodeIds.has(target);
        })
        : [];

    const positionedNodes = applySphericalHierarchyLayout(visibleNodes, visibleLinks);

    return {
        nodes: positionedNodes,
        links: visibleLinks,
        stats: {
            ...(payload.stats || {}),
            node_count: positionedNodes.length,
            link_count: visibleLinks.length,
        },
        meta: {
            ...(payload.meta || {}),
            center_node: 'DrvDocs',
            layout: 'spherical-hierarchy',
        },
    };
}

export function buildChapterExpandFilters(node, currentFilters = {}) {
    if (node?.type !== 'chapter') return null;

    const filters = { ...currentFilters, limit: '800', include_pages: '1' };
    delete filters.chapter_id;
    delete filters.direct_pages;
    if (node.bookshelf_id != null && String(node.bookshelf_id) !== '') {
        filters.bookshelf_id = String(node.bookshelf_id);
    }

    const chapterId = Number(node.chapter_id || 0);
    if (chapterId > 0) {
        filters.chapter_id = String(chapterId);
        return filters;
    }

    if (node.direct_pages === true && node.book_id != null && String(node.book_id) !== '') {
        filters.book_id = String(node.book_id);
        filters.direct_pages = '1';
        return filters;
    }

    return null;
}

export function mergeChapterExpansion(graph, chapter, payload = {}) {
    const chapterId = String(chapter?.id || '');
    const pageById = new Map(
        (Array.isArray(payload.nodes) ? payload.nodes : [])
            .filter((node) => node.type === 'page')
            .map((node) => [String(node.id), node]),
    );
    const pageLinks = (Array.isArray(payload.links) ? payload.links : []).filter((link) => {
        const source = linkId(link.source);
        const target = linkId(link.target);
        return source === chapterId && pageById.has(target);
    });
    const pageIds = [...new Set(pageLinks.map((link) => linkId(link.target)))];
    const allowedPages = pageIds.map((id) => pageById.get(id)).filter(Boolean);
    const nodesById = new Map((graph.nodes || []).map((node) => [String(node.id), node]));
    for (const page of allowedPages) nodesById.set(String(page.id), page);
    if (nodesById.has(chapterId)) {
        nodesById.set(chapterId, { ...nodesById.get(chapterId), pages_expanded: pageIds.length > 0 });
    }

    const linksByKey = new Map();
    for (const link of [...(graph.links || []), ...pageLinks]) {
        linksByKey.set(`${linkId(link.source)}>${linkId(link.target)}:${link.type || ''}`, {
            ...link,
            source: linkId(link.source),
            target: linkId(link.target),
        });
    }

    return {
        data: prepareRadialHierarchyGraph({
            ...graph,
            nodes: [...nodesById.values()],
            links: [...linksByKey.values()],
        }),
        pageIds,
    };
}

export function collapseChapterExpansion(graph, pageIds = []) {
    const removed = new Set(pageIds.map(String));
    const parentIds = new Set(
        (graph.links || [])
            .filter((link) => removed.has(linkId(link.target)))
            .map((link) => linkId(link.source)),
    );
    return prepareRadialHierarchyGraph({
        ...graph,
        nodes: (graph.nodes || [])
            .filter((node) => !removed.has(String(node.id)))
            .map((node) => parentIds.has(String(node.id)) ? { ...node, pages_expanded: false } : node),
        links: (graph.links || []).filter((link) => !removed.has(linkId(link.source)) && !removed.has(linkId(link.target))),
    });
}

function drawGraph(runtime, data) {
    const canvasHost = runtime.host.querySelector('#knowledge-graph-canvas');
    canvasHost.replaceChildren();

    if (!data.nodes.length) {
        canvasHost.innerHTML = viewState('empty', '暂无可展示的知识节点');
        renderIcons();
        return;
    }

    runtime.graph?._destructor?.();
    runtime.graph = ForceGraph3D()(canvasHost)
        .backgroundColor('rgba(0,0,0,0)')
        .graphData({ nodes: data.nodes, links: data.links })
        .nodeColor(nodeColor)
        .nodeVal(nodeSize)
        .nodeLabel(nodeLabel)
        .linkColor((link) => link.type === 'contains' ? 'rgba(148, 171, 210, .36)' : 'rgba(84, 176, 255, .46)')
        .onNodeHover((node) => highlightNeighbors(runtime, node))
        .onNodeClick((node) => selectNode(runtime, node))
        .onNodeDblClick((node) => handleNodeDoubleClick(runtime, node))
        .onNodeDragEnd((node) => {
            node.fx = node.x;
            node.fy = node.y;
            node.fz = node.z;
        })
        .cooldownTicks(260);

    runtime.graph.zoomToFit?.(640, 52);
}

function selectNode(runtime, node) {
    runtime.selectedNode = node;
    runtime.host.querySelector('#knowledge-graph-detail').innerHTML = renderNodeDetails(node, neighborsOf(runtime.data, node.id));
    renderIcons();
}

function openNode(runtime, node) {
    if (node?.url) {
        globalThis.open(node.url, '_blank', 'noopener,noreferrer');
        return;
    }
    if (node?.asset_id && runtime.openAsset) {
        runtime.openAsset(Number(node.asset_id));
    }
}

async function handleNodeDoubleClick(runtime, node) {
    if (node?.type === 'chapter') {
        await toggleChapterPages(runtime, node);
        return;
    }
    openNode(runtime, node);
}

async function toggleChapterPages(runtime, node) {
    const nodeId = String(node?.id || '');
    if (!nodeId || runtime.loadingChapters.has(nodeId)) return;

    const expandedPageIds = runtime.expandedChapters.get(nodeId);
    if (expandedPageIds) {
        runtime.data = collapseChapterExpansion(runtime.data, expandedPageIds);
        runtime.expandedChapters.delete(nodeId);
        refreshGraphData(runtime, nodeId);
        runtime.toast?.(`已收起 ${expandedPageIds.length} 个页面`, 'success');
        return;
    }

    const filters = buildChapterExpandFilters(node, runtime.filters);
    if (!filters) {
        runtime.toast?.('该章节缺少可用的章节或书籍标识，无法读取页面。', 'error');
        return;
    }

    runtime.loadingChapters.add(nodeId);
    const generation = runtime.loadGeneration;
    selectNode(runtime, { ...node, pages_loading: true });
    try {
        const payload = await runtime.api.get('/knowledge-graph', filters);
        if (generation !== runtime.loadGeneration) return;
        const expansion = mergeChapterExpansion(runtime.data, node, payload);
        if (expansion.pageIds.length === 0) {
            runtime.toast?.('该分组下没有可见页面。', 'info');
            selectNode(runtime, node);
            return;
        }
        runtime.data = expansion.data;
        runtime.expandedChapters.set(nodeId, expansion.pageIds);
        refreshGraphData(runtime, nodeId);
        runtime.toast?.(`已展开 ${expansion.pageIds.length} 个页面`, 'success');
    } catch (error) {
        if (generation !== runtime.loadGeneration) return;
        runtime.toast?.(error.message || '章节页面读取失败', 'error');
        selectNode(runtime, node);
    } finally {
        runtime.loadingChapters.delete(nodeId);
    }
}

function refreshGraphData(runtime, selectedNodeId = '') {
    runtime.graph?.graphData?.({ nodes: runtime.data.nodes, links: runtime.data.links });
    if (runtime.paused) runtime.graph?.pauseAnimation?.();
    runtime.graph?.zoomToFit?.(360, 48);
    runtime.host.querySelector('#knowledge-graph-stats').innerHTML = renderGraphStats(runtime.data.stats, runtime.data.meta);
    const selected = runtime.data.nodes.find((item) => item.id === selectedNodeId);
    if (selected) selectNode(runtime, selected);
}

function focusNode(runtime, id) {
    const node = runtime.data.nodes.find((item) => item.id === id);
    if (!node) return;
    selectNode(runtime, node);
    runtime.graph?.cameraPosition?.({ x: node.x || 0, y: node.y || 0, z: 220 }, node, 500);
}

function updateSearchResults(runtime, rawQuery) {
    const results = runtime.host.querySelector('#knowledge-graph-results');
    const query = String(rawQuery || '').trim().toLowerCase();
    if (!query) {
        results.hidden = true;
        results.innerHTML = '';
        return;
    }

    const matches = runtime.data.nodes.filter((node) => {
        const target = [
            node.title,
            node.type,
            node.bookshelf_name,
            node.book_name,
            node.chapter_name,
            node.owner_name,
            ...(node.tags || []),
        ].join(' ').toLowerCase();
        return target.includes(query);
    });
    results.innerHTML = renderSearchResults(matches);
    results.hidden = false;
}

function highlightNeighbors(runtime, node) {
    const ids = new Set(node ? neighborsOf(runtime.data, node.id).map((item) => item.id) : []);
    if (node) ids.add(node.id);
    for (const graphNode of runtime.data.nodes) {
        graphNode.dimmed = ids.size > 0 && !ids.has(graphNode.id);
    }
}

function showNeighborOnly(runtime, id) {
    const node = runtime.data.nodes.find((item) => item.id === id);
    if (!node) return;
    const ids = new Set([id, ...neighborsOf(runtime.data, id).map((item) => item.id)]);
    const scoped = {
        nodes: runtime.data.nodes.filter((item) => ids.has(item.id)),
        links: runtime.data.links.filter((link) => ids.has(link.source) && ids.has(link.target)),
        stats: runtime.data.stats,
        meta: runtime.data.meta,
    };
    drawGraph(runtime, scoped);
    selectNode(runtime, node);
}

function neighborsOf(data, id) {
    const ids = new Set();
    for (const link of data.links || []) {
        if (link.source === id) ids.add(link.target);
        if (link.target === id) ids.add(link.source);
    }
    return data.nodes.filter((node) => ids.has(node.id));
}

function applySphericalHierarchyLayout(nodes, links) {
    const parents = parentMap(links);
    const children = childrenMap(links);
    const byId = new Map(nodes.map((node) => [String(node.id), node]));
    const shelfNodes = nodes.filter((node) => node.type === 'bookshelf');
    const shelfDirections = new Map();

    shelfNodes.forEach((node, index) => {
        shelfDirections.set(String(node.id), fibonacciSphereDirection(index, shelfNodes.length, 0.45));
    });

    const directionCache = new Map();
    const directionFor = (node) => {
        const id = String(node.id);
        if (directionCache.has(id)) return directionCache.get(id);
        if (node.type === 'bookshelf') {
            const direct = shelfDirections.get(id) || fibonacciSphereDirection(0, 1, 0.45);
            directionCache.set(id, direct);
            return direct;
        }

        const parentId = parents.get(id);
        const parent = byId.get(parentId);
        const parentDirection = parent ? directionFor(parent) : fibonacciSphereDirection(stableIndex(id), 97, 0.45);
        const siblings = children.get(parentId) || [id];
        const siblingIndex = Math.max(0, siblings.indexOf(id));
        const level = HIERARCHY_LEVELS[node.type] || 4;
        const spread = ({ 2: 0.38, 3: 0.25, 4: 0.16 })[level] || 0.18;
        const direction = clusterDirection(parentDirection, siblingIndex, siblings.length, spread, stablePhase(id));
        directionCache.set(id, direction);
        return direction;
    };

    return nodes.map((node) => {
        const level = HIERARCHY_LEVELS[node.type] || 4;
        if (node.type === 'root' || String(node.id || '').startsWith('root:')) {
            return {
                ...node,
                title: 'DrvDocs',
                layout_mode: 'spherical-hierarchy',
                layout_variant: 'spherical-cloud',
                layout_level: 0,
                layout_radius: 0,
                fx: 0, fy: 0, fz: 0,
                x: 0, y: 0, z: 0,
                vx: 0, vy: 0, vz: 0,
            };
        }
        const radius = HIERARCHY_RADII[node.type] || (92 + level * 82);
        const direction = directionFor(node);
        const jitter = deterministicJitter(String(node.id), level === 4 ? 13 : 8);
        const x = direction.x * radius + jitter.x;
        const y = direction.y * radius + jitter.y;
        const z = direction.z * radius + jitter.z;

        return {
            ...node,
            layout_mode: 'spherical-hierarchy',
            layout_variant: 'spherical-cloud',
            layout_level: level,
            layout_radius: radius,
            layout_direction: direction,
            fx: x, fy: y, fz: z,
            x, y, z,
            vx: 0, vy: 0, vz: 0,
        };
    });
}

function fibonacciSphereDirection(index, total, phase = 0) {
    const count = Math.max(1, total);
    if (count === 1) return normalizeVector({ x: 0.72, y: 0.28, z: 0.63 });
    const goldenAngle = Math.PI * (3 - Math.sqrt(5));
    const y = 1 - (index / (count - 1)) * 2;
    const horizontal = Math.sqrt(Math.max(0, 1 - y * y));
    const theta = goldenAngle * index + phase;
    return normalizeVector({ x: Math.cos(theta) * horizontal, y, z: Math.sin(theta) * horizontal });
}

function clusterDirection(parent, index, total, spread, phase = 0) {
    const base = normalizeVector(parent);
    const reference = Math.abs(base.y) < 0.88 ? { x: 0, y: 1, z: 0 } : { x: 1, y: 0, z: 0 };
    const tangentA = normalizeVector(cross(base, reference));
    const tangentB = normalizeVector(cross(base, tangentA));
    const goldenAngle = Math.PI * (3 - Math.sqrt(5));
    const radial = total <= 1 ? 0 : spread * Math.sqrt((index + 0.55) / Math.max(1, total));
    const angle = goldenAngle * index + phase;
    return normalizeVector({
        x: base.x + tangentA.x * Math.cos(angle) * radial + tangentB.x * Math.sin(angle) * radial,
        y: base.y + tangentA.y * Math.cos(angle) * radial + tangentB.y * Math.sin(angle) * radial,
        z: base.z + tangentA.z * Math.cos(angle) * radial + tangentB.z * Math.sin(angle) * radial,
    });
}

function cross(a, b) {
    return { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x };
}

function normalizeVector(value) {
    const length = Math.hypot(value.x || 0, value.y || 0, value.z || 0) || 1;
    return { x: (value.x || 0) / length, y: (value.y || 0) / length, z: (value.z || 0) / length };
}

function stableHash(value) {
    let hash = 2166136261;
    for (const char of String(value || '')) {
        hash ^= char.codePointAt(0);
        hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
}

function stableIndex(value) {
    return stableHash(value) % 97;
}

function stablePhase(value) {
    return (stableHash(value) % 6283) / 1000;
}

function deterministicJitter(value, amount) {
    const hash = stableHash(value);
    return {
        x: (((hash & 255) / 255) - 0.5) * amount,
        y: ((((hash >>> 8) & 255) / 255) - 0.5) * amount,
        z: ((((hash >>> 16) & 255) / 255) - 0.5) * amount,
    };
}

function parentMap(links) {
    const parents = new Map();
    for (const link of links) {
        parents.set(linkId(link.target), linkId(link.source));
    }
    return parents;
}

function childrenMap(links) {
    const children = new Map();
    for (const link of links) {
        const parentId = linkId(link.source);
        const childId = linkId(link.target);
        if (!children.has(parentId)) children.set(parentId, []);
        if (!children.get(parentId).includes(childId)) children.get(parentId).push(childId);
    }
    for (const ids of children.values()) {
        ids.sort((left, right) => String(left).localeCompare(String(right), 'zh-Hans-CN'));
    }
    return children;
}

function linkId(value) {
    return typeof value === 'object' && value !== null ? String(value.id) : String(value || '');
}

function togglePause(runtime, button) {
    runtime.paused = !runtime.paused;
    if (runtime.paused) {
        runtime.graph?.pauseAnimation?.();
        button.innerHTML = '继续布局';
    } else {
        runtime.graph?.resumeAnimation?.();
        button.innerHTML = '暂停布局';
    }
    renderIcons();
}

export const GRAPH_VERSION = '20260827-sphere-i';

export const REVIEW_COLORS = Object.freeze({
    pending: '#8292a8',
    partial: '#f0ad4e',
    approved: '#4f8cff',
    verified: '#36c98f',
    rejected: '#ef6262',
    deprecated: '#505864',
    unknown: '#8a75ba',
});

export const RAG_COLORS = Object.freeze({
    not_ingested: 'rgba(130,146,168,.22)',
    uploaded: '#4f8cff',
    unstart: '#6aa8ff',
    parsing: '#35cde6',
    parsed: '#30d5aa',
    failed: '#ef6262',
    stale: '#f0ad4e',
    unknown: 'rgba(180,190,210,.34)',
});

export const TYPE_COLORS = Object.freeze({
    root: '#42d7ff',
    bookshelf: '#35c98f',
    book: '#4f8cff',
    chapter: '#f0ad4e',
    page: '#aa7cff',
    unknown: '#8292a8',
});

export const TYPE_LABELS = Object.freeze({
    root: '根节点',
    bookshelf: '书架',
    book: '书籍',
    chapter: '章节',
    page: '页面',
});

export const REVIEW_LABELS = Object.freeze({
    pending: '待治理',
    partial: '部分审阅',
    approved: '已审阅',
    verified: '已验证',
    rejected: '已退回',
    deprecated: '已废弃',
    unknown: '未知',
});

export const RAG_LABELS = Object.freeze({
    not_ingested: '未入库',
    uploaded: '已上传',
    unstart: '待解析',
    parsing: '解析中',
    parsed: '可召回',
    failed: '失败',
    stale: '待更新',
    unknown: '未知',
});

export function nodeColor(node) {
    return TYPE_COLORS[node?.type] || TYPE_COLORS.unknown;
}

export function ragColor(node) {
    return RAG_COLORS[node?.rag_status] || RAG_COLORS.unknown;
}

export function nodeSize(node) {
    const typeBase = { root: 18, bookshelf: 12, book: 8, chapter: 6, page: 3 };
    const count = Math.max(1, Number(node?.page_count || 1));
    return (typeBase[node?.type] || 4) + Math.log(count + 1) * 1.4;
}

export function nodeLabel(node) {
    return `${TYPE_LABELS[node?.type] || node?.type || '节点'} · ${node?.title || '未命名'}`;
}

const now = new Date();
const day = 86400000;

export const demoData = {
    summary: {
        source_assets: 248,
        wiki_assets: 176,
        pending_reviews: 12,
        rag_ready: 158,
        open_gaps: 7,
        permissions: { can_write: true },
        integrations: { ragflow: { configured: true, web_url: 'http://10.222.120.25/' } },
    },
    bookshelves: [
        { id: 'manuals', name: '芯片手册', page_count: 2 },
        { id: 'cases', name: '驱动故障案例库', page_count: 3 },
        { id: 'platform', name: '平台流程文档', page_count: 1 },
    ],
    reviewUnits: {
        total: 5,
        items: [
            { unit_key: 'chapter:manuals:301', unit_type: 'chapter', unit_title: 'DDR 配置', bookshelf_id: 'manuals', bookshelf_name: '芯片手册', book_name: 'HiSilicon SDK', member_count: 2, asset_count: 2, review_status: 'pending_review', allowed_actions: ['reviewed', 'need_fix', 'deprecated'] },
            { unit_key: 'chapter:manuals:302', unit_type: 'chapter', unit_title: 'BootROM 启动', bookshelf_id: 'manuals', bookshelf_name: '芯片手册', book_name: 'HiSilicon SDK', member_count: 1, asset_count: 1, review_status: 'draft', allowed_actions: ['pending_review', 'deprecated'] },
            { unit_key: 'page:cases:317', unit_type: 'page', unit_title: 'I2C 设备无应答故障案例', bookshelf_id: 'cases', bookshelf_name: '驱动故障案例库', book_name: '总线故障案例', member_count: 1, asset_count: 1, publishable_count: 1, can_publish: true, review_status: 'reviewed', allowed_actions: ['verified', 'need_recheck', 'deprecated'] },
            { unit_key: 'page:cases:328', unit_type: 'page', unit_title: 'PCIe 链路训练异常定位指南', bookshelf_id: 'cases', bookshelf_name: '驱动故障案例库', book_name: '总线故障案例', member_count: 1, asset_count: 1, publishable_count: 1, can_publish: true, review_status: 'verified', allowed_actions: ['need_recheck', 'deprecated'] },
            { unit_key: 'page:platform:251', unit_type: 'page', unit_title: '平台版本发布流程', bookshelf_id: 'platform', bookshelf_name: '平台流程文档', book_name: '平台发布流程', member_count: 1, asset_count: 1, publishable_count: 1, can_publish: true, review_status: 'reviewed', allowed_actions: ['verified', 'need_recheck', 'deprecated'] },
        ],
    },
    assets: {
        total: 6, page: 1, page_size: 25,
        items: [
            { asset_id: 106, page_id: 328, asset_type: 'wiki', title: 'PCIe 链路训练异常定位指南', material_type: 'tech_notes', current_version: 4, updated_at: new Date(now - day).toISOString(), metadata_json: '{"module":"PCIe","review_status":"verified","rag_status":"ready"}' },
            { asset_id: 105, page_id: 317, asset_type: 'wiki', title: 'I2C 设备无应答故障案例', material_type: 'cases', current_version: 3, updated_at: new Date(now - day * 2).toISOString(), metadata_json: '{"module":"I2C","review_status":"reviewed","rag_status":"ready"}' },
            { asset_id: 104, page_id: 302, asset_type: 'wiki', title: 'DDR 时序参数配置手册', material_type: 'manuals', current_version: 2, updated_at: new Date(now - day * 3).toISOString(), metadata_json: '{"module":"DDR","review_status":"pending_review","rag_status":"parsing"}' },
            { asset_id: 103, page_id: 298, asset_type: 'source', title: 'BootROM 启动日志原始记录', material_type: 'docs', current_version: 1, updated_at: new Date(now - day * 4).toISOString(), metadata_json: '{"module":"BootROM","review_status":"draft","rag_status":"blocked"}' },
            { asset_id: 102, page_id: 276, asset_type: 'wiki', title: 'CAN 总线错误帧处理', material_type: 'tech_notes', current_version: 6, updated_at: new Date(now - day * 6).toISOString(), metadata_json: '{"module":"CAN","review_status":"need_fix","rag_status":"blocked"}' },
            { asset_id: 101, page_id: 251, asset_type: 'wiki', title: '平台版本发布流程', material_type: 'project_docs', current_version: 5, updated_at: new Date(now - day * 8).toISOString(), metadata_json: '{"module":"Platform","review_status":"reviewed","rag_status":"ready"}' },
        ],
    },
    contributions: [
        { owner_id: 12, owner_name: 'A04217', document_count: 31, asset_count: 42, bookshelf_id: 'cases' },
        { owner_id: 7, owner_name: 'A03882', document_count: 26, asset_count: 35, bookshelf_id: 'cases' },
        { owner_id: 18, owner_name: 'A05109', document_count: 19, asset_count: 27, bookshelf_id: 'manuals' },
        { owner_id: 4, owner_name: 'A02943', document_count: 14, asset_count: 18, bookshelf_id: 'platform' },
    ],
    quality: [
        { quality_check_id: 8, asset_id: 102, asset_title: 'CAN 总线错误帧处理.md', current_version: 6, bookshelf_id: 'cases', score: 58, gate_result: 'blocked', conclusion: '无法入库：缺少可追溯来源；质量总分低于 70 分。请按修复建议处理后重新检查。', problems: [{ code: 'missing_source', severity: '阻断', title: '缺少可追溯来源', deduction: 40, blocking: true, fix: '补充有效来源链接或来源文档，确保结论可以核验。' }, { code: 'missing:platform', severity: '警告', title: '缺少适用平台', deduction: 8, blocking: false, fix: '填写 platform，明确适用芯片、平台或产品系列。' }], warnings_json: '["missing:platform"]', reject_reasons_json: '["missing_source","score_below_minimum"]', checked_at: new Date(now - 3600000).toISOString() },
        { unit_key: 'chapter:manuals:301', unit_type: 'chapter', unit_title: 'DDR 配置', bookshelf_id: 'manuals', bookshelf_name: '芯片手册', book_name: 'HiSilicon SDK', member_count: 2, checked_page_count: 2, issue_page_count: 2, blocked_page_count: 1, score: 64, gate_result: 'blocked', conclusion: '本章节无法通过质量门禁：2/2 个页面存在问题，其中 1 个页面含硬阻断。修复全部阻断项并重新检查后，才能通过章节审核并正式入库。', checked_at: new Date(now - 7200000).toISOString(), members: [
            { page_id: 302, page_title: 'DDR 时序参数配置手册', asset_id: 104, asset_title: 'DDR 时序参数配置手册.md', current_version: 2, score: 76, gate_result: 'warning', conclusion: '当前未触发硬阻断，但存在质量扣分项；建议修复后再进入正式知识库。', problems: [{ code: 'missing:owner', severity: '警告', title: '缺少负责人', deduction: 8, blocking: false, fix: '在文章 Front Matter 中填写 owner，明确知识负责人。' }] },
            { page_id: 298, page_title: 'DDR 训练原始记录', asset_id: 103, asset_title: 'DDR 训练原始记录.md', current_version: 1, score: 64, gate_result: 'blocked', conclusion: '无法入库：当前记录是原始资料。请先生成可审阅 Wiki。', problems: [{ code: 'source_asset_review_only', severity: '阻断', title: '当前记录是原始资料', deduction: null, blocking: true, fix: '先生成 Wiki 条目，原始资料本身不能正式发布到 RAGFlow。' }] },
        ] },
    ],
    rag: [
    { rag_snapshot_id: 9, asset_id: 106, asset_title: 'PCIe 链路训练异常定位指南.md', current_version: 4, bookshelf_id: 'cases', dataset_id: 'tech-notes', document_id: 'doc-903', parse_status: 'ready', chunk_count: 28, last_action_result: 'updated', review_status: 'verified', can_publish: true, checked_at: new Date(now - 1800000).toISOString() },
    { rag_snapshot_id: 8, asset_id: 105, asset_title: 'I2C 设备无应答故障案例.md', current_version: 3, bookshelf_id: 'cases', dataset_id: 'cases', document_id: 'doc-887', parse_status: 'ready', chunk_count: 16, last_action_result: 'skipped', review_status: 'reviewed', can_publish: true, checked_at: new Date(now - 3000000).toISOString() },
    { rag_snapshot_id: 7, asset_id: 104, asset_title: 'DDR 时序参数配置手册.md', current_version: 2, bookshelf_id: 'manuals', dataset_id: 'manuals', document_id: 'doc-866', parse_status: 'parsing', chunk_count: 0, last_action_result: 'created', review_status: 'pending_review', can_publish: false, checked_at: new Date(now - 4200000).toISOString() },
    { rag_snapshot_id: 6, asset_id: 102, asset_title: 'CAN 总线错误帧处理.md', current_version: 6, bookshelf_id: 'cases', dataset_id: 'tech-notes', document_id: null, parse_status: 'blocked', chunk_count: 0, last_action_result: null, review_status: 'need_fix', can_publish: false, checked_at: new Date(now - 7200000).toISOString() },
    ],
    knowledgeGraph: {
        nodes: [
            { id: 'root:knowledge-base', type: 'root', title: 'DrvDocs 知识库', review_status: 'verified', rag_status: 'parsed', quality_status: 'passed', page_count: 6, content_size: 6, tags: [] },
            { id: 'bookshelf:manuals', type: 'bookshelf', title: '芯片手册', bookshelf_id: 'manuals', bookshelf_name: '芯片手册', review_status: 'partial', rag_status: 'parsing', quality_status: 'warning', page_count: 2, content_size: 420, tags: ['manual'] },
            { id: 'bookshelf:cases', type: 'bookshelf', title: '驱动故障案例库', bookshelf_id: 'cases', bookshelf_name: '驱动故障案例库', review_status: 'verified', rag_status: 'parsed', quality_status: 'passed', page_count: 3, content_size: 680, tags: ['case'] },
            { id: 'bookshelf:platform', type: 'bookshelf', title: '平台流程文档', bookshelf_id: 'platform', bookshelf_name: '平台流程文档', review_status: 'approved', rag_status: 'parsed', quality_status: 'passed', page_count: 1, content_size: 180, tags: ['process'] },
            { id: 'book:sdk', type: 'book', title: 'HiSilicon SDK', bookshelf_name: '芯片手册', book_id: 'sdk', book_name: 'HiSilicon SDK', review_status: 'partial', rag_status: 'parsing', quality_status: 'warning', page_count: 2, content_size: 420, tags: ['sdk'] },
            { id: 'book:cases', type: 'book', title: '总线故障案例', bookshelf_name: '驱动故障案例库', book_id: 'cases', book_name: '总线故障案例', review_status: 'verified', rag_status: 'parsed', quality_status: 'passed', page_count: 3, content_size: 680, tags: ['i2c', 'pcie', 'can'] },
            { id: 'book:release', type: 'book', title: '平台发布流程', bookshelf_name: '平台流程文档', book_id: 'release', book_name: '平台发布流程', review_status: 'approved', rag_status: 'parsed', quality_status: 'passed', page_count: 1, content_size: 180, tags: ['release'] },
            { id: 'chapter:sdk:ddr', type: 'chapter', title: 'DDR 配置', bookshelf_name: '芯片手册', book_id: 'sdk', book_name: 'HiSilicon SDK', chapter_id: 301, chapter_name: 'DDR 配置', review_status: 'pending', rag_status: 'parsing', quality_status: 'warning', page_count: 1, asset_count: 1, has_asset: true, content_size: 210, owner_name: 'A05109', updated_at: new Date(now - day * 3).toISOString(), tags: ['ddr', 'timing'] },
            { id: 'chapter:sdk:bootrom', type: 'chapter', title: 'BootROM 启动', bookshelf_name: '芯片手册', book_id: 'sdk', book_name: 'HiSilicon SDK', chapter_id: 302, chapter_name: 'BootROM 启动', review_status: 'rejected', rag_status: 'not_ingested', quality_status: 'failed', page_count: 1, asset_count: 1, has_asset: true, content_size: 210, owner_name: 'A02943', updated_at: new Date(now - day * 4).toISOString(), tags: ['bootrom'] },
            { id: 'chapter:cases:direct', type: 'chapter', title: '书籍直属页面', bookshelf_name: '驱动故障案例库', book_id: 'cases', book_name: '总线故障案例', chapter_id: null, chapter_name: '书籍直属页面', direct_pages: true, review_status: 'approved', rag_status: 'parsed', quality_status: 'passed', page_count: 3, asset_count: 3, has_asset: true, content_size: 680, tags: ['i2c', 'pcie', 'can'] },
            { id: 'chapter:release:direct', type: 'chapter', title: '书籍直属页面', bookshelf_name: '平台流程文档', book_id: 'release', book_name: '平台发布流程', chapter_id: null, chapter_name: '书籍直属页面', direct_pages: true, review_status: 'approved', rag_status: 'parsed', quality_status: 'passed', page_count: 1, asset_count: 1, has_asset: true, content_size: 180, tags: ['release'] },
            { id: 'page:302', type: 'page', title: 'DDR 时序参数配置手册', asset_id: 104, page_id: 302, bookshelf_name: '芯片手册', book_id: 'sdk', book_name: 'HiSilicon SDK', chapter_id: 301, chapter_name: 'DDR 配置', review_status: 'pending', rag_status: 'parsing', quality_status: 'warning', page_count: 1, asset_count: 1, has_asset: true, content_size: 210, owner_name: 'A05109', updated_at: new Date(now - day * 3).toISOString(), tags: ['ddr', 'timing'], url: '/drvdocs/page/ddr-timing' },
            { id: 'page:298', type: 'page', title: 'BootROM 启动日志原始记录', asset_id: 103, page_id: 298, bookshelf_name: '芯片手册', book_id: 'sdk', book_name: 'HiSilicon SDK', chapter_id: 302, chapter_name: 'BootROM 启动', review_status: 'rejected', rag_status: 'not_ingested', quality_status: 'failed', page_count: 1, asset_count: 1, has_asset: true, content_size: 210, owner_name: 'A02943', updated_at: new Date(now - day * 4).toISOString(), tags: ['bootrom'], url: '/drvdocs/page/bootrom-log' },
            { id: 'page:317', type: 'page', title: 'I2C 设备无应答故障案例', asset_id: 105, page_id: 317, bookshelf_name: '驱动故障案例库', book_id: 'cases', book_name: '总线故障案例', chapter_id: null, chapter_name: '书籍直属页面', direct_pages: true, review_status: 'approved', rag_status: 'parsed', quality_status: 'passed', page_count: 1, asset_count: 1, has_asset: true, content_size: 180, owner_name: 'A03882', updated_at: new Date(now - day * 2).toISOString(), tags: ['i2c'], url: '/drvdocs/page/i2c-case' },
            { id: 'page:328', type: 'page', title: 'PCIe 链路训练异常定位指南', asset_id: 106, page_id: 328, bookshelf_name: '驱动故障案例库', book_id: 'cases', book_name: '总线故障案例', chapter_id: null, chapter_name: '书籍直属页面', direct_pages: true, review_status: 'verified', rag_status: 'parsed', quality_status: 'passed', page_count: 1, asset_count: 1, has_asset: true, content_size: 260, owner_name: 'A04217', updated_at: new Date(now - day).toISOString(), tags: ['pcie'], url: '/drvdocs/page/pcie-training' },
            { id: 'page:276', type: 'page', title: 'CAN 总线错误帧处理', asset_id: 102, page_id: 276, bookshelf_name: '驱动故障案例库', book_id: 'cases', book_name: '总线故障案例', chapter_id: null, chapter_name: '书籍直属页面', direct_pages: true, review_status: 'rejected', rag_status: 'failed', quality_status: 'failed', page_count: 1, asset_count: 1, has_asset: true, content_size: 240, owner_name: 'A03882', updated_at: new Date(now - day * 6).toISOString(), tags: ['can'], url: '/drvdocs/page/can-error-frame' },
            { id: 'page:251', type: 'page', title: '平台版本发布流程', asset_id: 101, page_id: 251, bookshelf_name: '平台流程文档', book_id: 'release', book_name: '平台发布流程', chapter_id: null, chapter_name: '书籍直属页面', direct_pages: true, review_status: 'approved', rag_status: 'parsed', quality_status: 'passed', page_count: 1, asset_count: 1, has_asset: true, content_size: 180, owner_name: 'A04217', updated_at: new Date(now - day * 8).toISOString(), tags: ['release'], url: '/drvdocs/page/release-flow' },
        ],
        links: [
            { source: 'root:knowledge-base', target: 'bookshelf:manuals', type: 'contains', weight: 2, label: '包含' },
            { source: 'root:knowledge-base', target: 'bookshelf:cases', type: 'contains', weight: 3, label: '包含' },
            { source: 'root:knowledge-base', target: 'bookshelf:platform', type: 'contains', weight: 1, label: '包含' },
            { source: 'bookshelf:manuals', target: 'book:sdk', type: 'contains', weight: 2, label: '包含' },
            { source: 'bookshelf:cases', target: 'book:cases', type: 'contains', weight: 3, label: '包含' },
            { source: 'bookshelf:platform', target: 'book:release', type: 'contains', weight: 1, label: '包含' },
            { source: 'book:sdk', target: 'chapter:sdk:ddr', type: 'contains', weight: 1, label: '包含' },
            { source: 'book:sdk', target: 'chapter:sdk:bootrom', type: 'contains', weight: 1, label: '包含' },
            { source: 'book:cases', target: 'chapter:cases:direct', type: 'contains', weight: 3, label: '包含' },
            { source: 'book:release', target: 'chapter:release:direct', type: 'contains', weight: 1, label: '包含' },
            { source: 'chapter:sdk:ddr', target: 'page:302', type: 'contains', weight: 1, label: '包含' },
            { source: 'chapter:sdk:bootrom', target: 'page:298', type: 'contains', weight: 1, label: '包含' },
            { source: 'chapter:cases:direct', target: 'page:317', type: 'contains', weight: 1, label: '包含' },
            { source: 'chapter:cases:direct', target: 'page:328', type: 'contains', weight: 1, label: '包含' },
            { source: 'chapter:cases:direct', target: 'page:276', type: 'contains', weight: 1, label: '包含' },
            { source: 'chapter:release:direct', target: 'page:251', type: 'contains', weight: 1, label: '包含' },
        ],
        stats: { node_count: 13, link_count: 12, pending_count: 1, partial_count: 2, approved_count: 3, verified_count: 4, rejected_count: 2, rag_parsed_count: 7, rag_failed_count: 1, isolated_count: 0 },
        meta: { depth: 3, limit: 300, truncated: false, include_pages: true, generated_at: now.toISOString() },
    },
    gaps: [
        { gap_id: 5, title: 'PCIe Gen5 均衡参数缺少可验证案例', missing_content: '需要补充不同板卡下的参数对照。', priority: 'critical', gap_status: 'doing', owner_id: 12, due_at: new Date(now + day * 3).toISOString() },
        { gap_id: 4, title: 'BootROM 错误码 0x31 缺少说明', missing_content: '召回无直接答案。', priority: 'high', gap_status: 'open', owner_id: null, due_at: new Date(now + day * 5).toISOString() },
        { gap_id: 3, title: 'CAN FD 波特率切换风险', missing_content: '缺少限制条件。', priority: 'medium', gap_status: 'closed', owner_id: 7, due_at: new Date(now - day).toISOString() },
    ],
};

function demoKnowledgeGraph(query = {}) {
    const graph = structuredClone(demoData.knowledgeGraph);
    const bookshelfId = query.bookshelf_id == null ? '' : String(query.bookshelf_id);
    const includePages = [true, 1, '1', 'true'].includes(query.include_pages);
    const chapterId = Number(query.chapter_id || 0);
    const directPages = [true, 1, '1', 'true'].includes(query.direct_pages);
    const bookId = query.book_id == null ? '' : String(query.book_id);

    if (bookshelfId) {
        const visibleNodeIds = new Set([`bookshelf:${bookshelfId}`]);
        let changed = true;
        while (changed) {
            changed = false;
            graph.links.forEach((link) => {
                const source = String(link.source);
                const target = String(link.target);
                if (visibleNodeIds.has(source) && !visibleNodeIds.has(target)) {
                    visibleNodeIds.add(target);
                    changed = true;
                }
            });
        }
        visibleNodeIds.add('root:knowledge-base');
        graph.nodes = graph.nodes.filter((node) => visibleNodeIds.has(String(node.id)));
        graph.links = graph.links.filter((link) => visibleNodeIds.has(String(link.source)) && visibleNodeIds.has(String(link.target)));
    }

    const visiblePageIds = new Set(
        graph.nodes
            .filter((node) => {
                if (node.type !== 'page' || !includePages) return false;
                if (chapterId > 0) return Number(node.chapter_id || 0) === chapterId;
                if (directPages) return node.direct_pages === true && String(node.book_id || '') === bookId;
                return true;
            })
            .map((node) => String(node.id)),
    );

    graph.nodes = graph.nodes.filter((node) => node.type !== 'page' || visiblePageIds.has(String(node.id)));
    const nodeIds = new Set(graph.nodes.map((node) => String(node.id)));
    graph.links = graph.links.filter((link) => nodeIds.has(String(link.source)) && nodeIds.has(String(link.target)));
    const linkedNodeIds = new Set(graph.links.flatMap((link) => [String(link.source), String(link.target)]));
    graph.stats = {
        ...graph.stats,
        node_count: graph.nodes.length,
        link_count: graph.links.length,
        pending_count: graph.nodes.filter((node) => ['draft', 'pending', 'pending_review'].includes(node.review_status)).length,
        partial_count: graph.nodes.filter((node) => node.review_status === 'partial').length,
        approved_count: graph.nodes.filter((node) => ['approved', 'reviewed'].includes(node.review_status)).length,
        verified_count: graph.nodes.filter((node) => node.review_status === 'verified').length,
        rejected_count: graph.nodes.filter((node) => ['rejected', 'need_fix', 'deprecated'].includes(node.review_status)).length,
        rag_parsed_count: graph.nodes.filter((node) => ['parsed', 'ready'].includes(node.rag_status)).length,
        rag_failed_count: graph.nodes.filter((node) => node.rag_status === 'failed').length,
        isolated_count: graph.nodes.filter((node) => node.type !== 'root' && !linkedNodeIds.has(String(node.id))).length,
    };
    graph.meta.include_pages = includePages;
    graph.meta.chapter_id = chapterId || null;
    graph.meta.direct_pages = directPages;
    graph.meta.bookshelf_id = bookshelfId || null;
    return graph;
}

function shelfFiltered(items, query = {}) {
    const bookshelfId = query.bookshelf_id == null ? '' : String(query.bookshelf_id);
    if (!bookshelfId) return structuredClone(items);
    return structuredClone(items.filter((item) => String(item.bookshelf_id || '') === bookshelfId));
}

function demoReviewUnits(query = {}) {
    let items = shelfFiltered(demoData.reviewUnits.items, query);
    if (query.review_status) items = items.filter((item) => item.review_status === query.review_status);
    if (query.search) {
        const search = String(query.search).trim().toLowerCase();
        items = items.filter((item) => [item.unit_title, item.book_name, item.bookshelf_name].some((value) => String(value || '').toLowerCase().includes(search)));
    }
    return { total: items.length, items };
}

function allowedReviewActions(status) {
    return ({
        draft: ['pending_review', 'deprecated'],
        pending_review: ['reviewed', 'need_fix', 'deprecated'],
        reviewed: ['verified', 'need_recheck', 'deprecated'],
        verified: ['need_recheck', 'deprecated'],
        need_fix: ['pending_review', 'deprecated'],
        need_recheck: ['pending_review', 'deprecated'],
        deprecated: [],
    })[status] || [];
}

export class DemoApi {
    async get(path, query = {}) {
        await new Promise((resolve) => setTimeout(resolve, 180));
        if (path === '/summary') return structuredClone(demoData.summary);
        if (path === '/filters/bookshelves') return structuredClone(demoData.bookshelves);
        if (path === '/review-units') return demoReviewUnits(query);
        if (path === '/assets') return structuredClone(demoData.assets);
        if (path === '/contributions') return shelfFiltered(demoData.contributions, query);
        if (path === '/quality/issues') return shelfFiltered(demoData.quality, query);
        if (path === '/quality/rules') return {
            minimum_score: 70,
            verified_minimum_score: 90,
            summary: '普通审阅至少 70 分，验证发布至少 90 分；缺少来源或文章已废弃时，无论分数多少都会阻断入库。',
            metadata_rules: [{ name: '负责人', trigger: 'Front Matter 未填写该字段或字段值为空。', deduction: 8, blocking: false, fix: '填写 owner，明确知识负责人。' }],
            section_rules: [{ name: '缺少“风险”章节', trigger: 'Wiki Markdown 中没有“风险”文字。', deduction: 4, blocking: false, fix: '增加风险与边界条件说明。' }],
            hard_blocks: [{ name: '缺少可追溯来源', trigger: '任何分数都不能正式入库。', deduction: 40, blocking: true, fix: '补充有效来源链接。' }],
            workflow_rules: [{ name: '文章仍为草稿', trigger: '尚未提交人工审阅，不扣分但不能发布。', deduction: null, blocking: false, fix: '完成内容后提交人工审阅。' }],
        };
        if (path === '/rag/status') return shelfFiltered(demoData.rag, query);
        if (path === '/knowledge-graph') return demoKnowledgeGraph(query);
        if (path === '/gaps') return structuredClone(demoData.gaps);
        if (/^\/assets\/\d+$/.test(path)) {
            const asset = demoData.assets.items.find((item) => item.asset_id === Number(path.split('/').pop()));
            const reviewStatus = JSON.parse(asset.metadata_json).review_status;
            const rag = demoData.rag.find((item) => item.asset_id === asset.asset_id) || null;
            return { asset, review: { review_status: reviewStatus }, allowed_actions: allowedReviewActions(reviewStatus), quality: null, rag, rag_action: { can_publish: asset.asset_type === 'wiki' && ['reviewed', 'verified'].includes(reviewStatus), dataset_id: rag?.dataset_id || 'default', has_snapshot: Boolean(rag), is_removed: rag?.parse_status === 'disabled' } };
        }
        return [];
    }

    async post(path, body) {
        await new Promise((resolve) => setTimeout(resolve, 220));
        if (path === '/reports') return { report_id: 12, markdown: demoReport(body) };
        if (path === '/review-units/reviews') {
            const unit = demoData.reviewUnits.items.find((item) => item.unit_key === body.unit_key);
            return { processed: unit ? Array.from({ length: unit.asset_count }, (_, index) => ({ asset_id: index + 1 })) : [], skipped: [], blocked: [] };
        }
        if (path === '/review-units/rag/publish') {
            const unit = demoData.reviewUnits.items.find((item) => item.unit_key === body.unit_key);
            return { published: unit?.can_publish ? Array.from({ length: unit.asset_count }, (_, index) => ({ asset_id: index + 1 })) : [], failed: [] };
        }
        return { accepted: true, saved: true };
    }

    async patch() {
        await new Promise((resolve) => setTimeout(resolve, 180));
        return { updated: true };
    }

    async delete() {
        await new Promise((resolve) => setTimeout(resolve, 180));
        return { removed: true };
    }
}

function demoReport({ report_type = '周报', period_start = '', period_end = '', bookshelf_id = '' } = {}) {
    const bookshelfName = demoData.bookshelves.find((item) => String(item.id) === String(bookshelf_id))?.name || '全部书架';
    const details = {
        manuals: `| A05109 | DDR 时序参数配置手册 | 芯片手册 | ${period_end || '2026-07-07'} 11:08 |`,
        cases: `| A04217 | PCIe 链路训练异常定位指南 | 驱动故障案例库 | ${period_end || '2026-07-07'} 09:18 |\n| A03882 | I2C 设备无应答故障案例 | 驱动故障案例库 | ${period_end || '2026-07-07'} 14:26 |`,
        platform: `| A02943 | 平台版本发布流程 | 平台流程文档 | ${period_end || '2026-07-07'} 16:40 |`,
    };
    const contributionRows = details[bookshelf_id] || Object.values(details).join('\n');
    return `# 知识治理${report_type}

统计周期：${period_start} 至 ${period_end}

书架范围：${bookshelfName}

## 建设成果

| 指标 | 数量 |
| --- | ---: |
| 原始资料 | 248 |
| 可见 Wiki | 176 |

## 贡献明细

| 用户名 | 贡献文档标题 | 贡献文档书架名称 | 贡献时间 |
| --- | --- | --- | --- |
${contributionRows}

## 审阅进展

| 指标 | 数量 |
| --- | ---: |
| 完成审阅 | 15 |

## RAG 健康

| 指标 | 数量 |
| --- | ---: |
| Ready 文档 | 158 |

## 质量问题

| 指标 | 数量 |
| --- | ---: |
| 警告或阻断 | 3 |

## 知识缺口

| 指标 | 数量 |
| --- | ---: |
| 开放或处理中 | 7 |

## 下周计划

| 优先级 | 事项 |
| --- | --- |
| 高 | 优先补齐 PCIe Gen5 案例。 |`;
}

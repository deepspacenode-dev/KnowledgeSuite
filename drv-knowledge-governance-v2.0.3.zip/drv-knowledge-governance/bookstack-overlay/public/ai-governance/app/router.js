export const KNOWN_VIEWS = Object.freeze([
    'overview',
    'assets',
    'contributions',
    'quality',
    'rag',
    'knowledge-graph',
    'gaps',
    'reports',
]);

export function parseRoute(href = globalThis.location?.href ?? 'http://localhost/ai-governance/') {
    const url = new URL(href, 'http://localhost');
    const requestedView = url.searchParams.get('view') || 'overview';

    return {
        view: KNOWN_VIEWS.includes(requestedView) ? requestedView : 'overview',
        pageId: url.searchParams.get('page_id') || '',
        mode: url.searchParams.get('mode') === 'current_page' ? 'current_page' : '',
    };
}

export function buildRouteUrl(view, options = {}) {
    const href = options.href ?? globalThis.location?.href ?? 'http://localhost/ai-governance/';
    const url = new URL(href, 'http://localhost');
    const next = new URLSearchParams();
    next.set('view', KNOWN_VIEWS.includes(view) ? view : 'overview');

    for (const key of ['demo', 'page_id', 'mode']) {
        const value = url.searchParams.get(key);
        if (value) next.set(key, value);
    }

    return `${url.pathname}?${next.toString()}`;
}

export function navigate(view) {
    const url = buildRouteUrl(view);
    globalThis.history?.pushState({}, '', url);
    globalThis.dispatchEvent?.(new PopStateEvent('popstate'));
}

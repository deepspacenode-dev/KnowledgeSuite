export function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

export function safeHref(value) {
    const href = String(value || '').trim();
    if (/^\/(?!\/)/.test(href) || /^https?:\/\//i.test(href)) return escapeHtml(href);
    return '';
}

export function icon(name, size = 18) {
    return `<i data-lucide="${escapeHtml(name)}" width="${size}" height="${size}" aria-hidden="true"></i>`;
}

export function statusBadge(status) {
    const labels = {
        draft: '草稿', pending_review: '待审阅', need_fix: '待修改', reviewed: '已审阅',
        verified: '已验证', deprecated: '已废弃', ready: '可召回', parsing: '解析中',
        parsed: '已解析', ingesting: '入库中', ingested: '已入库',
        not_ingested: '未入库', uploaded: '已上传', unstart: '未开始', stale: '已过期',
        failed: '失败', blocked: '已阻断', disabled: '已移出', deleted: '已删除', open: '待处理', doing: '处理中', closed: '已关闭',
        created: '已创建', updated: '已更新', moved: '已迁移', skipped: '无变化',
    };
    if (status === null || status === undefined) return '<span class="status-badge status-badge--none">-</span>';
    const safe = escapeHtml(status || 'unknown');
    return `<span class="status-badge status-badge--${safe}">${escapeHtml(labels[status] || status)}</span>`;
}

export function viewState(type, title, detail = '') {
    const icons = { loading: 'loader-circle', empty: 'inbox', error: 'triangle-alert' };
    return `<div class="view-state view-state--${type}">
        <span class="view-state__icon">${icon(icons[type] || 'info')}</span>
        <strong>${escapeHtml(title)}</strong>
        ${detail ? `<p>${escapeHtml(detail)}</p>` : ''}
    </div>`;
}

export function formatDate(value) {
    if (!value) return '-';
    const date = new Date(value);
    return Number.isNaN(date.valueOf()) ? escapeHtml(value) : new Intl.DateTimeFormat('zh-CN', {
        month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit',
    }).format(date);
}

export function renderIcons() {
    globalThis.lucide?.createIcons?.({ attrs: { 'stroke-width': 1.8 } });
}

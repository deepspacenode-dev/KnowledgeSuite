export class ApiError extends Error {
    constructor(message, { code = 'REQUEST_FAILED', status = 0, retryable = false } = {}) {
        super(message);
        this.name = 'ApiError';
        this.code = code;
        this.status = status;
        this.retryable = retryable;
    }
}

function cookieValue(name) {
    const item = (globalThis.document?.cookie || '')
        .split('; ')
        .find((entry) => entry.startsWith(`${name}=`));
    return item ? decodeURIComponent(item.slice(name.length + 1)) : '';
}

export class ApiClient {
    constructor({
        baseUrl = '/api/ai-governance/v1',
        fetchImpl = globalThis.fetch?.bind(globalThis),
        csrfToken = '',
        timeout = 15000,
    } = {}) {
        this.baseUrl = baseUrl.replace(/\/$/, '');
        this.fetchImpl = fetchImpl;
        this.csrfToken = csrfToken;
        this.timeout = timeout;
    }

    setCsrfToken(token) {
        this.csrfToken = String(token || '');
    }

    get(path, query = {}) {
        const search = new URLSearchParams(
            Object.entries(query).filter(([, value]) => value !== '' && value != null),
        );
        return this.request(`${path}${search.size ? `?${search}` : ''}`);
    }

    post(path, body = {}) {
        return this.request(path, { method: 'POST', body });
    }

    patch(path, body = {}) {
        return this.request(path, { method: 'PATCH', body });
    }

    delete(path, body = {}) {
        return this.request(path, { method: 'DELETE', body });
    }

    async request(path, { method = 'GET', body } = {}) {
        if (!this.fetchImpl) throw new ApiError('当前浏览器不支持网络请求。');
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), this.timeout);
        const sessionToken = this.csrfToken
            || globalThis.document?.querySelector('meta[name="csrf-token"]')?.content
            || '';
        const cookieToken = sessionToken ? '' : cookieValue('XSRF-TOKEN');
        const headers = { Accept: 'application/json' };
        const init = { method, headers, credentials: 'same-origin', signal: controller.signal };

        if (body !== undefined) {
            headers['Content-Type'] = 'application/json';
            init.body = JSON.stringify(body);
        }
        if (sessionToken && method !== 'GET') headers['X-CSRF-TOKEN'] = sessionToken;
        if (cookieToken && method !== 'GET') headers['X-XSRF-TOKEN'] = cookieToken;

        try {
            const response = await this.fetchImpl(`${this.baseUrl}${path}`, init);
            const payload = await response.json().catch(() => ({}));
            if (!response.ok || payload.success === false) {
                const error = payload.error || {};
                const code = error.code || error.error_code || payload.error_code || 'REQUEST_FAILED';
                const message = response.status === 419
                    ? '会话校验失败，请刷新页面后重试。'
                    : (error.message || payload.message || `请求失败 (${response.status})`);
                throw new ApiError(message, {
                    code,
                    status: response.status,
                    retryable: Boolean(error.retryable ?? payload.retryable),
                });
            }
            return payload.data ?? payload;
        } catch (error) {
            if (error?.name === 'AbortError') {
                throw new ApiError('请求超时，请稍后重试。', { code: 'REQUEST_TIMEOUT', retryable: true });
            }
            if (error instanceof ApiError) throw error;
            throw new ApiError('无法连接知识治理服务。', { code: 'NETWORK_ERROR', retryable: true });
        } finally {
            clearTimeout(timer);
        }
    }
}

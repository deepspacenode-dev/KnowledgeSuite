<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V2;

use BookStack\AI\Governance\Application\Assistant\AssistantConfig;
use BookStack\AI\Governance\Http\ApiResponse;
use Illuminate\Http\JsonResponse;

final class AssistantConfigController
{
    public function __invoke(AssistantConfig $config): JsonResponse
    {
        return ApiResponse::success($config->toArray());
    }
}

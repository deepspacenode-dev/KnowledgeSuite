<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Application\Gap\DeleteKnowledgeGap;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackIdentityAdapter;
use BookStack\AI\Governance\Infrastructure\Persistence\GapRepository;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class GapCommandController
{
    public function store(Request $request, BookStackIdentityAdapter $identity, GapRepository $gaps): JsonResponse
    {
        $identity->requireAdministrator();
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'missing_content' => 'required|string',
            'impact' => 'nullable|string',
            'priority' => 'required|in:low,medium,high,critical',
            'owner_id' => 'nullable|integer',
            'related_asset_id' => 'nullable|integer',
            'due_at' => 'nullable|date',
        ]);
        $data['created_by'] = $identity->userId();
        $data['gap_status'] = 'open';

        return ApiResponse::success(['gap_id' => $gaps->create($data)], [], 201);
    }

    public function update(int $gap_id, Request $request, BookStackIdentityAdapter $identity, GapRepository $gaps): JsonResponse
    {
        $identity->requireAdministrator();
        $data = $request->validate([
            'gap_status' => 'sometimes|in:open,doing,closed',
            'priority' => 'sometimes|in:low,medium,high,critical',
            'owner_id' => 'nullable|integer',
            'due_at' => 'nullable|date',
        ]);
        if (($data['gap_status'] ?? null) === 'closed') {
            $data['closed_at'] = now();
        }

        return ApiResponse::success(['updated' => $gaps->update($gap_id, $data)]);
    }

    public function destroy(
        int $gap_id,
        Request $request,
        BookStackIdentityAdapter $identity,
        DeleteKnowledgeGap $command,
    ): JsonResponse {
        $identity->requireAdministrator();
        $data = $request->validate(['reason' => 'required|string|max:1000']);
        try {
            return ApiResponse::success($command->execute(
                $gap_id,
                $identity->userId(),
                trim((string) $data['reason']),
            ));
        } catch (DomainException $error) {
            return ApiResponse::error('GAP_DELETE_FAILED', $error->getMessage(), 404, false);
        }
    }
}

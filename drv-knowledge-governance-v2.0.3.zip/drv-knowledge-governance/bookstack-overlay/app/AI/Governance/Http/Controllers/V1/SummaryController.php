<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Application\Query\GovernanceSummaryQuery;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackIdentityAdapter;
use Illuminate\Http\JsonResponse;

final class SummaryController
{
    public function __invoke(
        GovernanceSummaryQuery $query,
        BookStackIdentityAdapter $identity,
    ): JsonResponse {
        $ragFlowWebUrl = $this->ragFlowWebUrl();
        return ApiResponse::success([
            ...$query->execute(),
            'permissions' => [
                'can_write' => $identity->isAdministrator(),
            ],
            'integrations' => [
                'ragflow' => [
                    'configured' => $ragFlowWebUrl !== null,
                    'web_url' => $ragFlowWebUrl,
                ],
            ],
            'csrf_token' => csrf_token(),
        ]);
    }

    private function ragFlowWebUrl(): ?string
    {
        $url = trim((string) env('RAGFLOW_WEB_URL', ''));
        if ($url === '') {
            $url = trim((string) env('RAGFLOW_BASE_URL', ''));
        }
        if ($url === '' || filter_var($url, FILTER_VALIDATE_URL) === false) {
            return null;
        }
        $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
        if (!in_array($scheme, ['http', 'https'], true)) {
            return null;
        }

        return rtrim($url, '/');
    }
}

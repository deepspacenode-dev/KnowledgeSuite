<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Application\Rag\QueueReviewedWikiForPublish;
use BookStack\AI\Governance\Application\Rag\RefreshRagSnapshots;
use BookStack\AI\Governance\Application\Sync\ReconcileBookStackDrafts;
use BookStack\AI\Governance\Application\Sync\RefreshQualityChecks;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackIdentityAdapter;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class SyncController
{
    public function store(
        Request $request,
        BookStackIdentityAdapter $identity,
        ReconcileBookStackDrafts $assets,
        RefreshQualityChecks $quality,
        QueueReviewedWikiForPublish $rag,
        RefreshRagSnapshots $ragStatus,
    ): JsonResponse {
        $identity->requireAdministrator();
        $data = $request->validate([
            'scope' => 'required|in:assets,quality,rag',
            'asset_id' => 'nullable|integer|min:1',
            'page_id' => 'nullable|integer|min:1',
        ]);
        $result = match ($data['scope']) {
            'assets' => $assets->execute(isset($data['page_id']) ? (int) $data['page_id'] : null),
            'quality' => $quality->execute(isset($data['asset_id']) ? (int) $data['asset_id'] : null),
            'rag' => [
                'publish' => $rag->dispatchPending(),
                'status_refresh' => $ragStatus->execute(isset($data['asset_id']) ? (int) $data['asset_id'] : null),
            ],
        };
        return ApiResponse::success([
            'scope' => $data['scope'],
            'asset_id' => $data['asset_id'] ?? null,
            'page_id' => $data['page_id'] ?? null,
            'result' => $result,
        ], [], 202);
    }
}

<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\V1;
use BookStack\AI\Governance\Application\Query\AssetListQuery;
use BookStack\AI\Governance\Domain\StateTransition;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\ReadablePageQuery;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
final class AssetController {
    public function index(Request $request, AssetListQuery $query): JsonResponse { return ApiResponse::success($query->execute($request->query())); }
    public function show(int $asset_id, ReadablePageQuery $pages): JsonResponse {
        $asset=DB::table('drv_kb_assets')->where('asset_id',$asset_id)->first();
        if($asset===null||!in_array((int)$asset->page_id,$pages->visibleIds(),true)){return ApiResponse::error('ASSET_NOT_FOUND','Asset not found.',404);}
        $review=DB::table('drv_kb_reviews')->where('asset_id',$asset_id)->orderByDesc('created_at')->first();
        $reviewStatus=(string)($review->review_status??'draft');
        $rag=DB::table('drv_kb_rag_snapshot')->where('asset_id',$asset_id)->orderByDesc('checked_at')->orderByDesc('rag_snapshot_id')->first();
        $isRemoved=in_array((string)($rag->parse_status??''),['disabled','deleted'],true);
        $datasetId=trim((string)($rag->dataset_id??env('RAGFLOW_DEFAULT_DATASET_ID','')));
        return ApiResponse::success([
            'asset'=>$asset,
            'review'=>$review,
            'allowed_actions'=>StateTransition::allowedTargets('review',$reviewStatus),
            'quality'=>DB::table('drv_kb_quality_checks')->where('asset_id',$asset_id)->orderByDesc('checked_at')->first(),
            'rag'=>$rag,
            'rag_action'=>[
                'can_publish'=>($asset->asset_type??null)==='wiki'&&in_array($reviewStatus,['reviewed','verified'],true)&&!$isRemoved&&$datasetId!=='',
                'dataset_id'=>$datasetId,
                'has_snapshot'=>$rag!==null,
                'is_removed'=>$isRemoved,
            ],
        ]);
    }
}

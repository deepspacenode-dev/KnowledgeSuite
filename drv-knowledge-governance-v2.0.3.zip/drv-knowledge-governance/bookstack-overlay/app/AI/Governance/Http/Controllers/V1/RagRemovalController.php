<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Application\Rag\RemoveWikiAssetFromRag;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackIdentityAdapter;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class RagRemovalController
{
    public function destroy(
        int $asset_id,
        Request $request,
        BookStackIdentityAdapter $identity,
        RemoveWikiAssetFromRag $remove,
    ): JsonResponse {
        $identity->requireAdministrator();
        $data = $request->validate([
            'reason' => 'required|string|min:2|max:500',
        ]);
        try {
            return ApiResponse::success(
                $remove->execute($asset_id, trim((string) $data['reason']), $identity->userId()),
            );
        } catch (DomainException $exception) {
            $code = $exception->getMessage();
            $message = match ($code) {
                'RAG_ASSET_NOT_REMOVABLE' => '只有 Wiki 知识可以从 RAGFlow 移除。',
                'RAG_NOT_INGESTED' => '该文档尚未进入 RAGFlow，无需删除。',
                'RAG_DELETE_FAILED' => 'RAGFlow 删除失败，本地状态没有改变，请检查服务连接后重试。',
                'RAG_STATE_WRITE_FAILED' => 'RAGFlow 已删除文档，但治理状态写入失败，请立即联系管理员处理。',
                default => $code,
            };
            return ApiResponse::error($code, $message, 422, $code === 'RAG_DELETE_FAILED');
        }
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Application\Review\MarkReviewUnit;
use BookStack\AI\Governance\Application\Review\ReviewUnitQuery;
use BookStack\AI\Governance\Application\Rag\PublishReviewUnit;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackIdentityAdapter;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class ReviewUnitController
{
    public function index(Request $request, ReviewUnitQuery $query): JsonResponse
    {
        return ApiResponse::success($query->execute($request->query()));
    }

    public function store(
        Request $request,
        BookStackIdentityAdapter $identity,
        MarkReviewUnit $command,
    ): JsonResponse {
        $identity->requireAdministrator();
        $data = $request->validate([
            'unit_key' => 'required|string|max:255',
            'bookshelf_id' => 'nullable',
            'review_status' => 'required|in:pending_review,reviewed,verified,need_fix,need_recheck,deprecated',
            'review_comment' => 'nullable|string|max:4000',
        ]);
        $data['reviewer_id'] = $identity->userId();
        try {
            return ApiResponse::success($command->execute($data), [], 201);
        } catch (DomainException $error) {
            return ApiResponse::error('REVIEW_UNIT_BLOCKED', $error->getMessage(), 422, false);
        }
    }

    public function publish(
        Request $request,
        BookStackIdentityAdapter $identity,
        PublishReviewUnit $command,
    ): JsonResponse {
        $identity->requireAdministrator();
        $data = $request->validate([
            'unit_key' => 'required|string|max:255',
            'bookshelf_id' => 'nullable',
        ]);
        $data['actor_id'] = $identity->userId();
        try {
            return ApiResponse::success($command->execute($data), [], 202);
        } catch (DomainException $error) {
            return ApiResponse::error('REVIEW_UNIT_RAG_BLOCKED', $error->getMessage(), 422, false);
        }
    }
}

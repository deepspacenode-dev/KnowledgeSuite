<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackHierarchyQuery;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class RagController
{
    public function __invoke(Request $request, BookStackHierarchyQuery $hierarchy): JsonResponse
    {
        $pageIds = $hierarchy->pageIdsForBookshelf($request->query('bookshelf_id'));
        $assetIds = DB::table('drv_kb_assets')->whereIn('page_id', $pageIds)->pluck('asset_id');
        $latestIds = DB::table('drv_kb_rag_snapshot')
            ->whereIn('asset_id', $assetIds)
            ->selectRaw('MAX(rag_snapshot_id)')
            ->groupBy('asset_id');
        $latestReviewIds = DB::table('drv_kb_reviews')
            ->whereIn('asset_id', $assetIds)
            ->selectRaw('asset_id, MAX(review_id) as review_id')
            ->groupBy('asset_id');
        $items = DB::table('drv_kb_rag_snapshot as rag')
            ->join('drv_kb_assets', 'drv_kb_assets.asset_id', '=', 'rag.asset_id')
            ->leftJoinSub($latestReviewIds, 'latest_review', function ($join): void {
                $join->on('latest_review.asset_id', '=', 'rag.asset_id');
            })
            ->leftJoin('drv_kb_reviews as review', 'review.review_id', '=', 'latest_review.review_id')
            ->whereIn('rag.rag_snapshot_id', $latestIds)
            ->select([
                'rag.*',
                'drv_kb_assets.title as asset_title',
                'drv_kb_assets.page_id',
                'drv_kb_assets.current_version',
                'drv_kb_assets.asset_type',
                'review.review_status',
            ])
            ->orderByDesc('rag.checked_at')
            ->limit(500)
            ->get()
            ->map(static function (object $item): object {
                $removed = in_array((string) $item->parse_status, ['disabled', 'deleted'], true)
                    || (string) $item->last_action_result === 'deleted';
                $item->can_publish = (string) $item->asset_type === 'wiki'
                    && in_array((string) $item->review_status, ['reviewed', 'verified'], true)
                    && !$removed
                    && trim((string) $item->dataset_id) !== '';
                return $item;
            });

        return ApiResponse::success($items);
    }
}

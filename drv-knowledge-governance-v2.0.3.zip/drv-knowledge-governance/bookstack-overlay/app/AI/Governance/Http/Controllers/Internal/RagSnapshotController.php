<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\Internal;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\Persistence\RagSnapshotRepository;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
final class RagSnapshotController { public function store(Request $r,RagSnapshotRepository $repo):JsonResponse{$d=$r->validate(['asset_id'=>'required|integer','dataset_id'=>'required|string','document_id'=>'required|string','parse_status'=>'required|in:not_ingested,queued,parsing,ready,stale,failed,disabled','chunk_count'=>'nullable|integer|min:0','last_action_result'=>'nullable|in:created,skipped,updated,moved,deleted,failed','last_error'=>'nullable|string|max:4000']);$repo->record($d);return ApiResponse::success(['recorded'=>true],[],201);} }

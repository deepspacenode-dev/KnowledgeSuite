<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackHierarchyQuery;
use Illuminate\Http\JsonResponse;

final class BookshelfFilterController
{
    public function __invoke(BookStackHierarchyQuery $hierarchy): JsonResponse
    {
        return ApiResponse::success($hierarchy->bookshelves());
    }
}

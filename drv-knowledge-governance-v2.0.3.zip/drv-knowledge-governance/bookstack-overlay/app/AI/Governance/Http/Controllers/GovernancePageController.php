<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

final class GovernancePageController
{
    private const KNOWN_VIEWS = [
        'overview',
        'assets',
        'contributions',
        'quality',
        'rag',
        'knowledge-graph',
        'gaps',
        'reports',
    ];

    public function __invoke(Request $request): RedirectResponse
    {
        $requestedView = trim((string) $request->query('view', ''));
        $view = in_array($requestedView, self::KNOWN_VIEWS, true) ? $requestedView : '';
        $query = array_filter([
            'view' => $view,
            'page_id' => (string) $request->query('page_id', ''),
            'mode' => $request->query('mode') === 'current_page' ? 'current_page' : '',
        ]);
        $target = '/ai-governance/index.html';

        return redirect($query ? $target . '?' . http_build_query($query) : $target);
    }
}

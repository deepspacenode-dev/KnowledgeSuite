<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V2;

use BookStack\AI\Governance\Application\Status\ResolveGovernanceStatus;
use BookStack\AI\Governance\Http\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

final class StatusController
{
    public function resolve(Request $request, ResolveGovernanceStatus $resolver): JsonResponse
    {
        $payload = $request->validate([
            'schema_version' => 'required|in:drvknowledge.status-resolve-request.v2',
            'trace_id' => 'required|string|min:8|max:128',
            'content_refs' => 'required|array|min:1|max:200',
            'content_refs.*' => ['required', 'string', 'regex:/^bookstack:page:[1-9][0-9]*$/'],
        ]);
        return ApiResponse::success($resolver->execute($payload['content_refs'], $payload['trace_id']));
    }
}

<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\V1;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\ReadablePageQuery;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
final class GapController { public function __invoke(ReadablePageQuery $pages): JsonResponse { $ids=DB::table('drv_kb_assets')->whereIn('page_id',$pages->visibleIds())->pluck('asset_id'); return ApiResponse::success(DB::table('drv_kb_gaps')->whereNull('related_asset_id')->orWhereIn('related_asset_id',$ids)->orderByRaw("FIELD(gap_status,'open','doing','closed')")->orderBy('due_at')->get()); } }

<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\Internal;
use BookStack\AI\Governance\Application\Compile\AcceptWikiResult;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\Persistence\AssetRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\CompileTaskRepository;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
final class CompileTaskController {
 public function next(Request $r,CompileTaskRepository $tasks,AssetRepository $assets):JsonResponse{$worker=(string)$r->header('X-AI-Worker','');if($worker===''){return ApiResponse::error('WORKER_ID_REQUIRED','Worker ID is required.',422);} $task=$tasks->claimNext($worker,(int)env('AI_GOVERNANCE_TASK_LEASE_SECONDS',300));if($task===null){return ApiResponse::success(null,[],204);}return ApiResponse::success(['task'=>$task,'source'=>$assets->findById((int)$task->source_asset_id)]);}
 public function heartbeat(int $task_id,Request $r,CompileTaskRepository $tasks):JsonResponse{$worker=(string)$r->header('X-AI-Worker','');return $tasks->heartbeat($task_id,$worker,(int)env('AI_GOVERNANCE_TASK_LEASE_SECONDS',300))?ApiResponse::success(['heartbeat'=>true]):ApiResponse::error('TASK_STALE','Task lease is stale.',409);}
 public function result(int $task_id,Request $r,AcceptWikiResult $accept):JsonResponse{try{return ApiResponse::success($accept->execute($task_id,(string)$r->header('X-AI-Worker',''),$r->json()->all()),[],201);}catch(DomainException $e){return ApiResponse::error($e->getMessage(),$e->getMessage(),422);}}
}

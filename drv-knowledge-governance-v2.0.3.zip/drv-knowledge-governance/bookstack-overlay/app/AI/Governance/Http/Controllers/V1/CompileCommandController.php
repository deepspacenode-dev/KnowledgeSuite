<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\V1;
use BookStack\AI\Governance\Application\Compile\QueueCompileTask;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackIdentityAdapter;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackPageExporter;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
final class CompileCommandController { public function store(int $asset_id,Request $request,BookStackIdentityAdapter $identity,BookStackPageExporter $exporter,QueueCompileTask $queue):JsonResponse{$identity->requireAdministrator();$data=$request->validate(['page_id'=>'required|integer|min:1','canonical_url'=>'required|url','title'=>'required|string|max:255','workflow'=>'nullable|in:ragflow,drvagent','material_type'=>'nullable|string|max:64']);try{$actual=$exporter->export((int)$data['page_id']);$result=$queue->execute(['actual'=>$actual,'expected'=>['page_id'=>$data['page_id'],'canonical_url'=>$data['canonical_url'],'title'=>$data['title']],'workflow'=>$data['workflow']??'drvagent','material_type'=>$data['material_type']??null,'trigger_type'=>'manual']);return ApiResponse::success($result,[],202);}catch(DomainException $e){return ApiResponse::error($e->getMessage(),$e->getMessage(),409);}} }

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Application\Quality\QualityIssueUnitQuery;
use BookStack\AI\Governance\Http\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class QualityController
{
    public function __invoke(Request $request, QualityIssueUnitQuery $query): JsonResponse
    {
        return ApiResponse::success($query->execute($request->query()));
    }
}

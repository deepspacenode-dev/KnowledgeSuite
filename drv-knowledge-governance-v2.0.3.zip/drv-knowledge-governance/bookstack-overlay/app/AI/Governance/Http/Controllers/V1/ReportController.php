<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\V1;
use BookStack\AI\Governance\Http\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
final class ReportController { public function show(int $report_id): JsonResponse { $report=DB::table('drv_kb_reports')->where('report_id',$report_id)->first(); return $report?ApiResponse::success($report):ApiResponse::error('REPORT_NOT_FOUND','Report not found.',404); } }

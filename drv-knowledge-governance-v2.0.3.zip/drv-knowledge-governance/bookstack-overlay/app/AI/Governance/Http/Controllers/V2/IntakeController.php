<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V2;

use BookStack\AI\Governance\Application\Intake\CreateIntake;
use BookStack\AI\Governance\Application\Intake\IntakeResponse;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackIdentityAdapter;
use BookStack\AI\Governance\Infrastructure\Persistence\IntakeRepository;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class IntakeController
{
    public function store(Request $request, BookStackIdentityAdapter $identity, CreateIntake $create): JsonResponse
    {
        $payload = $request->json()->all();
        try {
            $identity->requireCanReadPage((int) ($payload['page_id'] ?? 0));
            $result = $create->execute($payload, (string) $request->header('Idempotency-Key', ''), $identity->userId());
            return ApiResponse::success($result, [], $result['replayed'] ? 200 : 202);
        } catch (DomainException $exception) {
            $code = $exception->getMessage();
            $status = $code === 'IDEMPOTENCY_CONFLICT' ? 409 : 422;
            return ApiResponse::error($code, $code, $status, false);
        }
    }

    public function show(int $intake_id, IntakeRepository $intakes, BookStackIdentityAdapter $identity): JsonResponse
    {
        $row = $intakes->find($intake_id);
        if ($row === null) {
            return ApiResponse::error('INTAKE_NOT_FOUND', 'Intake was not found.', 404);
        }
        $identity->requireCanReadPage((int) $row->page_id);
        $response = json_decode((string) $row->response_json, true);
        $response = IntakeResponse::withCurrentCompileStatus(
            is_array($response) ? $response : [],
            isset($row->current_compile_status) ? (string) $row->current_compile_status : null,
        );
        return ApiResponse::success($response + [
            'intake_id' => (string) $row->intake_id,
            'intake_status' => (string) $row->intake_status,
            'created_at' => (string) $row->created_at,
            'updated_at' => (string) $row->updated_at,
        ]);
    }
}

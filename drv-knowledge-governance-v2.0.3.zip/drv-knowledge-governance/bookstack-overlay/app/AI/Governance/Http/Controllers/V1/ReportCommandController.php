<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\V1;
use BookStack\AI\Governance\Application\Report\GenerateGovernanceReport;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackIdentityAdapter;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
final class ReportCommandController
{
    public function store(Request $request,BookStackIdentityAdapter $identity,GenerateGovernanceReport $generator):JsonResponse
    {
        $identity->requireAdministrator();
        $data=$request->validate([
            'report_type'=>'required|in:周报,月报',
            'period_start'=>'required|date',
            'period_end'=>'required|date|after_or_equal:period_start',
            'bookshelf_id'=>'nullable',
            'filters'=>'nullable|array',
        ]);
        $filters=$data['filters']??[];
        if(array_key_exists('bookshelf_id',$data)){$filters['bookshelf_id']=$data['bookshelf_id'];}
        return ApiResponse::success($generator->execute($data['report_type'],$data['period_start'],$data['period_end'],$filters,$identity->userId()),[],201);
    }
}

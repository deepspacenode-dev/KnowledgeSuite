<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Application\Rag\PublishWikiAsset;
use BookStack\AI\Governance\Application\Rag\RagDatasetResolver;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackIdentityAdapter;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class RagCommandController
{
    public function retry(
        int $asset_id,
        Request $request,
        BookStackIdentityAdapter $identity,
        PublishWikiAsset $publish,
        RagDatasetResolver $datasets,
    ): JsonResponse {
        $identity->requireAdministrator();
        $data = $request->validate(['dataset_id' => 'nullable|string|max:255']);
        $datasetId = trim((string) ($data['dataset_id'] ?? ''));
        if ($datasetId === '') {
            $datasetId = $datasets->forAsset($asset_id);
        }
        if ($datasetId === '') {
            return ApiResponse::error('RAG_DATASET_NOT_CONFIGURED', '尚未配置 RAGFlow 数据集，无法执行入库。', 422);
        }

        try {
            return ApiResponse::success(
                $publish->execute($asset_id, $datasetId, $identity->userId()),
                [],
                202,
            );
        } catch (DomainException $exception) {
            $code = $exception->getMessage();
            $message = match ($code) {
                'RAG_PUBLISH_DISABLED' => '该知识已从 RAGFlow 移除，当前禁止重新入库。',
                'RAG_DELETE_FAILED' => '更新前删除旧 RAGFlow 文档失败，本次没有上传新文档。',
                default => $code,
            };
            return ApiResponse::error($code, $message, 422);
        }
    }
}

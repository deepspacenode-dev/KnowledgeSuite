<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\Internal;

use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\Persistence\AuditEventRepository;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

final class WorkerEventV2Controller
{
    public function store(Request $request, AuditEventRepository $audit): JsonResponse
    {
        $payload = $request->validate([
            'schema_version' => 'required|in:drvknowledge.worker-event.v2',
            'trace_id' => 'required|string|min:8|max:128',
            'event' => 'required|string|max:96',
            'task_id' => 'nullable|string|max:128',
            'error' => 'nullable|array',
        ]);
        $id = $audit->append([
            'trace_id' => (string) Str::uuid(),
            'event_type' => 'worker.' . $payload['event'],
            'object_type' => 'compile_task',
            'object_id' => (string) ($payload['task_id'] ?? 'unknown'),
            'metadata_json' => ['trace_id' => $payload['trace_id'], 'error' => $payload['error'] ?? null],
        ]);
        return ApiResponse::success(['audit_event_id' => $id], [], 201);
    }
}

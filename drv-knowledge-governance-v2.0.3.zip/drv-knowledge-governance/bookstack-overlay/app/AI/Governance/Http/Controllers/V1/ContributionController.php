<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Application\Contribution\ContributionMetrics;
use BookStack\AI\Governance\Http\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class ContributionController
{
    public function __invoke(Request $request, ContributionMetrics $metrics): JsonResponse
    {
        $from = (string) $request->query('date_from', '1970-01-01');
        $to = (string) $request->query('date_to', now()->toDateString());
        return ApiResponse::success($metrics->between($from, $to, $request->query('bookshelf_id')));
    }
}

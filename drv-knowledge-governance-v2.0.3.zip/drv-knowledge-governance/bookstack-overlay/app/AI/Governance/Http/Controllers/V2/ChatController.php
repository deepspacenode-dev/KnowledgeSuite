<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V2;

use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\RagFlow\RagFlowGateway;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use RuntimeException;
use Throwable;

final class ChatController
{
    public function store(Request $request, RagFlowGateway $ragFlow): JsonResponse
    {
        $payload = $request->validate([
            'schema_version' => 'required|in:drvknowledge.chat-request.v2',
            'trace_id' => 'required|string|min:8|max:128',
            'question' => 'required|string|min:1|max:4000',
            'session_token' => 'nullable|string|max:4096',
            'page_id' => 'nullable|integer|min:1',
            'page_url' => 'nullable|url|max:2048',
        ]);
        $userId = (int) $request->user()->getAuthIdentifier();

        try {
            $sessionId = $this->decodeSessionToken($payload['session_token'] ?? null, $userId);
            $result = $ragFlow->chatCompletion(
                trim((string) $payload['question']),
                $sessionId,
                [
                    'page_id' => $payload['page_id'] ?? null,
                    'page_url' => $payload['page_url'] ?? null,
                ],
            );
            $result['schema_version'] = 'drvknowledge.chat-response.v2';
            $result['trace_id'] = (string) $payload['trace_id'];
            $result['session_token'] = $this->encodeSessionToken((string) $result['session_id'], $userId);
            unset($result['session_id']);
            return ApiResponse::success($result);
        } catch (RuntimeException $exception) {
            report($exception);
            return ApiResponse::error('RAGFLOW_CHAT_UNAVAILABLE', '知识助手暂时不可用，请稍后重试。', 503, true);
        }
    }

    private function decodeSessionToken(?string $token, int $userId): ?string
    {
        if ($token === null || trim($token) === '') {
            return null;
        }
        try {
            $decoded = json_decode(Crypt::decryptString($token), true, 8, JSON_THROW_ON_ERROR);
        } catch (Throwable $exception) {
            throw new RuntimeException('Chat session token is invalid.', 0, $exception);
        }
        if (!is_array($decoded)
            || (int) ($decoded['user_id'] ?? 0) !== $userId
            || !is_string($decoded['session_id'] ?? null)
            || trim((string) $decoded['session_id']) === ''
        ) {
            throw new RuntimeException('Chat session token is invalid.');
        }
        return trim((string) $decoded['session_id']);
    }

    private function encodeSessionToken(string $sessionId, int $userId): string
    {
        if ($sessionId === '') {
            return '';
        }
        return Crypt::encryptString(json_encode([
            'user_id' => $userId,
            'session_id' => $sessionId,
        ], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
    }
}

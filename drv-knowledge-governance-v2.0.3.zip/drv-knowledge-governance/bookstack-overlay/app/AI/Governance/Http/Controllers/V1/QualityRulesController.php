<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Application\Quality\QualityExplanation;
use BookStack\AI\Governance\Http\ApiResponse;
use Illuminate\Http\JsonResponse;

final class QualityRulesController
{
    public function __invoke(QualityExplanation $explanation): JsonResponse
    {
        return ApiResponse::success($explanation->help());
    }
}

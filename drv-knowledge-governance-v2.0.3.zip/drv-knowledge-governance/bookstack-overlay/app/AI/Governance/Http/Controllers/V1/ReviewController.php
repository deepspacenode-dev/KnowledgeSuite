<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\V1;
use BookStack\AI\Governance\Application\Review\MarkReview;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackIdentityAdapter;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
final class ReviewController { public function store(int $asset_id,Request $request,BookStackIdentityAdapter $identity,MarkReview $mark):JsonResponse{$identity->requireAdministrator();try{$data=$request->validate(['review_status'=>'required|in:pending_review,reviewed,verified,need_fix,deprecated','review_comment'=>'nullable|string|max:4000','source_version'=>'nullable|integer|min:1']);$data['asset_id']=$asset_id;$data['reviewer_id']=$identity->userId();return ApiResponse::success($mark->execute($data),[],201);}catch(DomainException $e){return ApiResponse::error('QUALITY_GATE_BLOCKED',$e->getMessage(),422);}} }

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\V1;

use BookStack\AI\Governance\Application\Query\KnowledgeGraphQuery;
use BookStack\AI\Governance\Http\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use InvalidArgumentException;
use Throwable;

final class KnowledgeGraphController
{
    public function __invoke(Request $request, KnowledgeGraphQuery $query): JsonResponse
    {
        try {
            return ApiResponse::success($query->execute($request->query()));
        } catch (InvalidArgumentException $error) {
            return ApiResponse::error('GRAPH_BAD_REQUEST', $error->getMessage(), 422);
        } catch (Throwable $error) {
            report($error);
            return ApiResponse::error('GRAPH_QUERY_FAILED', '知识图谱生成失败。', 500, true);
        }
    }
}

<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\V1;
use BookStack\AI\Governance\Http\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
final class DiagnosisController { public function __invoke(): JsonResponse { return ApiResponse::success(['database'=>'available','queue'=>['queued'=>DB::table('drv_kb_compile_tasks')->where('task_status','queued')->count(),'running'=>DB::table('drv_kb_compile_tasks')->where('task_status','running')->count()],'rag_snapshot_checked_at'=>DB::table('drv_kb_rag_snapshot')->max('checked_at'),'audit_last_at'=>DB::table('drv_kb_audit_events')->max('created_at')]); } }

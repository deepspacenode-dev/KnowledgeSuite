<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Controllers\Internal;

use BookStack\AI\Governance\Application\Compile\AcceptWikiResult;
use BookStack\AI\Governance\Application\Compile\WikiTaskV2Builder;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\Persistence\AssetRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\CompileTaskRepository;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class CompileTaskV2Controller
{
    public function claim(Request $request, CompileTaskRepository $tasks, AssetRepository $assets, WikiTaskV2Builder $builder): JsonResponse
    {
        $worker = (string) $request->header('X-AI-Worker', '');
        if ($worker === '') {
            return ApiResponse::error('WORKER_ID_REQUIRED', 'Worker ID is required.', 422);
        }
        $task = $tasks->claimNext($worker, (int) env('AI_GOVERNANCE_TASK_LEASE_SECONDS', 300));
        if ($task === null) {
            return ApiResponse::success(null, [], 204);
        }
        $source = $assets->findById((int) $task->source_asset_id);
        if ($source === null) {
            return ApiResponse::error('SOURCE_NOT_FOUND', 'Task source is unavailable.', 409, true);
        }
        return ApiResponse::success(['task' => $builder->build($task, $source)]);
    }

    public function heartbeat(int $task_id, Request $request, CompileTaskRepository $tasks): JsonResponse
    {
        $worker = (string) $request->header('X-AI-Worker', '');
        return $tasks->heartbeat($task_id, $worker, (int) env('AI_GOVERNANCE_TASK_LEASE_SECONDS', 300))
            ? ApiResponse::success(['heartbeat' => true])
            : ApiResponse::error('TASK_STALE', 'Task lease is stale.', 409, true);
    }

    public function result(int $task_id, Request $request, AcceptWikiResult $accept): JsonResponse
    {
        try {
            $accepted = $accept->execute($task_id, (string) $request->header('X-AI-Worker', ''), $request->json()->all());
            return ApiResponse::success($accepted, [], ($accepted['replayed'] ?? false) ? 200 : 201);
        } catch (DomainException $exception) {
            $code = $exception->getMessage();
            $status = in_array($code, ['TASK_STALE', 'RESULT_REPLAY_CONFLICT'], true) ? 409 : 422;
            return ApiResponse::error($code, $code, $status, $code === 'TASK_STALE');
        }
    }
}

<?php
declare(strict_types=1);
namespace BookStack\AI\Governance\Http\Controllers\Internal;
use BookStack\AI\Governance\Http\ApiResponse;
use BookStack\AI\Governance\Infrastructure\Persistence\AuditEventRepository;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
final class InternalEventController { public function store(Request $r,AuditEventRepository $audit):JsonResponse{$d=$r->validate(['event_id'=>'required|string|max:128','event_type'=>'required|string|max:96','payload'=>'required|array']);$trace=Str::isUuid($d['event_id'])?$d['event_id']:(string)Str::uuid();$id=$audit->append(['trace_id'=>$trace,'event_type'=>$d['event_type'],'object_type'=>'workflow','object_id'=>$d['event_id'],'metadata_json'=>$d['payload']]);return ApiResponse::success(['audit_event_id'=>$id],[],201);} }

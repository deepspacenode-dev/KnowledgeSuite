<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http;

use Illuminate\Http\JsonResponse;
use Illuminate\Support\Str;

final class ApiResponse
{
    /** @param mixed $data @param array<string, mixed> $meta */
    public static function success(mixed $data, array $meta = [], int $status = 200): JsonResponse
    {
        $traceId = (string) Str::uuid();
        return response()->json([
            'success' => true,
            'data' => $data,
            'meta' => $meta + ['trace_id' => $traceId, 'generated_at' => now()->toAtomString()],
        ], $status);
    }

    /** @param array<string, mixed> $details */
    public static function error(
        string $errorCode,
        string $message,
        int $status,
        bool $retryable = false,
        array $details = [],
    ): JsonResponse {
        return response()->json([
            'success' => false,
            'error_code' => $errorCode,
            'message' => $message,
            'retryable' => $retryable,
            'details' => $details,
            'trace_id' => (string) Str::uuid(),
        ], $status);
    }
}

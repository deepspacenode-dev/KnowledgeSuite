<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Http\Middleware;

use BookStack\AI\Governance\Http\ApiResponse;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\HttpFoundation\Response;

final class VerifyWorkerSignature
{
    public function handle(Request $request, Closure $next): Response
    {
        $body = $request->getContent();
        if (strlen($body) > 5 * 1024 * 1024) {
            return ApiResponse::error('PAYLOAD_TOO_LARGE', 'Worker payload exceeds 5 MB.', 413);
        }

        $timestamp = (string) $request->header('X-AI-Timestamp', '');
        $nonce = (string) $request->header('X-AI-Nonce', '');
        $signature = strtolower((string) $request->header('X-AI-Signature', ''));
        $key = (string) env('AI_GOVERNANCE_WORKER_KEY', '');
        if ($key === '' || !ctype_digit($timestamp) || $nonce === '' || !preg_match('/^[0-9a-f]{64}$/', $signature)) {
            return ApiResponse::error('SIGNATURE_INVALID', 'Worker signature is invalid.', 401);
        }
        $clockSkew = (int) env('AI_GOVERNANCE_WORKER_CLOCK_SKEW_SECONDS', 300);
        if (abs(time() - (int) $timestamp) > min(300, max(30, $clockSkew))) {
            return ApiResponse::error('SIGNATURE_EXPIRED', 'Worker signature expired.', 401);
        }
        $canonical = implode("\n", [
            strtoupper($request->method()),
            '/' . ltrim($request->path(), '/'),
            $timestamp,
            $nonce,
            hash('sha256', $body),
        ]);
        $expected = hash_hmac('sha256', $canonical, $key);
        if (!hash_equals($expected, $signature)) {
            return ApiResponse::error('SIGNATURE_INVALID', 'Worker signature is invalid.', 401);
        }
        if (!Cache::add('ai-governance:nonce:' . hash('sha256', $nonce), true, 300)) {
            return ApiResponse::error('NONCE_REUSED', 'Worker nonce was already used.', 409);
        }

        return $next($request);
    }
}

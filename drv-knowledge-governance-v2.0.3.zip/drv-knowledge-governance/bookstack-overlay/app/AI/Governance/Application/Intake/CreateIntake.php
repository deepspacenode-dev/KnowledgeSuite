<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Intake;

use BookStack\AI\Governance\Application\Compile\QueueCompileTask;
use BookStack\AI\Governance\Application\Compile\ValidateSourceIdentity;
use BookStack\AI\Governance\Application\Contract\ContractValidatorV2;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackPageExporter;
use BookStack\AI\Governance\Infrastructure\Persistence\AssetRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\IntakeRepository;
use DomainException;
use Illuminate\Support\Facades\DB;

final class CreateIntake
{
    public function __construct(
        private readonly ContractValidatorV2 $contracts,
        private readonly BookStackPageExporter $exporter,
        private readonly ValidateSourceIdentity $identity,
        private readonly QueueCompileTask $queue,
        private readonly AssetRepository $assets,
        private readonly IntakeRepository $intakes,
    ) {
    }

    /** @param array<string, mixed> $request @return array<string, mixed> */
    public function execute(array $request, string $idempotencyKey, int $requestedBy): array
    {
        $this->contracts->assertIntake($request);
        if ($idempotencyKey === '' || !hash_equals((string) $request['client_submission_id'], $idempotencyKey)) {
            throw new DomainException('IDEMPOTENCY_KEY_INVALID');
        }
        $requestHash = $this->requestHash($request);

        return DB::transaction(function () use ($request, $idempotencyKey, $requestedBy, $requestHash): array {
            $existing = $this->intakes->findBySubmissionId((string) $request['client_submission_id'], true);
            if ($existing !== null) {
                if (!hash_equals((string) $existing->request_hash, $requestHash)) {
                    throw new DomainException('IDEMPOTENCY_CONFLICT');
                }
                $response = json_decode((string) $existing->response_json, true);
                return IntakeResponse::asReplay(is_array($response) ? $response : [], (int) $existing->intake_id);
            }

            $actual = $this->exporter->export((int) $request['page_id']);
            $this->identity->assertMatches($actual, [
                'page_id' => $request['page_id'],
                'canonical_url' => $request['canonical_url'],
                'title' => $request['title'],
                'content_hash' => $request['content_hash'],
            ]);
            $requestedWorkflow = (string) ($request['requested_workflow'] ?? '');
            $compiler = in_array($requestedWorkflow, ['ragflow_workflow', 'openai_compatible', 'offline'], true)
                ? $requestedWorkflow
                : (string) env('AI_GOVERNANCE_DEFAULT_COMPILER', 'offline');
            $queued = $this->queue->execute([
                'actual' => $actual,
                'expected' => $request,
                'material_type' => $request['material_type'],
                'workflow' => $compiler,
                'trigger_type' => 'intake',
            ]);
            $source = $this->assets->findBySourceKey((string) $queued['source_key'], 'source');
            $response = [
                'schema_version' => 'drvknowledge.intake-response.v2',
                'trace_id' => $request['trace_id'],
                'intake_id' => null,
                'client_submission_id' => $request['client_submission_id'],
                'content_ref' => 'bookstack:page:' . $request['page_id'],
                'source_key' => $queued['source_key'],
                'source_version' => $queued['source_version'],
                'content_hash' => $queued['content_hash'],
                'task_id' => (string) $queued['task_id'],
                'compile_status' => 'queued',
                'replayed' => false,
            ];
            $intakeId = $this->intakes->create([
                'client_submission_id' => $request['client_submission_id'],
                'idempotency_key' => $idempotencyKey,
                'trace_id' => $request['trace_id'],
                'request_hash' => $requestHash,
                'page_id' => $request['page_id'],
                'source_asset_id' => $source?->asset_id,
                'compile_task_id' => $queued['task_id'],
                'requested_by' => $requestedBy,
                'intake_status' => 'accepted',
                'source_hash' => $queued['content_hash'],
                'request_json' => json_encode($request, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                'response_json' => null,
                'last_error' => null,
            ]);
            $response['intake_id'] = (string) $intakeId;
            DB::table('drv_kb_intakes')->where('intake_id', $intakeId)->update([
                'response_json' => json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                'updated_at' => now(),
            ]);
            return $response;
        });
    }

    /** @param array<string, mixed> $request */
    private function requestHash(array $request): string
    {
        ksort($request);
        return hash('sha256', json_encode($request, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
    }
}

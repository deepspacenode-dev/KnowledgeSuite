<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Intake;

final class IntakeResponse
{
    /** @param array<string, mixed> $stored @return array<string, mixed> */
    public static function asReplay(array $stored, int $intakeId): array
    {
        if (!isset($stored['intake_id'])) {
            $stored['intake_id'] = (string) $intakeId;
        }
        $stored['replayed'] = true;

        return $stored;
    }

    /** @param array<string, mixed> $stored @return array<string, mixed> */
    public static function withCurrentCompileStatus(array $stored, ?string $compileStatus): array
    {
        $compileStatus = trim((string) $compileStatus);
        if ($compileStatus !== '') {
            $stored['compile_status'] = $compileStatus;
        }

        return $stored;
    }
}

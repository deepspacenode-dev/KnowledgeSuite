<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Contract;

use DomainException;

final class ContractValidatorV2
{
    /** @param array<string, mixed> $payload */
    public function assertIntake(array $payload): void
    {
        $this->assertExactFields($payload, [
            'schema_version', 'trace_id', 'client_submission_id', 'page_id', 'canonical_url',
            'title', 'material_type', 'content_hash', 'requested_workflow', 'source_key', 'content_ref', 'client',
        ]);
        $required = ['schema_version', 'trace_id', 'client_submission_id', 'page_id', 'canonical_url', 'title', 'material_type', 'content_hash'];
        $this->assertRequired($payload, $required);
        $clientValid = true;
        if (array_key_exists('client', $payload)) {
            if (!is_array($payload['client'])) {
                throw new DomainException('CONTRACT_INVALID');
            }
            $this->assertExactFields($payload['client'], ['name', 'version']);
            $this->assertRequired($payload['client'], ['name', 'version']);
            $clientValid = is_string($payload['client']['name']) && trim($payload['client']['name']) !== ''
                && strlen($payload['client']['name']) <= 64
                && is_string($payload['client']['version']) && trim($payload['client']['version']) !== ''
                && strlen($payload['client']['version']) <= 32;
        }
        $valid = ($payload['schema_version'] ?? null) === 'drvknowledge.intake-request.v2'
            && is_string($payload['trace_id']) && strlen($payload['trace_id']) >= 8
            && strlen($payload['trace_id']) <= 128
            && is_string($payload['client_submission_id']) && preg_match('/^[A-Za-z0-9._:-]{8,128}$/', $payload['client_submission_id']) === 1
            && is_int($payload['page_id']) && $payload['page_id'] > 0
            && filter_var($payload['canonical_url'], FILTER_VALIDATE_URL) !== false
            && preg_match('/^https?:\/\//', $payload['canonical_url']) === 1
            && is_string($payload['title']) && trim($payload['title']) !== '' && strlen($payload['title']) <= 255
            && in_array($payload['material_type'], ['cases', 'manuals', 'tech_notes', 'project_docs', 'docs'], true)
            && is_string($payload['content_hash']) && preg_match('/^[a-f0-9]{64}$/', $payload['content_hash']) === 1
            && $clientValid;
        if (!$valid) {
            throw new DomainException('CONTRACT_INVALID');
        }
        $pageId = (int) $payload['page_id'];
        if (isset($payload['source_key']) && $payload['source_key'] !== "bookstack_page:{$pageId}") {
            throw new DomainException('CONTRACT_INVALID');
        }
        if (isset($payload['content_ref']) && $payload['content_ref'] !== "bookstack:page:{$pageId}") {
            throw new DomainException('CONTRACT_INVALID');
        }
        if (isset($payload['requested_workflow']) && !in_array($payload['requested_workflow'], [
            'drvknowledge_worker', 'ragflow_workflow', 'openai_compatible', 'offline',
        ], true)) {
            throw new DomainException('CONTRACT_INVALID');
        }
    }

    /** @param array<string, mixed> $result */
    public function assertWikiResult(array $result): void
    {
        $this->assertExactFields($result, [
            'schema_version', 'trace_id', 'task_id', 'result_id', 'generated_at', 'source_key',
            'source_version', 'compiler', 'status', 'title', 'markdown', 'front_matter',
            'sources', 'quality_report', 'relations',
        ]);
        $this->assertRequired($result, [
            'schema_version', 'trace_id', 'task_id', 'result_id', 'source_key', 'source_version',
            'compiler', 'status', 'title', 'markdown', 'front_matter', 'sources', 'quality_report',
        ]);
        $frontMatter = is_array($result['front_matter'] ?? null) ? $result['front_matter'] : [];
        $compiler = is_array($result['compiler'] ?? null) ? $result['compiler'] : [];
        $quality = is_array($result['quality_report'] ?? null) ? $result['quality_report'] : [];
        $this->assertExactFields($compiler, ['system', 'workflow', 'model']);
        $this->assertRequired($compiler, ['system', 'workflow']);
        $this->assertExactFields($quality, ['score', 'warnings', 'reject_reasons']);
        $this->assertRequired($quality, ['score', 'warnings', 'reject_reasons']);
        $sourcesValid = $this->validateSources($result['sources'] ?? null);
        $relationsValid = !array_key_exists('relations', $result)
            || $this->isArrayList($result['relations']);
        $score = $quality['score'] ?? null;
        $valid = ($result['schema_version'] ?? null) === 'drvknowledge.wiki-result.v2'
            && is_string($result['trace_id']) && strlen($result['trace_id']) >= 8 && strlen($result['trace_id']) <= 128
            && is_string($result['task_id']) && $result['task_id'] !== '' && strlen($result['task_id']) <= 128
            && is_string($result['result_id']) && $result['result_id'] !== '' && strlen($result['result_id']) <= 128
            && is_string($result['source_key']) && preg_match('/^bookstack_page:[1-9][0-9]*$/', $result['source_key']) === 1
            && is_int($result['source_version']) && $result['source_version'] > 0
            && ($compiler['system'] ?? null) === 'drvknowledge_worker'
            && is_string($compiler['workflow'] ?? null) && $compiler['workflow'] !== ''
            && (!array_key_exists('model', $compiler) || $compiler['model'] === null || is_string($compiler['model']))
            && ($result['status'] ?? null) === 'draft'
            && is_string($result['title']) && trim($result['title']) !== '' && strlen($result['title']) <= 255
            && is_string($result['markdown']) && trim($result['markdown']) !== ''
            && is_string($frontMatter['title'] ?? null) && trim($frontMatter['title']) !== ''
            && ($frontMatter['status'] ?? null) === 'draft'
            && ($frontMatter['rag_enabled'] ?? null) === false
            && ($frontMatter['source_key'] ?? null) === $result['source_key']
            && in_array($frontMatter['material_type'] ?? null, ['cases', 'manuals', 'tech_notes', 'project_docs', 'docs'], true)
            && $sourcesValid
            && is_numeric($score) && (float) $score >= 0 && (float) $score <= 100
            && $this->isStringList($quality['warnings'] ?? null)
            && $this->isStringList($quality['reject_reasons'] ?? null)
            && $relationsValid;
        if (!$valid) {
            throw new DomainException('CONTRACT_INVALID');
        }
    }

    /** @param array<string, mixed> $payload @param array<int, string> $allowed */
    private function assertExactFields(array $payload, array $allowed): void
    {
        if (array_diff(array_keys($payload), $allowed) !== []) {
            throw new DomainException('CONTRACT_INVALID');
        }
    }

    /** @param array<string, mixed> $payload @param array<int, string> $required */
    private function assertRequired(array $payload, array $required): void
    {
        foreach ($required as $field) {
            if (!array_key_exists($field, $payload)) {
                throw new DomainException('CONTRACT_INVALID');
            }
        }
    }

    private function isStringList(mixed $value): bool
    {
        if (!is_array($value) || !array_is_list($value)) {
            return false;
        }
        foreach ($value as $item) {
            if (!is_string($item)) {
                return false;
            }
        }
        return true;
    }

    private function isArrayList(mixed $value): bool
    {
        if (!is_array($value) || !array_is_list($value)) {
            return false;
        }
        foreach ($value as $item) {
            if (!is_array($item)) {
                return false;
            }
        }
        return true;
    }

    private function validateSources(mixed $sources): bool
    {
        if (!is_array($sources) || !array_is_list($sources) || $sources === []) {
            return false;
        }
        foreach ($sources as $source) {
            if (!is_array($source)) {
                return false;
            }
            $this->assertExactFields($source, ['title', 'url', 'source_key', 'section']);
            $this->assertRequired($source, ['title', 'url', 'source_key']);
            if (!is_string($source['title']) || trim($source['title']) === ''
                || !is_string($source['url']) || filter_var($source['url'], FILTER_VALIDATE_URL) === false
                || !is_string($source['source_key']) || preg_match('/^bookstack_page:[1-9][0-9]*$/', $source['source_key']) !== 1
                || (array_key_exists('section', $source) && $source['section'] !== null && !is_string($source['section']))
            ) {
                return false;
            }
        }
        return true;
    }
}

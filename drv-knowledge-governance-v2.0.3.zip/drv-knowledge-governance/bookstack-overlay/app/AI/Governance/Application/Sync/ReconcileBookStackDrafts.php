<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Sync;

use BookStack\AI\Governance\Application\Compile\QueueCompileTask;
use BookStack\AI\Governance\Application\Rag\AiShelfPolicy;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackHierarchyQuery;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackPageExporter;
use Throwable;

final class ReconcileBookStackDrafts
{
    public function __construct(
        private readonly BookStackHierarchyQuery $hierarchy,
        private readonly BookStackPageExporter $exporter,
        private readonly QueueCompileTask $queue,
        private readonly AiShelfPolicy $shelfPolicy,
    ) {
    }

    /** @return array<string, mixed> */
    public function execute(?int $pageId = null, int $limit = 200): array
    {
        $pageIds = $pageId ? [$pageId] : array_slice($this->hierarchy->visiblePageIds(), 0, max(1, min(1000, $limit)));
        $queued = [];
        $skipped = [];
        $failed = [];
        foreach ($pageIds as $candidate) {
            try {
                $this->shelfPolicy->assertPageAllowed((int) $candidate);
                $actual = $this->exporter->export((int) $candidate);
                $markdown = (string) ($actual['markdown'] ?? '');
                if (preg_match('/^status:\s*draft\s*$/mi', $markdown) !== 1) {
                    $skipped[] = ['page_id' => (int) $candidate, 'reason' => 'not_draft'];
                    continue;
                }
                preg_match('/^material_type:\s*([a-z_]+)\s*$/mi', $markdown, $materialMatch);
                $material = $materialMatch[1] ?? 'docs';
                $queued[] = $this->queue->execute([
                    'actual' => $actual,
                    'expected' => $actual,
                    'material_type' => $material,
                    'workflow' => (string) env('AI_GOVERNANCE_DEFAULT_COMPILER', 'offline'),
                    'trigger_type' => 'reconcile',
                ]);
            } catch (Throwable $exception) {
                $failed[] = ['page_id' => (int) $candidate, 'error' => $exception->getMessage()];
            }
        }
        return ['queued' => $queued, 'skipped' => $skipped, 'failed' => $failed];
    }
}

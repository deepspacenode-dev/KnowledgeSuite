<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Sync;

use BookStack\AI\Governance\Application\Quality\QualityGate;
use BookStack\AI\Governance\Infrastructure\Persistence\QualityCheckRepository;
use Illuminate\Support\Facades\DB;

final class RefreshQualityChecks
{
    public function __construct(
        private readonly QualityGate $qualityGate,
        private readonly QualityCheckRepository $qualityChecks,
    ) {
    }

    /** @return array<string, mixed> */
    public function execute(?int $assetId = null, int $limit = 200): array
    {
        $query = DB::table('drv_kb_assets')->where('asset_type', 'wiki')->orderBy('asset_id');
        if ($assetId !== null) {
            $query->where('asset_id', $assetId);
        }
        $items = [];
        foreach ($query->limit(max(1, min(1000, $limit)))->get() as $asset) {
            $metadata = json_decode((string) $asset->metadata_json, true);
            $metadata = is_array($metadata) ? $metadata : [];
            $quality = $this->qualityGate->evaluate([
                'metadata' => is_array($metadata['front_matter'] ?? null) ? $metadata['front_matter'] : [],
                'sources' => is_array($metadata['sources'] ?? null) ? $metadata['sources'] : [],
                'markdown' => (string) ($metadata['wiki_markdown'] ?? ''),
                'source_modified_after_review' => (bool) ($metadata['source_modified_after_review'] ?? false),
            ], 'reviewed');
            $this->qualityChecks->record([
                'asset_id' => (int) $asset->asset_id,
                'source_version' => (int) $asset->current_version,
                'check_type' => 'deterministic_sync',
                'content_score' => $quality['quality_score'],
                'metadata_score' => $quality['quality_score'],
                'warnings_json' => json_encode($quality['warnings'], JSON_UNESCAPED_UNICODE),
                'reject_reasons_json' => json_encode($quality['reject_reasons'], JSON_UNESCAPED_UNICODE),
            ]);
            $items[] = ['asset_id' => (int) $asset->asset_id, 'quality' => $quality];
        }
        return ['processed' => count($items), 'items' => $items];
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Rag;

use BookStack\AI\Governance\Infrastructure\Persistence\AssetRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\AuditEventRepository;
use Throwable;

final class QueueReviewedWikiForPublish
{
    public function __construct(
        private readonly AuditEventRepository $audit,
        private readonly AssetRepository $assets,
        private readonly RagDatasetResolver $datasets,
        private readonly PublishWikiAsset $publish,
    ) {
    }

    /** @return array{published: array<int, mixed>, failed: array<int, mixed>} */
    public function dispatchPending(int $limit = 50): array
    {
        $published = [];
        $failed = [];
        foreach ($this->audit->pendingPublishEvents($limit) as $event) {
            $assetId = (int) $event->object_id;
            $asset = $this->assets->findById($assetId);
            $dataset = $asset ? $this->datasets->forAsset($assetId) : '';
            try {
                $published[] = $this->publish->execute($assetId, $dataset, $event->actor_id ? (int) $event->actor_id : null);
                $this->audit->markDispatched((int) $event->audit_event_id);
            } catch (Throwable $exception) {
                $failed[] = ['asset_id' => $assetId, 'error_code' => $exception->getMessage()];
            }
        }

        return ['published' => $published, 'failed' => $failed];
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Rag;

use BookStack\AI\Governance\Infrastructure\Persistence\RagSnapshotRepository;
use BookStack\AI\Governance\Infrastructure\RagFlow\RagFlowGateway;
use Illuminate\Support\Facades\DB;
use Throwable;

final class RefreshRagSnapshots
{
    public function __construct(
        private readonly RagSnapshotRepository $snapshots,
        private readonly RagFlowGateway $ragFlow,
    ) {
    }

    /** @return array{refreshed: array<int, mixed>, failed: array<int, mixed>} */
    public function execute(?int $assetId = null, int $limit = 200): array
    {
        $query = DB::table('drv_kb_rag_snapshot')->select('asset_id')->distinct()->orderBy('asset_id');
        if ($assetId !== null) {
            $query->where('asset_id', $assetId);
        }
        $refreshed = [];
        $failed = [];
        foreach ($query->limit(max(1, min(1000, $limit)))->pluck('asset_id') as $candidateId) {
            $snapshot = $this->snapshots->latestForAsset((int) $candidateId);
            if ($snapshot === null || !in_array((string) $snapshot->parse_status, ['queued', 'parsing'], true)) {
                continue;
            }
            try {
                $status = $this->ragFlow->documentStatus(
                    (string) $snapshot->dataset_id,
                    (string) $snapshot->document_id,
                );
                $this->snapshots->record([
                    'asset_id' => (int) $snapshot->asset_id,
                    'dataset_id' => (string) $snapshot->dataset_id,
                    'document_id' => (string) $snapshot->document_id,
                    'content_hash' => (string) $snapshot->content_hash,
                    'parse_status' => (string) $status['parse_status'],
                    'chunk_count' => $status['chunk_count'] ?? $snapshot->chunk_count,
                    'last_action_result' => $snapshot->last_action_result,
                    'image_documents_json' => $snapshot->image_documents_json,
                    'last_error' => null,
                ]);
                $refreshed[] = [
                    'asset_id' => (int) $snapshot->asset_id,
                    'parse_status' => (string) $status['parse_status'],
                    'chunk_count' => $status['chunk_count'] ?? null,
                ];
            } catch (Throwable $exception) {
                $failed[] = [
                    'asset_id' => (int) $snapshot->asset_id,
                    'error_code' => $exception->getMessage(),
                ];
            }
        }

        return ['refreshed' => $refreshed, 'failed' => $failed];
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Rag;

use BookStack\AI\Governance\Domain\ReviewStatus;
use BookStack\AI\Governance\Domain\StateTransition;
use BookStack\AI\Governance\Infrastructure\BookStack\ArticleImageCollector;
use BookStack\AI\Governance\Infrastructure\Persistence\AssetRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\AuditEventRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\RagSnapshotRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\ReviewRepository;
use BookStack\AI\Governance\Infrastructure\RagFlow\RagFlowGateway;
use DomainException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

final class PublishWikiAsset
{
    public function __construct(
        private readonly AssetRepository $assets,
        private readonly ReviewRepository $reviews,
        private readonly RagSnapshotRepository $snapshots,
        private readonly AuditEventRepository $audit,
        private readonly RagFlowGateway $ragFlow,
        private readonly ArticleImageCollector $imageCollector,
        private readonly AiShelfPolicy $shelfPolicy,
    ) {
    }

    /** @return array<string, mixed> */
    public function execute(int $assetId, string $datasetId, ?int $actorId = null): array
    {
        $asset = $this->assets->findById($assetId);
        if ($asset === null || ($asset->asset_type ?? null) !== 'wiki') {
            throw new DomainException('Only Wiki assets may enter formal RAG.');
        }
        $this->shelfPolicy->assertPageAllowed((int) $asset->page_id);
        $review = $this->reviews->latestForAsset($assetId);
        $reviewStatus = ReviewStatus::from((string) ($review->review_status ?? ReviewStatus::Draft->value));
        StateTransition::assertFormalPublishAllowed($reviewStatus);
        if (($review->gate_result ?? 'blocked') === 'blocked') {
            throw new DomainException('Quality gate blocked formal RAG publishing.');
        }

        $metadata = json_decode((string) $asset->metadata_json, true);
        $markdown = is_array($metadata) ? (string) ($metadata['wiki_markdown'] ?? '') : '';
        if ($markdown === '') {
            throw new DomainException('Wiki Markdown is unavailable.');
        }
        $frontMatter = is_array($metadata['front_matter'] ?? null) ? $metadata['front_matter'] : [];
        $ragEnabled = $frontMatter['rag_enabled'] ?? $metadata['rag_enabled'] ?? true;
        if (filter_var($ragEnabled, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE) === false) {
            throw new DomainException('RAG_PUBLISH_DISABLED');
        }
        $sourceUrl = (string) ($frontMatter['page_url'] ?? $frontMatter['source_url'] ?? $metadata['sources'][0]['url'] ?? '');
        $ragMetadata = $this->ragMetadata($asset, $frontMatter, $sourceUrl, $reviewStatus);
        $parserConfig = $this->parserConfig();
        $images = $this->imageCollector->collect($markdown, $sourceUrl);
        $publishHash = hash('sha256', (string) $asset->content_hash . implode('', array_column($images, 'sha256')));
        $existing = $this->snapshots->latestForAsset($assetId);
        $existingImages = $this->decodeImageDocuments($existing->image_documents_json ?? null);
        if ($existing
            && !in_array((string) $existing->parse_status, ['deleted', 'failed'], true)
            && $existing->dataset_id === $datasetId
            && hash_equals((string) $existing->content_hash, $publishHash)
        ) {
            return [
                'action_result' => 'skipped',
                'document_id' => $existing->document_id,
                'image_document_ids' => array_column($existingImages, 'document_id'),
                'content_hash' => $publishHash,
            ];
        }

        $action = $existing === null ? 'created' : ($existing->dataset_id === $datasetId ? 'updated' : 'moved');
        if ($existing !== null && !in_array((string) $existing->parse_status, ['deleted', 'failed'], true)) {
            $oldDocumentIds = array_values(array_filter(array_merge(
                [(string) $existing->document_id],
                array_column($existingImages, 'document_id'),
            )));
            try {
                $this->ragFlow->deleteDocuments((string) $existing->dataset_id, $oldDocumentIds);
            } catch (RuntimeException $exception) {
                throw new DomainException('RAG_DELETE_FAILED', 0, $exception);
            }
            $this->snapshots->record([
                'asset_id' => $assetId,
                'dataset_id' => (string) $existing->dataset_id,
                'document_id' => (string) $existing->document_id,
                'content_hash' => (string) $existing->content_hash,
                'parse_status' => 'deleted',
                'chunk_count' => null,
                'last_action_result' => $action,
                'image_documents_json' => json_encode([], JSON_THROW_ON_ERROR),
                'last_error' => null,
            ]);
        }

        $manifest = $this->imageManifest($images);
        $uploadedIds = [];
        $imageDocuments = [];
        $uploadingImage = false;
        $phase = 'upload';
        try {
            $upload = $this->ragFlow->uploadDocument($datasetId, $this->filename($asset), $markdown . $manifest);
            $uploadedIds[] = $upload['document_id'];
            $phase = 'configure';
            $this->ragFlow->configureDocument($datasetId, $upload['document_id'], $ragMetadata, 'naive', $parserConfig);
            foreach ($images as $image) {
                $phase = 'upload';
                $uploadingImage = true;
                $imageUpload = $this->ragFlow->uploadBinary($datasetId, $image['filename'], $image['bytes'], $image['mime']);
                $uploadedIds[] = $imageUpload['document_id'];
                $phase = 'configure';
                $imageMetadata = array_replace($ragMetadata, [
                    'source_url' => $image['url'],
                    'image_sha256' => $image['sha256'],
                    'parent_document_id' => $upload['document_id'],
                ]);
                $this->ragFlow->configureDocument($datasetId, $imageUpload['document_id'], $imageMetadata, 'picture');
                $imageDocuments[] = [
                    'document_id' => $imageUpload['document_id'],
                    'filename' => $image['filename'],
                    'source_url' => $image['url'],
                    'sha256' => $image['sha256'],
                    'size' => $image['size'],
                    'mime' => $image['mime'],
                ];
            }
            $phase = 'parse';
            $this->ragFlow->startParsing($datasetId, $uploadedIds);
        } catch (RuntimeException $exception) {
            if ($uploadedIds !== []) {
                try {
                    $this->ragFlow->deleteDocuments($datasetId, $uploadedIds);
                } catch (RuntimeException) {
                    // The audit error remains authoritative; cleanup is best effort.
                }
            }
            $code = match ($phase) {
                'configure' => 'RAG_CONFIGURE_FAILED',
                'parse' => 'RAG_PARSE_START_FAILED',
                default => $uploadingImage ? 'RAG_IMAGE_UPLOAD_FAILED' : 'RAG_UPLOAD_FAILED',
            };
            throw new DomainException($code, 0, $exception);
        }

        try {
            DB::transaction(function () use ($assetId, $datasetId, $upload, $publishHash, $action, $imageDocuments, $actorId): void {
                $this->snapshots->record([
                    'asset_id' => $assetId,
                    'dataset_id' => $datasetId,
                    'document_id' => $upload['document_id'],
                    'content_hash' => $publishHash,
                    'parse_status' => 'queued',
                    'chunk_count' => null,
                    'last_action_result' => $action,
                    'image_documents_json' => json_encode($imageDocuments, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                    'last_error' => null,
                ]);
                $this->audit->append([
                    'trace_id' => (string) Str::uuid(),
                    'event_type' => 'rag.published',
                    'object_type' => 'asset',
                    'object_id' => (string) $assetId,
                    'actor_id' => $actorId,
                    'after_digest' => $publishHash,
                    'metadata_json' => [
                        'dataset_id' => $datasetId,
                        'document_id' => $upload['document_id'],
                        'image_document_ids' => array_column($imageDocuments, 'document_id'),
                        'action_result' => $action,
                    ],
                ]);
            });
        } catch (Throwable $exception) {
            try {
                $this->ragFlow->deleteDocuments($datasetId, $uploadedIds);
            } catch (RuntimeException) {
                // Preserve the state-write error while cleanup remains best effort.
            }
            throw new DomainException('RAG_STATE_WRITE_FAILED', 0, $exception);
        }

        return [
            'action_result' => $action,
            'document_id' => $upload['document_id'],
            'image_document_ids' => array_column($imageDocuments, 'document_id'),
            'content_hash' => $publishHash,
        ];
    }

    private function filename(object $asset): string
    {
        $safe = preg_replace('/[^A-Za-z0-9._-]+/', '-', (string) $asset->title) ?: 'wiki';
        return "{$safe}-v{$asset->current_version}.md";
    }

    /** @param array<string, mixed> $frontMatter @return array<string, mixed> */
    private function ragMetadata(object $asset, array $frontMatter, string $sourceUrl, ReviewStatus $reviewStatus): array
    {
        $pageId = (int) $asset->page_id;
        return [
            'page_id' => (string) $pageId,
            'bookstack_page_id' => (string) $pageId,
            'page_url' => $sourceUrl,
            'source_url' => $sourceUrl,
            'source_key' => (string) $asset->source_key,
            'content_ref' => "bookstack:page:{$pageId}",
            'title' => (string) $asset->title,
            'material_type' => $this->normalizeDomainMetadata($frontMatter['material_type'] ?? $asset->material_type ?? 'docs'),
            'status' => $reviewStatus->value,
            'module' => $this->normalizeDomainMetadata($frontMatter['module'] ?? 'unknown'),
            'platform' => $this->normalizeDomainMetadata($frontMatter['platform'] ?? 'unknown'),
            'chip' => $this->normalizeDomainMetadata($frontMatter['chip'] ?? 'unknown'),
            'project' => $this->normalizeDomainMetadata($frontMatter['project'] ?? 'unknown'),
            'rag_enabled' => true,
            'ingestion_profile' => 'bookstack-markdown-v1',
        ];
    }

    private function normalizeDomainMetadata(mixed $value): string
    {
        $normalized = strtolower(trim((string) $value));
        return $normalized !== '' ? $normalized : 'unknown';
    }

    /** @return array<string, mixed> */
    private function parserConfig(): array
    {
        return [
            'layout_recognize' => 'DeepDOC',
            'chunk_token_num' => max(128, min((int) env('RAGFLOW_MARKDOWN_CHUNK_TOKENS', 512), 2048)),
            'delimiter' => "\n",
            'auto_keywords' => 0,
            'auto_questions' => 0,
            'html4excel' => false,
            'raptor' => ['use_raptor' => false],
            'graphrag' => ['use_graphrag' => false],
            'parent_child' => ['use_parent_child' => false, 'children_delimiter' => "\n"],
        ];
    }

    /** @return array<int, array<string, mixed>> */
    private function decodeImageDocuments(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }
        $decoded = is_string($value) ? json_decode($value, true) : null;
        return is_array($decoded) ? $decoded : [];
    }

    /** @param array<int, array<string, mixed>> $images */
    private function imageManifest(array $images): string
    {
        if ($images === []) {
            return '';
        }
        $lines = ["\n\n## 关联图片\n"];
        foreach ($images as $image) {
            $lines[] = '- `' . $image['filename'] . '` - ' . $image['url'];
        }
        return implode("\n", $lines) . "\n";
    }
}

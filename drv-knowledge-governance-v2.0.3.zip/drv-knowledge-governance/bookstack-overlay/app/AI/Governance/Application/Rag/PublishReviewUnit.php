<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Rag;

use BookStack\AI\Governance\Application\Review\ReviewUnitQuery;
use DomainException;
use Throwable;

final class PublishReviewUnit
{
    public function __construct(
        private readonly ReviewUnitQuery $units,
        private readonly RagDatasetResolver $datasets,
        private readonly PublishWikiAsset $publish,
    ) {
    }

    /** @param array<string, mixed> $command @return array<string, mixed> */
    public function execute(array $command): array
    {
        $unit = $this->units->find((string) ($command['unit_key'] ?? ''), $command['bookshelf_id'] ?? null);
        if ($unit === null) {
            throw new DomainException('评审单元不存在或当前用户不可见。');
        }
        if (($unit['can_publish'] ?? false) !== true) {
            throw new DomainException('该评审单元尚未全部通过审核，或仍有页面未生成 Wiki，无法一键入库。');
        }

        $published = [];
        $failed = [];
        foreach ((array) $unit['members'] as $member) {
            $assetId = (int) ($member['asset_id'] ?? 0);
            $title = (string) ($member['page_title'] ?? "知识资产 #{$assetId}");
            $datasetId = $assetId > 0 ? $this->datasets->forAsset($assetId) : '';
            if ($datasetId === '') {
                $failed[] = [
                    'asset_id' => $assetId,
                    'title' => $title,
                    'error_code' => 'RAG_DATASET_NOT_CONFIGURED',
                    'message' => '未配置该文档对应的 RAGFlow 数据集。',
                ];
                continue;
            }
            try {
                $result = $this->publish->execute($assetId, $datasetId, (int) ($command['actor_id'] ?? 0));
                $published[] = [
                    'asset_id' => $assetId,
                    'title' => $title,
                    'dataset_id' => $datasetId,
                    'action_result' => $result['action_result'] ?? 'created',
                    'document_id' => $result['document_id'] ?? null,
                ];
            } catch (Throwable $error) {
                $failed[] = [
                    'asset_id' => $assetId,
                    'title' => $title,
                    'error_code' => $error->getMessage() ?: 'RAG_PUBLISH_FAILED',
                    'message' => $this->failureMessage($error),
                ];
            }
        }

        return [
            'unit_key' => $unit['unit_key'],
            'unit_type' => $unit['unit_type'],
            'published' => $published,
            'failed' => $failed,
        ];
    }

    private function failureMessage(Throwable $error): string
    {
        return match ($error->getMessage()) {
            'RAG_PUBLISH_DISABLED' => '该知识已被标记为禁止入库。',
            'RAG_DELETE_FAILED' => '删除旧 RAGFlow 文档失败，未上传新版本。',
            'RAG_CONFIGURE_FAILED' => 'RAGFlow 文档参数配置失败。',
            'RAG_PARSE_START_FAILED' => '文档已上传，但触发解析失败。',
            'RAG_IMAGE_UPLOAD_FAILED' => '文章关联图片上传失败。',
            'RAG_UPLOAD_FAILED' => 'Wiki Markdown 上传失败。',
            'RAG_STATE_WRITE_FAILED' => 'RAGFlow 已处理文档，但治理状态写入失败并已尝试清理。',
            default => '入库失败，请检查审核门禁、AI 书架限制、RAGFlow 配置和服务状态。',
        };
    }
}

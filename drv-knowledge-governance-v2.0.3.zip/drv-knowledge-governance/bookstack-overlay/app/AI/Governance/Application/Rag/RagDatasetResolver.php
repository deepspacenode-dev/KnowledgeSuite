<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Rag;

use BookStack\AI\Governance\Infrastructure\Persistence\AssetRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\RagSnapshotRepository;

final class RagDatasetResolver
{
    public function __construct(
        private readonly RagSnapshotRepository $snapshots,
        private readonly AssetRepository $assets,
    ) {
    }

    public function forAsset(int $assetId): string
    {
        $snapshot = $this->snapshots->latestForAsset($assetId);
        $datasetId = trim((string) ($snapshot->dataset_id ?? ''));
        if ($datasetId !== '') {
            return $datasetId;
        }

        $asset = $this->assets->findById($assetId);
        $metadata = is_string($asset->metadata_json ?? null)
            ? json_decode((string) $asset->metadata_json, true)
            : ($asset->metadata_json ?? []);
        $metadata = is_array($metadata) ? $metadata : [];
        $frontMatter = is_array($metadata['front_matter'] ?? null) ? $metadata['front_matter'] : [];
        foreach ([$frontMatter['dataset_id'] ?? null, $frontMatter['dataset'] ?? null, $metadata['dataset_id'] ?? null] as $candidate) {
            $datasetId = trim((string) $candidate);
            if ($datasetId !== '') {
                return $datasetId;
            }
        }

        $materialType = strtoupper((string) preg_replace('/[^A-Za-z0-9]+/', '_', (string) ($asset->material_type ?? '')));
        if ($materialType !== '') {
            $datasetId = trim((string) env('RAGFLOW_DATASET_ID_' . $materialType, ''));
            if ($datasetId !== '') {
                return $datasetId;
            }
        }

        return trim((string) env('RAGFLOW_DEFAULT_DATASET_ID', ''));
    }
}

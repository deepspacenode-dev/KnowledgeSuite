<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Rag;

use BookStack\AI\Governance\Infrastructure\Persistence\AssetRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\AuditEventRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\RagSnapshotRepository;
use BookStack\AI\Governance\Infrastructure\RagFlow\RagFlowGateway;
use DomainException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

final class RemoveWikiAssetFromRag
{
    public function __construct(
        private readonly AssetRepository $assets,
        private readonly RagSnapshotRepository $snapshots,
        private readonly AuditEventRepository $audit,
        private readonly RagFlowGateway $ragFlow,
    ) {
    }

    /** @return array<string, mixed> */
    public function execute(int $assetId, string $reason, ?int $actorId = null): array
    {
        $asset = $this->assets->findById($assetId);
        if ($asset === null || ($asset->asset_type ?? null) !== 'wiki') {
            throw new DomainException('RAG_ASSET_NOT_REMOVABLE');
        }
        $snapshot = $this->snapshots->latestForAsset($assetId);
        if ($snapshot === null) {
            throw new DomainException('RAG_NOT_INGESTED');
        }
        if (in_array((string) $snapshot->parse_status, ['disabled', 'deleted'], true)) {
            return [
                'removed' => true,
                'already_removed' => true,
                'asset_id' => $assetId,
                'dataset_id' => (string) $snapshot->dataset_id,
                'document_id' => (string) $snapshot->document_id,
            ];
        }

        $imageDocuments = $this->decodeImageDocuments($snapshot->image_documents_json ?? null);
        $documentIds = array_values(array_unique(array_filter(array_merge(
            [(string) $snapshot->document_id],
            array_map(static fn (array $image): string => (string) ($image['document_id'] ?? ''), $imageDocuments),
        ))));
        if ($documentIds !== []) {
            try {
                $this->ragFlow->deleteDocuments((string) $snapshot->dataset_id, $documentIds);
            } catch (RuntimeException $exception) {
                throw new DomainException('RAG_DELETE_FAILED', 0, $exception);
            }
        }

        $metadata = $this->decodeMetadata($asset->metadata_json ?? null);
        if (is_array($metadata['front_matter'] ?? null)) {
            $metadata['front_matter']['rag_enabled'] = false;
        } else {
            $metadata['rag_enabled'] = false;
        }
        $metadata['rag_removed_at'] = now()->toIso8601String();
        $metadata['rag_removed_reason'] = $reason;

        try {
            DB::transaction(function () use ($asset, $assetId, $snapshot, $metadata, $reason, $actorId): void {
                DB::table('drv_kb_assets')->where('asset_id', $assetId)->update([
                    'metadata_json' => json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
                    'updated_at' => now(),
                ]);
                $this->snapshots->record([
                    'asset_id' => $assetId,
                    'dataset_id' => (string) $snapshot->dataset_id,
                    'document_id' => (string) $snapshot->document_id,
                    'content_hash' => (string) $snapshot->content_hash,
                    'parse_status' => 'disabled',
                    'chunk_count' => 0,
                    'last_action_result' => 'deleted',
                    'image_documents_json' => json_encode([], JSON_THROW_ON_ERROR),
                    'last_error' => null,
                ]);
                $this->audit->append([
                    'trace_id' => (string) Str::uuid(),
                    'event_type' => 'rag.removed',
                    'object_type' => 'asset',
                    'object_id' => (string) $assetId,
                    'actor_id' => $actorId,
                    'before_digest' => (string) $snapshot->content_hash,
                    'after_digest' => hash('sha256', 'disabled:' . $assetId),
                    'metadata_json' => [
                        'dataset_id' => (string) $snapshot->dataset_id,
                        'document_id' => (string) $snapshot->document_id,
                        'reason' => $reason,
                    ],
                ]);
            });
        } catch (Throwable $exception) {
            throw new DomainException('RAG_STATE_WRITE_FAILED', 0, $exception);
        }

        return [
            'removed' => true,
            'already_removed' => false,
            'asset_id' => $assetId,
            'dataset_id' => (string) $snapshot->dataset_id,
            'document_id' => (string) $snapshot->document_id,
            'removed_document_count' => count($documentIds),
        ];
    }

    /** @return array<int, array<string, mixed>> */
    private function decodeImageDocuments(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }
        $decoded = is_string($value) ? json_decode($value, true) : null;
        return is_array($decoded) ? $decoded : [];
    }

    /** @return array<string, mixed> */
    private function decodeMetadata(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }
        $decoded = is_string($value) ? json_decode($value, true) : null;
        return is_array($decoded) ? $decoded : [];
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Rag;

use BookStack\AI\Governance\Infrastructure\BookStack\BookStackHierarchyQuery;
use DomainException;

final class AiShelfPolicy
{
    public function __construct(private readonly BookStackHierarchyQuery $hierarchy)
    {
    }

    public function assertPageAllowed(int $pageId): void
    {
        $page = $this->hierarchy->structure([$pageId])[$pageId] ?? null;
        self::assertHierarchyAllowed((array) ($page['bookshelf_memberships'] ?? []));
    }

    /** @param array<int, array<string, mixed>> $memberships */
    public static function assertHierarchyAllowed(array $memberships): void
    {
        foreach ($memberships as $membership) {
            if (str_starts_with(trim((string) ($membership['bookshelf_name'] ?? '')), '【AI】')) {
                return;
            }
        }
        throw new DomainException('RAG_SHELF_NOT_ALLOWED');
    }
}

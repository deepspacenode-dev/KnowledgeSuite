<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Review;

use BookStack\AI\Governance\Application\Quality\QualityGate;
use BookStack\AI\Governance\Domain\ReviewStatus;
use BookStack\AI\Governance\Domain\StateTransition;
use BookStack\AI\Governance\Infrastructure\Persistence\AssetRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\AuditEventRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\QualityCheckRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\ReviewRepository;
use DomainException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class MarkReview
{
    public function __construct(
        private readonly AssetRepository $assets,
        private readonly ReviewRepository $reviews,
        private readonly QualityCheckRepository $qualityChecks,
        private readonly AuditEventRepository $audit,
        private readonly QualityGate $qualityGate,
    ) {
    }

    /** @param array<string, mixed> $command @return array<string, mixed> */
    public function execute(array $command): array
    {
        $assetId = (int) ($command['asset_id'] ?? 0);
        $asset = $this->assets->findById($assetId);
        if ($asset === null) {
            throw new DomainException('Asset not found.');
        }
        $target = ReviewStatus::from((string) $command['review_status']);
        $currentRecord = $this->reviews->latestForAsset($assetId);
        $current = ReviewStatus::from((string) ($currentRecord->review_status ?? ReviewStatus::Draft->value));
        StateTransition::assertAllowed('review', $current->value, $target->value);

        $comment = trim((string) ($command['review_comment'] ?? ''));
        if (in_array($target, [ReviewStatus::NeedFix, ReviewStatus::Deprecated], true) && $comment === '') {
            throw new DomainException('A review comment is required for this decision.');
        }

        $isWiki = ($asset->asset_type ?? null) === 'wiki';
        $quality = $isWiki
            ? $this->qualityGate->evaluate($this->documentFromAsset($asset), $target->value)
            : $this->sourceReviewQuality();
        if (in_array($target, [ReviewStatus::Reviewed, ReviewStatus::Verified], true) && !$quality['allowed']) {
            throw new DomainException('Quality gate blocked this review decision.');
        }

        return DB::transaction(function () use ($asset, $assetId, $target, $comment, $command, $quality, $current, $isWiki): array {
            $sourceVersion = (int) ($command['source_version'] ?? $asset->current_version);
            $this->qualityChecks->record([
                'asset_id' => $assetId,
                'source_version' => $sourceVersion,
                'check_type' => 'deterministic',
                'content_score' => $quality['quality_score'],
                'metadata_score' => $quality['quality_score'],
                'warnings_json' => json_encode($quality['warnings'], JSON_UNESCAPED_UNICODE),
                'reject_reasons_json' => json_encode($quality['reject_reasons'], JSON_UNESCAPED_UNICODE),
            ]);
            $reviewId = $this->reviews->append([
                'asset_id' => $assetId,
                'source_version' => $sourceVersion,
                'review_status' => $target->value,
                'gate_result' => $quality['gate_result'],
                'reviewer_id' => (int) $command['reviewer_id'],
                'quality_score' => $quality['quality_score'],
                'review_comment' => $comment !== '' ? $comment : null,
                'reviewed_at' => now(),
            ]);
            $this->audit->append([
                'trace_id' => (string) Str::uuid(),
                'event_type' => 'review.marked',
                'object_type' => 'asset',
                'object_id' => (string) $assetId,
                'actor_id' => (int) $command['reviewer_id'],
                'before_digest' => hash('sha256', $current->value),
                'after_digest' => hash('sha256', $target->value),
                'metadata_json' => ['review_id' => $reviewId, 'gate_result' => $quality['gate_result']],
            ]);
            if ($isWiki && in_array($target, [ReviewStatus::Reviewed, ReviewStatus::Verified], true)) {
                $this->audit->append([
                    'trace_id' => (string) Str::uuid(),
                    'event_type' => 'wiki.publish.requested',
                    'object_type' => 'asset',
                    'object_id' => (string) $assetId,
                    'actor_id' => (int) $command['reviewer_id'],
                    'after_digest' => hash('sha256', $target->value),
                    'metadata_json' => ['asset_id' => $assetId],
                    'dispatch_status' => 'pending',
                ]);
            }

            return ['review_id' => $reviewId, 'status' => $target->value, 'quality' => $quality];
        });
    }

    /** @return array<string, mixed> */
    private function sourceReviewQuality(): array
    {
        return [
            'allowed' => true,
            'gate_result' => 'warning',
            'quality_score' => 80,
            'warnings' => ['source_asset_review_only'],
            'reject_reasons' => [],
        ];
    }

    /** @return array<string, mixed> */
    private function documentFromAsset(object $asset): array
    {
        $metadata = [];
        if (is_string($asset->metadata_json ?? null) && $asset->metadata_json !== '') {
            $decoded = json_decode($asset->metadata_json, true);
            $metadata = is_array($decoded) ? $decoded : [];
        } elseif (is_array($asset->metadata_json ?? null)) {
            $metadata = $asset->metadata_json;
        }

        $frontMatter = is_array($metadata['front_matter'] ?? null) ? $metadata['front_matter'] : $metadata;
        $sources = is_array($metadata['sources'] ?? null) ? $metadata['sources'] : [];
        if ($sources === [] && is_string($asset->source_key ?? null)) {
            $sources[] = $asset->source_key;
        }

        return [
            'metadata' => $frontMatter,
            'sources' => $sources,
            'markdown' => (string) ($metadata['wiki_markdown'] ?? ''),
            'source_modified_after_review' => (bool) ($metadata['source_modified_after_review'] ?? false),
        ];
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Review;

use BookStack\AI\Governance\Domain\ReviewStatus;
use BookStack\AI\Governance\Domain\StateTransition;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackHierarchyQuery;
use Illuminate\Support\Facades\DB;

final class ReviewUnitQuery
{
    public function __construct(
        private readonly BookStackHierarchyQuery $hierarchy,
        private readonly ReviewUnitResolver $resolver,
    ) {
    }

    /** @param array<string, mixed> $filters @return array{items: array<int, array<string, mixed>>, total: int} */
    public function execute(array $filters = []): array
    {
        $bookshelfId = $filters['bookshelf_id'] ?? null;
        $pageIds = $this->hierarchy->pageIdsForBookshelf($bookshelfId);
        $structure = $this->hierarchy->structure($pageIds);
        $assets = $this->effectiveAssets($pageIds);
        $reviews = $this->latestReviews(array_values(array_filter(array_map(static fn (?object $asset): int => (int) ($asset->asset_id ?? 0), $assets))));
        $units = [];

        foreach ($structure as $pageId => $page) {
            $memberships = (array) ($page['bookshelf_memberships'] ?? []);
            if ($bookshelfId !== null && $bookshelfId !== '') {
                $memberships = array_values(array_filter($memberships, static fn (array $membership): bool => (string) ($membership['bookshelf_id'] ?? 'unassigned') === (string) $bookshelfId));
            } else {
                $memberships = $memberships === [] ? [] : [$memberships[0]];
            }
            foreach ($memberships as $membership) {
                $unit = $this->resolver->unitForPage($page, $membership);
                $key = (string) $unit['unit_key'];
                $units[$key] ??= $unit + ['members' => [], 'status_counts' => []];
                $asset = $assets[(int) $pageId] ?? null;
                $review = $asset ? ($reviews[(int) $asset->asset_id] ?? null) : null;
                $status = (string) ($review->review_status ?? ReviewStatus::Draft->value);
                $units[$key]['members'][] = [
                    'page_id' => (int) $pageId,
                    'page_title' => (string) ($page['page_name'] ?? '未命名页面'),
                    'asset_id' => $asset ? (int) $asset->asset_id : null,
                    'asset_type' => $asset->asset_type ?? null,
                    'review_status' => $status,
                ];
                $units[$key]['status_counts'][$status] = (int) ($units[$key]['status_counts'][$status] ?? 0) + 1;
            }
        }

        $items = array_values(array_map(function (array $unit): array {
            $statuses = array_keys($unit['status_counts']);
            $unit['review_status'] = count($statuses) === 1 ? $statuses[0] : 'partial';
            $unit['member_count'] = count($unit['members']);
            $unit['asset_count'] = count(array_filter($unit['members'], static fn (array $member): bool => !empty($member['asset_id'])));
            $unit['publishable_count'] = count(array_filter(
                $unit['members'],
                static fn (array $member): bool => ($member['asset_type'] ?? null) === 'wiki'
                    && in_array((string) ($member['review_status'] ?? ''), [ReviewStatus::Reviewed->value, ReviewStatus::Verified->value], true),
            ));
            $unit['can_publish'] = $unit['member_count'] > 0 && $unit['publishable_count'] === $unit['member_count'];
            $actions = [];
            foreach ($statuses as $status) {
                $actions = array_merge($actions, StateTransition::allowedTargets('review', $status));
            }
            $unit['allowed_actions'] = array_values(array_unique($actions));
            return $unit;
        }, $units));

        if (!empty($filters['search'])) {
            $needle = trim((string) $filters['search']);
            $items = array_values(array_filter($items, static fn (array $unit): bool => str_contains((string) $unit['unit_title'], $needle) || str_contains((string) $unit['book_name'], $needle)));
        }
        if (!empty($filters['review_status'])) {
            $items = array_values(array_filter($items, static fn (array $unit): bool => (string) $unit['review_status'] === (string) $filters['review_status']));
        }
        usort($items, static fn (array $left, array $right): int => strcmp($left['bookshelf_name'] . $left['book_name'] . $left['unit_title'], $right['bookshelf_name'] . $right['book_name'] . $right['unit_title']));

        return ['items' => $items, 'total' => count($items)];
    }

    /** @return array<string, mixed>|null */
    public function find(string $unitKey, int|string|null $bookshelfId = null): ?array
    {
        foreach ($this->execute(['bookshelf_id' => $bookshelfId])['items'] as $unit) {
            if ((string) $unit['unit_key'] === $unitKey) {
                return $unit;
            }
        }
        return null;
    }

    /** @param array<int, int> $pageIds @return array<int, object> */
    private function effectiveAssets(array $pageIds): array
    {
        $rows = DB::table('drv_kb_assets')
            ->whereIn('page_id', $pageIds)
            ->orderByRaw("CASE asset_type WHEN 'wiki' THEN 0 ELSE 1 END")
            ->orderByDesc('current_version')
            ->orderByDesc('asset_id')
            ->get()
            ->all();
        $result = [];
        foreach ($rows as $row) {
            $result[(int) $row->page_id] ??= $row;
        }
        return $result;
    }

    /** @param array<int, int> $assetIds @return array<int, object> */
    private function latestReviews(array $assetIds): array
    {
        if ($assetIds === []) {
            return [];
        }
        $rows = DB::table('drv_kb_reviews')->whereIn('asset_id', $assetIds)->orderByDesc('created_at')->orderByDesc('review_id')->get()->all();
        $result = [];
        foreach ($rows as $row) {
            $result[(int) $row->asset_id] ??= $row;
        }
        return $result;
    }
}

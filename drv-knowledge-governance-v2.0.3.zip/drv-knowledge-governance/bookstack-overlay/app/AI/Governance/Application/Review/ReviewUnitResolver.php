<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Review;

final class ReviewUnitResolver
{
    /** @param array<string, mixed> $page @param array<string, mixed> $membership @return array<string, mixed> */
    public function unitForPage(array $page, array $membership): array
    {
        $shelfId = $membership['bookshelf_id'] ?? 'unassigned';
        $shelfName = (string) ($membership['bookshelf_name'] ?? '未归属书架');
        $chapterId = (int) ($page['chapter_id'] ?? 0);
        $directPages = (bool) ($page['direct_pages'] ?? ($chapterId <= 0));
        $chapterUnit = $this->isChapterReviewShelf($shelfName) && !$directPages && $chapterId > 0;

        if ($chapterUnit) {
            return [
                'unit_key' => "chapter:{$shelfId}:{$chapterId}",
                'unit_type' => 'chapter',
                'unit_title' => (string) ($page['chapter_name'] ?? '未命名章节'),
                'bookshelf_id' => $membership['bookshelf_id'] ?? null,
                'bookshelf_name' => $shelfName,
                'book_id' => $page['book_id'] ?? null,
                'book_name' => (string) ($page['book_name'] ?? '未归属书籍'),
                'chapter_id' => $chapterId,
                'chapter_name' => (string) ($page['chapter_name'] ?? '未命名章节'),
                'chapter_url' => $page['chapter_url'] ?? null,
            ];
        }

        $pageId = (int) ($page['page_id'] ?? 0);
        return [
            'unit_key' => "page:{$shelfId}:{$pageId}",
            'unit_type' => 'page',
            'unit_title' => (string) ($page['page_name'] ?? '未命名页面'),
            'bookshelf_id' => $membership['bookshelf_id'] ?? null,
            'bookshelf_name' => $shelfName,
            'book_id' => $page['book_id'] ?? null,
            'book_name' => (string) ($page['book_name'] ?? '未归属书籍'),
            'chapter_id' => $page['chapter_id'] ?? null,
            'chapter_name' => (string) ($page['chapter_name'] ?? '书籍直属页面'),
            'page_url' => $page['page_url'] ?? null,
        ];
    }

    public function isChapterReviewShelf(string $bookshelfName): bool
    {
        foreach ($this->chapterReviewShelfNames() as $configuredName) {
            if ($configuredName !== '' && str_contains($bookshelfName, $configuredName)) {
                return true;
            }
        }
        return false;
    }

    /** @return array<int, string> */
    public function chapterReviewShelfNames(): array
    {
        $configured = (string) env('AI_GOVERNANCE_CHAPTER_REVIEW_SHELVES', '芯片手册');
        return array_values(array_unique(array_filter(array_map('trim', preg_split('/[,，]/u', $configured) ?: []))));
    }
}

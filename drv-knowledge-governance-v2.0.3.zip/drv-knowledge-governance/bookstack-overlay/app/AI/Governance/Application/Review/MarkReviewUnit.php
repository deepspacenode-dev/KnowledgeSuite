<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Review;

use BookStack\AI\Governance\Domain\ReviewStatus;
use BookStack\AI\Governance\Domain\StateTransition;
use DomainException;
use Illuminate\Support\Facades\DB;

final class MarkReviewUnit
{
    public function __construct(
        private readonly ReviewUnitQuery $units,
        private readonly MarkReview $markReview,
    ) {
    }

    /** @param array<string, mixed> $command @return array<string, mixed> */
    public function execute(array $command): array
    {
        $unitKey = (string) ($command['unit_key'] ?? '');
        $unit = $this->units->find($unitKey, $command['bookshelf_id'] ?? null);
        if ($unit === null) {
            throw new DomainException('Review unit not found or not visible.');
        }
        $target = ReviewStatus::from((string) ($command['review_status'] ?? ''));

        return DB::transaction(function () use ($unit, $target, $command): array {
            $processed = [];
            $skipped = [];
            $blocked = [];
            foreach ((array) $unit['members'] as $member) {
                $assetId = (int) ($member['asset_id'] ?? 0);
                $current = (string) ($member['review_status'] ?? ReviewStatus::Draft->value);
                if ($assetId <= 0) {
                    $blocked[] = ['page_id' => $member['page_id'], 'title' => $member['page_title'], 'reason' => '尚未建立治理资产'];
                    continue;
                }
                if ($current === $target->value) {
                    $skipped[] = ['asset_id' => $assetId, 'title' => $member['page_title'], 'reason' => '状态未变化'];
                    continue;
                }
                if (!in_array($target->value, StateTransition::allowedTargets('review', $current), true)) {
                    $blocked[] = ['asset_id' => $assetId, 'title' => $member['page_title'], 'reason' => "不允许 {$current} -> {$target->value}"];
                    continue;
                }
                try {
                    $result = $this->markReview->execute([
                        'asset_id' => $assetId,
                        'review_status' => $target->value,
                        'review_comment' => (string) ($command['review_comment'] ?? ''),
                        'reviewer_id' => (int) $command['reviewer_id'],
                    ]);
                    $processed[] = ['asset_id' => $assetId, 'title' => $member['page_title'], 'review_id' => $result['review_id']];
                } catch (DomainException $error) {
                    throw new DomainException($member['page_title'] . ': ' . $error->getMessage(), 0, $error);
                }
            }

            return [
                'unit_key' => $unit['unit_key'],
                'unit_type' => $unit['unit_type'],
                'target_status' => $target->value,
                'processed' => $processed,
                'skipped' => $skipped,
                'blocked' => $blocked,
            ];
        });
    }
}

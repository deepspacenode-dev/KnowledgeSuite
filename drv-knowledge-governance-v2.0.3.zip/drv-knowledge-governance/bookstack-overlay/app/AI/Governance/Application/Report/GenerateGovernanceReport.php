<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Report;

use BookStack\AI\Governance\Application\Contribution\ContributionMetrics;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackHierarchyQuery;
use BookStack\AI\Governance\Infrastructure\Persistence\ReportRepository;
use Illuminate\Support\Facades\DB;

final class GenerateGovernanceReport
{
    public function __construct(
        private readonly BookStackHierarchyQuery $hierarchy,
        private readonly ContributionMetrics $contributions,
        private readonly ReportRepository $reports,
    ) {
    }

    /** @param array<string, mixed> $filters @return array<string, mixed> */
    public function execute(string $type, string $from, string $to, array $filters, int $actorId): array
    {
        $bookshelfId = $filters['bookshelf_id'] ?? null;
        $bookshelfName = $this->bookshelfName($bookshelfId);
        $pageIds = $this->hierarchy->pageIdsForBookshelf($bookshelfId);
        $assetQuery = DB::table('drv_kb_assets')->whereIn('page_id', $pageIds);
        $wikiIds = (clone $assetQuery)->where('asset_type', 'wiki')->pluck('asset_id');
        $bounds = $this->periodBounds($from, $to);
        $metrics = [
            'source_assets' => (clone $assetQuery)->where('asset_type', 'source')->count(),
            'wiki_assets' => $wikiIds->count(),
            'reviews_completed' => DB::table('drv_kb_reviews')->whereIn('asset_id', $wikiIds)->whereIn('review_status', ['reviewed', 'verified'])->whereBetween('created_at', $bounds)->distinct('asset_id')->count('asset_id'),
            'rag_ready' => DB::table('drv_kb_rag_snapshot')->whereIn('asset_id', $wikiIds)->where('parse_status', 'ready')->distinct('asset_id')->count('asset_id'),
            'quality_issues' => DB::table('drv_kb_quality_checks')->whereIn('asset_id', $wikiIds)->whereBetween('checked_at', $bounds)->whereRaw('JSON_LENGTH(reject_reasons_json) > 0 OR JSON_LENGTH(warnings_json) > 0')->count(),
            'open_gaps' => DB::table('drv_kb_gaps')->whereIn('gap_status', ['open', 'doing'])->count(),
            'bookshelf_id' => $bookshelfId,
            'bookshelf_name' => $bookshelfName,
            'contributions' => $this->contributions->between($from, $to, $bookshelfId),
            'contribution_details' => $this->contributions->contributionDetails($from, $to, $bookshelfId),
        ];
        $markdown = $this->markdown($type, $from, $to, $bookshelfName, $metrics);
        $reportId = $this->reports->store([
            'report_type' => $type,
            'period_start' => $from,
            'period_end' => $to,
            'filters_json' => json_encode($filters, JSON_UNESCAPED_UNICODE),
            'metrics_json' => json_encode($metrics, JSON_UNESCAPED_UNICODE),
            'markdown' => $markdown,
            'markdown_hash' => hash('sha256', $markdown),
            'generated_by' => $actorId,
        ]);

        return ['report_id' => $reportId, 'metrics' => $metrics, 'markdown' => $markdown, 'markdown_hash' => hash('sha256', $markdown)];
    }

    /** @param array<string, mixed> $metrics */
    private function markdown(string $type, string $from, string $to, string $bookshelfName, array $metrics): string
    {
        return "# 知识治理{$type}\n\n统计周期：{$from} 至 {$to}\n\n书架范围：{$bookshelfName}\n\n"
            . "## 建设成果\n\n| 指标 | 数量 |\n| --- | ---: |\n"
            . "| 原始资料 | {$metrics['source_assets']} |\n| 可见 Wiki | {$metrics['wiki_assets']} |\n\n"
            . "## 贡献明细\n\n" . $this->contributionTable($metrics['contribution_details']) . "\n"
            . "## 审阅进展\n\n| 指标 | 数量 |\n| --- | ---: |\n| 完成审阅 | {$metrics['reviews_completed']} |\n\n"
            . "## RAG 健康\n\n| 指标 | 数量 |\n| --- | ---: |\n| Ready 文档 | {$metrics['rag_ready']} |\n\n"
            . "## 质量问题\n\n| 指标 | 数量 |\n| --- | ---: |\n| 警告或阻断 | {$metrics['quality_issues']} |\n\n"
            . "## 知识缺口\n\n| 指标 | 数量 |\n| --- | ---: |\n| 开放或处理中 | {$metrics['open_gaps']} |\n\n"
            . "## 下周计划\n\n| 优先级 | 事项 |\n| --- | --- |\n| 高 | 优先处理阻断项、逾期缺口和待复核 Wiki。 |\n";
    }

    /** @param iterable<int, object|array<string, mixed>> $rows */
    private function contributionTable(iterable $rows): string
    {
        $markdown = "| 用户名 | 贡献文档标题 | 贡献文档书架名称 | 贡献时间 |\n| --- | --- | --- | --- |\n";
        $count = 0;
        foreach ($rows as $row) {
            $item = (array) $row;
            $markdown .= '| ' . $this->markdownCell($item['owner_name'] ?? '未分配')
                . ' | ' . $this->markdownCell($item['document_title'] ?? '-')
                . ' | ' . $this->markdownCell($item['shelf_name'] ?? '未归属书架')
                . ' | ' . $this->markdownCell($item['contribution_time'] ?? '-')
                . " |\n";
            $count++;
        }

        return $count > 0 ? $markdown : $markdown . "| 暂无 | - | - | - |\n";
    }

    private function markdownCell(mixed $value): string
    {
        return str_replace(["\r", "\n", '|'], [' ', ' ', '\\|'], trim((string) $value));
    }

    private function bookshelfName(int|string|null $bookshelfId): string
    {
        if ($bookshelfId === null || $bookshelfId === '') {
            return '全部书架';
        }

        foreach ($this->hierarchy->bookshelves() as $bookshelf) {
            if ((string)$bookshelf['id'] === (string)$bookshelfId) {
                return (string)$bookshelf['name'];
            }
        }

        return (string)$bookshelfId;
    }

    /** @return array{0: string, 1: string} */
    private function periodBounds(string $from, string $to): array
    {
        return [
            strlen($from) <= 10 ? $from . ' 00:00:00' : $from,
            strlen($to) <= 10 ? $to . ' 23:59:59' : $to,
        ];
    }
}

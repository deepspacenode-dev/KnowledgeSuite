<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Query;

use BookStack\AI\Governance\Infrastructure\BookStack\ReadablePageQuery;
use Illuminate\Support\Facades\DB;

final class GovernanceSummaryQuery
{
    public function __construct(private readonly ReadablePageQuery $readablePages)
    {
    }

    /** @return array<string, mixed> */
    public function execute(): array
    {
        $visiblePageIds = $this->readablePages->visibleIds();
        $assets = DB::table('drv_kb_assets')->whereIn('page_id', $visiblePageIds);
        $wikiIds = (clone $assets)->where('asset_type', 'wiki')->pluck('asset_id');
        $pending = DB::table('drv_kb_reviews')
            ->whereIn('asset_id', $wikiIds)
            ->where('review_status', 'pending_review')
            ->distinct('asset_id')
            ->count('asset_id');
        $ragReady = DB::table('drv_kb_rag_snapshot')
            ->whereIn('asset_id', $wikiIds)
            ->where('parse_status', 'ready')
            ->distinct('asset_id')
            ->count('asset_id');

        return [
            'source_assets' => (clone $assets)->where('asset_type', 'source')->count(),
            'wiki_assets' => $wikiIds->count(),
            'pending_reviews' => $pending,
            'rag_ready' => $ragReady,
            'open_gaps' => DB::table('drv_kb_gaps')->whereIn('gap_status', ['open', 'doing'])->count(),
        ];
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Query;

use BookStack\AI\Governance\Infrastructure\BookStack\BookStackHierarchyQuery;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

final class AssetListQuery
{
    private const allowedSorts = ['updated_at', 'created_at', 'title', 'current_version'];

    public function __construct(private readonly BookStackHierarchyQuery $hierarchy)
    {
    }

    /** @param array<string, mixed> $filters @return array<string, mixed> */
    public function execute(array $filters): array
    {
        $page = max(1, (int) ($filters['page'] ?? 1));
        $pageSize = min(100, max(1, (int) ($filters['page_size'] ?? 25)));
        $sort = (string) ($filters['sort'] ?? 'updated_at');
        if (!in_array($sort, self::allowedSorts, true)) {
            throw new InvalidArgumentException('Unsupported sort field.');
        }

        $pageIds = $this->hierarchy->pageIdsForBookshelf($filters['bookshelf_id'] ?? null);
        $query = DB::table('drv_kb_assets')->whereIn('page_id', $pageIds);
        if (!empty($filters['page_id'])) {
            $query->where('page_id', (int) $filters['page_id']);
        }
        foreach (['asset_type', 'material_type', 'owner_id'] as $field) {
            if (isset($filters[$field]) && $filters[$field] !== '') {
                $query->where($field, $filters[$field]);
            }
        }
        if (!empty($filters['module'])) {
            $query->where('metadata_json->module', (string) $filters['module']);
        }
        if (!empty($filters['date_from'])) {
            $query->whereDate('updated_at', '>=', (string) $filters['date_from']);
        }
        if (!empty($filters['date_to'])) {
            $query->whereDate('updated_at', '<=', (string) $filters['date_to']);
        }
        if (!empty($filters['review_status'])) {
            $query->whereRaw(
                '(SELECT review_status FROM drv_kb_reviews WHERE drv_kb_reviews.asset_id = drv_kb_assets.asset_id ORDER BY created_at DESC, review_id DESC LIMIT 1) = ?',
                [(string) $filters['review_status']],
            );
        }
        if (!empty($filters['rag_status'])) {
            $query->whereRaw(
                '(SELECT parse_status FROM drv_kb_rag_snapshot WHERE drv_kb_rag_snapshot.asset_id = drv_kb_assets.asset_id ORDER BY checked_at DESC, rag_snapshot_id DESC LIMIT 1) = ?',
                [(string) $filters['rag_status']],
            );
        }
        if (!empty($filters['search'])) {
            $query->where('title', 'like', '%' . trim((string) $filters['search']) . '%');
        }

        $total = (clone $query)->count();
        $items = $query->orderBy($sort, 'desc')->forPage($page, $pageSize)->get()->all();

        return ['items' => $items, 'total' => $total, 'page' => $page, 'page_size' => $pageSize];
    }
}

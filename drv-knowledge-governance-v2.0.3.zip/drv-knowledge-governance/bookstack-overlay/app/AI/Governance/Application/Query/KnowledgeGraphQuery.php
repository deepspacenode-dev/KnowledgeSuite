<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Query;

use BookStack\AI\Governance\Application\Graph\GraphLinkFactory;
use BookStack\AI\Governance\Application\Graph\GraphNodeFactory;
use BookStack\AI\Governance\Application\Graph\GraphStatusMapper;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackHierarchyQuery;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class KnowledgeGraphQuery
{
    private const DEFAULT_LIMIT = 300;
    private const MAX_LIMIT = 800;

    public function __construct(
        private readonly BookStackHierarchyQuery $hierarchy,
        private readonly GraphNodeFactory $nodeFactory,
        private readonly GraphLinkFactory $linkFactory,
        private readonly GraphStatusMapper $statusMapper,
    ) {
    }

    /** @param array<string, mixed> $filters @return array<string, mixed> */
    public function execute(array $filters): array
    {
        $limit = min(self::MAX_LIMIT, max(20, (int) ($filters['limit'] ?? self::DEFAULT_LIMIT)));
        $includePages = $this->toBool($filters['include_pages'] ?? false);
        $visiblePageIds = $this->hierarchy->pageIdsForBookshelf($filters['bookshelf_id'] ?? null);
        if ($visiblePageIds === []) {
            return $this->emptyGraph($limit);
        }

        $structure = $this->loadBookStackStructure($visiblePageIds);
        $assets = $this->loadAssets($visiblePageIds, $filters);
        $assetIds = array_map(static fn (array $asset): int => (int) $asset['asset_id'], $assets);
        $reviews = $this->loadLatestByAsset('drv_kb_reviews', $assetIds, 'created_at');
        $rag = $this->loadLatestByAsset('drv_kb_rag_snapshot', $assetIds, 'checked_at');
        $quality = $this->loadLatestByAsset('drv_kb_quality_checks', $assetIds, 'checked_at');
        $owners = $this->loadOwners($assets);
        $rows = $this->mergeStructureAndAssets($structure, $assets, $reviews, $rag, $quality, $owners, $filters);

        return $this->buildGraph($rows, $limit, $includePages, $filters);
    }

    /** @param array<int, int> $visiblePageIds @param array<string, mixed> $filters @return array<int, array<string, mixed>> */
    private function loadAssets(array $visiblePageIds, array $filters): array
    {
        if (!Schema::hasTable('drv_kb_assets')) {
            return [];
        }

        $query = DB::table('drv_kb_assets')->whereIn('page_id', $visiblePageIds);
        foreach (['owner_id', 'material_type', 'asset_type'] as $field) {
            if (($filters[$field] ?? '') !== '') {
                $query->where($field, $filters[$field]);
            }
        }
        if (($filters['updated_from'] ?? '') !== '') {
            $query->whereDate('updated_at', '>=', (string) $filters['updated_from']);
        }
        if (($filters['updated_to'] ?? '') !== '') {
            $query->whereDate('updated_at', '<=', (string) $filters['updated_to']);
        }

        return array_map(static fn (object $row): array => (array) $row, $query->orderByDesc('updated_at')->get()->all());
    }

    /** @param array<int, int> $assetIds @return array<int, array<string, mixed>> */
    private function loadLatestByAsset(string $table, array $assetIds, string $dateColumn): array
    {
        if ($assetIds === [] || !Schema::hasTable($table)) {
            return [];
        }

        $rows = DB::table($table)->whereIn('asset_id', $assetIds)->orderByDesc($dateColumn)->get()->all();
        $latest = [];
        foreach ($rows as $row) {
            $data = (array) $row;
            $assetId = (int) ($data['asset_id'] ?? 0);
            if ($assetId > 0 && !isset($latest[$assetId])) {
                $latest[$assetId] = $data;
            }
        }

        return $latest;
    }

    /** @param array<int, array<string, mixed>> $assets @return array<int, string> */
    private function loadOwners(array $assets): array
    {
        if (!Schema::hasTable('users')) {
            return [];
        }

        $ids = array_values(array_unique(array_filter(array_map(static fn (array $asset): int => (int) ($asset['owner_id'] ?? 0), $assets))));
        if ($ids === []) {
            return [];
        }

        return DB::table('users')->whereIn('id', $ids)->pluck('name', 'id')->map(static fn ($name): string => (string) $name)->all();
    }

    /** @param array<int, int> $pageIds @return array<int, array<string, mixed>> */
    private function loadBookStackStructure(array $pageIds): array
    {
        $structure = [];
        $bookIds = [];
        $chapterIds = [];

        if (Schema::hasTable('pages')) {
            foreach (DB::table('pages')->whereIn('id', $pageIds)->get()->all() as $page) {
                $data = (array) $page;
                $pageId = (int) ($data['id'] ?? 0);
                if ($pageId <= 0) {
                    continue;
                }
                $bookIds[] = (int) ($data['book_id'] ?? 0);
                $chapterIds[] = (int) ($data['chapter_id'] ?? 0);
                $structure[$pageId] = [
                    'page_id' => $pageId,
                    'title' => $data['name'] ?? null,
                    'book_id' => $data['book_id'] ?? null,
                    'chapter_id' => $data['chapter_id'] ?? null,
                    'page_slug' => $data['slug'] ?? null,
                    'updated_at' => $data['updated_at'] ?? null,
                ];
            }
        } elseif (Schema::hasTable('entities')) {
            foreach (DB::table('entities')->where('type', 'page')->whereIn('id', $pageIds)->get()->all() as $entity) {
                $data = (array) $entity;
                $pageId = (int) ($data['id'] ?? 0);
                if ($pageId <= 0) {
                    continue;
                }
                $bookIds[] = (int) ($data['book_id'] ?? 0);
                $chapterIds[] = (int) ($data['chapter_id'] ?? 0);
                $structure[$pageId] = [
                    'page_id' => $pageId,
                    'title' => $data['name'] ?? null,
                    'book_id' => $data['book_id'] ?? null,
                    'chapter_id' => $data['chapter_id'] ?? null,
                    'page_slug' => $data['slug'] ?? null,
                    'updated_at' => $data['updated_at'] ?? null,
                ];
            }
        }

        $books = $this->loadBooks(array_values(array_unique(array_filter($bookIds))));
        $chapters = $this->loadChapters(array_values(array_unique(array_filter($chapterIds))));
        foreach ($structure as $pageId => $data) {
            $book = $books[(int) ($data['book_id'] ?? 0)] ?? [];
            $chapter = $chapters[(int) ($data['chapter_id'] ?? 0)] ?? [];
            $directPages = (int) ($data['chapter_id'] ?? 0) <= 0;
            $resolved = $data + $book + $chapter;
            $resolved['chapter_id'] = $directPages ? null : (int) $data['chapter_id'];
            $resolved['chapter_key'] = $directPages ? 'direct' : ($resolved['chapter_key'] ?? (string) $data['chapter_id']);
            $resolved['chapter_name'] = $directPages ? '书籍直属页面' : ($resolved['chapter_name'] ?? '未命名章节');
            $resolved['direct_pages'] = $directPages;
            $resolved['url'] = $this->pageUrl($resolved);
            $structure[$pageId] = $resolved;
        }

        return $structure;
    }

    /** @param array<int, int> $bookIds @return array<int, array<string, mixed>> */
    private function loadBooks(array $bookIds): array
    {
        if ($bookIds === []) {
            return [];
        }

        $shelvesByBook = $this->loadBookshelfLinks($bookIds);
        if (Schema::hasTable('books')) {
            $records = DB::table('books')->whereIn('id', $bookIds)->get()->all();
        } elseif (Schema::hasTable('entities')) {
            $records = DB::table('entities')->where('type', 'book')->whereIn('id', $bookIds)->get()->all();
        } else {
            return [];
        }

        $result = [];
        foreach ($records as $book) {
            $data = (array) $book;
            $bookId = (int) ($data['id'] ?? 0);
            $memberships = $shelvesByBook[$bookId] ?? [];
            if ($memberships === []) {
                $memberships = [['bookshelf_id' => null, 'bookshelf_name' => '未归属书架']];
            }
            $shelf = $memberships[0];
            $result[$bookId] = [
                'book_id' => $bookId,
                'book_name' => $data['name'] ?? '未归属书籍',
                'book_slug' => $data['slug'] ?? null,
                'bookshelf_id' => $shelf['bookshelf_id'] ?? null,
                'bookshelf_name' => $shelf['bookshelf_name'] ?? '未归属书架',
                'bookshelf_memberships' => $memberships,
            ];
        }

        return $result;
    }

    /** @param array<int, int> $bookIds @return array<int, array<int, array<string, mixed>>> */
    private function loadBookshelfLinks(array $bookIds): array
    {
        if ($bookIds === [] || !Schema::hasTable('bookshelves_books')) {
            return [];
        }

        $links = DB::table('bookshelves_books')->whereIn('book_id', $bookIds)->orderBy('bookshelf_id')->get()->all();
        $shelfIds = array_values(array_unique(array_filter(array_map(static fn (object $link): int => (int) ($link->bookshelf_id ?? 0), $links))));
        if ($shelfIds === []) {
            $shelves = [];
        } elseif (Schema::hasTable('bookshelves')) {
            $shelves = DB::table('bookshelves')->whereIn('id', $shelfIds)->pluck('name', 'id')->all();
        } elseif (Schema::hasTable('entities')) {
            $shelves = DB::table('entities')->where('type', 'bookshelf')->whereIn('id', $shelfIds)->pluck('name', 'id')->all();
        } else {
            $shelves = [];
        }
        $result = [];
        foreach ($links as $link) {
            $bookId = (int) ($link->book_id ?? 0);
            $shelfId = (int) ($link->bookshelf_id ?? 0);
            if ($bookId > 0) {
                $result[$bookId][] = ['bookshelf_id' => $shelfId ?: null, 'bookshelf_name' => (string) ($shelves[$shelfId] ?? '未归属书架')];
            }
        }

        return $result;
    }

    /** @param array<int, int> $chapterIds @return array<int, array<string, mixed>> */
    private function loadChapters(array $chapterIds): array
    {
        if ($chapterIds === []) {
            return [];
        }

        if (Schema::hasTable('chapters')) {
            $records = DB::table('chapters')->whereIn('id', $chapterIds)->get()->all();
        } elseif (Schema::hasTable('entities')) {
            $records = DB::table('entities')->where('type', 'chapter')->whereIn('id', $chapterIds)->get()->all();
        } else {
            return [];
        }

        $result = [];
        foreach ($records as $chapter) {
            $data = (array) $chapter;
            $chapterId = (int) ($data['id'] ?? 0);
            if ($chapterId > 0) {
                $result[$chapterId] = [
                    'chapter_id' => $chapterId,
                    'chapter_name' => $data['name'] ?? '未归属章节',
                    'chapter_key' => $data['slug'] ?? $data['name'] ?? $chapterId,
                    'chapter_slug' => $data['slug'] ?? null,
                ];
            }
        }

        return $result;
    }

    /**
     * @param array<int, array<string, mixed>> $structure
     * @param array<int, array<string, mixed>> $assets
     * @param array<int, array<string, mixed>> $reviews
     * @param array<int, array<string, mixed>> $rag
     * @param array<int, array<string, mixed>> $quality
     * @param array<int, string> $owners
     * @param array<string, mixed> $filters
     * @return array<int, array<string, mixed>>
     */
    private function mergeStructureAndAssets(
        array $structure,
        array $assets,
        array $reviews,
        array $rag,
        array $quality,
        array $owners,
        array $filters,
    ): array {
        $assetsByPage = [];
        foreach ($assets as $asset) {
            $pageId = (int) ($asset['page_id'] ?? 0);
            if ($pageId > 0 && !isset($assetsByPage[$pageId])) {
                $assetsByPage[$pageId] = $asset;
            }
        }

        $rows = [];
        $includeUnmanaged = !$this->hasAssetScopedFilters($filters);
        foreach ($structure as $pageId => $page) {
            $asset = $assetsByPage[$pageId] ?? null;
            if ($asset === null && !$includeUnmanaged) {
                continue;
            }

            if ($asset === null) {
                $row = $this->normalizeStructurePage((int) $pageId, $page);
            } else {
                $assetId = (int) $asset['asset_id'];
                $row = $this->normalizeAsset(
                    $asset,
                    $reviews[$assetId] ?? [],
                    $rag[$assetId] ?? [],
                    $quality[$assetId] ?? [],
                    $owners,
                    $page,
                );
            }

            if ($this->matchesNormalizedFilters($row, $filters)) {
                $rows[] = $row;
            }
        }

        return $rows;
    }

    /** @param array<string, mixed> $page @return array<string, mixed> */
    private function normalizeStructurePage(int $pageId, array $page): array
    {
        return [
            'asset_id' => null,
            'page_id' => $pageId,
            'title' => (string) ($page['title'] ?? '未命名页面'),
            'bookshelf_id' => $page['bookshelf_id'] ?? null,
            'bookshelf_name' => (string) ($page['bookshelf_name'] ?? '未归属书架'),
            'bookshelf_memberships' => $this->shelfMemberships($page),
            'book_id' => $page['book_id'] ?? null,
            'book_name' => (string) ($page['book_name'] ?? '未归属书籍'),
            'chapter_id' => $page['chapter_id'] ?? null,
            'chapter_key' => $page['chapter_key'] ?? 'direct',
            'chapter_name' => (string) ($page['chapter_name'] ?? '书籍直属页面'),
            'direct_pages' => (bool) ($page['direct_pages'] ?? false),
            'review_status' => 'pending',
            'rag_status' => 'not_ingested',
            'quality_status' => 'unknown',
            'quality_score' => null,
            'content_size' => 1,
            'owner_id' => null,
            'owner_name' => null,
            'updated_at' => $page['updated_at'] ?? null,
            'tags' => [],
            'url' => (string) ($page['url'] ?? ('/pages/' . $pageId)),
            'material_type' => '',
            'asset_type' => null,
            'has_asset' => false,
        ];
    }

    /** @param array<string, mixed> $asset @param array<string, mixed> $review @param array<string, mixed> $rag @param array<string, mixed> $quality @param array<int, string> $owners @param array<string, mixed> $structure @return array<string, mixed> */
    private function normalizeAsset(array $asset, array $review, array $rag, array $quality, array $owners, array $structure): array
    {
        $meta = $this->json((string) ($asset['metadata_json'] ?? ''));
        $merged = $structure + $meta + $asset;
        $ownerId = (int) ($asset['owner_id'] ?? 0);
        $qualityStatus = $this->statusMapper->quality($quality);

        return [
            'asset_id' => (int) $asset['asset_id'],
            'page_id' => (int) ($asset['page_id'] ?? 0),
            'title' => (string) ($merged['title'] ?? $asset['title'] ?? '未命名页面'),
            'bookshelf_id' => $merged['bookshelf_id'] ?? null,
            'bookshelf_name' => (string) ($merged['bookshelf_name'] ?? '未归属书架'),
            'bookshelf_memberships' => $this->shelfMemberships($merged),
            'book_id' => $merged['book_id'] ?? null,
            'book_name' => (string) ($merged['book_name'] ?? '未归属书籍'),
            'chapter_id' => (int) ($merged['chapter_id'] ?? 0) ?: null,
            'chapter_key' => $merged['chapter_key'] ?? $merged['chapter_id'] ?? $merged['chapter_name'] ?? $merged['module'] ?? 'chapter',
            'chapter_name' => (string) ($merged['chapter_name'] ?? $merged['module'] ?? '未归属章节'),
            'direct_pages' => (bool) ($merged['direct_pages'] ?? ((int) ($merged['chapter_id'] ?? 0) <= 0)),
            'review_status' => $this->statusMapper->review($review['review_status'] ?? $meta['review_status'] ?? null),
            'rag_status' => $this->statusMapper->rag($rag['parse_status'] ?? $meta['rag_status'] ?? null),
            'quality_status' => $qualityStatus,
            'quality_score' => $quality['content_score'] ?? $review['quality_score'] ?? null,
            'content_size' => (int) ($meta['content_size'] ?? strlen((string) ($asset['content_hash'] ?? '')) ?: 1),
            'owner_id' => $ownerId ?: null,
            'owner_name' => $ownerId > 0 ? ($owners[$ownerId] ?? (string) $ownerId) : null,
            'updated_at' => $asset['updated_at'] ?? $structure['updated_at'] ?? null,
            'tags' => $this->tags($meta['tags'] ?? []),
            'url' => (string) ($meta['source_url'] ?? $meta['url'] ?? $structure['url'] ?? ('/pages/' . (int) ($asset['page_id'] ?? 0))),
            'material_type' => (string) ($asset['material_type'] ?? $meta['material_type'] ?? ''),
            'asset_type' => $asset['asset_type'] ?? null,
            'has_asset' => true,
        ];
    }

    /** @param array<string, mixed> $filters @return bool */
    private function matchesNormalizedFilters(array $row, array $filters): bool
    {
        foreach (['book_id', 'owner_id', 'review_status', 'rag_status', 'quality_status'] as $field) {
            if (($filters[$field] ?? '') !== '' && (string) ($row[$field] ?? '') !== (string) $filters[$field]) {
                return false;
            }
        }
        if (($filters['bookshelf_id'] ?? '') !== '') {
            $shelfIds = array_map(
                static fn (array $membership): string => (string) ($membership['bookshelf_id'] ?? ''),
                $this->shelfMemberships($row),
            );
            if (!in_array((string) $filters['bookshelf_id'], $shelfIds, true)) {
                return false;
            }
        }
        if (($filters['tag'] ?? '') !== '' && !in_array((string) $filters['tag'], $row['tags'], true)) {
            return false;
        }
        if (($filters['chapter_id'] ?? '') !== '' && (string) ($row['chapter_id'] ?? '') !== (string) $filters['chapter_id']) {
            return false;
        }
        if ($this->toBool($filters['direct_pages'] ?? false) && !(bool) ($row['direct_pages'] ?? false)) {
            return false;
        }

        return true;
    }

    /** @param array<int, array<string, mixed>> $rows @param array<string, mixed> $filters @return array<string, mixed> */
    private function buildGraph(array $rows, int $limit, bool $includePages, array $filters): array
    {
        $nodes = [];
        $links = [];
        $truncated = false;
        $shelves = [];
        $books = [];
        $chapters = [];
        $branchRows = [];
        foreach ($rows as $row) {
            foreach ($this->shelfMembershipsForGraph($row, $filters) as $membership) {
                $branch = array_merge($row, $membership);
                $branchRows[] = $branch;
                $shelfId = 'bookshelf:' . $this->key($branch['bookshelf_id'] ?? 'unassigned');
                $bookId = $this->bookNodeId($branch);
                $chapterId = $this->chapterNodeId($branch);
                $this->pushBucket($shelves[$shelfId], $branch + ['id' => $shelfId]);
                $this->pushBucket($books[$bookId], $branch + ['id' => $bookId]);
                $this->pushBucket($chapters[$chapterId], $branch + ['id' => $chapterId]);
            }
        }
        $nodes['root:knowledge-base'] = $this->nodeFactory->root(
            count(array_unique(array_map(static fn (array $row): string => (string) ($row['bookshelf_id'] ?? 'unassigned'), $branchRows))),
            count(array_unique(array_map(static fn (array $row): string => (string) ($row['book_id'] ?? 'unassigned'), $rows))),
            count($rows),
        );

        foreach ($shelves as $id => $bucket) {
            if (!$this->addNode($nodes, $id, $this->nodeFactory->bookshelf($this->bucketNode($bucket)), $limit, $truncated)) {
                break;
            }
            $links[] = $this->linkFactory->contains('root:knowledge-base', $id, (int) $bucket['page_count']);
        }
        foreach ($books as $id => $bucket) {
            if (!$this->addNode($nodes, $id, $this->nodeFactory->book($this->bucketNode($bucket)), $limit, $truncated)) {
                break;
            }
            $links[] = $this->linkFactory->contains('bookshelf:' . $this->key($bucket['bookshelf_id'] ?? 'unassigned'), $id, (int) $bucket['page_count']);
        }
        foreach ($chapters as $id => $bucket) {
            if (!$this->addNode($nodes, $id, $this->nodeFactory->chapter($this->bucketNode($bucket)), $limit, $truncated)) {
                break;
            }
            $links[] = $this->linkFactory->contains($this->bookNodeId($bucket), $id, (int) $bucket['page_count']);
        }

        if ($includePages) {
            foreach ($branchRows as $row) {
                $pageId = 'page:' . $this->key($row['page_id'] ?: $row['asset_id']);
                if (!$this->addNode($nodes, $pageId, $this->nodeFactory->page($row), $limit, $truncated)) {
                    break;
                }
                $parent = $this->chapterNodeId($row);
                $links[] = $this->linkFactory->contains($parent, $pageId);
            }
        }

        $links = $this->linkFactory->unique($links);
        $stats = $this->stats(array_values($nodes), $links);

        return [
            'nodes' => array_values($nodes),
            'links' => $links,
            'stats' => $stats,
            'meta' => [
                'depth' => (int) ($filters['depth'] ?? 3),
                'limit' => $limit,
                'truncated' => $truncated,
                'include_pages' => $includePages,
                'chapter_id' => $filters['chapter_id'] ?? null,
                'direct_pages' => $this->toBool($filters['direct_pages'] ?? false),
                'generated_at' => now()->toAtomString(),
            ],
        ];
    }

    /** @param array<string, mixed>|null $bucket */
    private function pushBucket(?array &$bucket, array $row): void
    {
        if ($bucket === null) {
            $bucket = $row + ['page_count' => 0, 'asset_count' => 0, 'content_size' => 0, 'review_states' => [], 'rag_states' => [], 'quality_states' => [], 'tags' => []];
        }
        $bucket['page_count'] = (int) ($bucket['page_count'] ?? 0) + 1;
        $bucket['asset_count'] = (int) ($bucket['asset_count'] ?? 0) + ((bool) ($row['has_asset'] ?? false) ? 1 : 0);
        $bucket['has_asset'] = (int) $bucket['asset_count'] > 0;
        $bucket['content_size'] = (int) ($bucket['content_size'] ?? 0) + (int) ($row['content_size'] ?? 1);
        $bucket['review_states'][] = (string) $row['review_status'];
        $bucket['rag_states'][] = (string) $row['rag_status'];
        $bucket['quality_states'][] = (string) $row['quality_status'];
        $bucket['tags'] = array_values(array_unique(array_merge((array) ($bucket['tags'] ?? []), (array) ($row['tags'] ?? []))));
        $bucket['updated_at'] = max((string) ($bucket['updated_at'] ?? ''), (string) ($row['updated_at'] ?? ''));
    }

    /** @param array<string, mixed> $bucket @return array<string, mixed> */
    private function bucketNode(array $bucket): array
    {
        return array_merge($bucket, [
            'review_status' => $this->aggregateReview((array) ($bucket['review_states'] ?? [])),
            'rag_status' => $this->aggregateRag((array) ($bucket['rag_states'] ?? [])),
            'quality_status' => $this->aggregateQuality((array) ($bucket['quality_states'] ?? [])),
        ]);
    }

    /** @param array<string, array<string, mixed>> $nodes @param array<string, mixed> $node */
    private function addNode(array &$nodes, string $id, array $node, int $limit, bool &$truncated): bool
    {
        if (isset($nodes[$id])) {
            return true;
        }
        if (count($nodes) >= $limit) {
            $truncated = true;
            return false;
        }
        $nodes[$id] = $node;

        return true;
    }

    /** @param array<int, array<string, mixed>> $nodes @param array<int, array<string, mixed>> $links @return array<string, int> */
    private function stats(array $nodes, array $links): array
    {
        $stats = ['node_count' => count($nodes), 'link_count' => count($links), 'isolated_count' => 0];
        foreach (['pending', 'partial', 'approved', 'verified', 'rejected'] as $status) {
            $stats[$status . '_count'] = count(array_filter($nodes, static fn (array $node): bool => ($node['review_status'] ?? '') === $status));
        }
        $stats['rag_parsed_count'] = count(array_filter($nodes, static fn (array $node): bool => ($node['rag_status'] ?? '') === 'parsed'));
        $stats['rag_failed_count'] = count(array_filter($nodes, static fn (array $node): bool => ($node['rag_status'] ?? '') === 'failed'));

        return $stats;
    }

    /** @return array<string, mixed> */
    private function emptyGraph(int $limit): array
    {
        return [
            'nodes' => [$this->nodeFactory->root(0, 0, 0)],
            'links' => [],
            'stats' => ['node_count' => 1, 'link_count' => 0, 'pending_count' => 0, 'partial_count' => 0, 'approved_count' => 0, 'verified_count' => 1, 'rejected_count' => 0, 'rag_parsed_count' => 1, 'rag_failed_count' => 0, 'isolated_count' => 0],
            'meta' => ['depth' => 3, 'limit' => $limit, 'truncated' => false, 'generated_at' => now()->toAtomString()],
        ];
    }

    /** @return array<string, mixed> */
    private function json(string $value): array
    {
        $decoded = json_decode($value, true);
        return is_array($decoded) ? $decoded : [];
    }

    /** @return array<int, string> */
    private function tags(mixed $tags): array
    {
        if (is_string($tags)) {
            $tags = preg_split('/[,，;；\s]+/u', $tags) ?: [];
        }
        return array_values(array_unique(array_filter(array_map('strval', (array) $tags))));
    }

    /** @param array<string, mixed> $filters */
    private function hasAssetScopedFilters(array $filters): bool
    {
        foreach (['owner_id', 'material_type', 'asset_type', 'review_status', 'rag_status', 'quality_status', 'tag', 'updated_from', 'updated_to'] as $field) {
            if (($filters[$field] ?? '') !== '') {
                return true;
            }
        }

        return false;
    }

    /** @param array<string, mixed> $row @return array<int, array<string, mixed>> */
    private function shelfMemberships(array $row): array
    {
        $memberships = array_values(array_filter(
            (array) ($row['bookshelf_memberships'] ?? []),
            static fn (mixed $membership): bool => is_array($membership),
        ));
        if ($memberships === []) {
            $memberships = [[
                'bookshelf_id' => $row['bookshelf_id'] ?? null,
                'bookshelf_name' => (string) ($row['bookshelf_name'] ?? '未归属书架'),
            ]];
        }

        return $memberships;
    }

    /** @param array<string, mixed> $row @param array<string, mixed> $filters @return array<int, array<string, mixed>> */
    private function shelfMembershipsForGraph(array $row, array $filters): array
    {
        $memberships = $this->shelfMemberships($row);
        if (($filters['bookshelf_id'] ?? '') === '') {
            return $memberships;
        }

        return array_values(array_filter(
            $memberships,
            static fn (array $membership): bool => (string) ($membership['bookshelf_id'] ?? '') === (string) $filters['bookshelf_id'],
        ));
    }

    /** @param array<string, mixed> $row */
    private function bookNodeId(array $row): string
    {
        return 'book:'
            . $this->key($row['bookshelf_id'] ?? 'unassigned') . ':'
            . $this->key($row['book_id'] ?? 'unassigned');
    }

    /** @param array<string, mixed> $row */
    private function chapterNodeId(array $row): string
    {
        return 'chapter:'
            . $this->key($row['bookshelf_id'] ?? 'unassigned') . ':'
            . $this->key($row['book_id'] ?? 'unassigned') . ':'
            . $this->key($row['chapter_key'] ?? 'direct');
    }

    /** @param array<string, mixed> $page */
    private function pageUrl(array $page): string
    {
        $bookSlug = trim((string) ($page['book_slug'] ?? ''));
        $pageSlug = trim((string) ($page['page_slug'] ?? ''));
        if ($bookSlug !== '' && $pageSlug !== '') {
            return '/books/' . rawurlencode($bookSlug) . '/page/' . rawurlencode($pageSlug);
        }

        return '/pages/' . (int) ($page['page_id'] ?? 0);
    }

    /** @param array<int, string> $states */
    private function aggregateReview(array $states): string
    {
        $states = array_values(array_unique($states));
        if (in_array('rejected', $states, true)) return 'rejected';
        if (in_array('deprecated', $states, true)) return 'deprecated';
        if ($states !== [] && count(array_diff($states, ['verified'])) === 0) return 'verified';
        if ($states !== [] && count(array_diff($states, ['verified', 'approved'])) === 0) return 'approved';
        if (array_intersect($states, ['verified', 'approved']) !== []) return 'partial';
        if (in_array('pending', $states, true)) return 'pending';
        return 'unknown';
    }

    /** @param array<int, string> $states */
    private function aggregateRag(array $states): string
    {
        foreach (['failed', 'stale', 'parsing', 'unstart', 'uploaded', 'parsed'] as $status) {
            if (in_array($status, $states, true)) return $status;
        }
        return 'not_ingested';
    }

    /** @param array<int, string> $states */
    private function aggregateQuality(array $states): string
    {
        if (in_array('failed', $states, true)) return 'failed';
        if (in_array('warning', $states, true)) return 'warning';
        if ($states !== [] && count(array_diff($states, ['passed'])) === 0) return 'passed';
        return 'unknown';
    }

    private function toBool(mixed $value): bool
    {
        return in_array($value, [true, 1, '1', 'true', 'yes', 'on'], true);
    }

    private function key(mixed $value): string
    {
        $key = strtolower(trim((string) ($value === null || $value === '' ? 'unassigned' : $value)));
        $key = preg_replace('/[^a-z0-9_\-:\x{4e00}-\x{9fa5}]+/u', '_', $key) ?: 'unassigned';

        return trim($key, '_') ?: 'unassigned';
    }
}

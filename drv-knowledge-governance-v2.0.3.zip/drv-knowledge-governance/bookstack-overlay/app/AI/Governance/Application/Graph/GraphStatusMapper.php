<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Graph;

final class GraphStatusMapper
{
    public function review(?string $status): string
    {
        $value = strtolower(trim((string) $status));

        return match ($value) {
            'draft', 'pending', 'pending_review', 'unreviewed' => 'pending',
            'partial', 'partially_reviewed' => 'partial',
            'reviewed', 'approved', 'pass', 'passed' => 'approved',
            'verified', 'validated' => 'verified',
            'need_fix', 'rejected', 'failed', 'blocked' => 'rejected',
            'deprecated', 'archived' => 'deprecated',
            default => 'unknown',
        };
    }

    public function rag(?string $status): string
    {
        $value = strtolower(trim((string) $status));

        return match ($value) {
            'ready', 'parsed', 'success', 'succeeded' => 'parsed',
            'uploaded', 'created', 'updated' => 'uploaded',
            'unstart', 'queued', 'pending' => 'unstart',
            'parsing', 'running', 'processing' => 'parsing',
            'failed', 'error' => 'failed',
            'stale', 'outdated' => 'stale',
            'blocked', 'not_ingested', 'not-ready', 'not_ready', '' => 'not_ingested',
            default => 'unknown',
        };
    }

    /**
     * @param array<string, mixed> $quality
     */
    public function quality(array $quality): string
    {
        if ($this->hasJsonItems($quality['reject_reasons_json'] ?? null)) {
            return 'failed';
        }
        if ($this->hasJsonItems($quality['warnings_json'] ?? null)) {
            return 'warning';
        }

        $contentScore = $this->toInt($quality['content_score'] ?? $quality['score'] ?? null);
        $metadataScore = $this->toInt($quality['metadata_score'] ?? null);
        $scores = array_filter([$contentScore, $metadataScore], static fn (?int $score): bool => $score !== null);

        if ($scores === []) {
            return 'unknown';
        }

        return min($scores) >= 70 ? 'passed' : 'warning';
    }

    private function toInt(mixed $value): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }

        return max(0, min(100, (int) $value));
    }

    private function hasJsonItems(mixed $value): bool
    {
        if ($value === null || $value === '') {
            return false;
        }
        if (is_array($value)) {
            return count($value) > 0;
        }

        $decoded = json_decode((string) $value, true);
        return is_array($decoded) && count($decoded) > 0;
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Graph;

final class GraphNodeFactory
{
    public function __construct(private readonly GraphStatusMapper $statusMapper)
    {
    }

    /**
     * @return array<string, mixed>
     */
    public function root(int $bookshelfCount, int $bookCount, int $pageCount): array
    {
        return $this->base([
            'id' => 'root:knowledge-base',
            'type' => 'root',
            'title' => '知识库',
            'review_status' => 'verified',
            'rag_status' => 'parsed',
            'quality_status' => 'passed',
            'page_count' => $pageCount,
            'content_size' => $pageCount,
            'description' => "书架 {$bookshelfCount} 个，书籍 {$bookCount} 个，页面 {$pageCount} 个",
            'expandable' => true,
        ]);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function bookshelf(array $data): array
    {
        return $this->base([
            'id' => 'bookshelf:' . $this->key($data['bookshelf_id'] ?? 'unassigned'),
            'type' => 'bookshelf',
            'title' => (string) ($data['bookshelf_name'] ?? '未归属书架'),
            'bookshelf_id' => $data['bookshelf_id'] ?? null,
            'bookshelf_name' => (string) ($data['bookshelf_name'] ?? '未归属书架'),
            'review_status' => $data['review_status'] ?? 'unknown',
            'rag_status' => $data['rag_status'] ?? 'not_ingested',
            'quality_status' => $data['quality_status'] ?? 'unknown',
            'page_count' => (int) ($data['page_count'] ?? 0),
            'asset_count' => (int) ($data['asset_count'] ?? 0),
            'has_asset' => (bool) ($data['has_asset'] ?? false),
            'content_size' => (int) ($data['content_size'] ?? 0),
            'expandable' => true,
        ]);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function book(array $data): array
    {
        return $this->base([
            'id' => 'book:' . $this->key($data['bookshelf_id'] ?? 'unassigned') . ':' . $this->key($data['book_id'] ?? 'unassigned'),
            'type' => 'book',
            'title' => (string) ($data['book_name'] ?? '未归属书籍'),
            'bookshelf_id' => $data['bookshelf_id'] ?? null,
            'bookshelf_name' => (string) ($data['bookshelf_name'] ?? '未归属书架'),
            'book_id' => $data['book_id'] ?? null,
            'book_name' => (string) ($data['book_name'] ?? '未归属书籍'),
            'review_status' => $data['review_status'] ?? 'unknown',
            'rag_status' => $data['rag_status'] ?? 'not_ingested',
            'quality_status' => $data['quality_status'] ?? 'unknown',
            'page_count' => (int) ($data['page_count'] ?? 0),
            'asset_count' => (int) ($data['asset_count'] ?? 0),
            'has_asset' => (bool) ($data['has_asset'] ?? false),
            'content_size' => (int) ($data['content_size'] ?? 0),
            'expandable' => true,
        ]);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function chapter(array $data): array
    {
        return $this->base([
            'id' => 'chapter:' . $this->key($data['bookshelf_id'] ?? 'unassigned') . ':' . $this->key($data['book_id'] ?? 'unassigned') . ':' . $this->key($data['chapter_key'] ?? 'chapter'),
            'type' => 'chapter',
            'title' => (string) ($data['chapter_name'] ?? '未归属章节'),
            'bookshelf_id' => $data['bookshelf_id'] ?? null,
            'bookshelf_name' => (string) ($data['bookshelf_name'] ?? '未归属书架'),
            'book_id' => $data['book_id'] ?? null,
            'book_name' => (string) ($data['book_name'] ?? '未归属书籍'),
            'chapter_id' => $data['chapter_id'] ?? null,
            'chapter_key' => $data['chapter_key'] ?? 'direct',
            'chapter_name' => (string) ($data['chapter_name'] ?? '书籍直属页面'),
            'direct_pages' => (bool) ($data['direct_pages'] ?? false),
            'review_unit_type' => 'chapter',
            'review_status' => $data['review_status'] ?? 'unknown',
            'rag_status' => $data['rag_status'] ?? 'not_ingested',
            'quality_status' => $data['quality_status'] ?? 'unknown',
            'quality_score' => $data['quality_score'] ?? null,
            'page_count' => (int) ($data['page_count'] ?? 0),
            'asset_count' => (int) ($data['asset_count'] ?? 0),
            'has_asset' => (bool) ($data['has_asset'] ?? false),
            'content_size' => (int) ($data['content_size'] ?? 0),
            'owner_id' => $data['owner_id'] ?? null,
            'owner_name' => $data['owner_name'] ?? null,
            'updated_at' => $data['updated_at'] ?? null,
            'tags' => $data['tags'] ?? [],
            'url' => $data['url'] ?? null,
            'expandable' => true,
        ]);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function page(array $data): array
    {
        return $this->base([
            'id' => 'page:' . $this->key($data['page_id'] ?? $data['asset_id'] ?? 'unknown'),
            'type' => 'page',
            'title' => (string) ($data['title'] ?? '未命名页面'),
            'asset_id' => $data['asset_id'] ?? null,
            'page_id' => $data['page_id'] ?? null,
            'bookshelf_id' => $data['bookshelf_id'] ?? null,
            'bookshelf_name' => (string) ($data['bookshelf_name'] ?? '未归属书架'),
            'book_id' => $data['book_id'] ?? null,
            'book_name' => (string) ($data['book_name'] ?? '未归属书籍'),
            'chapter_id' => $data['chapter_id'] ?? null,
            'chapter_name' => $data['chapter_name'] ?? null,
            'direct_pages' => (bool) ($data['direct_pages'] ?? false),
            'review_unit_type' => 'page',
            'review_status' => $data['review_status'] ?? 'unknown',
            'rag_status' => $data['rag_status'] ?? 'not_ingested',
            'quality_status' => $data['quality_status'] ?? 'unknown',
            'quality_score' => $data['quality_score'] ?? null,
            'page_count' => 1,
            'asset_count' => (bool) ($data['has_asset'] ?? false) ? 1 : 0,
            'has_asset' => (bool) ($data['has_asset'] ?? false),
            'content_size' => (int) ($data['content_size'] ?? 1),
            'owner_id' => $data['owner_id'] ?? null,
            'owner_name' => $data['owner_name'] ?? null,
            'updated_at' => $data['updated_at'] ?? null,
            'tags' => $data['tags'] ?? [],
            'url' => $data['url'] ?? null,
            'expandable' => false,
        ]);
    }

    /**
     * @param array<string, mixed> $node
     * @return array<string, mixed>
     */
    private function base(array $node): array
    {
        $node['review_status'] = $this->statusMapper->review($node['review_status'] ?? null);
        $node['rag_status'] = $this->statusMapper->rag($node['rag_status'] ?? null);
        $node['quality_status'] = (string) ($node['quality_status'] ?? 'unknown');
        $node['tags'] = array_values(array_unique(array_filter((array) ($node['tags'] ?? []))));

        return $node;
    }

    private function key(mixed $value): string
    {
        $key = strtolower(trim((string) ($value === null || $value === '' ? 'unassigned' : $value)));
        $key = preg_replace('/[^a-z0-9_\-:\x{4e00}-\x{9fa5}]+/u', '_', $key) ?: 'unassigned';

        return trim($key, '_') ?: 'unassigned';
    }
}

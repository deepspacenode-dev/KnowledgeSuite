<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Graph;

final class GraphLinkFactory
{
    /** @var array<string, true> */
    private array $seen = [];

    /**
     * @return array{source: string, target: string, type: string, weight: int, label: string}
     */
    public function contains(string $source, string $target, int $weight = 1): array
    {
        return [
            'source' => $source,
            'target' => $target,
            'type' => 'contains',
            'weight' => max(1, $weight),
            'label' => '包含',
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $links
     * @return array<int, array<string, mixed>>
     */
    public function unique(array $links): array
    {
        $this->seen = [];
        $result = [];

        foreach ($links as $link) {
            $source = (string) ($link['source'] ?? '');
            $target = (string) ($link['target'] ?? '');
            $type = (string) ($link['type'] ?? 'contains');
            if ($source === '' || $target === '' || $source === $target) {
                continue;
            }

            $key = "{$type}:{$source}:{$target}";
            if (isset($this->seen[$key])) {
                continue;
            }

            $this->seen[$key] = true;
            $result[] = $link;
        }

        return $result;
    }
}

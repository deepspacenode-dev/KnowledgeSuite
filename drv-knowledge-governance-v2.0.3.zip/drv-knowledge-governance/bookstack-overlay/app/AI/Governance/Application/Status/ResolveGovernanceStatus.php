<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Status;

use Illuminate\Support\Facades\DB;

final class ResolveGovernanceStatus
{
    /** @param array<int, string> $contentRefs @return array<string, mixed> */
    public function execute(array $contentRefs, string $traceId): array
    {
        $items = [];
        $unresolved = [];
        foreach (array_slice(array_values(array_unique($contentRefs)), 0, 200) as $contentRef) {
            if (preg_match('/^bookstack:page:([1-9][0-9]*)$/', $contentRef, $match) !== 1) {
                $unresolved[] = $contentRef;
                continue;
            }
            $sourceKey = 'bookstack_page:' . $match[1];
            $source = DB::table('drv_kb_assets')->where('source_key', $sourceKey)->where('asset_type', 'source')->first();
            if ($source === null) {
                $unresolved[] = $contentRef;
                continue;
            }
            $task = DB::table('drv_kb_compile_tasks')->where('source_asset_id', $source->asset_id)->orderByDesc('created_at')->orderByDesc('task_id')->first();
            if ($task === null) {
                $unresolved[] = $contentRef;
                continue;
            }
            $wiki = DB::table('drv_kb_assets')->where('source_key', $sourceKey)->where('asset_type', 'wiki')->first();
            $review = $wiki ? DB::table('drv_kb_reviews')->where('asset_id', $wiki->asset_id)->orderByDesc('created_at')->orderByDesc('review_id')->first() : null;
            $snapshot = $wiki ? DB::table('drv_kb_rag_snapshot')->where('asset_id', $wiki->asset_id)->orderByDesc('checked_at')->first() : null;
            $reviewStatus = (string) ($review->review_status ?? 'pending_review');
            if ($review && (int) $review->source_version < (int) $source->current_version && in_array($reviewStatus, ['reviewed', 'verified'], true)) {
                $reviewStatus = 'need_recheck';
            }
            $ragStatus = $this->ragStatus($snapshot?->parse_status, $reviewStatus);
            if ($reviewStatus === 'need_recheck' && $ragStatus === 'ready') {
                $ragStatus = 'stale';
            }
            $updatedAt = $snapshot?->checked_at ?? $review?->created_at ?? $task->finished_at ?? $task->created_at ?? now();
            $items[] = [
                'content_ref' => $contentRef,
                'source_key' => $sourceKey,
                'asset_id' => $wiki ? (int) $wiki->asset_id : (int) $source->asset_id,
                'compile_status' => (string) $task->task_status,
                'review_status' => $reviewStatus,
                'rag_status' => $ragStatus,
                'quality_score' => $review?->quality_score !== null ? (float) $review->quality_score : null,
                'updated_at' => method_exists($updatedAt, 'toAtomString') ? $updatedAt->toAtomString() : date(DATE_ATOM, strtotime((string) $updatedAt)),
            ];
        }

        return [
            'schema_version' => 'drvknowledge.governance-status.v2',
            'trace_id' => $traceId,
            'generated_at' => now()->toAtomString(),
            'items' => $items,
            'unresolved' => $unresolved,
        ];
    }

    private function ragStatus(mixed $parseStatus, string $reviewStatus): string
    {
        if ($reviewStatus === 'deprecated') {
            return 'disabled';
        }
        return match ((string) $parseStatus) {
            'queued' => 'queued',
            'parsing', 'running' => 'parsing',
            'ready', 'success', 'parsed' => 'ready',
            'stale' => 'stale',
            'failed', 'error' => 'failed',
            'disabled' => 'disabled',
            default => 'not_ingested',
        };
    }
}

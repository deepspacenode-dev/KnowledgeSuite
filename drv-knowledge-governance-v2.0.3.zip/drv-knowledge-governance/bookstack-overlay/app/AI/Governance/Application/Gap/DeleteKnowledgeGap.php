<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Gap;

use BookStack\AI\Governance\Infrastructure\Persistence\AuditEventRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\GapRepository;
use DomainException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class DeleteKnowledgeGap
{
    public function __construct(
        private readonly GapRepository $gaps,
        private readonly AuditEventRepository $audit,
    ) {
    }

    /** @return array{gap_id: int, deleted: bool} */
    public function execute(int $gapId, int $actorId, string $reason): array
    {
        $gap = $this->gaps->findById($gapId);
        if ($gap === null) {
            throw new DomainException('知识缺口不存在或已删除。');
        }

        return DB::transaction(function () use ($gap, $gapId, $actorId, $reason): array {
            $snapshot = [
                'gap_id' => $gapId,
                'title' => (string) ($gap->title ?? ''),
                'gap_status' => (string) ($gap->gap_status ?? ''),
                'priority' => (string) ($gap->priority ?? ''),
            ];
            $this->audit->append([
                'trace_id' => (string) Str::uuid(),
                'event_type' => 'gap.deleted',
                'object_type' => 'knowledge_gap',
                'object_id' => (string) $gapId,
                'actor_id' => $actorId,
                'before_digest' => hash('sha256', json_encode((array) $gap, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)),
                'metadata_json' => $snapshot + ['reason' => $reason],
            ]);
            if (!$this->gaps->delete($gapId)) {
                throw new DomainException('知识缺口删除失败，请刷新后重试。');
            }

            return ['gap_id' => $gapId, 'deleted' => true];
        });
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Quality;

use BookStack\AI\Governance\Application\Review\ReviewUnitResolver;
use BookStack\AI\Governance\Infrastructure\BookStack\BookStackHierarchyQuery;
use Illuminate\Support\Facades\DB;

final class QualityIssueUnitQuery
{
    public function __construct(
        private readonly BookStackHierarchyQuery $hierarchy,
        private readonly ReviewUnitResolver $resolver,
        private readonly QualityExplanation $explanation,
        private readonly QualityUnitAggregator $aggregator,
    ) {
    }

    /** @param array<string, mixed> $filters @return array<int, array<string, mixed>> */
    public function execute(array $filters = []): array
    {
        $bookshelfId = $filters['bookshelf_id'] ?? null;
        $pageIds = $this->hierarchy->pageIdsForBookshelf($bookshelfId);
        if ($pageIds === []) {
            return [];
        }

        $structure = $this->hierarchy->structure($pageIds);
        $assets = $this->effectiveAssets($pageIds);
        $assetIds = array_values(array_filter(array_map(
            static fn (?object $asset): int => (int) ($asset->asset_id ?? 0),
            $assets,
        )));
        $checks = $this->latestChecks($assetIds);
        $units = [];

        foreach ($structure as $pageId => $page) {
            foreach ($this->membershipsForPage($page, $bookshelfId) as $membership) {
                $unit = $this->resolver->unitForPage($page, $membership);
                $unit['chapter_url'] ??= $page['chapter_url'] ?? null;
                $key = (string) $unit['unit_key'];
                $units[$key] ??= $unit + [
                    'member_count' => 0,
                    'checked_page_count' => 0,
                    'members' => [],
                    'scores' => [],
                    'checked_at' => null,
                ];
                $units[$key]['member_count']++;

                $asset = $assets[(int) $pageId] ?? null;
                $check = $asset ? ($checks[(int) $asset->asset_id] ?? null) : null;
                if ($asset === null || $check === null) {
                    continue;
                }

                $described = $this->explanation->describeCheck((array) $check + [
                    'score' => $check->content_score ?? null,
                    'asset_title' => (string) $asset->title,
                    'page_id' => (int) $pageId,
                    'current_version' => (int) $asset->current_version,
                ]);
                $units[$key]['checked_page_count']++;
                if (is_numeric($described['score'] ?? null)) {
                    $units[$key]['scores'][] = (int) $described['score'];
                }
                $checkedAt = (string) ($described['checked_at'] ?? '');
                if ($checkedAt !== '' && (
                    $units[$key]['checked_at'] === null
                    || strcmp($checkedAt, (string) $units[$key]['checked_at']) > 0
                )) {
                    $units[$key]['checked_at'] = $checkedAt;
                }
                if (($described['gate_result'] ?? 'allow') === 'allow') {
                    continue;
                }

                $units[$key]['members'][] = [
                    'page_id' => (int) $pageId,
                    'page_title' => (string) ($page['page_name'] ?? '未命名页面'),
                    'page_url' => (string) ($page['page_url'] ?? ''),
                    'asset_id' => (int) $asset->asset_id,
                    'asset_title' => (string) $asset->title,
                    'current_version' => (int) $asset->current_version,
                    'source_version' => (int) ($described['source_version'] ?? $asset->current_version),
                    'score' => $described['score'] ?? null,
                    'gate_result' => (string) $described['gate_result'],
                    'conclusion' => (string) $described['conclusion'],
                    'problems' => (array) ($described['problems'] ?? []),
                    'warnings_json' => $described['warnings_json'] ?? null,
                    'reject_reasons_json' => $described['reject_reasons_json'] ?? null,
                    'checked_at' => $described['checked_at'] ?? null,
                ];
            }
        }

        $items = [];
        foreach ($units as $unit) {
            if ($unit['members'] === []) {
                continue;
            }
            $items[] = $this->aggregator->summarize($unit);
        }
        usort($items, static function (array $left, array $right): int {
            $time = strcmp((string) ($right['checked_at'] ?? ''), (string) ($left['checked_at'] ?? ''));
            if ($time !== 0) {
                return $time;
            }
            return strcmp((string) $left['unit_key'], (string) $right['unit_key']);
        });

        return array_slice($items, 0, 200);
    }

    /** @param array<string, mixed> $page @return array<int, array<string, mixed>> */
    private function membershipsForPage(array $page, int|string|null $bookshelfId): array
    {
        $memberships = array_values((array) ($page['bookshelf_memberships'] ?? []));
        if ($bookshelfId !== null && $bookshelfId !== '') {
            return array_values(array_filter(
                $memberships,
                static fn (array $membership): bool => (string) ($membership['bookshelf_id'] ?? 'unassigned') === (string) $bookshelfId,
            ));
        }
        if ($memberships === []) {
            return [];
        }
        foreach ($memberships as $membership) {
            if ($this->resolver->isChapterReviewShelf((string) ($membership['bookshelf_name'] ?? ''))) {
                return [$membership];
            }
        }
        return [$memberships[0]];
    }

    /** @param array<int, int> $pageIds @return array<int, object> */
    private function effectiveAssets(array $pageIds): array
    {
        $rows = DB::table('drv_kb_assets')
            ->whereIn('page_id', $pageIds)
            ->orderByRaw("CASE asset_type WHEN 'wiki' THEN 0 ELSE 1 END")
            ->orderByDesc('current_version')
            ->orderByDesc('asset_id')
            ->get()
            ->all();
        $result = [];
        foreach ($rows as $row) {
            $result[(int) $row->page_id] ??= $row;
        }
        return $result;
    }

    /** @param array<int, int> $assetIds @return array<int, object> */
    private function latestChecks(array $assetIds): array
    {
        if ($assetIds === []) {
            return [];
        }
        $latestIds = DB::table('drv_kb_quality_checks')
            ->whereIn('asset_id', $assetIds)
            ->selectRaw('MAX(quality_check_id)')
            ->groupBy('asset_id');
        $rows = DB::table('drv_kb_quality_checks')
            ->whereIn('quality_check_id', $latestIds)
            ->get()
            ->all();
        $result = [];
        foreach ($rows as $row) {
            $result[(int) $row->asset_id] ??= $row;
        }
        return $result;
    }
}

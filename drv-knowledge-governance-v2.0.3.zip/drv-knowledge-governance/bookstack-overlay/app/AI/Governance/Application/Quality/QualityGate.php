<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Quality;

use JsonException;
use RuntimeException;

final class QualityGate
{
    /** @var array<string, mixed>|null */
    private ?array $rules = null;

    /** @param array<string, mixed> $document @return array<string, mixed> */
    public function evaluate(array $document, ?string $targetStatus = null): array
    {
        $rules = $this->rules();
        $metadata = is_array($document['metadata'] ?? null) ? $document['metadata'] : [];
        $sources = is_array($document['sources'] ?? null) ? array_filter($document['sources']) : [];
        $markdown = (string) ($document['markdown'] ?? '');
        $warnings = [];
        $rejected = [];
        $score = 100;

        foreach ($rules['required_metadata'] as $field) {
            if (!array_key_exists($field, $metadata) || $metadata[$field] === '' || $metadata[$field] === null) {
                $score -= (int) $rules['penalties']['missing_required_metadata'];
                $warnings[] = "missing:{$field}";
            }
        }
        foreach ($rules['recommended_sections'] as $section) {
            if ($markdown !== '' && !str_contains($markdown, (string) $section)) {
                $score -= (int) $rules['penalties']['missing_recommended_section'];
                $warnings[] = "missing_section:{$section}";
            }
        }
        if ($sources === []) {
            $score -= (int) $rules['penalties']['missing_source'];
            $rejected[] = 'missing_source';
        }
        if (($metadata['status'] ?? null) === 'deprecated') {
            $rejected[] = 'deprecated';
        }
        if (($metadata['rag_enabled'] ?? null) === false) {
            $warnings[] = 'rag_disabled_in_source';
        }
        if (($metadata['status'] ?? null) === 'draft') {
            $warnings[] = 'draft';
        }
        if (($document['source_modified_after_review'] ?? false) === true) {
            $warnings[] = 'need_recheck';
        }

        $score = max(0, $score);
        $effectiveStatus = $targetStatus ?? (string) ($metadata['status'] ?? 'reviewed');
        $minimumScore = $effectiveStatus === 'verified'
            ? (int) ($rules['verified_minimum_score'] ?? 90)
            : (int) $rules['minimum_score'];
        if ($score < $minimumScore) {
            $rejected[] = $effectiveStatus === 'verified' ? 'verified_score_below_minimum' : 'score_below_minimum';
        }
        $rejected = array_values(array_unique($rejected));
        $warnings = array_values(array_unique($warnings));

        return [
            'allowed' => $rejected === [],
            'gate_result' => $rejected !== [] ? 'blocked' : ($warnings !== [] ? 'warning' : 'allow'),
            'quality_score' => $score,
            'warnings' => $warnings,
            'reject_reasons' => $rejected,
        ];
    }

    /** @return array<string, mixed> */
    private function rules(): array
    {
        if ($this->rules !== null) {
            return $this->rules;
        }
        $json = file_get_contents(__DIR__ . '/quality-rules.json');
        if ($json === false) {
            throw new RuntimeException('Quality rules are unavailable.');
        }
        try {
            return $this->rules = json_decode($json, true, 32, JSON_THROW_ON_ERROR);
        } catch (JsonException $exception) {
            throw new RuntimeException('Quality rules are invalid.', 0, $exception);
        }
    }
}

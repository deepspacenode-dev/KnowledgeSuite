<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Quality;

final class QualityUnitAggregator
{
    /** @param array<string, mixed> $unit @return array<string, mixed> */
    public function summarize(array $unit): array
    {
        $members = array_values((array) ($unit['members'] ?? []));
        $scores = array_values(array_filter(
            (array) ($unit['scores'] ?? []),
            static fn (mixed $score): bool => is_numeric($score),
        ));
        $unit['score'] = $scores === [] ? null : min(array_map('intval', $scores));
        $unit['issue_page_count'] = count($members);
        $unit['blocked_page_count'] = count(array_filter(
            $members,
            static fn (array $member): bool => ($member['gate_result'] ?? '') === 'blocked',
        ));
        $unit['gate_result'] = $unit['blocked_page_count'] > 0 ? 'blocked' : 'warning';
        $unit['members'] = $members;
        $unit['problems'] = $this->flattenProblems($members);

        if (($unit['unit_type'] ?? 'page') === 'chapter') {
            $unit['asset_id'] = null;
            $unit['asset_title'] = (string) ($unit['unit_title'] ?? '未命名章节');
            $unit['conclusion'] = $this->chapterConclusion($unit);
        } elseif ($members !== []) {
            $member = $members[0];
            foreach ([
                'asset_id', 'asset_title', 'current_version', 'source_version',
                'page_url', 'warnings_json', 'reject_reasons_json', 'conclusion', 'checked_at',
            ] as $field) {
                if (array_key_exists($field, $member)) {
                    $unit[$field] = $member[$field];
                }
            }
        }

        unset($unit['scores']);

        return $unit;
    }

    /** @param array<string, mixed> $unit */
    private function chapterConclusion(array $unit): string
    {
        $memberCount = (int) ($unit['member_count'] ?? 0);
        $issueCount = (int) ($unit['issue_page_count'] ?? 0);
        $blockedCount = (int) ($unit['blocked_page_count'] ?? 0);

        if ($blockedCount > 0) {
            return "本章节无法通过质量门禁：{$issueCount}/{$memberCount} 个页面存在问题，其中 {$blockedCount} 个页面含硬阻断。修复全部阻断项并重新检查后，才能通过章节审核并正式入库。";
        }

        return "本章节存在质量扣分项：{$issueCount}/{$memberCount} 个页面需要修复。当前没有硬阻断，但建议修复后再通过章节审核。";
    }

    /** @param array<int, array<string, mixed>> $members @return array<int, array<string, mixed>> */
    private function flattenProblems(array $members): array
    {
        $problems = [];
        foreach ($members as $member) {
            foreach ((array) ($member['problems'] ?? []) as $problem) {
                $problems[] = (array) $problem + [
                    'page_id' => $member['page_id'] ?? null,
                    'page_title' => $member['page_title'] ?? '未命名页面',
                ];
            }
        }
        return $problems;
    }
}

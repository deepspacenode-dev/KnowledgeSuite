<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Quality;

use JsonException;
use RuntimeException;

final class QualityExplanation
{
    /** @var array<string, mixed>|null */
    private ?array $rules = null;

    /** @param array<string, mixed> $check @return array<string, mixed> */
    public function describeCheck(array $check): array
    {
        $warnings = $this->decodeList($check['warnings_json'] ?? null);
        $rejectReasons = $this->decodeList($check['reject_reasons_json'] ?? null);
        $problems = [];
        foreach ($rejectReasons as $code) {
            $problems[] = $this->describeCode($code, true);
        }
        foreach ($warnings as $code) {
            $problems[] = $this->describeCode($code, false);
        }

        $gateResult = $rejectReasons !== [] ? 'blocked' : ($warnings !== [] ? 'warning' : 'allow');
        $blockingTitles = array_values(array_map(
            static fn (array $problem): string => (string) $problem['title'],
            array_filter($problems, static fn (array $problem): bool => (bool) $problem['blocking']),
        ));
        $conclusion = match ($gateResult) {
            'blocked' => '无法入库：' . implode('；', $blockingTitles) . '。请按修复建议处理后重新检查。',
            'warning' => '当前未触发硬阻断，但存在质量扣分项；建议修复后再进入正式知识库。',
            default => '已通过质量门禁，可以进入 RAGFlow 入库流程。',
        };

        return array_replace($check, [
            'score' => isset($check['score']) ? (int) $check['score'] : null,
            'gate_result' => $gateResult,
            'conclusion' => $conclusion,
            'blocking_reasons' => $blockingTitles,
            'problems' => $problems,
        ]);
    }

    /** @return array<string, mixed> */
    public function help(): array
    {
        $rules = $this->rules();
        $metadata = [];
        foreach ($rules['required_metadata'] as $field) {
            $metadata[] = [
                'code' => "missing:{$field}",
                'name' => (string) ($rules['field_labels'][$field] ?? $field),
                'trigger' => 'Front Matter 未填写该字段或字段值为空。',
                'deduction' => (int) $rules['penalties']['missing_required_metadata'],
                'blocking' => false,
                'fix' => (string) ($rules['field_fixes'][$field] ?? '补齐对应 Front Matter 字段。'),
            ];
        }
        $sections = [];
        foreach ($rules['recommended_sections'] as $section) {
            $sections[] = [
                'code' => "missing_section:{$section}",
                'name' => "缺少“{$section}”章节",
                'trigger' => "Wiki Markdown 中没有“{$section}”文字。",
                'deduction' => (int) $rules['penalties']['missing_recommended_section'],
                'blocking' => false,
                'fix' => (string) ($rules['section_fixes'][$section] ?? "补充“{$section}”章节。"),
            ];
        }
        $hardBlocks = [];
        foreach ($rules['hard_blocks'] as $code => $description) {
            $detail = $this->describeCode((string) $code, true);
            $hardBlocks[] = [
                'code' => $code,
                'name' => $detail['title'],
                'trigger' => (string) $description,
                'deduction' => $code === 'missing_source' ? (int) $rules['penalties']['missing_source'] : null,
                'blocking' => true,
                'fix' => $detail['fix'],
            ];
        }
        $workflowRules = [];
        foreach ($rules['workflow_notices'] as $code => $description) {
            $detail = $this->describeCode((string) $code, false);
            $workflowRules[] = [
                'code' => $code,
                'name' => $detail['title'],
                'trigger' => (string) $description,
                'deduction' => null,
                'blocking' => false,
                'fix' => $detail['fix'],
            ];
        }

        return [
            'minimum_score' => (int) $rules['minimum_score'],
            'verified_minimum_score' => (int) $rules['verified_minimum_score'],
            'summary' => '普通审阅至少 70 分，验证发布至少 90 分；缺少来源或文章已废弃时，无论分数多少都会阻断入库。',
            'metadata_rules' => $metadata,
            'section_rules' => $sections,
            'hard_blocks' => $hardBlocks,
            'workflow_rules' => $workflowRules,
        ];
    }

    /** @return array<string, mixed> */
    private function describeCode(string $code, bool $blocking): array
    {
        $rules = $this->rules();
        $title = $code;
        $fix = '根据文章详情补齐信息后，点击“重新检查”。';
        $deduction = null;

        if (str_starts_with($code, 'missing:')) {
            $field = substr($code, strlen('missing:'));
            $label = (string) ($rules['field_labels'][$field] ?? $field);
            $title = "缺少{$label}";
            $fix = (string) ($rules['field_fixes'][$field] ?? "补齐 {$field} 字段。");
            $deduction = (int) $rules['penalties']['missing_required_metadata'];
        } elseif (str_starts_with($code, 'missing_section:')) {
            $section = substr($code, strlen('missing_section:'));
            $title = "缺少“{$section}”章节";
            $fix = (string) ($rules['section_fixes'][$section] ?? "补充“{$section}”章节。");
            $deduction = (int) $rules['penalties']['missing_recommended_section'];
        } else {
            [$title, $fix, $deduction] = match ($code) {
                'missing_source' => ['缺少可追溯来源', '补充有效来源链接或来源文档，确保结论可以核验。', (int) $rules['penalties']['missing_source']],
                'deprecated' => ['文章已废弃', '确认文章仍有效后恢复为待审阅状态，或保留废弃状态且不入库。', null],
                'score_below_minimum' => ['质量总分低于 70 分', '修复上方扣分项，使普通审阅分数达到 70 分。', null],
                'verified_score_below_minimum' => ['验证分数低于 90 分', '修复扣分项，使验证发布分数达到 90 分。', null],
                'rag_disabled_in_source' => ['文章已关闭 RAG 入库', '确认内容可发布后重新启用 rag_enabled。', null],
                'draft' => ['文章仍为草稿', '完成内容编写并提交人工审阅。', null],
                'need_recheck' => ['来源内容在审阅后发生变化', '重新核对正文、图片和来源后提交复审。', null],
                'source_asset_review_only' => ['当前记录是原始资料', '先生成 Wiki 条目，原始资料本身不能正式发布到 RAGFlow。', null],
                default => ["未识别的质量规则（{$code}）", '联系治理管理员检查质量规则版本。', null],
            };
        }

        return [
            'code' => $code,
            'severity' => $blocking ? '阻断' : '警告',
            'title' => $title,
            'deduction' => $deduction,
            'blocking' => $blocking,
            'fix' => $fix,
        ];
    }

    /** @return array<int, string> */
    private function decodeList(mixed $value): array
    {
        if (is_array($value)) {
            return array_values(array_map('strval', $value));
        }
        if (!is_string($value) || trim($value) === '') {
            return [];
        }
        $decoded = json_decode($value, true);
        return is_array($decoded) ? array_values(array_map('strval', $decoded)) : [];
    }

    /** @return array<string, mixed> */
    private function rules(): array
    {
        if ($this->rules !== null) {
            return $this->rules;
        }
        $json = file_get_contents(__DIR__ . '/quality-rules.json');
        if ($json === false) {
            throw new RuntimeException('Quality rules are unavailable.');
        }
        try {
            return $this->rules = json_decode($json, true, 32, JSON_THROW_ON_ERROR);
        } catch (JsonException $exception) {
            throw new RuntimeException('Quality rules are invalid.', 0, $exception);
        }
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Assistant;

final class AssistantConfig
{
    private const DEFAULT_ALLOWED_PATHS = ['/chats/widget', '/next-chats/widget'];

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        $enabled = filter_var(env('RAGFLOW_WIDGET_ENABLED', false), FILTER_VALIDATE_BOOL);
        $baseUrl = rtrim(trim((string) env('RAGFLOW_WIDGET_BASE_URL', '')), '/');
        $path = '/' . ltrim(trim((string) env('RAGFLOW_WIDGET_PATH', '/chats/widget')), '/');
        $sharedId = trim((string) env('RAGFLOW_WIDGET_SHARED_ID', ''));
        $auth = trim((string) env('RAGFLOW_WIDGET_AUTH', ''));
        $allowMedia = filter_var(env('RAGFLOW_WIDGET_ALLOW_MEDIA', false), FILTER_VALIDATE_BOOL);
        $timeout = max(3000, min((int) env('RAGFLOW_WIDGET_LOAD_TIMEOUT_MS', 12000), 60000));
        $ragflowWebUrl = $this->safeWebUrl((string) env('RAGFLOW_WEB_URL', $baseUrl));

        $base = [
            'schema_version' => 'drvknowledge.assistant-config.v2',
            'chat_mode' => 'ragflow_widget',
            'ragflow_web_url' => $ragflowWebUrl,
        ];
        if (!$enabled) {
            return $base + ['widget' => $this->disabledWidget('RAGFlow 官方聊天组件未启用。', $timeout)];
        }

        $origin = $this->validatedOrigin($baseUrl);
        if ($origin === null) {
            return $base + ['widget' => $this->disabledWidget('RAGFlow Widget 地址无效，仅支持不含账号、查询参数和片段的 HTTP(S) 地址。', $timeout)];
        }
        if (!in_array($path, $this->allowedPaths(), true)) {
            return $base + ['widget' => $this->disabledWidget('RAGFlow Widget 路径不在允许列表中。', $timeout)];
        }
        if (!$this->safeToken($sharedId) || !$this->safeToken($auth)) {
            return $base + ['widget' => $this->disabledWidget('RAGFlow Widget 的共享 ID 或浏览器凭据尚未正确配置。', $timeout)];
        }

        $query = [
            'shared_id' => $sharedId,
            'from' => 'chat',
            'auth' => $auth,
            'locale' => 'zh',
            'mode' => 'window',
            'streaming' => $this->boolString('RAGFLOW_WIDGET_STREAMING', false),
            'muted' => $this->boolString('RAGFLOW_WIDGET_MUTED', true),
            'widget_accent_color' => $this->color('RAGFLOW_WIDGET_ACCENT_COLOR', '#2563eb'),
            'widget_background_color' => $this->color('RAGFLOW_WIDGET_BACKGROUND_COLOR', '#ffffff'),
            'widget_text_color' => $this->color('RAGFLOW_WIDGET_TEXT_COLOR', '#111827'),
            'widget_header_text_color' => $this->color('RAGFLOW_WIDGET_HEADER_TEXT_COLOR', '#ffffff'),
            'widget_footer_text_color' => $this->color('RAGFLOW_WIDGET_FOOTER_TEXT_COLOR', '#111827'),
        ];
        foreach ([
            'widget_title' => 'RAGFLOW_WIDGET_TITLE',
            'widget_subtitle' => 'RAGFLOW_WIDGET_SUBTITLE',
            'widget_footer' => 'RAGFLOW_WIDGET_FOOTER',
            'widget_footer_link' => 'RAGFLOW_WIDGET_FOOTER_LINK',
        ] as $queryKey => $environmentKey) {
            $value = trim((string) env($environmentKey, ''));
            if ($value !== '') {
                $query[$queryKey] = mb_substr($value, 0, 240);
            }
        }

        return $base + [
            'widget' => [
                'enabled' => true,
                'src' => $baseUrl . $path . '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986),
                'origin' => $origin,
                'allow_media' => $allowMedia,
                'load_timeout_ms' => $timeout,
                'reason' => '',
            ],
        ];
    }

    /** @return array<string, mixed> */
    private function disabledWidget(string $reason, int $timeout): array
    {
        return [
            'enabled' => false,
            'src' => '',
            'origin' => '',
            'allow_media' => false,
            'load_timeout_ms' => $timeout,
            'reason' => $reason,
        ];
    }

    private function validatedOrigin(string $url): ?string
    {
        if ($url === '' || filter_var($url, FILTER_VALIDATE_URL) === false) {
            return null;
        }
        $parts = parse_url($url);
        if (!is_array($parts)
            || !in_array(strtolower((string) ($parts['scheme'] ?? '')), ['http', 'https'], true)
            || trim((string) ($parts['host'] ?? '')) === ''
            || isset($parts['user'])
            || isset($parts['pass'])
            || isset($parts['query'])
            || isset($parts['fragment'])
            || !in_array((string) ($parts['path'] ?? ''), ['', '/'], true)
        ) {
            return null;
        }
        $scheme = strtolower((string) $parts['scheme']);
        $origin = $scheme . '://' . strtolower((string) $parts['host']);
        if (isset($parts['port'])) {
            $origin .= ':' . (int) $parts['port'];
        }
        return $origin;
    }

    private function safeWebUrl(string $value): string
    {
        $url = rtrim(trim($value), '/') . '/';
        if (filter_var($url, FILTER_VALIDATE_URL) === false) {
            return '';
        }
        $parts = parse_url($url);
        if (!is_array($parts)
            || !in_array(strtolower((string) ($parts['scheme'] ?? '')), ['http', 'https'], true)
            || !isset($parts['host'])
            || isset($parts['user'])
            || isset($parts['pass'])
        ) {
            return '';
        }
        return $url;
    }

    /** @return array<int, string> */
    private function allowedPaths(): array
    {
        $configured = array_filter(array_map(
            static fn (string $path): string => '/' . ltrim(trim($path), '/'),
            explode(',', (string) env('RAGFLOW_WIDGET_ALLOWED_PATHS', '')),
        ));
        $safeConfigured = array_filter($configured, static fn (string $path): bool => preg_match('#^/[A-Za-z0-9/_-]{1,160}$#', $path) === 1);
        return array_values(array_unique([...self::DEFAULT_ALLOWED_PATHS, ...$safeConfigured]));
    }

    private function safeToken(string $value): bool
    {
        return preg_match('/^[A-Za-z0-9._~-]{8,512}$/', $value) === 1;
    }

    private function boolString(string $name, bool $default): string
    {
        return filter_var(env($name, $default), FILTER_VALIDATE_BOOL) ? 'true' : 'false';
    }

    private function color(string $name, string $default): string
    {
        $value = trim((string) env($name, $default));
        return preg_match('/^#[0-9A-Fa-f]{6}$/', $value) === 1 ? strtolower($value) : $default;
    }
}

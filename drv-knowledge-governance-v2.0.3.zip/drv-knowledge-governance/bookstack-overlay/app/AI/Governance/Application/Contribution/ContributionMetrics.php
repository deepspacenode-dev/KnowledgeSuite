<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Contribution;

use BookStack\AI\Governance\Infrastructure\BookStack\BookStackHierarchyQuery;
use Illuminate\Support\Facades\DB;

final class ContributionMetrics
{
    public function __construct(private readonly BookStackHierarchyQuery $hierarchy)
    {
    }

    /** @return array<int, object> */
    public function between(string $from, string $to, int|string|null $bookshelfId = null): array
    {
        $bounds = $this->periodBounds($from, $to);

        return DB::table('drv_kb_assets')
            ->leftJoin('users', 'users.id', '=', 'drv_kb_assets.owner_id')
            ->whereIn('drv_kb_assets.page_id', $this->hierarchy->pageIdsForBookshelf($bookshelfId))
            ->whereBetween('drv_kb_assets.updated_at', $bounds)
            ->selectRaw('drv_kb_assets.owner_id, COALESCE(users.name, \'未分配\') AS owner_name, COUNT(DISTINCT drv_kb_assets.page_id) AS document_count, COUNT(DISTINCT drv_kb_assets.page_id) AS effective_pages, COUNT(*) AS asset_count, SUM(CASE WHEN drv_kb_assets.asset_type = \'wiki\' THEN 1 ELSE 0 END) AS wiki_assets')
            ->groupBy('drv_kb_assets.owner_id', 'users.name')
            ->orderByDesc('effective_pages')
            ->get()
            ->all();
    }

    /** @return array<int, object> */
    public function contributionDetails(string $from, string $to, int|string|null $bookshelfId = null): array
    {
        $bounds = $this->periodBounds($from, $to);

        $pageIds = $this->hierarchy->pageIdsForBookshelf($bookshelfId);
        $structure = $this->hierarchy->structure($pageIds);
        $items = DB::table('drv_kb_assets')
            ->leftJoin('users', 'users.id', '=', 'drv_kb_assets.owner_id')
            ->whereIn('drv_kb_assets.page_id', $pageIds)
            ->whereBetween('drv_kb_assets.updated_at', $bounds)
            ->selectRaw('drv_kb_assets.asset_id, drv_kb_assets.page_id, drv_kb_assets.owner_id, COALESCE(users.name, \'未分配\') AS owner_name, drv_kb_assets.title AS document_title, drv_kb_assets.updated_at AS contribution_time')
            ->orderByDesc('contribution_time')
            ->limit(200)
            ->get()
            ->all();

        return array_map(static function (object $item) use ($structure, $bookshelfId): object {
            $page = $structure[(int) $item->page_id] ?? [];
            $memberships = (array) ($page['bookshelf_memberships'] ?? []);
            if ($bookshelfId !== null && $bookshelfId !== '') {
                $memberships = array_values(array_filter($memberships, static fn (array $membership): bool => (string) ($membership['bookshelf_id'] ?? 'unassigned') === (string) $bookshelfId));
            }
            $item->shelf_name = implode(' / ', array_unique(array_map(static fn (array $membership): string => (string) ($membership['bookshelf_name'] ?? '未归属书架'), $memberships))) ?: '未归属书架';
            $item->chapter_name = (string) ($page['chapter_name'] ?? '书籍直属页面');
            return $item;
        }, $items);
    }

    /** @return array{0: string, 1: string} */
    private function periodBounds(string $from, string $to): array
    {
        return [
            strlen($from) <= 10 ? $from . ' 00:00:00' : $from,
            strlen($to) <= 10 ? $to . ' 23:59:59' : $to,
        ];
    }
}

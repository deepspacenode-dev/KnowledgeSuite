<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Compile;

use DomainException;

final class ValidateSourceIdentity
{
    /** @param array<string, mixed> $actual @param array<string, mixed> $expected */
    public function assertMatches(array $actual, array $expected): void
    {
        $matches = (int) ($actual['page_id'] ?? 0) === (int) ($expected['page_id'] ?? 0)
            && $this->normalizeUrl((string) ($actual['canonical_url'] ?? '')) === $this->normalizeUrl((string) ($expected['canonical_url'] ?? ''))
            && $this->normalizeTitle((string) ($actual['title'] ?? '')) === $this->normalizeTitle((string) ($expected['title'] ?? ''))
            && (!isset($expected['content_hash']) || hash_equals((string) ($actual['content_hash'] ?? ''), (string) $expected['content_hash']));
        if (!$matches) {
            throw new DomainException('SOURCE_IDENTITY_MISMATCH');
        }
    }

    private function normalizeUrl(string $url): string
    {
        $parts = parse_url(trim($url));
        if (!is_array($parts)) {
            return '';
        }
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = strtolower((string) ($parts['host'] ?? ''));
        $path = rtrim((string) ($parts['path'] ?? ''), '/');
        return "{$scheme}://{$host}{$path}";
    }

    private function normalizeTitle(string $title): string
    {
        return preg_replace('/\s+/u', ' ', trim($title)) ?? '';
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Compile;

use DateTimeInterface;
use DomainException;

final class WikiTaskV2Builder
{
    /** @return array<string, mixed> */
    public function build(object $task, object $source): array
    {
        $metadata = json_decode((string) ($source->metadata_json ?? ''), true);
        if (!is_array($metadata) || !is_string($metadata['raw_markdown'] ?? null) || trim($metadata['raw_markdown']) === '') {
            throw new DomainException('SOURCE_MARKDOWN_UNAVAILABLE');
        }
        $pageId = (int) $source->page_id;
        $material = (string) ($source->material_type ?: 'docs');
        $wikiTypes = [
            'cases' => 'case', 'manuals' => 'manual', 'tech_notes' => 'tech_note',
            'project_docs' => 'project_doc', 'docs' => 'doc',
        ];
        $compiler = in_array((string) $task->workflow, ['ragflow_workflow', 'openai_compatible', 'offline'], true)
            ? (string) $task->workflow
            : 'offline';

        return [
            'schema_version' => 'drvknowledge.wiki-task.v2',
            'trace_id' => 'trace:task:' . $task->task_id . ':' . $task->source_version,
            'task_id' => (string) $task->task_id,
            'created_at' => $this->dateTime($task->created_at) ?? now()->toAtomString(),
            'lease_expires_at' => $this->dateTime($task->lease_expires_at ?? null),
            'source_version' => (int) $task->source_version,
            'source' => [
                'page_id' => $pageId,
                'canonical_url' => (string) $metadata['canonical_url'],
                'title' => (string) $source->title,
                'source_key' => "bookstack_page:{$pageId}",
                'content_ref' => "bookstack:page:{$pageId}",
                'content_hash' => (string) $source->content_hash,
                'material_type' => $material,
                'markdown' => (string) $metadata['raw_markdown'],
                'hierarchy' => array_values(array_map('strval', (array) ($metadata['hierarchy'] ?? []))),
                'tags' => array_values(array_map('strval', (array) ($metadata['tags'] ?? []))),
                'domain_metadata' => $this->domainMetadata((array) ($metadata['domain_metadata'] ?? [])),
            ],
            'target' => [
                'wiki_type' => $wikiTypes[$material] ?? 'doc',
                'language' => 'zh-CN',
                'review_required' => true,
            ],
            'compile_policy' => [
                'compiler' => $compiler,
                'allow_unsourced_claims' => false,
                'default_status' => 'draft',
                'model' => null,
            ],
        ];
    }

    private function dateTime(mixed $value): ?string
    {
        if ($value instanceof DateTimeInterface) {
            return $value->format(DATE_ATOM);
        }
        if (is_string($value) && trim($value) !== '') {
            $timestamp = strtotime($value);
            return $timestamp === false ? null : date(DATE_ATOM, $timestamp);
        }
        return null;
    }

    /** @param array<string, mixed> $metadata @return array<string, ?string> */
    private function domainMetadata(array $metadata): array
    {
        $result = [];
        foreach (['owner', 'module', 'platform', 'chip', 'project'] as $field) {
            $value = trim((string) ($metadata[$field] ?? ''));
            $result[$field] = $value !== '' ? strtolower($value) : null;
        }
        return $result;
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Compile;

use BookStack\AI\Governance\Infrastructure\Persistence\AssetRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\CompileTaskRepository;

final class QueueCompileTask
{
    public function __construct(
        private readonly ValidateSourceIdentity $identity,
        private readonly AssetRepository $assets,
        private readonly CompileTaskRepository $tasks,
    ) {
    }

    /** @param array<string, mixed> $command @return array<string, mixed> */
    public function execute(array $command): array
    {
        $this->identity->assertMatches((array) $command['actual'], (array) $command['expected']);
        $actual = $command['actual'];
        $pageId = (int) $actual['page_id'];
        $sourceKey = "bookstack_page:{$pageId}";
        $workflow = (string) ($command['workflow'] ?? 'drvagent');
        $contentHash = (string) ($actual['governance_hash'] ?? $actual['content_hash'] ?? hash('sha256', (string) ($actual['markdown'] ?? '')));
        $existing = $this->assets->findBySourceKey($sourceKey, 'source');
        $sourceVersion = $existing && hash_equals((string) $existing->content_hash, $contentHash)
            ? (int) $existing->current_version
            : (int) ($existing->current_version ?? 0) + 1;

        $assetId = $this->assets->upsert([
            'asset_type' => 'source',
            'source_key' => $sourceKey,
            'page_id' => $pageId,
            'parent_asset_id' => null,
            'title' => (string) $actual['title'],
            'owner_id' => $actual['owner_id'] ?? null,
            'material_type' => $command['material_type'] ?? null,
            'content_hash' => $contentHash,
            'current_version' => $sourceVersion,
            'metadata_json' => json_encode([
                'canonical_url' => $actual['canonical_url'],
                'raw_markdown' => $actual['markdown'] ?? '',
                'page_updated_at' => $actual['page_updated_at'] ?? null,
                'hierarchy' => $actual['hierarchy'] ?? [],
                'tags' => $actual['tags'] ?? [],
                'domain_metadata' => $actual['domain_metadata'] ?? [],
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);

        $idempotencyKey = hash('sha256', implode('|', [$sourceKey, $sourceVersion, $contentHash, $workflow]));
        $taskId = $this->tasks->enqueue([
            'source_asset_id' => $assetId,
            'source_version' => $sourceVersion,
            'trigger_type' => (string) ($command['trigger_type'] ?? ($existing ? 'updated' : 'created')),
            'workflow' => $workflow,
            'idempotency_key' => $idempotencyKey,
        ]);

        return ['task_id' => $taskId, 'source_key' => $sourceKey, 'source_version' => $sourceVersion, 'content_hash' => $contentHash, 'idempotency_key' => $idempotencyKey];
    }
}

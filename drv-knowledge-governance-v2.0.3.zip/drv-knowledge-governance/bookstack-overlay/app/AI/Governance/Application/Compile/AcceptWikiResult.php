<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Application\Compile;

use BookStack\AI\Governance\Application\Contract\ContractValidatorV2;
use BookStack\AI\Governance\Infrastructure\Persistence\AssetRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\CompileTaskRepository;
use BookStack\AI\Governance\Infrastructure\Persistence\ReviewRepository;
use DateTimeImmutable;
use DomainException;
use Illuminate\Support\Facades\DB;
use Throwable;

final class AcceptWikiResult
{
    public function __construct(
        private readonly CompileTaskRepository $tasks,
        private readonly AssetRepository $assets,
        private readonly ReviewRepository $reviews,
        private readonly ContractValidatorV2 $contracts,
    ) {
    }

    /** @param array<string, mixed> $result @return array<string, mixed> */
    public function execute(int $taskId, string $worker, array $result): array
    {
        $this->contracts->assertWikiResult($result);
        $task = $this->tasks->find($taskId);
        if ($task === null) {
            throw new DomainException('TASK_STALE');
        }
        $source = $this->assets->findById((int) $task->source_asset_id);
        if ($task->task_status === 'succeeded') {
            $this->assertResultIdentity($taskId, $task, $source, $result, false);
            return $this->alreadyAccepted($task, $source, $result) + ['replayed' => true];
        }
        if ($task->task_status !== 'running' || $task->lease_owner !== $worker || !$this->hasActiveLease($task)) {
            throw new DomainException('TASK_STALE');
        }
        $this->assertResultIdentity($taskId, $task, $source, $result, true);

        return DB::transaction(function () use ($task, $taskId, $worker, $result, $source): array {
            $wikiHash = $this->resultHash($result);
            $wiki = $this->assets->findBySourceKey((string) $source->source_key, 'wiki');
            $version = $wiki && hash_equals((string) $wiki->content_hash, $wikiHash)
                ? (int) $wiki->current_version
                : (int) ($wiki->current_version ?? 0) + 1;
            $wikiId = $this->assets->upsert([
                'asset_type' => 'wiki',
                'source_key' => $source->source_key,
                'page_id' => $source->page_id,
                'parent_asset_id' => $source->asset_id,
                'title' => (string) ($result['title'] ?? $source->title),
                'owner_id' => $source->owner_id,
                'material_type' => $result['front_matter']['material_type'] ?? $source->material_type,
                'content_hash' => $wikiHash,
                'current_version' => $version,
                'metadata_json' => json_encode([
                    'front_matter' => $result['front_matter'],
                    'sources' => $result['sources'],
                    'wiki_markdown' => $result['markdown'],
                    'quality_report' => $result['quality_report'] ?? [],
                    'relations' => $result['relations'] ?? [],
                    'result_id' => $result['result_id'],
                    'source_version' => $result['source_version'],
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ]);
            $this->reviews->append([
                'asset_id' => $wikiId,
                'source_version' => (int) $task->source_version,
                'review_status' => 'pending_review',
                'gate_result' => 'warning',
                'reviewer_id' => null,
                'quality_score' => $result['quality_report']['score'] ?? null,
                'review_comment' => 'Generated draft requires human review.',
                'reviewed_at' => null,
            ]);
            if (!$this->tasks->complete($taskId, $worker)) {
                throw new DomainException('TASK_STALE');
            }

            return ['asset_id' => $wikiId, 'asset_type' => 'wiki', 'review_status' => 'pending_review', 'version' => $version, 'result_id' => $result['result_id'], 'replayed' => false];
        });
    }

    /** @param array<string, mixed> $result */
    private function assertResultIdentity(int $taskId, object $task, ?object $source, array $result, bool $requireCurrentSourceVersion): void
    {
        if ((string) ($result['task_id'] ?? '') !== (string) $taskId) {
            throw new DomainException('CONTRACT_INVALID');
        }
        if ($source === null
            || ($result['source_key'] ?? null) !== $source->source_key
            || ($result['front_matter']['source_key'] ?? null) !== $source->source_key
        ) {
            throw new DomainException('SOURCE_MISMATCH');
        }
        if ($requireCurrentSourceVersion && (int) $source->current_version !== (int) $task->source_version) {
            throw new DomainException('TASK_STALE');
        }
        if ((int) ($result['source_version'] ?? 0) !== (int) $task->source_version
            || ($result['front_matter']['rag_enabled'] ?? null) !== false
        ) {
            throw new DomainException('CONTRACT_INVALID');
        }
    }

    /** @param array<string, mixed> $result @return array<string, mixed> */
    private function alreadyAccepted(object $task, object $source, array $result): array
    {
        $wiki = $this->assets->findBySourceKey((string) $source->source_key, 'wiki');
        if ($wiki === null) {
            throw new DomainException('TASK_STALE');
        }
        $metadata = json_decode((string) $wiki->metadata_json, true);
        if (!is_array($metadata) || !hash_equals((string) ($metadata['result_id'] ?? ''), (string) $result['result_id'])) {
            throw new DomainException('RESULT_REPLAY_CONFLICT');
        }
        $wikiHash = $this->resultHash($result);
        if (!hash_equals((string) $wiki->content_hash, $wikiHash)) {
            throw new DomainException('RESULT_REPLAY_CONFLICT');
        }
        return [
            'asset_id' => (int) $wiki->asset_id,
            'asset_type' => 'wiki',
            'review_status' => (string) ($this->reviews->latestForAsset((int) $wiki->asset_id)?->review_status ?? 'pending_review'),
            'version' => (int) $wiki->current_version,
            'result_id' => $result['result_id'],
        ];
    }

    /** @param array<string, mixed> $result */
    private function resultHash(array $result): string
    {
        return hash('sha256', $result['markdown'] . json_encode($result['sources']));
    }

    private function hasActiveLease(object $task): bool
    {
        try {
            $expiresAt = new DateTimeImmutable((string) ($task->lease_expires_at ?? ''));
            return $expiresAt > new DateTimeImmutable('now');
        } catch (Throwable) {
            return false;
        }
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Domain;

use DomainException;
use JsonException;
use RuntimeException;

final class StateTransition
{
    /** @var array<string, mixed>|null */
    private static ?array $definition = null;

    public static function assertAllowed(string $machine, string $from, string $to): void
    {
        $definition = self::definition();
        $transitions = $definition[$machine]['transitions'] ?? null;

        if (!is_array($transitions) || !array_key_exists($from, $transitions)) {
            throw new DomainException("Unknown {$machine} state: {$from}");
        }

        if (!in_array($to, $transitions[$from], true)) {
            throw new DomainException("Disallowed {$machine} transition: {$from} -> {$to}");
        }
    }

    /** @return array<int, string> */
    public static function allowedTargets(string $machine, string $from): array
    {
        $transitions = self::definition()[$machine]['transitions'] ?? [];
        $targets = $transitions[$from] ?? [];
        return is_array($targets) ? array_values(array_map('strval', $targets)) : [];
    }

    public static function assertFormalPublishAllowed(ReviewStatus $reviewStatus): void
    {
        $allowed = self::definition()['review']['formal_publish_allowed'] ?? [];
        if (!in_array($reviewStatus->value, $allowed, true)) {
            throw new DomainException("Review status cannot enter formal RAG: {$reviewStatus->value}");
        }
    }

    public static function assertFormalRagTransitionAllowed(
        ReviewStatus $reviewStatus,
        RagStatus $from,
        RagStatus $to,
    ): void {
        self::assertFormalPublishAllowed($reviewStatus);
        self::assertAllowed('rag', $from->value, $to->value);
    }

    public static function assertRagReadyAllowed(
        ReviewStatus $reviewStatus,
        RagStatus $from,
        RagStatus $to,
        bool $hasSuccessfulSnapshot,
    ): void {
        self::assertFormalRagTransitionAllowed($reviewStatus, $from, $to);
        if ($to !== RagStatus::Ready) {
            return;
        }

        if (!$hasSuccessfulSnapshot) {
            throw new DomainException('RAG ready requires a successful technical snapshot.');
        }
    }

    /** @return array<string, mixed> */
    private static function definition(): array
    {
        if (self::$definition !== null) {
            return self::$definition;
        }

        $path = __DIR__ . '/state-machines.json';
        $json = file_get_contents($path);
        if ($json === false) {
            throw new RuntimeException('State machine definition is unavailable.');
        }

        try {
            self::$definition = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $exception) {
            throw new RuntimeException('State machine definition is invalid.', 0, $exception);
        }

        return self::$definition;
    }
}

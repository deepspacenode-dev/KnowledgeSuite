<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Domain;

enum ActionResult: string
{
    case Created = 'created';
    case Skipped = 'skipped';
    case Updated = 'updated';
    case Moved = 'moved';
    case Failed = 'failed';
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Domain;

enum ReviewStatus: string
{
    case Draft = 'draft';
    case PendingReview = 'pending_review';
    case Reviewed = 'reviewed';
    case Verified = 'verified';
    case NeedFix = 'need_fix';
    case NeedRecheck = 'need_recheck';
    case Deprecated = 'deprecated';
}

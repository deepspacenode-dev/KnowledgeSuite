<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Domain;

enum CompileStatus: string
{
    case Queued = 'queued';
    case Running = 'running';
    case Succeeded = 'succeeded';
    case RetryWait = 'retry_wait';
    case Failed = 'failed';
}

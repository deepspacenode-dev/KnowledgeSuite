<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Domain;

enum RagStatus: string
{
    case NotIngested = 'not_ingested';
    case Queued = 'queued';
    case Parsing = 'parsing';
    case Ready = 'ready';
    case Stale = 'stale';
    case Failed = 'failed';
    case Disabled = 'disabled';
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Domain;

enum AssetType: string
{
    case Source = 'source';
    case Wiki = 'wiki';
}

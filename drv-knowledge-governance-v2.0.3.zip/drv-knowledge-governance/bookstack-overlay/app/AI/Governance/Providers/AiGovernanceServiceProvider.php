<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Providers;

use BookStack\AI\Governance\Infrastructure\BookStack\GovernanceHeadContentProvider;
use BookStack\Theming\CustomHtmlHeadContentProvider;
use Illuminate\Support\ServiceProvider;

final class AiGovernanceServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(CustomHtmlHeadContentProvider::class, GovernanceHeadContentProvider::class);
    }

    public function boot(): void
    {
        $this->loadRoutesFrom(base_path('routes/ai-governance.php'));
        $this->loadRoutesFrom(base_path('routes/ai-governance-page.php'));
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\Persistence;

use Illuminate\Support\Facades\DB;
use JsonException;

final class AuditEventRepository
{
    /** @param array<string, mixed> $event */
    public function append(array $event): int
    {
        $metadata = $event['metadata_json'] ?? [];
        if (is_string($metadata)) {
            try {
                $metadata = json_decode($metadata, true, 64, JSON_THROW_ON_ERROR);
            } catch (JsonException) {
                $metadata = ['invalid_metadata' => '[REDACTED]'];
            }
        }
        $event['metadata_json'] = json_encode(
            $this->sanitizeMetadata($metadata),
            JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES,
        );

        $allowedColumns = array_flip([
            'trace_id', 'event_type', 'object_type', 'object_id', 'actor_id',
            'before_digest', 'after_digest', 'metadata_json', 'dispatch_status',
        ]);
        $event = array_intersect_key($event, $allowedColumns);

        return (int) DB::table('drv_kb_audit_events')->insertGetId($event + [
            'created_at' => now(),
        ], 'audit_event_id');
    }

    public function markDispatched(int $eventId): bool
    {
        return DB::table('drv_kb_audit_events')->where('audit_event_id', $eventId)->update([
            'dispatch_status' => 'dispatched',
        ]) === 1;
    }

    /** @return array<int, object> */
    public function pendingPublishEvents(int $limit = 50): array
    {
        return DB::table('drv_kb_audit_events')
            ->where('event_type', 'wiki.publish.requested')
            ->where('dispatch_status', 'pending')
            ->orderBy('created_at')
            ->limit(min(100, max(1, $limit)))
            ->get()
            ->all();
    }

    /** @return mixed */
    private function sanitizeMetadata(mixed $value): mixed
    {
        if (is_object($value)) {
            $value = get_object_vars($value);
        }
        if (!is_array($value)) {
            return $value;
        }

        $sensitiveKeys = [
            'authorization', 'cookie', 'token', 'api_key', 'apikey', 'secret',
            'password', 'content', 'markdown', 'body', 'prompt',
        ];
        $sanitized = [];
        foreach ($value as $key => $item) {
            $normalizedKey = strtolower((string) $key);
            $sanitized[$key] = in_array($normalizedKey, $sensitiveKeys, true)
                ? '[REDACTED]'
                : $this->sanitizeMetadata($item);
        }

        return $sanitized;
    }
}

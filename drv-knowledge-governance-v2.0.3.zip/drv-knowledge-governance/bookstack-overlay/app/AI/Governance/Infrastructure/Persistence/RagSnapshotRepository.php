<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\Persistence;

use Illuminate\Support\Facades\DB;

final class RagSnapshotRepository
{
    /** @param array<string, mixed> $snapshot */
    public function record(array $snapshot): void
    {
        DB::transaction(function () use ($snapshot): void {
            $identity = [
                'asset_id' => $snapshot['asset_id'],
                'dataset_id' => $snapshot['dataset_id'],
                'document_id' => $snapshot['document_id'],
            ];
            DB::table('drv_kb_rag_snapshot')->updateOrInsert($identity, $snapshot + [
                'checked_at' => now(),
            ]);
        });
    }

    public function latestForAsset(int $assetId): ?object
    {
        return DB::table('drv_kb_rag_snapshot')
            ->where('asset_id', $assetId)
            ->orderByDesc('checked_at')
            ->orderByDesc('rag_snapshot_id')
            ->first();
    }
}

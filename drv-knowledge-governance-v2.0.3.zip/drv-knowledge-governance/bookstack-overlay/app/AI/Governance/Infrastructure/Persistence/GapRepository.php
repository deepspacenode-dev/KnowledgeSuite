<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\Persistence;

use Illuminate\Support\Facades\DB;

final class GapRepository
{
    public function findById(int $gapId): ?object
    {
        return DB::table('drv_kb_gaps')->where('gap_id', $gapId)->first();
    }

    /** @param array<string, mixed> $gap */
    public function create(array $gap): int
    {
        $now = now();
        return (int) DB::table('drv_kb_gaps')->insertGetId($gap + [
            'created_at' => $now,
            'updated_at' => $now,
        ], 'gap_id');
    }

    /** @param array<string, mixed> $changes */
    public function update(int $gapId, array $changes): bool
    {
        return DB::table('drv_kb_gaps')->where('gap_id', $gapId)->update(
            $changes + ['updated_at' => now()],
        ) === 1;
    }

    public function delete(int $gapId): bool
    {
        return DB::table('drv_kb_gaps')->where('gap_id', $gapId)->delete() === 1;
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\Persistence;

use DateTimeImmutable;
use Illuminate\Support\Facades\DB;

final class CompileTaskRepository
{
    /** @param array<string, mixed> $task */
    public function enqueue(array $task): int
    {
        return DB::transaction(function () use ($task): int {
            $existing = DB::table('drv_kb_compile_tasks')
                ->where('idempotency_key', $task['idempotency_key'])
                ->lockForUpdate()
                ->value('task_id');
            if (is_numeric($existing)) {
                return (int) $existing;
            }

            return (int) DB::table('drv_kb_compile_tasks')->insertGetId($task + [
                'task_status' => 'queued',
                'retry_count' => 0,
                'created_at' => now(),
            ], 'task_id');
        });
    }

    public function claimNext(
        string $worker,
        int $leaseSeconds,
        int $retryDelaySeconds = 30,
        int $maxRetries = 3,
    ): ?object
    {
        return DB::transaction(function () use ($worker, $leaseSeconds, $retryDelaySeconds, $maxRetries): ?object {
            $now = new DateTimeImmutable('now');

            $readyForRetry = DB::table('drv_kb_compile_tasks')
                ->where('task_status', 'retry_wait')
                ->where('lease_expires_at', '<=', $now)
                ->lockForUpdate()
                ->get();
            foreach ($readyForRetry as $retryTask) {
                DB::table('drv_kb_compile_tasks')->where('task_id', $retryTask->task_id)->update([
                    'task_status' => 'queued',
                    'lease_owner' => null,
                    'lease_expires_at' => null,
                ]);
            }

            $expiredRunning = DB::table('drv_kb_compile_tasks')
                ->where('task_status', 'running')
                ->where('lease_expires_at', '<=', $now)
                ->lockForUpdate()
                ->get();
            foreach ($expiredRunning as $expiredTask) {
                $retryCount = (int) $expiredTask->retry_count + 1;
                $failed = $retryCount >= $maxRetries;
                DB::table('drv_kb_compile_tasks')->where('task_id', $expiredTask->task_id)->update([
                    'task_status' => $failed ? 'failed' : 'retry_wait',
                    'retry_count' => $retryCount,
                    'lease_owner' => null,
                    'lease_expires_at' => $failed ? null : $now->modify("+{$retryDelaySeconds} seconds"),
                    'finished_at' => $failed ? $now : null,
                    'error_code' => $failed ? 'TASK_LEASE_EXHAUSTED' : 'TASK_LEASE_EXPIRED',
                ]);
            }

            $task = DB::table('drv_kb_compile_tasks')
                ->where('task_status', 'queued')
                ->orderBy('created_at')
                ->lockForUpdate()
                ->first();
            if ($task === null) {
                return null;
            }

            DB::table('drv_kb_compile_tasks')->where('task_id', $task->task_id)->update([
                'task_status' => 'running',
                'lease_owner' => $worker,
                'lease_expires_at' => $now->modify("+{$leaseSeconds} seconds"),
                'started_at' => $task->started_at ?? $now,
            ]);

            return DB::table('drv_kb_compile_tasks')->where('task_id', $task->task_id)->first();
        });
    }

    public function find(int $taskId): ?object
    {
        return DB::table('drv_kb_compile_tasks')->where('task_id', $taskId)->first();
    }

    public function latestForSource(int $sourceAssetId): ?object
    {
        return DB::table('drv_kb_compile_tasks')
            ->where('source_asset_id', $sourceAssetId)
            ->orderByDesc('created_at')
            ->orderByDesc('task_id')
            ->first();
    }

    public function heartbeat(int $taskId, string $worker, int $leaseSeconds): bool
    {
        return DB::table('drv_kb_compile_tasks')
            ->where('task_id', $taskId)
            ->where('task_status', 'running')
            ->where('lease_owner', $worker)
            ->where('lease_expires_at', '>', new DateTimeImmutable('now'))
            ->update(['lease_expires_at' => (new DateTimeImmutable('now'))->modify("+{$leaseSeconds} seconds")]) === 1;
    }

    public function complete(int $taskId, string $worker): bool
    {
        return DB::table('drv_kb_compile_tasks')
            ->where('task_id', $taskId)
            ->where('task_status', 'running')
            ->where('lease_owner', $worker)
            ->where('lease_expires_at', '>', new DateTimeImmutable('now'))
            ->update([
                'task_status' => 'succeeded',
                'lease_owner' => null,
                'lease_expires_at' => null,
                'finished_at' => now(),
                'error_code' => null,
                'error_detail' => null,
            ]) === 1;
    }
}

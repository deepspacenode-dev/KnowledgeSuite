<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\Persistence;

use Illuminate\Support\Facades\DB;

final class IntakeRepository
{
    public function findBySubmissionId(string $submissionId, bool $lock = false): ?object
    {
        $query = DB::table('drv_kb_intakes')->where('client_submission_id', $submissionId);
        return ($lock ? $query->lockForUpdate() : $query)->first();
    }

    public function find(int $intakeId): ?object
    {
        return DB::table('drv_kb_intakes as intakes')
            ->leftJoin('drv_kb_compile_tasks as tasks', 'tasks.task_id', '=', 'intakes.compile_task_id')
            ->where('intakes.intake_id', $intakeId)
            ->select('intakes.*', 'tasks.task_status as current_compile_status')
            ->first();
    }

    /** @param array<string, mixed> $attributes */
    public function create(array $attributes): int
    {
        return (int) DB::table('drv_kb_intakes')->insertGetId($attributes + [
            'created_at' => now(),
            'updated_at' => now(),
        ], 'intake_id');
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\Persistence;

use BookStack\AI\Governance\Domain\AssetType;
use Illuminate\Support\Facades\DB;
use RuntimeException;

final class AssetRepository
{
    /** @param array<string, mixed> $attributes */
    public function upsert(array $attributes): int
    {
        foreach (['source_key', 'asset_type', 'title', 'content_hash'] as $required) {
            if (!array_key_exists($required, $attributes)) {
                throw new RuntimeException("Missing asset attribute: {$required}");
            }
        }

        return DB::transaction(function () use ($attributes): int {
            $this->assertValidParent($attributes);
            $identity = [
                'source_key' => $attributes['source_key'],
                'asset_type' => $attributes['asset_type'],
            ];
            $now = now();
            $existing = DB::table('drv_kb_assets')->where($identity)->lockForUpdate()->first();
            if ($existing === null) {
                return (int) DB::table('drv_kb_assets')->insertGetId($attributes + [
                    'created_at' => $now,
                    'updated_at' => $now,
                ], 'asset_id');
            }

            unset($attributes['asset_id'], $attributes['created_at']);
            DB::table('drv_kb_assets')->where('asset_id', $existing->asset_id)->update(
                $attributes + ['updated_at' => $now],
            );

            return (int) $existing->asset_id;
        });
    }

    public function findById(int $assetId): ?object
    {
        return DB::table('drv_kb_assets')->where('asset_id', $assetId)->first();
    }

    public function findBySourceKey(string $sourceKey, string $assetType): ?object
    {
        return DB::table('drv_kb_assets')
            ->where('source_key', $sourceKey)
            ->where('asset_type', $assetType)
            ->first();
    }

    /** @param array<string, mixed> $attributes */
    private function assertValidParent(array $attributes): void
    {
        $assetType = AssetType::tryFrom((string) $attributes['asset_type']);
        if ($assetType === null) {
            throw new RuntimeException('Unsupported asset_type.');
        }

        $parentId = $attributes['parent_asset_id'] ?? null;
        if ($assetType === AssetType::Source) {
            if ($parentId !== null) {
                throw new RuntimeException('Source assets cannot have a parent asset.');
            }
            return;
        }

        if (!is_numeric($parentId) || (int) $parentId < 1) {
            throw new RuntimeException('Wiki assets require a source parent.');
        }

        $isSource = DB::table('drv_kb_assets')
            ->where('asset_id', (int) $parentId)
            ->where('asset_type', AssetType::Source->value)
            ->exists();
        if (!$isSource) {
            throw new RuntimeException('Wiki parent must reference a source asset.');
        }
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\Persistence;

use Illuminate\Support\Facades\DB;

final class QualityCheckRepository
{
    /** @param array<string, mixed> $check */
    public function record(array $check): int
    {
        return (int) DB::table('drv_kb_quality_checks')->insertGetId($check + [
            'checked_at' => now(),
        ], 'quality_check_id');
    }

    public function latestForAsset(int $assetId): ?object
    {
        return DB::table('drv_kb_quality_checks')
            ->where('asset_id', $assetId)
            ->orderByDesc('checked_at')
            ->first();
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\Persistence;

use Illuminate\Support\Facades\DB;

final class ReportRepository
{
    /** @param array<string, mixed> $report */
    public function store(array $report): int
    {
        return (int) DB::table('drv_kb_reports')->insertGetId($report + [
            'generated_at' => now(),
        ], 'report_id');
    }

    public function find(int $reportId): ?object
    {
        return DB::table('drv_kb_reports')->where('report_id', $reportId)->first();
    }
}

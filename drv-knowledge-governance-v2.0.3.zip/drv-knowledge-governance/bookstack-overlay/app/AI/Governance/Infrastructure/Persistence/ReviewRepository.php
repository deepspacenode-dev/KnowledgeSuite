<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\Persistence;

use Illuminate\Support\Facades\DB;

final class ReviewRepository
{
    /** @param array<string, mixed> $review */
    public function append(array $review): int
    {
        return DB::transaction(function () use ($review): int {
            DB::table('drv_kb_assets')
                ->where('asset_id', $review['asset_id'])
                ->lockForUpdate()
                ->first();

            return (int) DB::table('drv_kb_reviews')->insertGetId($review + [
                'created_at' => now(),
            ], 'review_id');
        });
    }

    public function latestForAsset(int $assetId): ?object
    {
        return DB::table('drv_kb_reviews')
            ->where('asset_id', $assetId)
            ->orderByDesc('created_at')
            ->orderByDesc('review_id')
            ->first();
    }
}

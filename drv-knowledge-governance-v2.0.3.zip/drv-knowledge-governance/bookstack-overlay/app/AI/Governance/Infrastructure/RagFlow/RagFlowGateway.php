<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\RagFlow;

use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;
use RuntimeException;

final class RagFlowGateway
{
    private const REFERENCE_METADATA_FIELDS = [
        'page_id', 'page_url', 'source_key', 'content_ref', 'title', 'material_type',
        'status', 'module', 'platform', 'chip', 'project',
    ];

    public function __construct(
        private readonly ?string $baseUrl = null,
        private readonly ?string $apiKey = null,
    ) {
    }

    public function deleteDocument(string $datasetId, string $documentId): void
    {
        $this->deleteDocuments($datasetId, [$documentId]);
    }

    /** @return array{version: string, response: mixed} */
    public function probeVersion(): array
    {
        $path = (string) env('RAGFLOW_VERSION_PATH', '/api/v1/system/version');
        $response = $this->client()->get($this->baseUrl() . '/' . ltrim($path, '/'));
        if (!$response->successful()) {
            throw new RuntimeException($this->redact('RAGFlow version probe failed with status ' . $response->status()));
        }
        $data = $response->json();
        $version = is_array($data)
            ? ($data['data']['version'] ?? $data['version'] ?? $data['data']['tag'] ?? $data['tag'] ?? null)
            : null;
        if (!is_string($version) || trim($version) === '') {
            throw new RuntimeException('RAGFlow version response is unsupported.');
        }
        return ['version' => trim($version), 'response' => $data];
    }

    /** @return array{document_id: string, parse_status: string, chunk_count: ?int, response: mixed} */
    public function documentStatus(string $datasetId, string $documentId): array
    {
        if (trim($datasetId) === '' || trim($documentId) === '') {
            throw new RuntimeException('RAG document identity is required.');
        }
        $response = $this->client()->get($this->datasetUrl($datasetId) . '/documents', [
            'id' => $documentId,
            'page' => 1,
            'page_size' => 1,
        ]);
        if (!$response->successful()) {
            throw new RuntimeException($this->redact('RAG document status failed with status ' . $response->status()));
        }
        $data = $response->json();
        $document = is_array($data)
            ? ($data['data']['docs'][0] ?? $data['data'][0] ?? $data['data'] ?? $data['document'] ?? null)
            : null;
        $rawStatus = is_array($document) ? ($document['run'] ?? $document['status'] ?? $document['parse_status'] ?? null) : null;
        $rawChunkCount = is_array($document)
            ? ($document['chunk_count'] ?? $document['chunk_num'] ?? $document['chunk_count_num'] ?? null)
            : null;
        return [
            'document_id' => $documentId,
            'parse_status' => $this->normalizeParseStatus($rawStatus),
            'chunk_count' => is_numeric($rawChunkCount) ? max(0, (int) $rawChunkCount) : null,
            'response' => $data,
        ];
    }

    public function normalizeParseStatus(mixed $status): string
    {
        return match (strtolower(trim((string) $status))) {
            '0', 'unstart', 'unstarted', 'queued', 'pending' => 'queued',
            '1', 'running', 'parsing', 'processing' => 'parsing',
            '2', 'done', 'success', 'succeeded', 'parsed', 'ready' => 'ready',
            '3', 'fail', 'failed', 'error', 'cancelled' => 'failed',
            default => 'failed',
        };
    }

    /** @param array<int, string> $documentIds */
    public function deleteDocuments(string $datasetId, array $documentIds): void
    {
        $documentIds = array_values(array_filter(array_map('trim', $documentIds)));
        if (trim($datasetId) === '' || $documentIds === []) {
            throw new RuntimeException('RAG document identity is required.');
        }
        $response = $this->client()->delete($this->datasetUrl($datasetId) . '/documents', [
            'ids' => $documentIds,
        ]);
        $this->assertApiSuccess($response->successful(), $response->status(), $response->json(), 'RAG delete');
    }

    /** @return array<string, mixed> */
    public function uploadDocument(string $datasetId, string $filename, string $markdown): array
    {
        if (trim($datasetId) === '' || trim($markdown) === '') {
            throw new RuntimeException('RAG dataset and Markdown are required.');
        }
        $response = $this->client()
            ->attach('file', $markdown, $filename)
            ->post($this->datasetUrl($datasetId) . '/documents');
        if (!$response->successful()) {
            throw new RuntimeException($this->redact('RAG upload failed with status ' . $response->status()));
        }
        $data = $response->json();
        $documentId = $this->documentId($data);

        return ['document_id' => $documentId, 'response' => $data];
    }

    /** @return array<string, mixed> */
    public function uploadBinary(string $datasetId, string $filename, string $bytes, string $mime): array
    {
        if (trim($datasetId) === '' || trim($filename) === '' || $bytes === '') {
            throw new RuntimeException('RAG dataset and image bytes are required.');
        }
        $response = $this->client()
            ->attach('file', $bytes, $filename, ['Content-Type' => $mime])
            ->post($this->datasetUrl($datasetId) . '/documents');
        if (!$response->successful()) {
            throw new RuntimeException($this->redact('RAG image upload failed with status ' . $response->status()));
        }
        $data = $response->json();

        return ['document_id' => $this->documentId($data), 'response' => $data];
    }

    /** @param array<string, mixed> $metadata @param array<string, mixed> $parserConfig */
    public function configureDocument(
        string $datasetId,
        string $documentId,
        array $metadata,
        string $chunkMethod = 'naive',
        array $parserConfig = [],
    ): void {
        if (trim($datasetId) === '' || trim($documentId) === '' || $metadata === []) {
            throw new RuntimeException('RAG document identity and metadata are required.');
        }
        $response = $this->client()->patch(
            $this->datasetUrl($datasetId) . '/documents/' . rawurlencode($documentId),
            [
                'meta_fields' => $metadata,
                'chunk_method' => $chunkMethod,
                'parser_config' => $parserConfig,
            ],
        );
        $this->assertApiSuccess($response->successful(), $response->status(), $response->json(), 'RAG document configuration');
    }

    /** @param array<int, string> $documentIds */
    public function startParsing(string $datasetId, array $documentIds): void
    {
        $documentIds = array_values(array_unique(array_filter(array_map('trim', $documentIds))));
        if (trim($datasetId) === '' || $documentIds === []) {
            throw new RuntimeException('RAG document identity is required.');
        }
        $response = $this->client()->post($this->datasetUrl($datasetId) . '/chunks', [
            'document_ids' => $documentIds,
        ]);
        $this->assertApiSuccess($response->successful(), $response->status(), $response->json(), 'RAG parse start');
    }

    /** @param array<string, mixed> $pageContext @return array<string, mixed> */
    public function chatCompletion(string $question, ?string $sessionId = null, array $pageContext = []): array
    {
        $chatId = trim((string) env('RAGFLOW_CHAT_ID', ''));
        if ($chatId === '' || trim($question) === '') {
            throw new RuntimeException('RAGFlow chat is not configured.');
        }
        $contextLines = [];
        if (!empty($pageContext['page_id'])) {
            $contextLines[] = '当前 BookStack 页面 ID：' . (int) $pageContext['page_id'];
        }
        if (!empty($pageContext['page_url']) && $this->isAllowedBookStackUrl((string) $pageContext['page_url'])) {
            $contextLines[] = '当前 BookStack 页面：' . (string) $pageContext['page_url'];
        }
        $scopedQuestion = $contextLines === []
            ? trim($question)
            : implode("\n", $contextLines) . "\n用户问题：" . trim($question);
        $request = [
            'chat_id' => $chatId,
            'question' => $scopedQuestion,
            'stream' => false,
            'pass_all_history_messages' => false,
            'reference_metadata' => [
                'include' => true,
                'fields' => self::REFERENCE_METADATA_FIELDS,
            ],
        ];
        if ($sessionId !== null && trim($sessionId) !== '') {
            $request['session_id'] = trim($sessionId);
        }
        $timeout = max(30, min((int) env('RAGFLOW_CHAT_TIMEOUT_SECONDS', 120), 300));
        $response = $this->chatClient()->timeout($timeout)->post($this->chatBaseUrl() . '/api/v1/chat/completions', $request);
        $payload = $response->json();
        $this->assertApiSuccess($response->successful(), $response->status(), $payload, 'RAGFlow chat completion');
        $data = is_array($payload) ? ($payload['data'] ?? null) : null;
        if (!is_array($data) || !is_string($data['answer'] ?? null)) {
            throw new RuntimeException('RAGFlow chat response is unsupported.');
        }
        return [
            'answer' => trim((string) $data['answer']),
            'session_id' => trim((string) ($data['session_id'] ?? '')),
            'chat_id' => $chatId,
            'references' => $this->normalizeChatReferences($data['reference']['chunks'] ?? []),
        ];
    }

    private function documentId(mixed $data): string
    {
        $documentId = is_array($data) ? ($data['data'][0]['id'] ?? $data['data']['id'] ?? $data['id'] ?? null) : null;
        if (!is_string($documentId) || $documentId === '') {
            throw new RuntimeException('RAG upload response did not contain a document ID.');
        }
        return $documentId;
    }

    private function assertApiSuccess(bool $httpSuccessful, int $status, mixed $payload, string $operation): void
    {
        $code = is_array($payload) ? ($payload['code'] ?? 0) : 0;
        if (!$httpSuccessful || !in_array($code, [0, null], true)) {
            $message = is_array($payload) ? (string) ($payload['message'] ?? '') : '';
            throw new RuntimeException($this->redact("{$operation} failed with status {$status}; code={$code}; {$message}"));
        }
    }

    /** @return array<int, array<string, string>> */
    private function normalizeChatReferences(mixed $chunks): array
    {
        if (!is_array($chunks)) {
            return [];
        }
        $references = [];
        foreach ($chunks as $chunk) {
            if (!is_array($chunk)) {
                continue;
            }
            $metadata = [];
            foreach (['metadata', 'document_metadata', 'meta_fields'] as $field) {
                if (is_array($chunk[$field] ?? null)) {
                    $metadata = array_merge($metadata, $chunk[$field]);
                }
            }
            $pageUrl = trim((string) ($metadata['page_url'] ?? $metadata['source_url'] ?? $chunk['page_url'] ?? $chunk['source_url'] ?? ''));
            if (!$this->isAllowedBookStackUrl($pageUrl)) {
                $pageUrl = '';
            }
            $references[] = [
                'title' => trim((string) ($metadata['title'] ?? $chunk['document_keyword'] ?? $chunk['document_name'] ?? '知识库原文')),
                'page_url' => $pageUrl,
                'page_id' => trim((string) ($metadata['page_id'] ?? $metadata['bookstack_page_id'] ?? '')),
                'source_key' => trim((string) ($metadata['source_key'] ?? '')),
                'document_id' => trim((string) ($chunk['document_id'] ?? $chunk['doc_id'] ?? '')),
                'chunk_id' => trim((string) ($chunk['id'] ?? $chunk['chunk_id'] ?? '')),
            ];
        }
        return array_values($references);
    }

    private function isAllowedBookStackUrl(string $url): bool
    {
        if ($url === '' || filter_var($url, FILTER_VALIDATE_URL) === false) {
            return false;
        }
        $candidate = parse_url($url);
        if (!is_array($candidate)
            || !isset($candidate['host'])
            || isset($candidate['user'])
            || isset($candidate['pass'])
            || !str_contains((string) ($candidate['path'] ?? ''), '/books/')
        ) {
            return false;
        }
        $origins = array_filter(array_map('trim', array_merge([
            (string) env('BOOKSTACK_PUBLIC_URL', ''),
            (string) env('BOOKSTACK_URL', ''),
            (string) config('app.url', ''),
        ], explode(',', (string) env('BOOKSTACK_URL_ALIASES', '')))));
        foreach ($origins as $origin) {
            $expected = parse_url($origin);
            if (!is_array($expected) || !isset($expected['host'])) {
                continue;
            }
            $candidatePort = (int) ($candidate['port'] ?? (strtolower((string) ($candidate['scheme'] ?? '')) === 'https' ? 443 : 80));
            $expectedPort = (int) ($expected['port'] ?? (strtolower((string) ($expected['scheme'] ?? '')) === 'https' ? 443 : 80));
            if (strtolower((string) $candidate['host']) === strtolower((string) $expected['host'])
                && $candidatePort === $expectedPort
            ) {
                return true;
            }
        }
        return false;
    }

    private function client(): PendingRequest
    {
        $key = $this->apiKey ?? (string) env('RAGFLOW_API_KEY', '');
        if ($key === '') {
            throw new RuntimeException('RAGFlow is not configured.');
        }
        return Http::withToken($key)->acceptJson()->timeout(60);
    }

    private function chatClient(): PendingRequest
    {
        $key = trim((string) env('RAGFLOW_CHAT_API_KEY', ''));
        if ($key === '') {
            $key = $this->apiKey ?? trim((string) env('RAGFLOW_API_KEY', ''));
        }
        if ($key === '') {
            throw new RuntimeException('RAGFlow chat is not configured.');
        }

        return Http::withToken($key)->acceptJson()->timeout(60);
    }

    private function datasetUrl(string $datasetId): string
    {
        return $this->baseUrl() . '/api/v1/datasets/' . rawurlencode($datasetId);
    }

    private function baseUrl(): string
    {
        $base = rtrim($this->baseUrl ?? (string) env('RAGFLOW_BASE_URL', ''), '/');
        if ($base === '') {
            throw new RuntimeException('RAGFlow is not configured.');
        }
        return $base;
    }

    private function chatBaseUrl(): string
    {
        $base = rtrim(trim((string) env('RAGFLOW_CHAT_BASE_URL', '')), '/');

        return $base !== '' ? $base : $this->baseUrl();
    }

    private function redact(string $message): string
    {
        $keys = array_values(array_unique(array_filter([
            $this->apiKey,
            trim((string) env('RAGFLOW_API_KEY', '')),
            trim((string) env('RAGFLOW_CHAT_API_KEY', '')),
        ], static fn (?string $key): bool => $key !== null && $key !== '')));

        return $keys === [] ? $message : str_replace($keys, '[REDACTED]', $message);
    }
}

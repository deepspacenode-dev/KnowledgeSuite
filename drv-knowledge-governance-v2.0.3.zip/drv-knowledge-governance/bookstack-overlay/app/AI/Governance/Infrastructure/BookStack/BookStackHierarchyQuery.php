<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\BookStack;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class BookStackHierarchyQuery
{
    public function __construct(private readonly ReadablePageQuery $readablePages)
    {
    }

    /** @return array<int, int> */
    public function visiblePageIds(): array
    {
        return array_values(array_unique($this->readablePages->visibleIds()));
    }

    /** @return array<int, int> */
    public function pageIdsForBookshelf(int|string|null $bookshelfId): array
    {
        $visibleIds = $this->visiblePageIds();
        if ($bookshelfId === null || $bookshelfId === '') {
            return $visibleIds;
        }

        $pages = $this->pageRecords($visibleIds);
        $bookByPage = [];
        foreach ($pages as $page) {
            $bookByPage[(int) ($page['id'] ?? 0)] = (int) ($page['book_id'] ?? 0);
        }

        $links = $this->bookshelfLinks(array_values(array_unique(array_filter($bookByPage))));
        $allowedBooks = [];
        if ((string) $bookshelfId === 'unassigned') {
            $linkedBooks = array_fill_keys(array_map(static fn (array $link): int => (int) $link['book_id'], $links), true);
            foreach ($bookByPage as $bookId) {
                if ($bookId > 0 && !isset($linkedBooks[$bookId])) {
                    $allowedBooks[$bookId] = true;
                }
            }
        } elseif (ctype_digit((string) $bookshelfId) && (int) $bookshelfId > 0) {
            foreach ($links as $link) {
                if ((int) $link['bookshelf_id'] === (int) $bookshelfId) {
                    $allowedBooks[(int) $link['book_id']] = true;
                }
            }
        } else {
            return [];
        }

        return array_values(array_unique(array_map(
            'intval',
            array_keys(array_filter($bookByPage, static fn (int $bookId): bool => isset($allowedBooks[$bookId]))),
        )));
    }

    /** @return array<int, array{id: int|string, name: string, page_count: int}> */
    public function bookshelves(): array
    {
        $visibleIds = $this->visiblePageIds();
        $pages = $this->pageRecords($visibleIds);
        $bookByPage = [];
        foreach ($pages as $page) {
            $pageId = (int) ($page['id'] ?? 0);
            $bookByPage[$pageId] = (int) ($page['book_id'] ?? 0);
        }

        $bookIds = array_values(array_unique(array_filter($bookByPage)));
        $links = $this->bookshelfLinks($bookIds);
        $shelfNames = $this->bookshelfNames(array_values(array_unique(array_map(
            static fn (array $link): int => (int) $link['bookshelf_id'],
            $links,
        ))));
        $shelvesByBook = [];
        foreach ($links as $link) {
            $shelvesByBook[(int) $link['book_id']][] = (int) $link['bookshelf_id'];
        }

        $pageSets = [];
        foreach ($bookByPage as $pageId => $bookId) {
            $shelfIds = $shelvesByBook[$bookId] ?? [];
            if ($shelfIds === []) {
                $pageSets['unassigned'][$pageId] = true;
                continue;
            }
            foreach ($shelfIds as $shelfId) {
                $pageSets[(string) $shelfId][$pageId] = true;
            }
        }

        $items = [];
        foreach ($pageSets as $id => $pageSet) {
            $items[] = [
                'id' => $id === 'unassigned' ? 'unassigned' : (int) $id,
                'name' => $id === 'unassigned' ? '未归属书架' : (string) ($shelfNames[(int) $id] ?? '未命名书架'),
                'page_count' => count($pageSet),
            ];
        }
        usort($items, static fn (array $left, array $right): int => strcmp($left['name'], $right['name']));

        return $items;
    }

    /** @param array<int, int> $pageIds @return array<int, array<string, mixed>> */
    public function structure(array $pageIds = []): array
    {
        $visible = $this->visiblePageIds();
        $pageIds = $pageIds === [] ? $visible : array_values(array_intersect($visible, array_map('intval', $pageIds)));
        $pages = $this->pageRecords($pageIds);
        $bookIds = array_values(array_unique(array_filter(array_map(static fn (array $page): int => (int) ($page['book_id'] ?? 0), $pages))));
        $chapterIds = array_values(array_unique(array_filter(array_map(static fn (array $page): int => (int) ($page['chapter_id'] ?? 0), $pages))));
        $books = $this->bookRecords($bookIds);
        $chapters = $this->chapterRecords($chapterIds);
        $links = $this->bookshelfLinks($bookIds);
        $shelfNames = $this->bookshelfNames(array_values(array_unique(array_map(static fn (array $link): int => (int) $link['bookshelf_id'], $links))));
        $memberships = [];
        foreach ($links as $link) {
            $shelfId = (int) $link['bookshelf_id'];
            $memberships[(int) $link['book_id']][] = [
                'bookshelf_id' => $shelfId,
                'bookshelf_name' => (string) ($shelfNames[$shelfId] ?? '未命名书架'),
            ];
        }

        $result = [];
        foreach ($pages as $page) {
            $pageId = (int) ($page['id'] ?? 0);
            $bookId = (int) ($page['book_id'] ?? 0);
            $chapterId = (int) ($page['chapter_id'] ?? 0);
            $pageMemberships = $memberships[$bookId] ?? [['bookshelf_id' => null, 'bookshelf_name' => '未归属书架']];
            $result[$pageId] = [
                'page_id' => $pageId,
                'page_name' => (string) ($page['name'] ?? '未命名页面'),
                'page_slug' => $page['slug'] ?? null,
                'page_url' => $this->pageUrl($books[$bookId] ?? [], $page),
                'book_id' => $bookId ?: null,
                'book_name' => (string) ($books[$bookId]['name'] ?? '未归属书籍'),
                'book_slug' => $books[$bookId]['slug'] ?? null,
                'chapter_id' => $chapterId ?: null,
                'chapter_name' => $chapterId > 0 ? (string) ($chapters[$chapterId]['name'] ?? '未命名章节') : '书籍直属页面',
                'chapter_slug' => $chapterId > 0 ? ($chapters[$chapterId]['slug'] ?? null) : null,
                'chapter_url' => $chapterId > 0 ? $this->chapterUrl($books[$bookId] ?? [], $chapters[$chapterId] ?? []) : null,
                'direct_pages' => $chapterId <= 0,
                'bookshelf_id' => $pageMemberships[0]['bookshelf_id'],
                'bookshelf_name' => $pageMemberships[0]['bookshelf_name'],
                'bookshelf_memberships' => $pageMemberships,
                'updated_at' => $page['updated_at'] ?? null,
            ];
        }

        return $result;
    }

    /** @param array<string, mixed> $book @param array<string, mixed> $page */
    private function pageUrl(array $book, array $page): string
    {
        $bookSlug = trim((string) ($book['slug'] ?? ''));
        $pageSlug = trim((string) ($page['slug'] ?? ''));
        if ($bookSlug !== '' && $pageSlug !== '') {
            return '/books/' . rawurlencode($bookSlug) . '/page/' . rawurlencode($pageSlug);
        }

        return '/pages/' . (int) ($page['id'] ?? 0);
    }

    /** @param array<string, mixed> $book @param array<string, mixed> $chapter */
    private function chapterUrl(array $book, array $chapter): ?string
    {
        $bookSlug = trim((string) ($book['slug'] ?? ''));
        $chapterSlug = trim((string) ($chapter['slug'] ?? ''));
        if ($bookSlug === '' || $chapterSlug === '') {
            return null;
        }

        return '/books/' . rawurlencode($bookSlug) . '/chapter/' . rawurlencode($chapterSlug);
    }

    /** @param array<int, int> $ids @return array<int, array<string, mixed>> */
    private function pageRecords(array $ids): array
    {
        if ($ids === []) {
            return [];
        }
        if (Schema::hasTable('pages')) {
            return array_map(static fn (object $row): array => (array) $row, DB::table('pages')->whereIn('id', $ids)->get()->all());
        }
        if (Schema::hasTable('entities')) {
            return array_map(static fn (object $row): array => (array) $row, DB::table('entities')->where('type', 'page')->whereIn('id', $ids)->get()->all());
        }
        return [];
    }

    /** @param array<int, int> $ids @return array<int, array<string, mixed>> */
    private function bookRecords(array $ids): array
    {
        if ($ids === []) {
            return [];
        }
        $rows = Schema::hasTable('books')
            ? DB::table('books')->whereIn('id', $ids)->get()->all()
            : (Schema::hasTable('entities') ? DB::table('entities')->where('type', 'book')->whereIn('id', $ids)->get()->all() : []);
        $result = [];
        foreach ($rows as $row) {
            $data = (array) $row;
            $result[(int) $data['id']] = $data;
        }
        return $result;
    }

    /** @param array<int, int> $ids @return array<int, array<string, mixed>> */
    private function chapterRecords(array $ids): array
    {
        if ($ids === []) {
            return [];
        }
        $rows = Schema::hasTable('chapters')
            ? DB::table('chapters')->whereIn('id', $ids)->get()->all()
            : (Schema::hasTable('entities') ? DB::table('entities')->where('type', 'chapter')->whereIn('id', $ids)->get()->all() : []);
        $result = [];
        foreach ($rows as $row) {
            $data = (array) $row;
            $result[(int) $data['id']] = $data;
        }
        return $result;
    }

    /** @param array<int, int> $bookIds @return array<int, array{book_id: int, bookshelf_id: int}> */
    private function bookshelfLinks(array $bookIds): array
    {
        if ($bookIds === [] || !Schema::hasTable('bookshelves_books')) {
            return [];
        }
        return array_map(
            static fn (object $row): array => ['book_id' => (int) $row->book_id, 'bookshelf_id' => (int) $row->bookshelf_id],
            DB::table('bookshelves_books')->whereIn('book_id', $bookIds)->get()->all(),
        );
    }

    /** @param array<int, int> $ids @return array<int, string> */
    private function bookshelfNames(array $ids): array
    {
        if ($ids === []) {
            return [];
        }
        if (Schema::hasTable('bookshelves')) {
            return array_map('strval', DB::table('bookshelves')->whereIn('id', $ids)->pluck('name', 'id')->all());
        }
        if (Schema::hasTable('entities')) {
            return array_map('strval', DB::table('entities')->where('type', 'bookshelf')->whereIn('id', $ids)->pluck('name', 'id')->all());
        }
        return [];
    }
}

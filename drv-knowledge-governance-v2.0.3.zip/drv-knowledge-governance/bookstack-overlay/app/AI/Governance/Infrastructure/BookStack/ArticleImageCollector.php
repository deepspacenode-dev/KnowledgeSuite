<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\BookStack;

use Illuminate\Support\Facades\Http;
use RuntimeException;

final class ArticleImageCollector
{
    /** @return array<int, array<string, mixed>> */
    public function collect(string $markdown, string $sourceUrl): array
    {
        if (!$this->enabled()) {
            return [];
        }

        $references = [];
        preg_match_all('/!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/u', $markdown, $markdownImages, PREG_SET_ORDER);
        foreach ($markdownImages as $match) {
            $references[] = ['alt' => trim($match[1]), 'url' => trim($match[2])];
        }
        preg_match_all('/<img\s[^>]*src=["\']([^"\']+)["\'][^>]*>/iu', $markdown, $htmlImages, PREG_SET_ORDER);
        foreach ($htmlImages as $match) {
            preg_match('/alt=["\']([^"\']*)["\']/iu', $match[0], $alt);
            $references[] = ['alt' => trim($alt[1] ?? ''), 'url' => trim($match[1])];
        }

        $images = [];
        $seen = [];
        foreach ($references as $reference) {
            $url = $this->absoluteUrl($reference['url'], $sourceUrl);
            if ($url === '' || isset($seen[$url])) {
                continue;
            }
            $seen[$url] = true;
            if (!$this->sameOrigin($url, $this->bookStackBaseUrl())) {
                throw new RuntimeException('External article image URLs are not allowed.');
            }
            $images[] = $this->download($url, $reference['alt']);
        }

        return $images;
    }

    /** @return array<string, mixed> */
    private function download(string $url, string $alt): array
    {
        $path = (string) parse_url($url, PHP_URL_PATH);
        $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $allowed = $this->allowedExtensions();
        if ($extension !== '' && !in_array($extension, $allowed, true)) {
            throw new RuntimeException("Unsupported article image extension: {$extension}");
        }

        $headers = ['Accept' => 'image/*,*/*'];
        $tokenId = (string) env('BOOKSTACK_TOKEN_ID', '');
        $tokenSecret = (string) env('BOOKSTACK_TOKEN_SECRET', '');
        if ($tokenId !== '' && $tokenSecret !== '') {
            $headers['Authorization'] = "Token {$tokenId}:{$tokenSecret}";
        }
        $response = Http::withHeaders($headers)->withoutRedirecting()->timeout(60)->get($url);
        if (!$response->successful()) {
            throw new RuntimeException('Article image download failed with status ' . $response->status());
        }
        $bytes = $response->body();
        $maxBytes = max(1, (int) env('RAGFLOW_IMAGE_MAX_BYTES', 10 * 1024 * 1024));
        if ($bytes === '' || strlen($bytes) > $maxBytes) {
            throw new RuntimeException('Article image is empty or exceeds RAGFLOW_IMAGE_MAX_BYTES.');
        }

        $contentType = strtolower(trim(explode(';', $response->header('Content-Type', ''))[0]));
        if ($extension === '') {
            $extension = $this->extensionFromMime($contentType);
        }
        if ($extension === '' || !in_array($extension, $allowed, true)) {
            throw new RuntimeException("Unsupported article image content type: {$contentType}");
        }
        $hash = hash('sha256', $bytes);
        $stem = preg_replace('/[^A-Za-z0-9._-]+/', '-', $alt !== '' ? $alt : pathinfo($path, PATHINFO_FILENAME));
        $stem = trim((string) $stem, '-_.') ?: 'article-image';

        return [
            'url' => $url,
            'filename' => substr($stem, 0, 80) . '-' . substr($hash, 0, 12) . '.' . $extension,
            'mime' => $contentType !== '' ? $contentType : $this->mimeFromExtension($extension),
            'sha256' => $hash,
            'bytes' => $bytes,
            'size' => strlen($bytes),
        ];
    }

    private function absoluteUrl(string $reference, string $sourceUrl): string
    {
        $reference = trim(html_entity_decode($reference, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($reference === '' || preg_match('/^(?:data|cid|blob):/i', $reference)) {
            return '';
        }
        if (preg_match('/^https?:\/\//i', $reference)) {
            return $reference;
        }
        $base = rtrim($this->bookStackBaseUrl(), '/');
        if (str_starts_with($reference, '//')) {
            $scheme = (string) (parse_url($base, PHP_URL_SCHEME) ?: 'https');
            return $scheme . ':' . $reference;
        }
        if (str_starts_with($reference, '/')) {
            return $base . $reference;
        }
        if (preg_match('/^https?:\/\//i', $sourceUrl)) {
            $parts = parse_url($sourceUrl);
            $origin = ($parts['scheme'] ?? 'https') . '://' . ($parts['host'] ?? '');
            if (isset($parts['port'])) {
                $origin .= ':' . $parts['port'];
            }
            $directory = rtrim(str_replace('\\', '/', dirname((string) ($parts['path'] ?? '/'))), '/');
            return $origin . $directory . '/' . ltrim($reference, '/');
        }

        return $base . '/' . ltrim($reference, '/');
    }

    private function sameOrigin(string $url, string $base): bool
    {
        $left = parse_url($url);
        $right = parse_url($base);
        if (!is_array($left) || !is_array($right)) {
            return false;
        }
        $port = static fn (array $parts): int => (int) ($parts['port'] ?? (($parts['scheme'] ?? '') === 'https' ? 443 : 80));
        return strtolower((string) ($left['scheme'] ?? '')) === strtolower((string) ($right['scheme'] ?? ''))
            && strtolower((string) ($left['host'] ?? '')) === strtolower((string) ($right['host'] ?? ''))
            && $port($left) === $port($right);
    }

    /** @return array<int, string> */
    private function allowedExtensions(): array
    {
        $raw = strtolower((string) env('RAGFLOW_IMAGE_ALLOWED_EXTENSIONS', 'png,jpg,jpeg,webp,gif,svg,bmp'));
        return array_values(array_filter(array_map('trim', explode(',', $raw))));
    }

    private function extensionFromMime(string $mime): string
    {
        return ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/gif' => 'gif', 'image/svg+xml' => 'svg', 'image/bmp' => 'bmp'][$mime] ?? '';
    }

    private function mimeFromExtension(string $extension): string
    {
        return ['png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'webp' => 'image/webp', 'gif' => 'image/gif', 'svg' => 'image/svg+xml', 'bmp' => 'image/bmp'][$extension] ?? 'application/octet-stream';
    }

    private function bookStackBaseUrl(): string
    {
        $base = rtrim((string) env('BOOKSTACK_URL', (string) config('app.url', '')), '/');
        if ($base === '') {
            throw new RuntimeException('BOOKSTACK_URL or APP_URL is required for article images.');
        }
        return $base;
    }

    private function enabled(): bool
    {
        return filter_var(env('RAGFLOW_INGEST_IMAGES', true), FILTER_VALIDATE_BOOL);
    }
}

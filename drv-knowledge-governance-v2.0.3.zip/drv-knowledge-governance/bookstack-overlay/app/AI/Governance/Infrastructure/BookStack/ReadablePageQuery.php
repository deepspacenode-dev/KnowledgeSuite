<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\BookStack;

use Closure;
use RuntimeException;

final class ReadablePageQuery
{
    public function __construct(private readonly ?Closure $queryFactory = null)
    {
    }

    /** @return array{items: array<int, object>, total: int} */
    public function paginate(int $page, int $pageSize, ?string $search = null): array
    {
        $query = $this->applyVisibility($this->newQuery());
        if (is_string($search) && trim($search) !== '') {
            $query->where('name', 'like', '%' . trim($search) . '%');
        }
        $total = (int) $query->count();
        $items = $query->orderBy('id')->forPage(max(1, $page), min(100, max(1, $pageSize)))->get()->all();

        return ['items' => $items, 'total' => $total];
    }

    /** @return array<int, int> */
    public function visibleIds(): array
    {
        return array_map('intval', $this->applyVisibility($this->newQuery())->pluck('id')->all());
    }

    private function newQuery(): mixed
    {
        if ($this->queryFactory !== null) {
            return ($this->queryFactory)();
        }

        $modelClass = 'BookStack\\Entities\\Models\\Page';
        if (!class_exists($modelClass)) {
            throw new RuntimeException('BookStack Page model is unavailable.');
        }

        return (new $modelClass())->newQuery();
    }

    private function applyVisibility(mixed $query): mixed
    {
        if (!is_callable([$query, 'visible'])) {
            throw new RuntimeException('BookStack visible page scope is unavailable.');
        }

        return $query->visible();
    }
}

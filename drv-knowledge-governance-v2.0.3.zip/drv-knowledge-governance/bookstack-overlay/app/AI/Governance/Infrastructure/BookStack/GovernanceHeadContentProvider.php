<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\BookStack;

use BookStack\Theming\CustomHtmlHeadContentProvider;
use BookStack\Util\HtmlNonceApplicator;

final class GovernanceHeadContentProvider extends CustomHtmlHeadContentProvider
{
    private const STYLESHEET_PATHS = [
        '/ai-assistant/ai-assistant-governance-entry.css?v=20260908-v203-widget-v1',
        '/ai-assistant/vendor/bloub/bloub-avatar.css?v=20260905-bloub-v1',
    ];
    private const SCRIPT_PATHS = [
        '/ai-assistant/vendor/bloub/bloub-avatar.iife.js?v=20260905-bloub-v1',
        '/ai-assistant/ai-assistant-governance-entry.js?v=20260908-v203-widget-v1',
    ];

    public function forWeb(): string
    {
        $content = parent::forWeb();
        if (!auth()->check()) {
            return $content;
        }

        $assets = '';
        foreach (self::STYLESHEET_PATHS as $stylesheetPath) {
            $cssUrl = e(url($stylesheetPath));
            $assets .= ($assets === '' ? '' : "\n") . "<link rel=\"stylesheet\" href=\"{$cssUrl}\">";
        }
        foreach (self::SCRIPT_PATHS as $scriptPath) {
            $scriptUrl = e(url($scriptPath));
            $assets .= "\n<script defer src=\"{$scriptUrl}\"></script>";
        }
        $assets = HtmlNonceApplicator::prepare($assets);
        $assets = HtmlNonceApplicator::apply($assets, $this->cspService->getNonce());

        return $content . "\n" . $assets;
    }
}

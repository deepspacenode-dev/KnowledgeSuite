<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\BookStack;

use RuntimeException;

final class BookStackPageExporter
{
    /** @return array<string, mixed> */
    public function export(int $pageId): array
    {
        $modelClass = 'BookStack\\Entities\\Models\\Page';
        if (!class_exists($modelClass)) {
            throw new RuntimeException('BookStack Page model is unavailable.');
        }
        $page = (new $modelClass())->newQuery()->find($pageId);
        if ($page === null) {
            throw new RuntimeException('BookStack page not found.');
        }
        $markdown = (string) ($page->markdown ?? '');
        $url = method_exists($page, 'getUrl') ? (string) $page->getUrl() : url('/books/page/' . $pageId);
        $contentHash = hash('sha256', $markdown);
        $updatedAt = $page->updated_at instanceof \DateTimeInterface
            ? $page->updated_at->format(DATE_ATOM)
            : (string) ($page->updated_at ?? '');
        $tagRows = method_exists($page, 'tags')
            ? $page->tags()->get(['name', 'value'])->map(static fn ($tag): array => [
                'name' => (string) ($tag->name ?? ''),
                'value' => (string) ($tag->value ?? ''),
            ])->all()
            : [];
        $tags = array_values(array_filter(array_map(
            static fn (array $tag): string => trim((string) ($tag['value'] ?? '')),
            $tagRows,
        ), static fn (string $value): bool => $value !== ''));
        $domainMetadata = self::domainMetadata($tagRows, $page->owned_by ?? null);
        $governanceHash = hash('sha256', json_encode([
            'markdown_hash' => $contentHash,
            'title' => (string) $page->name,
            'page_updated_at' => $updatedAt,
            'tags' => $tags,
            'domain_metadata' => $domainMetadata,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));

        return [
            'page_id' => (int) $page->id,
            'canonical_url' => $url,
            'title' => (string) $page->name,
            'markdown' => $markdown,
            'content_hash' => $contentHash,
            'governance_hash' => $governanceHash,
            'page_updated_at' => $updatedAt,
            'owner_id' => $page->owned_by ?? null,
            'hierarchy' => [],
            'tags' => $tags,
            'domain_metadata' => $domainMetadata,
        ];
    }

    /**
     * Convert trusted, named BookStack tags into the closed metadata set used by
     * strict RAGFlow filters. Free-form tag values remain available in `tags` but
     * can never introduce arbitrary filter fields.
     *
     * @param array<int, array{name?: mixed, value?: mixed}> $tags
     * @return array{owner: ?string, module: ?string, platform: ?string, chip: ?string, project: ?string}
     */
    public static function domainMetadata(array $tags, mixed $ownerId): array
    {
        $aliases = [
            'owner' => ['owner', '负责人', '责任人'],
            'module' => ['module', '模块', '领域'],
            'platform' => ['platform', '平台', '系统'],
            'chip' => ['chip', '芯片', '型号'],
            'project' => ['project', '项目'],
        ];
        $metadata = [
            'owner' => is_numeric($ownerId) && (int) $ownerId > 0 ? 'user:' . (int) $ownerId : null,
            'module' => null,
            'platform' => null,
            'chip' => null,
            'project' => null,
        ];
        foreach ($tags as $tag) {
            $name = strtolower(trim((string) ($tag['name'] ?? '')));
            $value = strtolower(trim((string) ($tag['value'] ?? '')));
            if ($name === '' || $value === '') {
                continue;
            }
            foreach ($aliases as $field => $names) {
                if (in_array($name, $names, true) && ($field === 'owner' || $metadata[$field] === null)) {
                    $metadata[$field] = $value;
                    break;
                }
            }
        }
        return $metadata;
    }
}

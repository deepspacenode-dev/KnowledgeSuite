<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Infrastructure\BookStack;

use Illuminate\Auth\AuthenticationException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

final class BookStackIdentityAdapter
{
    public function user(): object
    {
        $user = auth()->user();
        if (!is_object($user)) {
            throw new AuthenticationException('BookStack login is required.');
        }

        return $user;
    }

    public function userId(): int
    {
        return (int) ($this->user()->id ?? 0);
    }

    public function isAdministrator(): bool
    {
        $user = $this->user();
        if (function_exists('userCan') && userCan('users-manage')) {
            return true;
        }
        if (method_exists($user, 'isAdmin')) {
            return (bool) $user->isAdmin();
        }

        return false;
    }

    public function requireAdministrator(): void
    {
        if (!$this->isAdministrator()) {
            throw new AccessDeniedHttpException('Administrator permission is required.');
        }
    }

    public function canReadPage(object $page): bool
    {
        if ($this->isAdministrator()) {
            return true;
        }
        return function_exists('userCan') && userCan('page-view', $page);
    }

    public function requireCanReadPage(int $pageId): void
    {
        $modelClass = 'BookStack\\Entities\\Models\\Page';
        $page = class_exists($modelClass) ? (new $modelClass())->newQuery()->find($pageId) : null;
        if (!is_object($page) || !$this->canReadPage($page)) {
            throw new AccessDeniedHttpException('Page access is denied.');
        }
    }
}

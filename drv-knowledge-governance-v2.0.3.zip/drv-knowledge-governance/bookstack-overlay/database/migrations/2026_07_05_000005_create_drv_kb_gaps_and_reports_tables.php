<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('drv_kb_gaps', function (Blueprint $table): void {
            $table->bigIncrements('gap_id');
            $table->foreignId('related_asset_id')->nullable()->constrained('drv_kb_assets', 'asset_id')->nullOnDelete();
            $table->string('title');
            $table->text('missing_content');
            $table->text('impact')->nullable();
            $table->string('priority', 16)->default('medium');
            $table->unsignedBigInteger('owner_id')->nullable();
            $table->string('gap_status', 16)->default('open');
            $table->timestamp('due_at')->nullable();
            $table->timestamp('closed_at')->nullable();
            $table->unsignedBigInteger('created_by');
            $table->timestamps();

            $table->index(['gap_status', 'due_at'], 'drv_kb_gaps_status_due_index');
            $table->index(['owner_id', 'gap_status'], 'drv_kb_gaps_owner_status_index');
        });

        Schema::create('drv_kb_reports', function (Blueprint $table): void {
            $table->bigIncrements('report_id');
            $table->string('report_type', 16);
            $table->date('period_start');
            $table->date('period_end');
            $table->json('filters_json')->nullable();
            $table->json('metrics_json');
            $table->longText('markdown');
            $table->char('markdown_hash', 64);
            $table->unsignedBigInteger('generated_by');
            $table->timestamp('generated_at')->useCurrent();

            $table->index(['report_type', 'period_start', 'period_end'], 'drv_kb_reports_period_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('drv_kb_reports');
        Schema::dropIfExists('drv_kb_gaps');
    }
};

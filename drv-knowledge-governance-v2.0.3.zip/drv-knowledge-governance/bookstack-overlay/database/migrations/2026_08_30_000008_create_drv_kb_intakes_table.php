<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('drv_kb_intakes', function (Blueprint $table): void {
            $table->bigIncrements('intake_id');
            $table->string('client_submission_id', 128);
            $table->string('idempotency_key', 128);
            $table->string('trace_id', 128);
            $table->char('request_hash', 64);
            $table->unsignedBigInteger('page_id');
            $table->foreignId('source_asset_id')->nullable()->constrained('drv_kb_assets', 'asset_id')->nullOnDelete();
            $table->foreignId('compile_task_id')->nullable()->constrained('drv_kb_compile_tasks', 'task_id')->nullOnDelete();
            $table->unsignedBigInteger('requested_by')->nullable();
            $table->string('intake_status', 24)->default('accepted');
            $table->char('source_hash', 64)->nullable();
            $table->json('request_json');
            $table->json('response_json')->nullable();
            $table->text('last_error')->nullable();
            $table->timestamps();

            $table->unique('client_submission_id', 'drv_kb_intakes_submission_unique');
            $table->unique('idempotency_key', 'drv_kb_intakes_idempotency_unique');
            $table->index(['page_id', 'created_at'], 'drv_kb_intakes_page_created_index');
            $table->index(['intake_status', 'updated_at'], 'drv_kb_intakes_status_updated_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('drv_kb_intakes');
    }
};

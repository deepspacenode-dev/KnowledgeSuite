<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('drv_kb_quality_checks', function (Blueprint $table): void {
            $table->bigIncrements('quality_check_id');
            $table->foreignId('asset_id')->constrained('drv_kb_assets', 'asset_id')->cascadeOnDelete();
            $table->unsignedInteger('source_version');
            $table->string('check_type', 32);
            $table->unsignedTinyInteger('content_score')->nullable();
            $table->unsignedTinyInteger('metadata_score')->nullable();
            $table->json('warnings_json')->nullable();
            $table->json('reject_reasons_json')->nullable();
            $table->timestamp('checked_at')->useCurrent();

            $table->index(['asset_id', 'source_version', 'checked_at'], 'drv_kb_quality_asset_version_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('drv_kb_quality_checks');
    }
};

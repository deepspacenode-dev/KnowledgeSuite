<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('drv_kb_rag_snapshot', function (Blueprint $table): void {
            $table->bigIncrements('rag_snapshot_id');
            $table->foreignId('asset_id')->constrained('drv_kb_assets', 'asset_id')->cascadeOnDelete();
            $table->string('dataset_id');
            $table->string('document_id');
            $table->char('content_hash', 64);
            $table->string('parse_status', 24);
            $table->unsignedInteger('chunk_count')->nullable();
            $table->string('last_action_result', 16)->nullable();
            $table->json('image_documents_json')->nullable();
            $table->text('last_error')->nullable();
            $table->timestamp('checked_at')->useCurrent();

            $table->unique(['asset_id', 'dataset_id', 'document_id'], 'drv_kb_rag_snapshot_identity_unique');
            $table->index(['parse_status', 'checked_at'], 'drv_kb_rag_snapshot_status_index');
        });

        Schema::create('drv_kb_audit_events', function (Blueprint $table): void {
            $table->bigIncrements('audit_event_id');
            $table->uuid('trace_id');
            $table->string('event_type', 96);
            $table->string('object_type', 32);
            $table->string('object_id', 128);
            $table->unsignedBigInteger('actor_id')->nullable();
            $table->char('before_digest', 64)->nullable();
            $table->char('after_digest', 64)->nullable();
            $table->json('metadata_json')->nullable();
            $table->string('dispatch_status', 16)->nullable();
            $table->timestamp('created_at')->useCurrent();

            $table->index(['object_type', 'object_id', 'created_at'], 'drv_kb_audit_object_index');
            $table->index(['event_type', 'dispatch_status'], 'drv_kb_audit_dispatch_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('drv_kb_audit_events');
        Schema::dropIfExists('drv_kb_rag_snapshot');
    }
};

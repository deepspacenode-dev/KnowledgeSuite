<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasColumn('drv_kb_rag_snapshot', 'image_documents_json')) {
            Schema::table('drv_kb_rag_snapshot', function (Blueprint $table): void {
                $table->json('image_documents_json')->nullable()->after('last_action_result');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('drv_kb_rag_snapshot', 'image_documents_json')) {
            Schema::table('drv_kb_rag_snapshot', function (Blueprint $table): void {
                $table->dropColumn('image_documents_json');
            });
        }
    }
};

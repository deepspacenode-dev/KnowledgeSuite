<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('drv_kb_assets', function (Blueprint $table): void {
            $table->bigIncrements('asset_id');
            $table->string('asset_type', 16);
            $table->string('source_key');
            $table->unsignedBigInteger('page_id')->nullable();
            $table->foreignId('parent_asset_id')->nullable()->constrained('drv_kb_assets', 'asset_id')->nullOnDelete();
            $table->string('title');
            $table->unsignedBigInteger('owner_id')->nullable();
            $table->string('material_type', 64)->nullable();
            $table->char('content_hash', 64);
            $table->unsignedInteger('current_version')->default(1);
            $table->json('metadata_json')->nullable();
            $table->timestamps();

            $table->unique(['source_key', 'asset_type'], 'drv_kb_assets_source_type_unique');
            $table->index(['page_id', 'asset_type'], 'drv_kb_assets_page_type_index');
            $table->index(['owner_id', 'updated_at'], 'drv_kb_assets_owner_updated_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('drv_kb_assets');
    }
};

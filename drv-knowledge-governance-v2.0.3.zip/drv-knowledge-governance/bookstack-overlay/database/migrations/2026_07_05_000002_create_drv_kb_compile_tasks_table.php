<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('drv_kb_compile_tasks', function (Blueprint $table): void {
            $table->bigIncrements('task_id');
            $table->foreignId('source_asset_id')->constrained('drv_kb_assets', 'asset_id')->cascadeOnDelete();
            $table->unsignedInteger('source_version');
            $table->string('trigger_type', 16);
            $table->string('workflow', 16);
            $table->string('task_status', 24)->default('queued');
            $table->string('lease_owner')->nullable();
            $table->timestamp('lease_expires_at')->nullable();
            $table->char('idempotency_key', 64);
            $table->unsignedTinyInteger('retry_count')->default(0);
            $table->string('error_code', 64)->nullable();
            $table->text('error_detail')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('finished_at')->nullable();

            $table->unique('idempotency_key', 'drv_kb_compile_tasks_idempotency_unique');
            $table->index(['task_status', 'lease_expires_at'], 'drv_kb_compile_tasks_claim_index');
            $table->index(['source_asset_id', 'source_version'], 'drv_kb_compile_tasks_source_version_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('drv_kb_compile_tasks');
    }
};

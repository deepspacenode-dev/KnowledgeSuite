<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('drv_kb_reviews', function (Blueprint $table): void {
            $table->bigIncrements('review_id');
            $table->foreignId('asset_id')->constrained('drv_kb_assets', 'asset_id')->cascadeOnDelete();
            $table->unsignedInteger('source_version');
            $table->string('review_status', 24);
            $table->string('gate_result', 16);
            $table->unsignedBigInteger('reviewer_id')->nullable();
            $table->unsignedTinyInteger('quality_score')->nullable();
            $table->text('review_comment')->nullable();
            $table->timestamp('reviewed_at')->nullable();
            $table->timestamp('created_at')->useCurrent();

            $table->index(['asset_id', 'source_version', 'created_at'], 'drv_kb_reviews_asset_version_index');
            $table->index(['review_status', 'created_at'], 'drv_kb_reviews_status_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('drv_kb_reviews');
    }
};

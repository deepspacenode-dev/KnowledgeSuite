<?php

use BookStack\AI\Governance\Http\Controllers\GovernancePageController;
use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth'])->group(function (): void {
    Route::get('/ai-governance-dashboard.html', GovernancePageController::class)
        ->name('ai-governance.dashboard');
});

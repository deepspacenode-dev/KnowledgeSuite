<?php

use BookStack\AI\Governance\Http\Controllers\Internal\CompileTaskController;
use BookStack\AI\Governance\Http\Controllers\Internal\CompileTaskV2Controller;
use BookStack\AI\Governance\Http\Controllers\Internal\InternalEventController;
use BookStack\AI\Governance\Http\Controllers\Internal\RagSnapshotController;
use BookStack\AI\Governance\Http\Controllers\Internal\WorkerEventV2Controller;
use BookStack\AI\Governance\Http\Controllers\V1\AssetController;
use BookStack\AI\Governance\Http\Controllers\V1\BookshelfFilterController;
use BookStack\AI\Governance\Http\Controllers\V1\CompileCommandController;
use BookStack\AI\Governance\Http\Controllers\V1\ContributionController;
use BookStack\AI\Governance\Http\Controllers\V1\DiagnosisController;
use BookStack\AI\Governance\Http\Controllers\V1\GapCommandController;
use BookStack\AI\Governance\Http\Controllers\V1\GapController;
use BookStack\AI\Governance\Http\Controllers\V1\KnowledgeGraphController;
use BookStack\AI\Governance\Http\Controllers\V1\QualityController;
use BookStack\AI\Governance\Http\Controllers\V1\QualityRulesController;
use BookStack\AI\Governance\Http\Controllers\V1\RagController;
use BookStack\AI\Governance\Http\Controllers\V1\RagCommandController;
use BookStack\AI\Governance\Http\Controllers\V1\RagRemovalController;
use BookStack\AI\Governance\Http\Controllers\V1\ReportController;
use BookStack\AI\Governance\Http\Controllers\V1\ReportCommandController;
use BookStack\AI\Governance\Http\Controllers\V1\ReviewController;
use BookStack\AI\Governance\Http\Controllers\V1\ReviewUnitController;
use BookStack\AI\Governance\Http\Controllers\V1\SummaryController;
use BookStack\AI\Governance\Http\Controllers\V1\SyncController;
use BookStack\AI\Governance\Http\Controllers\V2\IntakeController;
use BookStack\AI\Governance\Http\Controllers\V2\AssistantConfigController;
use BookStack\AI\Governance\Http\Controllers\V2\ChatController;
use BookStack\AI\Governance\Http\Controllers\V2\StatusController;
use BookStack\AI\Governance\Http\Middleware\VerifyWorkerSignature;
use Illuminate\Support\Facades\Route;

Route::prefix('api/ai-governance/v1')->middleware(['web', 'auth'])->group(function (): void {
    Route::get('summary', SummaryController::class);
    Route::get('assets', [AssetController::class, 'index']);
    Route::get('assets/{asset_id}', [AssetController::class, 'show'])->whereNumber('asset_id');
    Route::get('filters/bookshelves', BookshelfFilterController::class);
    Route::get('contributions', ContributionController::class);
    Route::get('quality/issues', QualityController::class);
    Route::get('quality/rules', QualityRulesController::class);
    Route::get('rag/status', RagController::class);
    Route::get('gaps', GapController::class);
    Route::get('knowledge-graph', KnowledgeGraphController::class);
    Route::get('reports/{report_id}', [ReportController::class, 'show'])->whereNumber('report_id');
    Route::get('diagnosis', DiagnosisController::class);
    Route::get('review-units', [ReviewUnitController::class, 'index']);

    Route::post('assets/{asset_id}/reviews', [ReviewController::class, 'store'])->whereNumber('asset_id');
    Route::post('review-units/reviews', [ReviewUnitController::class, 'store']);
    Route::post('review-units/rag/publish', [ReviewUnitController::class, 'publish']);
    Route::post('assets/{asset_id}/compile', [CompileCommandController::class, 'store'])->whereNumber('asset_id');
    Route::post('assets/{asset_id}/rag/retry', [RagCommandController::class, 'retry'])->whereNumber('asset_id');
    Route::delete('assets/{asset_id}/rag', [RagRemovalController::class, 'destroy'])->whereNumber('asset_id');
    Route::post('gaps', [GapCommandController::class, 'store']);
    Route::patch('gaps/{gap_id}', [GapCommandController::class, 'update'])->whereNumber('gap_id');
    Route::delete('gaps/{gap_id}', [GapCommandController::class, 'destroy'])->whereNumber('gap_id');
    Route::post('reports', [ReportCommandController::class, 'store']);
    Route::post('sync', [SyncController::class, 'store']);
});

Route::prefix('api/ai-governance/v1/internal')->middleware([VerifyWorkerSignature::class])->group(function (): void {
    Route::get('tasks/next', [CompileTaskController::class, 'next']);
    Route::post('tasks/{task_id}/heartbeat', [CompileTaskController::class, 'heartbeat'])->whereNumber('task_id');
    Route::post('tasks/{task_id}/result', [CompileTaskController::class, 'result'])->whereNumber('task_id');
    Route::post('events', [InternalEventController::class, 'store']);
    Route::post('rag/snapshot', [RagSnapshotController::class, 'store']);
});

Route::prefix('api/ai-governance/v2')->middleware(['api', 'auth'])->group(function (): void {
    Route::post('intakes', [IntakeController::class, 'store']);
    Route::get('intakes/{intake_id}', [IntakeController::class, 'show'])->whereNumber('intake_id');
    Route::post('status/resolve', [StatusController::class, 'resolve']);
});

Route::prefix('api/ai-governance/v2')->middleware(['web', 'auth'])->group(function (): void {
    Route::get('assistant/config', AssistantConfigController::class);
    Route::post('chat/completions', [ChatController::class, 'store']);
});

Route::prefix('api/ai-governance/v2/internal')->middleware([VerifyWorkerSignature::class])->group(function (): void {
    Route::post('tasks/claim', [CompileTaskV2Controller::class, 'claim']);
    Route::post('tasks/{task_id}/heartbeat', [CompileTaskV2Controller::class, 'heartbeat'])->whereNumber('task_id');
    Route::post('tasks/{task_id}/result', [CompileTaskV2Controller::class, 'result'])->whereNumber('task_id');
    Route::post('events', [WorkerEventV2Controller::class, 'store']);
});

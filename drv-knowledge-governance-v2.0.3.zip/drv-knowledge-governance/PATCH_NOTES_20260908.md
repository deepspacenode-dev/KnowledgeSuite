# V2.0.2 治理易用性与 RAG 控制补丁

本补丁面向已部署的 Drv Knowledge Suite V2.0.2，不修改 BookStack 正文、附件、用户、权限或既有 `drv_kb_*` 数据。本次没有新增数据库迁移，只更新治理后端、前端、路由与离线文档。

## 修复内容

- P2：芯片手册的质量问题与人工审核统一按章节聚合；章节分数取成员页面最低分，任一页面硬阻断即阻断整章。页面问题仅作为可展开的定位明细，审核入口统一跳转到章节评审。
- 质量问题、RAG 状态以文章标题显示，资产序号仅作审计信息。
- 质量问题显示中文最终结论、阻断依据、扣分原因和修复方法，并增加“门禁说明”。
- 新增管理员“从 RAGFlow 移除”操作，删除远端 Markdown 和关联图片但保留 BookStack 原文及治理审计。
- 新增治理中心顶部 RAGFlow 网站入口。
- 手工入库支持从现有快照或 `RAGFLOW_DEFAULT_DATASET_ID` 取得 Dataset。
- RAG 同步回查真实解析状态与分块数。
- 移除点击 Bloub 小人后出现的蓝色虚线圆框。

## 升级前配置

将下列配置写入目标 BookStack 的 `.env`，不得把真实密钥写回本补丁包：

```dotenv
RAGFLOW_BASE_URL=http://10.222.120.25
RAGFLOW_WEB_URL=http://10.222.120.25/
RAGFLOW_API_KEY=replace_me
RAGFLOW_DEFAULT_DATASET_ID=replace_me
```

`RAGFLOW_BASE_URL` 是 BookStack 容器访问 API 的地址；`RAGFLOW_WEB_URL` 是用户浏览器可以访问的地址，两者在 Docker 网络环境中可能不同。

## Linux / Docker 容器升级

先完成数据库、BookStack `/config` 卷和当前镜像/配置备份，再把补丁解压到临时目录并执行：

```bash
cd drv-knowledge-governance
sh scripts/install.sh /app/www
php /app/www/artisan route:list | grep ai-governance
php /app/www/artisan optimize:clear
```

安装脚本会把被替换文件保存到包内 `backups/install-时间戳/`。对于 LinuxServer BookStack 镜像，建议在自定义镜像构建阶段应用补丁，避免容器重建后丢失运行时覆盖。

## 最小验收

1. 质量问题页显示文章标题、中文结论，并可打开“门禁说明”。
2. 芯片手册同一章节只显示一条质量记录；展开后能看到问题页面，点击“前往章节审核”后只出现章节级审核操作。
3. RAG 状态页显示文章标题和“重新入库并解析”“从 RAGFlow 移除”按钮。
4. 顶部“打开 RAGFlow”指向 `RAGFLOW_WEB_URL`。
5. 选择一篇测试 Wiki 入库，确认 RAGFlow 收到 `.md`、关联图片并开始解析。
6. 点击“发布并同步状态”，确认治理中心回写 `ready/failed` 和分块数。
7. 使用测试文档验证安全移除；远端删除失败时治理状态必须保持不变。
8. 点击 Bloub 小人，确认不再出现蓝色虚线圆框。

完整部署与回滚说明见 `DEPLOY.md`，完整功能验收见 `TEST_CHECKLIST.md`。

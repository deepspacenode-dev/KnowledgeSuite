# Changelog

## 2.0.3 official RAGFlow widget, review publishing and governance usability - 2026-09-08

- Replaced the custom assistant chat renderer with a lazy, origin-checked official RAGFlow Widget iframe.
- Added source-article links to page/chapter quality issues and one-click reviewed-unit publishing to RAGFlow.
- Added audited knowledge-gap deletion, asset deletion controls, Chinese gate explanations and filename-first labels.
- Unified the current intranet RAGFlow web target and static asset cache key.

## 2.0.2 governance usability and RAG controls patch - 2026-09-07

- 质量问题与 RAG 状态以文章标题为主身份，资产序号和版本降为审计信息。
- 质量检查输出中文最终结论、阻断原因、扣分与修复方法，并提供与实际规则同源的门禁说明。
- 新增管理员安全移除 RAGFlow 文档功能：先删除 Markdown 与关联图片，失败时不改变本地状态，成功后保留资产和审计记录。
- 手工入库可从请求、现有快照或默认配置解析 Dataset，并继续执行 Wiki Markdown、图片、元数据上传与解析。
- RAG 同步增加远端解析状态和分块数回写；顶部增加可配置的 RAGFlow 网站入口。
- 移除 Bloub 小人点击后的浏览器默认蓝色虚线焦点圈，同时保留键盘焦点的亮度与位移反馈。

## 2.0.2 Bloub avatar patch - 2026-09-05

- 默认悬浮小人切换为蓝色 Bloub，旧 GrokBot 源码和数据作为隔离回滚资产保留且不再默认加载。
- 默认表情按权重在专注、平静、好奇、开心、兴奋和惊讶之间低频轮换，避免立即重复并限制高能量表情连续出现。
- 自动轮换主要使用看眼形变，每第四次使用旋流；手动表情事件使用彗星，治理事件之间使用爆散切换。
- 处理、进展和异常分别映射到 `thinking`、`notify` 和 `alert`，同时保持现有 `DrvKnowledgeAvatar` 调用契约。
- 新增 Bloub MIT 许可、上游固定提交、适配源码、重建说明、离线浏览器测试与安装/卸载/Docker 交付路径。

## 2.0.2 RAGFlow v0.27.1 ingestion and assistant chat - 2026-09-03

- RAG 发布在上传后写入 BookStack 页面来源、领域和治理元数据，应用稳定解析参数并显式启动解析。
- 悬浮机器人通过 BookStack 同源后端调用 RAGFlow Chat，API Key 不进入浏览器；会话令牌加密绑定当前用户。
- 回答返回 BookStack 原文链接，Chat Prompt 禁止跨芯片/模块混用和伪造来源。
- 提供版本化 Chat/解析配置、Fake RAGFlow 离线链路和非破坏性 V2 数据集迁移控制命令。

## 2.0.0-rc.3 GrokBot contextual assistant - 2026-09-02

- 用本地 GrokBot 25 组表情几何替换普通导航胶囊，保留 Drv 蓝白识别色，并记录 MIT / BSD-3-Clause 上游来源与固定提交。
- 机器人始终以悬浮助手存在，不再迁移到旧 AI 工具栏；点击后展开当前页面治理状态与审核入库、知识图谱、知识缺口、日周报入口。
- 增加 260px 邻近范围内的 G3 分层视线跟随：眼睛高响应、头部低幅惯性、离开后平滑回正；触屏与减少动态效果偏好自动降级。
- 编译、审核和 RAG 三维状态驱动表情，治理中心的加载、成功与失败事件也会实时切换搜索、雷达、书写、庆祝和告警状态。
- Git 后台备份和文档转换作为 V2.1 规划能力展示，不伪造未实现的运行状态。
- Docker、PowerShell/Linux 安装、卸载、离线校验和浏览器验证夹具同步纳入 GrokBot 本地资产。

## 2.0.0-rc.2 governance entry visibility - 2026-08-31

- 通过 BookStack `CustomHtmlHeadContentProvider` 扩展点，在已登录页面自动加载同源、带版本号的治理入口 CSS 与 JavaScript；保留既有自定义 Head 和 CSP 处理。
- 当前页面存在 AI 入库工具箱时复用原按钮样式，否则显示独立的右下角“知识治理中心”悬浮按钮。
- Docker 镜像、PowerShell/Linux 安装与卸载流程同步纳入悬浮入口样式文件，不再要求现场手工修改 BookStack 自定义 HTML。

## 1.9.1 governance scope and spherical graph - 2026-08-27

- 新增统一书架目录与跨页签 `bookshelf_id` 过滤，覆盖审阅、贡献、质量、RAG、报告和知识图谱。
- “芯片手册”类书架默认以章节作为最小评审单元，书籍直属页面自动回退为页面评审；可通过环境变量调整匹配名称。
- 修复静态治理页 CSRF 令牌来源：会话令牌使用 `X-CSRF-TOKEN`，`XSRF-TOKEN` Cookie 使用 `X-XSRF-TOKEN`，并提供明确的 419 提示。
- 原始资料与 Wiki 都可进入治理审阅；正式 RAG 发布仍只允许 reviewed / verified Wiki。
- 详情抽屉和评审列表仅展示后端状态机允许的操作，章节评审以事务批量作用于有效成员。
- 知识图谱改用参考实现的 `spherical-cloud` 球形云布局，DrvDocs 位于中心，四级节点使用独立三维球层。
- 图谱、质量、RAG 与报告接口统一复用可见页面和书架作用域；报告 Markdown 明确输出书架范围。
- 图谱资源缓存版本升级为 `20260827-sphere-i`。

## 1.9.1 maintenance - 2026-08-26

- RAG 状态视图改为读取 `last_action_result`，补全解析与入库状态中文标签，空状态统一显示 `-`。
- 审阅按钮与审阅请求增加有效 `asset_id` 双重校验，避免请求 `/assets/undefined/reviews`。
- 保留 `layered-orbits` 分层星轨布局，增加关联高亮、非关联淡化、点击选中和纵深标签控制。
- BookStack 悬浮工具箱的“知识治理中心”入口改为复用原生按钮结构，统一图标、字号、间距与悬停效果。
- 治理入口与知识图谱静态资源增加新缓存版本，避免内网浏览器继续读取旧文件。

## 1.9.1

- 新增可验证的 Source -> Wiki -> Review -> RAG 治理链路。
- 新增 DrvAgent / CodeBuddy Wiki 编译契约与 HMAC 工作者接口。
- 新增 reviewed / verified 门禁、质量检查、缺口、贡献和报告。
- 新增自主蓝色知识治理中心，不依赖 TailAdmin 或 CDN。
- 新增 Wiki 文章图片与主文档统一 upsert、hash、回滚清理与审计记录。
- 保留历史 V1.9 regression-safe robot 包，本包以独立 overlay 方式安装。

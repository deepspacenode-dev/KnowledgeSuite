<?php

declare(strict_types=1);

$packageRoot = dirname(__DIR__);
$packageAutoloader = $packageRoot . '/vendor/autoload.php';

if (!is_file($packageAutoloader)) {
    throw new RuntimeException('Package dependencies are unavailable; run Composer before PHPUnit.');
}

require_once $packageAutoloader;

$bookStackRoot = getenv('BOOKSTACK_ROOT');
if ($bookStackRoot === false || trim($bookStackRoot) === '') {
    return;
}

$bookStackAutoloader = rtrim($bookStackRoot, '/\\') . '/vendor/autoload.php';
if (!is_file($bookStackAutoloader)) {
    throw new RuntimeException('BOOKSTACK_ROOT does not contain vendor/autoload.php.');
}

require_once $bookStackAutoloader;

$bookStackBootstrap = rtrim($bookStackRoot, '/\\') . '/bootstrap/app.php';
if (!is_file($bookStackBootstrap)) {
    throw new RuntimeException('BOOKSTACK_ROOT does not contain bootstrap/app.php.');
}

$application = require $bookStackBootstrap;
$consoleKernel = $application->make(Illuminate\Contracts\Console\Kernel::class);
$consoleKernel->bootstrap();

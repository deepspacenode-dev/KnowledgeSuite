import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { runInNewContext } from 'node:vm';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const assistantRoot = join(root, 'bookstack-overlay', 'public', 'ai-assistant');

function loadLegacyAvatarApi() {
    const dataSource = readFileSync(join(assistantRoot, 'vendor', 'grokbot', 'grokbot-data.js'), 'utf8');
    const avatarSource = readFileSync(join(assistantRoot, 'grokbot-avatar.js'), 'utf8');
    const window = {};
    const context = {
        window,
        document: {},
        Math,
        Number,
        Object,
        String,
        Array,
        Date,
        setTimeout() { return 1; },
        clearTimeout() {},
        requestAnimationFrame() { return 1; },
        cancelAnimationFrame() {},
    };
    runInNewContext(dataSource, context);
    runInNewContext(avatarSource, context);
    return window.DrvKnowledgeAvatar;
}

function loadEntryApi() {
    const source = readFileSync(join(assistantRoot, 'ai-assistant-governance-entry.js'), 'utf8');
    const window = {
        location: { href: 'http://bookstack.local/books/example/page/demo', assign() {} },
        addEventListener() {},
    };
    const document = {
        readyState: 'loading',
        addEventListener() {},
        querySelector() { return null; },
    };
    runInNewContext(source, { window, document, URL, URLSearchParams, CustomEvent: class {} });
    return window.DrvKnowledgeAssistantEntry;
}

test('service provider registers authenticated page and versioned API routes', () => {
    const provider = readFileSync(join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Providers', 'AiGovernanceServiceProvider.php'), 'utf8');
    const pageRoutes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance-page.php'), 'utf8');

    assert.match(provider, /loadRoutesFrom/);
    assert.match(provider, /ai-governance\.php/);
    assert.match(provider, /ai-governance-page\.php/);
    assert.match(pageRoutes, /ai-governance-dashboard\.html/);
    assert.match(pageRoutes, /\['web', 'auth'\]/);
});

test('authenticated BookStack pages load the local Bloub engine before the P0 assistant entry', () => {
    const provider = readFileSync(join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Infrastructure', 'BookStack', 'GovernanceHeadContentProvider.php'), 'utf8');

    assert.match(provider, /auth\(\)->check\(\)/);
    assert.match(provider, /HtmlNonceApplicator::apply/);
    assert.match(provider, /bloub-avatar\.css\?v=20260905-bloub-v1/);
    assert.match(provider, /bloub-avatar\.iife\.js\?v=20260905-bloub-v1/);
    assert.match(provider, /ai-assistant-governance-entry\.js\?v=20260908-v203-widget-v1/);
    assert.ok(provider.indexOf('bloub-avatar.iife.js') < provider.indexOf('ai-assistant-governance-entry.js'));
    assert.doesNotMatch(provider, /grokbot-data\.js|grokbot-avatar\.js/);
});

test('legacy GrokBot state mapping remains available as an isolated fallback', () => {
    const avatar = loadLegacyAvatarApi();

    assert.equal(avatar.stateForFeature('assets', 'loading'), 'working');
    assert.equal(avatar.stateForFeature('knowledge-graph', 'loading'), 'radar');
    assert.equal(avatar.stateForFeature('gaps', 'ready'), 'curious');
    assert.equal(avatar.stateForFeature('reports', 'loading'), 'writing');
    assert.equal(avatar.stateForFeature('git-backup', 'loading'), 'sending');
    assert.equal(avatar.stateForFeature('document-conversion', 'loading'), 'uploading');
    assert.equal(avatar.stateForFeature('overview', 'error'), 'alerting');
});

test('legacy GrokBot status mapping remains unchanged for rollback compatibility', () => {
    const avatar = loadLegacyAvatarApi();

    assert.equal(avatar.mapGovernanceStatus({ compile_status: 'running', review_status: 'pending_review', rag_status: 'not_ingested' }).state, 'working');
    assert.equal(avatar.mapGovernanceStatus({ compile_status: 'succeeded', review_status: 'need_recheck', rag_status: 'stale' }).state, 'confused');
    assert.equal(avatar.mapGovernanceStatus({ compile_status: 'succeeded', review_status: 'verified', rag_status: 'ready' }).state, 'proud');
    assert.equal(avatar.mapGovernanceStatus({ compile_status: 'failed', review_status: 'pending_review', rag_status: 'failed' }).state, 'alerting');
    assert.equal(avatar.mapGovernanceStatus(null).state, 'curious');
});

test('assistant routes current page actions without scanning arbitrary data-page-id nodes', () => {
    const entry = loadEntryApi();

    assert.equal(entry.positiveId('42'), '42');
    assert.equal(entry.positiveId('-1'), '');
    assert.equal(entry.featureUrl('assets', '42'), '/ai-governance-dashboard.html?view=assets&mode=current_page&page_id=42');
    assert.equal(entry.featureUrl('knowledge-graph', ''), '/ai-governance-dashboard.html?view=knowledge-graph&mode=current_page');

    const source = readFileSync(join(assistantRoot, 'ai-assistant-governance-entry.js'), 'utf8');
    assert.match(source, /canonical/);
    assert.doesNotMatch(source, /querySelector\(['"]\[data-page-id\]/);
});

test('quality chapter action routes to the filtered chapter review view', () => {
  const source = readFileSync(join(root, 'bookstack-overlay/public/ai-governance/app/main.js'), 'utf8');

  assert.match(source, /open-review-unit/);
  assert.match(source, /reviewUnitTitle/);
  assert.match(source, /bookshelfId/);
  assert.match(source, /navigate\('assets'\)/);
});

test('assistant remains floating and exposes contextual actions instead of migrating into legacy toolbox', () => {
    const source = readFileSync(join(assistantRoot, 'ai-assistant-governance-entry.js'), 'utf8');
    const css = readFileSync(join(assistantRoot, 'ai-assistant-governance-entry.css'), 'utf8');

    assert.match(source, /aiGovernanceCenterBtn/);
    assert.match(source, /drvKnowledgeAssistantPanel/);
    assert.match(source, /知识审核与入库/);
    assert.match(source, /知识图谱/);
    assert.match(source, /知识缺口/);
    assert.match(source, /日周报/);
    assert.match(source, /Git 后台备份/);
    assert.match(source, /文档转换/);
    assert.doesNotMatch(source, /aiIngestCenterBtn/);
    assert.match(css, /position:\s*fixed/);
    assert.match(css, /prefers-reduced-motion/);
});

test('mouse focus never draws a blue or dotted circle around the Bloub trigger', () => {
    const css = readFileSync(join(assistantRoot, 'ai-assistant-governance-entry.css'), 'utf8');
    assert.match(css, /drv-assistant__trigger:focus\s*\{[^}]*outline:\s*none\s*!important[^}]*box-shadow:\s*none\s*!important/s);
    assert.match(css, /drv-assistant__trigger:focus-visible\s*\{[^}]*outline:\s*none\s*!important/s);
    assert.doesNotMatch(css, /drv-assistant__trigger:focus-visible\s*\{[^}]*outline:\s*3px/s);
});

test('assistant normalizes only an origin-matched official RAGFlow widget configuration', () => {
    const entry = loadEntryApi();
    assert.equal(entry.assistantConfigUrl(), '/api/ai-governance/v2/assistant/config');
    const normalized = entry.normalizeAssistantConfig({ data: {
        schema_version: 'drvknowledge.assistant-config.v2',
        ragflow_web_url: 'http://ragflow.local/',
        widget: {
            enabled: true,
            src: 'http://ragflow.local/chats/widget?shared_id=chat-1&auth=beta-token&from=chat&mode=window',
            origin: 'http://ragflow.local',
            allow_media: false,
            load_timeout_ms: 9000,
        },
    } });
    assert.equal(normalized.enabled, true);
    assert.equal(normalized.origin, 'http://ragflow.local');
    assert.equal(normalized.allowMedia, false);
    assert.equal(normalized.loadTimeoutMs, 9000);
    assert.equal(entry.isAllowedWidgetConfig(normalized), true);
    normalized.origin = 'http://evil.local';
    assert.equal(entry.isAllowedWidgetConfig(normalized), false);
});

test('assistant lazy loads the official widget and removes the custom proxy chat UI', () => {
    const source = readFileSync(join(assistantRoot, 'ai-assistant-governance-entry.js'), 'utf8');
    const css = readFileSync(join(assistantRoot, 'ai-assistant-governance-entry.css'), 'utf8');
    assert.match(source, /data-assistant-widget-host/);
    assert.match(source, /document\.createElement\('iframe'\)/);
    assert.match(source, /frame\.referrerPolicy\s*=\s*'no-referrer'/);
    assert.match(source, /frame\.loading\s*=\s*'lazy'/);
    assert.match(source, /config\.allowMedia\s*\?\s*'microphone; camera'\s*:\s*''/);
    assert.match(source, /new URL\(config\.src\)/);
    assert.match(source, /candidate\.origin\s*!==\s*config\.origin/);
    assert.match(source, /candidate\.searchParams\.get\('mode'\)\s*!==\s*'window'/);
    assert.doesNotMatch(source, /CHAT_API|chatPayload|normalizeChatResponse|sessionToken|data-assistant-chat-form/);
    assert.match(css, /\.drv-assistant__widget-frame\s*\{[^}]*width:\s*100%[^}]*height:\s*min\(500px,/s);
    assert.match(css, /data-widget-state="ready"/);
});

test('governance dashboard emits avatar lifecycle events for real view loads and writes', () => {
    const source = readFileSync(join(root, 'bookstack-overlay', 'public', 'ai-governance', 'app', 'main.js'), 'utf8');

    assert.match(source, /drvknowledge:avatar-state/);
    assert.match(source, /emitAvatarState\(view, 'loading'/);
    assert.match(source, /emitAvatarState\(view, 'ready'/);
    assert.match(source, /emitAvatarState\(view, 'error'/);
    assert.match(source, /emitAvatarState\(state\.route\.view, 'success'/);
});

test('GrokBot distribution is offline, attributed, and included by both installers and image build', () => {
    const expected = [
        'grokbot-avatar.js',
        join('vendor', 'grokbot', 'grokbot-data.js'),
        join('vendor', 'grokbot', 'LICENSE-BSD-3-Clause.txt'),
        join('vendor', 'grokbot', 'LICENSE-MIT.txt'),
        join('vendor', 'grokbot', 'UPSTREAM.json'),
    ];
    for (const relative of expected) assert.ok(existsSync(join(assistantRoot, relative)), relative);

    const installPs = readFileSync(join(root, 'scripts', 'install.ps1'), 'utf8');
    const installSh = readFileSync(join(root, 'scripts', 'install.sh'), 'utf8');
    const uninstallPs = readFileSync(join(root, 'scripts', 'uninstall.ps1'), 'utf8');
    const uninstallSh = readFileSync(join(root, 'scripts', 'uninstall.sh'), 'utf8');
    const dockerfile = readFileSync(join(root, 'docker', 'bookstack', 'Dockerfile'), 'utf8');

    for (const source of [installPs, installSh, uninstallPs, uninstallSh, dockerfile]) {
        assert.match(source, /grokbot-avatar\.js/);
        assert.match(source, /vendor[\\/]grokbot/);
    }
    assert.doesNotMatch(readFileSync(join(assistantRoot, 'grokbot-avatar.js'), 'utf8'), /https?:\/\//);
    assert.doesNotMatch(readFileSync(join(assistantRoot, 'ai-assistant-governance-entry.js'), 'utf8'), /https?:\/\//);
});

test('Bloub distribution is offline, attributed, reproducible, and included by every delivery path', () => {
    const bloubRoot = join(assistantRoot, 'vendor', 'bloub');
    const expected = [
        'bloub-avatar.iife.js',
        'bloub-avatar.css',
        'LICENSE-MIT.txt',
        'UPSTREAM.json',
        'BUILD.md',
        join('source', 'bookstack-avatar-runtime.ts'),
        join('source', 'bookstack-avatar-i18n.ts'),
        join('source', 'vite.bookstack-avatar.config.ts'),
        join('source', 'upstream-blink-api.patch'),
    ];
    for (const relative of expected) assert.ok(existsSync(join(bloubRoot, relative)), relative);

    const adapter = readFileSync(join(bloubRoot, 'source', 'bookstack-avatar-runtime.ts'), 'utf8');
    const bundle = readFileSync(join(bloubRoot, 'bloub-avatar.iife.js'), 'utf8');
    const installPs = readFileSync(join(root, 'scripts', 'install.ps1'), 'utf8');
    const installSh = readFileSync(join(root, 'scripts', 'install.sh'), 'utf8');
    const uninstallPs = readFileSync(join(root, 'scripts', 'uninstall.ps1'), 'utf8');
    const uninstallSh = readFileSync(join(root, 'scripts', 'uninstall.sh'), 'utf8');
    const dockerfile = readFileSync(join(root, 'docker', 'bookstack', 'Dockerfile'), 'utf8');

    for (const source of [installPs, installSh, uninstallPs, uninstallSh, dockerfile]) {
        assert.match(source, /vendor[\\/]bloub/);
    }
    assert.match(adapter, /idleIntervalMs:\s*\[45000, 75000\]/);
    assert.match(adapter, /eventTransition:\s*'burst'/);
    assert.match(adapter, /highEnergyCooldownCycles:\s*2/);
    assert.match(adapter, /rag === 'queued' \|\| rag === 'parsing'/);
    assert.match(bundle, /DrvKnowledgeAvatar/);
    assert.doesNotMatch(bundle, /\bfetch\s*\(|XMLHttpRequest|importScripts/);
    const runtimeUrls = [...bundle.matchAll(/https?:\/\/[^\s'"`<>]+/g)].map((match) => match[0]);
    const externalRuntimeUrls = runtimeUrls.filter((url) => ![
        'http://www.w3.org/2000/svg',
        'http://www.w3.org/1998/Math/MathML',
        'http://www.w3.org/1999/xlink',
    ].includes(url));
    assert.deepEqual(externalRuntimeUrls, []);
});

test('automatic entry assets are cache-busted consistently', () => {
    const deploy = readFileSync(join(root, 'DEPLOY.md'), 'utf8');
    const provider = readFileSync(join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Infrastructure', 'BookStack', 'GovernanceHeadContentProvider.php'), 'utf8');
    const avatarScriptVersion = /bloub-avatar\.iife\.js\?v=20260905-bloub-v1/;
    const avatarStyleVersion = /bloub-avatar\.css\?v=20260905-bloub-v1/;
    const assistantVersion = /ai-assistant-governance-entry\.(?:css|js)\?v=20260908-v203-widget-v1/g;

    assert.match(deploy, avatarScriptVersion);
    assert.match(provider, avatarScriptVersion);
    assert.match(deploy, avatarStyleVersion);
    assert.match(provider, avatarStyleVersion);
    assert.equal([...deploy.matchAll(assistantVersion)].length, 2);
    assert.equal([...provider.matchAll(assistantVersion)].length, 2);
});

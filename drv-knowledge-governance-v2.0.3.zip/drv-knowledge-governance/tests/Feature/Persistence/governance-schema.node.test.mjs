import assert from 'node:assert/strict';
import { readdirSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const packageRoot = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const migrationRoot = join(packageRoot, 'bookstack-overlay', 'database', 'migrations');
const repositoryRoot = join(
  packageRoot,
  'bookstack-overlay',
  'app',
  'AI',
  'Governance',
  'Infrastructure',
  'Persistence',
);

const migrationSource = () => readdirSync(migrationRoot)
  .filter((name) => name.endsWith('.php'))
  .sort()
  .map((name) => readFileSync(join(migrationRoot, name), 'utf8'))
  .join('\n');

test('migrations create only the nine approved governance tables', () => {
  const source = migrationSource();
  const tables = [...source.matchAll(/Schema::create\('([^']+)'/g)].map((match) => match[1]);

  assert.deepEqual(tables, [
    'drv_kb_assets',
    'drv_kb_compile_tasks',
    'drv_kb_reviews',
    'drv_kb_quality_checks',
    'drv_kb_gaps',
    'drv_kb_reports',
    'drv_kb_rag_snapshot',
    'drv_kb_audit_events',
    'drv_kb_intakes',
  ]);
  assert.doesNotMatch(source, /Schema::(?:table|drop)\('(?!drv_kb_)/);
});

test('asset, task, review and snapshot identity constraints are explicit', () => {
  const source = migrationSource();

  assert.match(source, /unique\(\['source_key', 'asset_type'\]/);
  assert.match(source, /foreignId\('parent_asset_id'\).*nullable/);
  assert.match(source, /unique\('idempotency_key'/);
  assert.match(source, /index\(\['asset_id', 'source_version'/);
  assert.match(source, /unique\(\['asset_id', 'dataset_id', 'document_id'\]/);
});

test('repositories use transactions and row locking for contested workflows', () => {
  const compile = readFileSync(join(repositoryRoot, 'CompileTaskRepository.php'), 'utf8');
  const review = readFileSync(join(repositoryRoot, 'ReviewRepository.php'), 'utf8');
  const rag = readFileSync(join(repositoryRoot, 'RagSnapshotRepository.php'), 'utf8');

  assert.match(compile, /DB::transaction/);
  assert.match(compile, /lockForUpdate/);
  assert.match(review, /DB::transaction/);
  assert.match(rag, /DB::transaction/);
  assert.match(compile, /where\('task_status', 'running'\)/);
  assert.match(compile, /'failed' : 'retry_wait'/);
  assert.match(compile, /task_status' => 'queued'/);
});

test('asset repository enforces source and Wiki parent invariants without resetting creation time', () => {
  const source = readFileSync(join(repositoryRoot, 'AssetRepository.php'), 'utf8');
  assert.match(source, /assertValidParent/);
  assert.match(source, /Wiki assets require a source parent/);
  assert.match(source, /parent_asset_id/);
  assert.doesNotMatch(source, /updateOrInsert/);
});

test('audit repository recursively redacts sensitive keys', () => {
  const source = readFileSync(join(repositoryRoot, 'AuditEventRepository.php'), 'utf8');
  assert.match(source, /sanitizeMetadata/);
  assert.match(source, /strtolower/);
  assert.match(source, /REDACTED/);
  assert.match(source, /json_encode/);
  assert.match(source, /array_intersect_key/);
});

test('repository table writes remain inside drv_kb namespace', () => {
  const files = readdirSync(repositoryRoot).filter((name) => name.endsWith('Repository.php'));
  assert.equal(files.length, 9);

  for (const file of files) {
    const source = readFileSync(join(repositoryRoot, file), 'utf8');
    const tables = [...source.matchAll(/DB::table\('([^']+)'\)/g)].map((match) => match[1]);
    assert.ok(tables.length > 0, file);
    for (const table of tables) assert.match(table, /^drv_kb_/, `${file}:${table}`);
  }
});

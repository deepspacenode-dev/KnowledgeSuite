<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Tests\Feature\Persistence;

use Illuminate\Support\Facades\Schema;
use PHPUnit\Framework\TestCase;

final class GovernanceSchemaTest extends TestCase
{
    public function test_governance_tables_are_available_in_bookstack_harness(): void
    {
        if (!class_exists(Schema::class) || !Schema::getFacadeRoot()) {
            if (getenv('BOOKSTACK_ROOT')) {
                self::fail('Mounted BookStack harness did not bootstrap Laravel facades.');
            }
            self::markTestSkipped('Requires the mounted BookStack Laravel test harness.');
        }

        foreach ([
            'drv_kb_assets',
            'drv_kb_compile_tasks',
            'drv_kb_reviews',
            'drv_kb_quality_checks',
            'drv_kb_gaps',
            'drv_kb_reports',
            'drv_kb_rag_snapshot',
            'drv_kb_audit_events',
            'drv_kb_intakes',
        ] as $table) {
            self::assertTrue(Schema::hasTable($table), $table);
        }
    }
}

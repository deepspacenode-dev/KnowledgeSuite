import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const app = join(root, 'bookstack-overlay', 'app', 'AI', 'Governance');

test('identity adapter uses BookStack login and permission helpers without HTTP probing', () => {
  const source = readFileSync(join(app, 'Infrastructure', 'BookStack', 'BookStackIdentityAdapter.php'), 'utf8');
  assert.match(source, /auth\(\)->user\(\)/);
  assert.match(source, /userCan/);
  assert.match(source, /requireAdministrator/);
  assert.doesNotMatch(source, /settings\/users|curl|file_get_contents\(['"]https?:/i);
});

test('readable page query applies visibility before count and pagination', () => {
  const source = readFileSync(join(app, 'Infrastructure', 'BookStack', 'ReadablePageQuery.php'), 'utf8');
  assert.match(source, /applyVisibility/);
  assert.match(source, /count\(\)/);
  assert.match(source, /forPage/);
  assert.ok(source.indexOf('applyVisibility') < source.indexOf('count()'));
});

test('browser write routes require auth, CSRF web middleware and administrator guard', () => {
  const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');
  assert.match(routes, /middleware\(\['web', 'auth'\]\)/);
  assert.match(routes, /assets\/\{asset_id\}\/reviews/);
  assert.match(routes, /gaps\/\{gap_id\}/);
  assert.doesNotMatch(routes, /withoutMiddleware.*csrf/i);
});

test('summary bootstraps a CSRF token for the static governance page', () => {
  const controller = readFileSync(join(app, 'Http', 'Controllers', 'V1', 'SummaryController.php'), 'utf8');
  assert.match(controller, /csrf_token\(\)/);
  assert.match(controller, /csrf_token/);
});

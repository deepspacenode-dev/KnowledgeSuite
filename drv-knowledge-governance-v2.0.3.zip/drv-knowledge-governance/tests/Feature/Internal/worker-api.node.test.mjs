import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const app = join(root, 'bookstack-overlay', 'app', 'AI', 'Governance');

test('worker signature verifies HMAC, timestamp, nonce and body hash', () => {
  const source = readFileSync(join(app, 'Http', 'Middleware', 'VerifyWorkerSignature.php'), 'utf8');
  for (const marker of ['hash_hmac', 'sha256', 'hash_equals', 'X-AI-Timestamp', 'X-AI-Nonce', 'X-AI-Signature']) {
    assert.match(source, new RegExp(marker), marker);
  }
  assert.match(source, /300/);
  assert.match(source, /Cache::add/);
  assert.ok(source.indexOf('hash_equals') < source.indexOf('Cache::add'));
});

test('internal task routes expose claim heartbeat result event and RAG snapshot', () => {
  const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');
  for (const path of ['tasks/next', 'tasks/{task_id}/heartbeat', 'tasks/{task_id}/result', 'events', 'rag/snapshot']) {
    assert.ok(routes.includes(path), path);
  }
  assert.match(routes, /VerifyWorkerSignature/);
});

test('compile queue uses stable identity and rejects mismatched exported pages', () => {
  const queue = readFileSync(join(app, 'Application', 'Compile', 'QueueCompileTask.php'), 'utf8');
  const identity = readFileSync(join(app, 'Application', 'Compile', 'ValidateSourceIdentity.php'), 'utf8');
  for (const marker of ['source_key', 'source_version', 'content_hash', 'workflow']) assert.match(queue, new RegExp(marker));
  assert.match(queue, /implode\('\|'.*sourceKey.*sourceVersion.*contentHash.*workflow/s);
  assert.match(queue, /idempotency_key/);
  for (const field of ['page_id', 'canonical_url', 'title']) assert.match(identity, new RegExp(field));
  assert.match(identity, /SOURCE_IDENTITY_MISMATCH/);
});

test('accepted worker result creates a pending-review Wiki linked to its source', () => {
  const source = readFileSync(join(app, 'Application', 'Compile', 'AcceptWikiResult.php'), 'utf8');
  assert.match(source, /asset_type' => 'wiki'/);
  assert.match(source, /parent_asset_id/);
  assert.match(source, /pending_review/);
  assert.match(source, /result\['task_id'\]/);
  assert.match(source, /source->current_version/);
  assert.match(source, /task->source_version/);
  assert.doesNotMatch(source, /review_status' => '(reviewed|verified)'/);
});

test('worker result replay requires identical task source version and payload hash', () => {
  const source = readFileSync(join(app, 'Application', 'Compile', 'AcceptWikiResult.php'), 'utf8');
  assert.match(source, /RESULT_REPLAY_CONFLICT/);
  assert.match(source, /result\['source_key'\]/);
  assert.match(source, /result\['source_version'\]/);
  assert.match(source, /hash_equals\(\(string\) \$wiki->content_hash, \$wikiHash\)/);
  const controller = readFileSync(join(app, 'Http', 'Controllers', 'Internal', 'CompileTaskV2Controller.php'), 'utf8');
  assert.match(controller, /RESULT_REPLAY_CONFLICT.*409/s);
});

test('worker result and heartbeat cannot revive an expired lease', () => {
  const accept = readFileSync(join(app, 'Application', 'Compile', 'AcceptWikiResult.php'), 'utf8');
  assert.match(accept, /lease_expires_at/);
  assert.match(accept, /TASK_STALE/);
  const repository = readFileSync(join(app, 'Infrastructure', 'Persistence', 'CompileTaskRepository.php'), 'utf8');
  assert.match(repository, /where\('lease_expires_at', '>',/);
});

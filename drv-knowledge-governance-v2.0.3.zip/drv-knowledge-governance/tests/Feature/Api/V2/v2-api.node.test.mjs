import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '..');
const overlay = join(root, 'bookstack-overlay');
const app = join(overlay, 'app', 'AI', 'Governance');

test('v2 routes expose public intake/status and signed worker endpoints', () => {
  const routes = readFileSync(join(overlay, 'routes', 'ai-governance.php'), 'utf8');
  for (const path of [
    'api/ai-governance/v2',
    'api/ai-governance/v2/internal',
    'intakes',
    'intakes/{intake_id}',
    'status/resolve',
    'tasks/claim',
    'tasks/{task_id}/heartbeat',
    'tasks/{task_id}/result',
    'events',
  ]) assert.ok(routes.includes(path), path);
  assert.match(routes, /VerifyWorkerSignature/);
});

test('intake implementation re-exports and atomically records source and task', () => {
  const intake = readFileSync(join(app, 'Application', 'Intake', 'CreateIntake.php'), 'utf8');
  for (const marker of ['BookStackPageExporter', 'ValidateSourceIdentity', 'QueueCompileTask', 'client_submission_id', 'content_hash', 'DB::transaction']) {
    assert.match(intake, new RegExp(marker), marker);
  }
  const migration = join(overlay, 'database', 'migrations', '2026_08_30_000008_create_drv_kb_intakes_table.php');
  assert.ok(existsSync(migration));
  const schema = readFileSync(migration, 'utf8');
  assert.match(schema, /unique\('client_submission_id'/);
  assert.match(schema, /request_hash/);
});

test('intake status reads the current compile task state instead of the creation snapshot', () => {
  const repository = readFileSync(join(app, 'Infrastructure', 'Persistence', 'IntakeRepository.php'), 'utf8');
  const controller = readFileSync(join(app, 'Http', 'Controllers', 'V2', 'IntakeController.php'), 'utf8');

  assert.match(repository, /leftJoin\('drv_kb_compile_tasks as tasks'/);
  assert.match(repository, /tasks\.task_status as current_compile_status/);
  assert.match(controller, /withCurrentCompileStatus/);
});

test('source version fingerprint includes BookStack page update time for image edits', () => {
  const exporter = readFileSync(join(app, 'Infrastructure', 'BookStack', 'BookStackPageExporter.php'), 'utf8');
  assert.match(exporter, /page_updated_at/);
  assert.match(exporter, /governance_hash/);
  const queue = readFileSync(join(app, 'Application', 'Compile', 'QueueCompileTask.php'), 'utf8');
  assert.match(queue, /actual\['governance_hash'\]/);
});

test('BookStack domain tags survive compile and become RAGFlow filter metadata', () => {
  const exporter = readFileSync(join(app, 'Infrastructure', 'BookStack', 'BookStackPageExporter.php'), 'utf8');
  const queue = readFileSync(join(app, 'Application', 'Compile', 'QueueCompileTask.php'), 'utf8');
  const builder = readFileSync(join(app, 'Application', 'Compile', 'WikiTaskV2Builder.php'), 'utf8');
  for (const source of [exporter, queue, builder]) assert.match(source, /domain_metadata/);
  for (const field of ['owner', 'module', 'platform', 'chip', 'project']) {
    assert.match(exporter, new RegExp(field));
  }
  assert.match(exporter, /governance_hash[\s\S]*domain_metadata/);
});

test('worker v2 claim builds the frozen task contract and validates results', () => {
  const builder = readFileSync(join(app, 'Application', 'Compile', 'WikiTaskV2Builder.php'), 'utf8');
  for (const marker of ['drvknowledge.wiki-task.v2', 'content_ref', 'content_hash', 'compile_policy', 'review_required']) {
    assert.match(builder, new RegExp(marker), marker);
  }
  const accept = readFileSync(join(app, 'Application', 'Compile', 'AcceptWikiResult.php'), 'utf8');
  assert.match(accept, /ContractValidatorV2/);
  assert.match(accept, /rag_enabled/);
  assert.match(accept, /source_version/);
  const controller = readFileSync(join(app, 'Http', 'Controllers', 'Internal', 'CompileTaskV2Controller.php'), 'utf8');
  assert.match(controller, /replayed.*200.*201/s);
});

test('status resolver reads compile review and rag dimensions from governance tables', () => {
  const resolver = readFileSync(join(app, 'Application', 'Status', 'ResolveGovernanceStatus.php'), 'utf8');
  for (const marker of ['drv_kb_compile_tasks', 'drv_kb_reviews', 'drv_kb_rag_snapshot', 'compile_status', 'review_status', 'rag_status']) {
    assert.match(resolver, new RegExp(marker), marker);
  }
  assert.doesNotMatch(resolver, /front.?matter.*status/is);
});

test('formal rag publish is limited to wiki assets in AI shelves', () => {
  const policy = readFileSync(join(app, 'Application', 'Rag', 'AiShelfPolicy.php'), 'utf8');
  assert.match(policy, /【AI】/);
  assert.match(policy, /__construct\(private readonly BookStackHierarchyQuery \$hierarchy\)/);
  assert.doesNotMatch(policy, /\?BookStackHierarchyQuery \$hierarchy\s*=\s*null/);
  const publish = readFileSync(join(app, 'Application', 'Rag', 'PublishWikiAsset.php'), 'utf8');
  assert.match(publish, /AiShelfPolicy/);
  assert.match(publish, /assertPageAllowed/);
});

test('ragflow adapter probes version and normalizes document parsing state', () => {
  const gateway = readFileSync(join(app, 'Infrastructure', 'RagFlow', 'RagFlowGateway.php'), 'utf8');
  for (const marker of ['probeVersion', 'documentStatus', 'normalizeParseStatus', '[REDACTED]']) {
    assert.match(gateway, new RegExp(marker.replace(/[\[\]]/g, '\\$&')), marker);
  }
  assert.match(gateway, /queued.*parsing.*ready.*failed/s);
});

test('administrator sync performs orphan draft reconciliation and quality refresh', () => {
  const sync = readFileSync(join(app, 'Http', 'Controllers', 'V1', 'SyncController.php'), 'utf8');
  assert.match(sync, /ReconcileBookStackDrafts/);
  assert.match(sync, /RefreshQualityChecks/);
  assert.doesNotMatch(sync, /\['accepted'=>true\]/);
  const reconcile = readFileSync(join(app, 'Application', 'Sync', 'ReconcileBookStackDrafts.php'), 'utf8');
  assert.match(reconcile, /BookStackPageExporter/);
  assert.match(reconcile, /QueueCompileTask/);
  assert.ok(reconcile.includes('status:\\s*draft'));
});

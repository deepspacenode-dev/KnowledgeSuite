import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '..');
const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');

test('versioned API exposes every approved read endpoint', () => {
  for (const path of [
    'summary', 'assets', 'assets/{asset_id}', 'contributions', 'quality/issues',
    'rag/status', 'gaps', 'reports/{report_id}', 'diagnosis', 'filters/bookshelves',
  ]) {
    assert.ok(routes.includes(path), path);
  }
  assert.match(routes, /prefix\('api\/ai-governance\/v1'\)/);
});

test('API response contract exposes traceable success and error envelopes', () => {
  const response = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Http', 'ApiResponse.php'),
    'utf8',
  );
  for (const field of ['success', 'data', 'meta', 'trace_id', 'error_code', 'retryable']) {
    assert.match(response, new RegExp(`['"]${field}['"]`), field);
  }
});

test('asset query validates page size and whitelists sort fields', () => {
  const query = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Application', 'Query', 'AssetListQuery.php'),
    'utf8',
  );
  assert.match(query, /min\(100/);
  assert.match(query, /allowedSorts/);
  assert.match(query, /BookStackHierarchyQuery/);
  for (const filter of ['review_status', 'rag_status', 'date_from', 'date_to', 'module']) {
    assert.match(query, new RegExp(filter), filter);
  }
  assert.match(query, /filters\['page_id'\]/, 'current page filter');
  assert.match(query, /filters\['bookshelf_id'\]/, 'bookshelf filter');
});

test('shared hierarchy query resolves visible shelf pages across BookStack schemas', () => {
  const source = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Infrastructure', 'BookStack', 'BookStackHierarchyQuery.php'),
    'utf8',
  );
  assert.match(source, /ReadablePageQuery/);
  assert.match(source, /bookshelves_books/);
  assert.match(source, /Schema::hasTable\('entities'\)/);
  assert.match(source, /where\('type', 'page'\)/);
  assert.match(source, /where\('type', 'bookshelf'\)/);
  assert.match(source, /pageIdsForBookshelf/);
  assert.match(source, /array_unique/);
});

test('contribution endpoint accepts date and bookshelf filters while preserving BookStack names', () => {
  const controller = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Http', 'Controllers', 'V1', 'ContributionController.php'),
    'utf8',
  );
  const metrics = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Application', 'Contribution', 'ContributionMetrics.php'),
    'utf8',
  );
  assert.match(controller, /Request/);
  assert.match(controller, /bookshelf_id/);
  assert.match(metrics, /BookStackHierarchyQuery/);
  assert.match(metrics, /COUNT\(DISTINCT drv_kb_assets\.page_id\)/);
  assert.match(metrics, /users\.name/);
});

test('quality and RAG endpoints apply the shared visible bookshelf scope', () => {
  const quality = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Application', 'Quality', 'QualityIssueUnitQuery.php'),
    'utf8',
  );
  const rag = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Http', 'Controllers', 'V1', 'RagController.php'),
    'utf8',
  );
  for (const source of [quality, rag]) {
    assert.match(source, /BookStackHierarchyQuery/);
    assert.match(source, /pageIdsForBookshelf/);
    assert.match(source, /bookshelf_id/);
  }
});

test('quality and RAG endpoints expose filename identity instead of asset numbers alone', () => {
  const quality = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Application', 'Quality', 'QualityIssueUnitQuery.php'),
    'utf8',
  );
  const rag = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Http', 'Controllers', 'V1', 'RagController.php'),
    'utf8',
  );
  assert.match(quality, /DB::table\('drv_kb_assets'/);
  assert.match(quality, /asset_title/);
  assert.match(quality, /current_version/);
  assert.match(rag, /join\('drv_kb_assets'/);
  assert.match(rag, /asset_title/);
  assert.match(rag, /current_version/);
  assert.match(rag, /review_status/);
  assert.match(rag, /can_publish/);
});

test('quality API exposes Chinese conclusions and a help endpoint from one rule source', () => {
  assert.match(routes, /quality\/rules/);
  const quality = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Application', 'Quality', 'QualityIssueUnitQuery.php'),
    'utf8',
  );
  const help = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Http', 'Controllers', 'V1', 'QualityRulesController.php'),
    'utf8',
  );
  const explanation = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Application', 'Quality', 'QualityExplanation.php'),
    'utf8',
  );

  assert.match(quality, /QualityExplanation/);
  assert.match(quality, /describeCheck/);
  assert.match(help, /->help\(\)/);
  assert.match(explanation, /conclusion/);
  assert.match(explanation, /problems/);
  assert.match(explanation, /无法入库|允许入库/);
  assert.match(explanation, /修复/);
});

test('manual quality issues reuse chapter review units and preserve page evidence', () => {
  const controller = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Http', 'Controllers', 'V1', 'QualityController.php'),
    'utf8',
  );
  const query = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Application', 'Quality', 'QualityIssueUnitQuery.php'),
    'utf8',
  );
  const aggregator = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Application', 'Quality', 'QualityUnitAggregator.php'),
    'utf8',
  );

  assert.match(controller, /QualityIssueUnitQuery/);
  assert.doesNotMatch(controller, /drv_kb_quality_checks/);
  assert.match(query, /BookStackHierarchyQuery/);
  assert.match(query, /ReviewUnitResolver/);
  assert.match(query, /member_count/);
  assert.match(query, /checked_page_count/);
  assert.match(query, /members/);
  assert.match(query, /page_url/);
  assert.match(query, /chapter_url/);
  assert.match(query, /MAX\(quality_check_id\)/);
  assert.match(aggregator, /issue_page_count/);
  assert.match(aggregator, /blocked_page_count/);
  assert.match(aggregator, /min\(/);
  assert.match(aggregator, /本章节无法通过质量门禁/);
});

test('summary tells the browser whether the current user can perform write actions', () => {
  const controller = readFileSync(
    join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Http', 'Controllers', 'V1', 'SummaryController.php'),
    'utf8',
  );

  assert.match(controller, /BookStackIdentityAdapter/);
  assert.match(controller, /can_write/);
  assert.match(controller, /isAdministrator/);
});

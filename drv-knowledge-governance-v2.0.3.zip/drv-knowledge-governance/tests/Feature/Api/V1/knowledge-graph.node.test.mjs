import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '..');
const app = (...parts) => join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', ...parts);

test('knowledge graph API is routed through the authenticated governance API', () => {
  const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');

  assert.match(routes, /KnowledgeGraphController/);
  assert.match(routes, /Route::get\('knowledge-graph'/);
  assert.match(routes, /middleware\(\['web', 'auth'\]\)/);
});

test('knowledge graph backend classes exist and keep graph work isolated', () => {
  for (const path of [
    app('Application', 'Graph', 'GraphStatusMapper.php'),
    app('Application', 'Graph', 'GraphNodeFactory.php'),
    app('Application', 'Graph', 'GraphLinkFactory.php'),
    app('Application', 'Query', 'KnowledgeGraphQuery.php'),
    app('Http', 'Controllers', 'V1', 'KnowledgeGraphController.php'),
  ]) {
    assert.ok(existsSync(path), path);
  }
});

test('knowledge graph query uses visible page filtering and BookStack schema fallbacks', () => {
  const source = readFileSync(app('Application', 'Query', 'KnowledgeGraphQuery.php'), 'utf8');

  assert.match(source, /BookStackHierarchyQuery/);
  assert.match(source, /pageIdsForBookshelf/);
  assert.match(source, /filters\['bookshelf_id'\]/);
  assert.match(source, /Schema::hasTable/);
  assert.match(source, /entities/);
  assert.match(source, /bookshelves_books/);
  assert.match(source, /limit/);
  assert.match(source, /truncated/);
  assert.match(source, /include_pages/);
  assert.match(source, /direct_pages/);
  assert.match(source, /书籍直属页面/);
  assert.doesNotMatch(source, /isManual\s*\(/, 'chapters must not be limited to manual material');
});

test('knowledge graph is driven by every visible DrvDocs page instead of only governed assets', () => {
  const source = readFileSync(app('Application', 'Query', 'KnowledgeGraphQuery.php'), 'utf8');

  assert.match(source, /mergeStructureAndAssets/);
  assert.match(source, /normalizeStructurePage/);
  assert.match(source, /foreach\s*\(\$structure\s+as\s+\$pageId\s*=>\s*\$page\)/);
  assert.match(source, /has_asset/);
  assert.doesNotMatch(source, /limit\(self::MAX_LIMIT\s*\*\s*4\)/, 'asset rows must not be truncated before hierarchy aggregation');
});

test('knowledge graph preserves every deterministic bookshelf membership for a book', () => {
  const source = readFileSync(app('Application', 'Query', 'KnowledgeGraphQuery.php'), 'utf8');
  const nodeFactory = readFileSync(app('Application', 'Graph', 'GraphNodeFactory.php'), 'utf8');

  assert.match(source, /bookshelf_memberships/);
  assert.match(source, /shelfMemberships/);
  assert.match(source, /orderBy\('bookshelf_id'\)/);
  assert.doesNotMatch(source, /!isset\(\$result\[\$bookId\]\)/, 'multi-shelf books cannot keep only the first relation');
  assert.match(nodeFactory, /'book:'\s*\.\s*\$this->key\(\$data\['bookshelf_id'\]/, 'book node identity must be shelf-scoped');
});

test('knowledge graph supports legacy entity tables and the unified BookStack entities table', () => {
  const source = readFileSync(app('Application', 'Query', 'KnowledgeGraphQuery.php'), 'utf8');

  for (const type of ['page', 'book', 'chapter', 'bookshelf']) {
    assert.match(source, new RegExp(`where\\(['\"]type['\"],\\s*['\"]${type}['\"]\\)`), `entities.${type}`);
  }
  assert.match(source, /bookshelves_books/);
  assert.match(source, /chapter_id/);
});

test('knowledge graph DTO exposes required node link stats and meta fields', () => {
  const query = readFileSync(app('Application', 'Query', 'KnowledgeGraphQuery.php'), 'utf8');
  const nodeFactory = readFileSync(app('Application', 'Graph', 'GraphNodeFactory.php'), 'utf8');
  const linkFactory = readFileSync(app('Application', 'Graph', 'GraphLinkFactory.php'), 'utf8');

  for (const field of ['nodes', 'links', 'stats', 'meta', 'node_count', 'link_count', 'generated_at']) {
    assert.match(query, new RegExp(`['"]${field}['"]`), field);
  }
  for (const type of ['root', 'bookshelf', 'book', 'chapter', 'page']) {
    assert.match(nodeFactory, new RegExp(`['"]${type}['"]`), type);
  }
  assert.match(nodeFactory, /chapter_id/);
  assert.match(nodeFactory, /direct_pages/);
  assert.match(nodeFactory, /has_asset/);
  assert.match(linkFactory, /contains/);
  assert.match(linkFactory, /unique/);
});

test('knowledge graph status mapper normalizes review rag and quality states', () => {
  const source = readFileSync(app('Application', 'Graph', 'GraphStatusMapper.php'), 'utf8');

  for (const status of ['pending', 'partial', 'approved', 'verified', 'rejected', 'deprecated', 'unknown']) {
    assert.match(source, new RegExp(`['"]${status}['"]`), status);
  }
  for (const status of ['not_ingested', 'uploaded', 'unstart', 'parsing', 'parsed', 'failed', 'stale']) {
    assert.match(source, new RegExp(`['"]${status}['"]`), status);
  }
});

import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '..');
const app = join(root, 'bookstack-overlay', 'app', 'AI', 'Governance');
const read = (...parts) => readFileSync(join(app, ...parts), 'utf8');

test('review unit resolver makes configured manual shelves chapter based with page fallback', () => {
  const source = read('Application', 'Review', 'ReviewUnitResolver.php');
  assert.match(source, /AI_GOVERNANCE_CHAPTER_REVIEW_SHELVES/);
  assert.match(source, /芯片手册/);
  assert.match(source, /chapter_id/);
  assert.match(source, /chapter:/);
  assert.match(source, /page:/);
  assert.match(source, /direct_pages/);
});

test('review unit query prefers one Wiki asset per page and exposes legal actions', () => {
  const source = read('Application', 'Review', 'ReviewUnitQuery.php');
  assert.match(source, /CASE asset_type WHEN 'wiki' THEN 0 ELSE 1 END/);
  assert.match(source, /allowedTargets/);
  assert.match(source, /status_counts/);
  assert.match(source, /member_count/);
  assert.match(source, /bookshelf_id/);
  assert.match(source, /publishable_count/);
  assert.match(source, /can_publish/);
});

test('unit review command is transactional and reports processed skipped and blocked members', () => {
  const source = read('Application', 'Review', 'MarkReviewUnit.php');
  assert.match(source, /DB::transaction/);
  for (const field of ['processed', 'skipped', 'blocked']) assert.match(source, new RegExp(`['"]${field}['"]`));
  assert.match(source, /MarkReview/);
});

test('source assets can be governed without requesting formal Wiki publication', () => {
  const source = read('Application', 'Review', 'MarkReview.php');
  assert.doesNotMatch(source, /Only Wiki assets can enter formal review/);
  assert.match(source, /source_asset_review_only/);
  assert.match(source, /asset_type.*wiki.*wiki\.publish\.requested/s);
});

test('review unit routes require BookStack auth and administrator identity', () => {
  const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');
  const controller = read('Http', 'Controllers', 'V1', 'ReviewUnitController.php');
  assert.match(routes, /review-units/);
  assert.match(controller, /requireAdministrator/);
  assert.match(controller, /review_status/);
  assert.match(controller, /unit_key/);
});

test('approved review units expose an administrator one-click RAGFlow publish command', () => {
  const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');
  const controller = read('Http', 'Controllers', 'V1', 'ReviewUnitController.php');
  const command = read('Application', 'Rag', 'PublishReviewUnit.php');
  const resolver = read('Application', 'Rag', 'RagDatasetResolver.php');

  assert.match(routes, /review-units\/rag\/publish/);
  assert.match(controller, /function publish/);
  assert.match(controller, /PublishReviewUnit/);
  assert.match(controller, /requireAdministrator/);
  assert.match(command, /ReviewUnitQuery/);
  assert.match(command, /PublishWikiAsset/);
  assert.match(command, /published/);
  assert.match(command, /failed/);
  assert.match(resolver, /latestForAsset/);
  assert.match(resolver, /RAGFLOW_DATASET_ID_/);
  assert.match(resolver, /RAGFLOW_DEFAULT_DATASET_ID/);
});

test('review state machine can disclose allowed actions without bypassing transitions', () => {
  const source = read('Domain', 'StateTransition.php');
  assert.match(source, /allowedTargets/);
  assert.match(source, /assertAllowed/);
});

test('asset detail discloses legal review actions for the persisted current state', () => {
  const source = read('Http', 'Controllers', 'V1', 'AssetController.php');
  assert.match(source, /StateTransition/);
  assert.match(source, /allowedTargets/);
  assert.match(source, /allowed_actions/);
});

import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '..');
const app = join(root, 'bookstack-overlay', 'app', 'AI', 'Governance');

test('report generator uses permission-filtered pages and all required Markdown sections', () => {
  const source = readFileSync(join(app, 'Application', 'Report', 'GenerateGovernanceReport.php'), 'utf8');
  assert.match(source, /BookStackHierarchyQuery/);
  assert.match(source, /pageIdsForBookshelf/);
  assert.match(source, /书架范围/);
  for (const section of ['建设成果', '贡献明细', '审阅进展', 'RAG 健康', '质量问题', '知识缺口', '下周计划']) {
    assert.ok(source.includes(section), section);
  }
  for (const column of ['用户名', '贡献文档标题', '贡献文档书架名称', '贡献时间']) {
    assert.ok(source.includes(column), column);
  }
  assert.match(source, /\|\s*用户名\s*\|\s*贡献文档标题\s*\|\s*贡献文档书架名称\s*\|\s*贡献时间\s*\|/);
  assert.match(source, /contribution_details/);
  assert.match(source, /markdown_hash/);
});

test('contribution metrics count distinct pages instead of automated events', () => {
  const source = readFileSync(join(app, 'Application', 'Contribution', 'ContributionMetrics.php'), 'utf8');
  assert.match(source, /COUNT\(DISTINCT drv_kb_assets\.page_id\)/);
  assert.match(source, /BookStackHierarchyQuery/);
  assert.match(source, /pageIdsForBookshelf/);
  assert.match(source, /leftJoin\('users/);
  assert.match(source, /owner_name/);
  assert.match(source, /23:59:59/);
  assert.doesNotMatch(source, /drv_kb_audit_events/);
});

test('contribution API returns BookStack account names for display', () => {
  const controller = readFileSync(join(app, 'Http', 'Controllers', 'V1', 'ContributionController.php'), 'utf8');
  const metrics = readFileSync(join(app, 'Application', 'Contribution', 'ContributionMetrics.php'), 'utf8');
  assert.match(controller, /ContributionMetrics/);
  assert.match(metrics, /leftJoin\('users/);
  assert.match(metrics, /owner_name/);
  assert.doesNotMatch(controller + metrics, /用户 #/);
});

test('report write route exists inside administrator-protected API group', () => {
  const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');
  const controller = readFileSync(join(app, 'Http', 'Controllers', 'V1', 'ReportCommandController.php'), 'utf8');
  assert.match(routes, /Route::post\('reports'/);
  assert.match(routes, /ReportCommandController/);
  assert.match(controller, /bookshelf_id/);
  assert.match(controller, /filters\['bookshelf_id'\]/);
});

test('knowledge gaps can be deleted only through an audited administrator command', () => {
  const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');
  const controller = readFileSync(join(app, 'Http', 'Controllers', 'V1', 'GapCommandController.php'), 'utf8');
  const command = readFileSync(join(app, 'Application', 'Gap', 'DeleteKnowledgeGap.php'), 'utf8');
  const repository = readFileSync(join(app, 'Infrastructure', 'Persistence', 'GapRepository.php'), 'utf8');

  assert.match(routes, /Route::delete\('gaps\/\{gap_id\}'/);
  assert.match(controller, /function destroy/);
  assert.match(controller, /requireAdministrator/);
  assert.match(controller, /reason.*required\|string\|max:1000/s);
  assert.match(command, /DB::transaction/);
  assert.match(command, /gap\.deleted/);
  assert.match(command, /before_digest/);
  assert.match(repository, /function findById/);
  assert.match(repository, /function delete/);
});

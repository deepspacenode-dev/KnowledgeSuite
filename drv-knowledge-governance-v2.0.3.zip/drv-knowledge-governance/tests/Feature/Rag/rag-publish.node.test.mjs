import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const app = join(root, 'bookstack-overlay', 'app', 'AI', 'Governance');

test('formal publish requires reviewed or verified Wiki and deterministic identity', () => {
  const source = readFileSync(join(app, 'Application', 'Rag', 'PublishWikiAsset.php'), 'utf8');
  assert.match(source, /assertFormalPublishAllowed/);
  assert.match(source, /asset_type.*wiki/s);
  assert.match(source, /content_hash/);
  assert.match(source, /dataset_id/);
});

test('delete failure blocks upload and unchanged content returns skipped', () => {
  const source = readFileSync(join(app, 'Application', 'Rag', 'PublishWikiAsset.php'), 'utf8');
  assert.match(source, /RAG_DELETE_FAILED/);
  assert.match(source, /skipped/);
  assert.ok(source.indexOf('deleteDocument') < source.indexOf('uploadDocument'));
});

test('RAG gateway redacts credentials and validates non-empty document identity', () => {
  const source = readFileSync(join(app, 'Infrastructure', 'RagFlow', 'RagFlowGateway.php'), 'utf8');
  const deleteFunction = source.slice(source.indexOf('function deleteDocuments'), source.indexOf('function uploadDocument'));
  assert.match(source, /datasetId.*documentId/s);
  assert.match(source, /redact/);
  assert.match(deleteFunction, /assertApiSuccess/);
  assert.doesNotMatch(source, /getenv\('RAGFLOW_API_KEY'\).*throw/s);
});

test('formal publish configures source metadata and starts parsing after every upload', () => {
  const publish = readFileSync(join(app, 'Application', 'Rag', 'PublishWikiAsset.php'), 'utf8');
  const gateway = readFileSync(join(app, 'Infrastructure', 'RagFlow', 'RagFlowGateway.php'), 'utf8');

  assert.match(publish, /configureDocument/);
  assert.match(publish, /startParsing/);
  assert.ok(publish.indexOf('uploadDocument') < publish.indexOf('configureDocument'));
  assert.ok(publish.indexOf('configureDocument') < publish.indexOf('startParsing'));
  for (const field of ['page_id', 'page_url', 'source_key', 'content_ref', 'material_type', 'module', 'chip', 'project']) {
    assert.match(publish, new RegExp(field));
  }
  assert.match(publish, /normalizeDomainMetadata/);
  assert.match(publish, /array_replace\(\$ragMetadata/);
  assert.match(gateway, /function configureDocument/);
  assert.match(gateway, /function startParsing/);
  assert.match(gateway, /meta_fields/);
  assert.match(gateway, /parser_config/);
  assert.match(gateway, /\/chunks/);
});

test('knowledge removal deletes markdown and image documents before disabling future RAG publish', () => {
  const removal = readFileSync(join(app, 'Application', 'Rag', 'RemoveWikiAssetFromRag.php'), 'utf8');
  const publish = readFileSync(join(app, 'Application', 'Rag', 'PublishWikiAsset.php'), 'utf8');
  const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');

  assert.match(routes, /Route::delete\('assets\/\{asset_id\}\/rag'/);
  assert.match(removal, /deleteDocuments/);
  assert.match(removal, /image_documents_json/);
  assert.match(removal, /rag_enabled/);
  assert.match(removal, /parse_status.*disabled/s);
  assert.match(removal, /last_action_result.*deleted/s);
  assert.match(removal, /rag\.removed/);
  assert.ok(removal.indexOf('deleteDocuments') < removal.indexOf("'rag_enabled'"));
  assert.match(publish, /RAG_PUBLISH_DISABLED/);
});

test('manual retry resolves the dataset from request, snapshot, or default configuration', () => {
  const controller = readFileSync(join(app, 'Http', 'Controllers', 'V1', 'RagCommandController.php'), 'utf8');
  const resolver = readFileSync(join(app, 'Application', 'Rag', 'RagDatasetResolver.php'), 'utf8');
  assert.match(controller, /nullable\|string\|max:255/);
  assert.match(controller, /RagDatasetResolver/);
  assert.match(resolver, /RAGFLOW_DEFAULT_DATASET_ID/);
  assert.match(resolver, /latestForAsset/);
  assert.match(controller, /尚未配置 RAGFlow 数据集/);
});

test('RAG sync both publishes pending Markdown and refreshes parsing snapshots from RAGFlow', () => {
  const refresh = readFileSync(join(app, 'Application', 'Rag', 'RefreshRagSnapshots.php'), 'utf8');
  const sync = readFileSync(join(app, 'Http', 'Controllers', 'V1', 'SyncController.php'), 'utf8');
  const gateway = readFileSync(join(app, 'Infrastructure', 'RagFlow', 'RagFlowGateway.php'), 'utf8');

  assert.match(refresh, /documentStatus/);
  assert.match(refresh, /latestForAsset/);
  assert.match(refresh, /parse_status/);
  assert.match(refresh, /chunk_count/);
  assert.match(sync, /RefreshRagSnapshots/);
  assert.match(sync, /status_refresh/);
  assert.match(gateway, /chunk_count/);
});

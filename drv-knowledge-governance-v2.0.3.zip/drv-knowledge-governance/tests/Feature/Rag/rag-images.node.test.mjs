import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const app = join(root, 'bookstack-overlay', 'app', 'AI', 'Governance');

test('Wiki image collector supports Markdown and HTML images with same-origin limits', () => {
    const source = readFileSync(join(app, 'Infrastructure', 'BookStack', 'ArticleImageCollector.php'), 'utf8');

    assert.match(source, /!\\\[/);
    assert.match(source, /<img/);
    assert.match(source, /RAGFLOW_IMAGE_MAX_BYTES/);
    assert.match(source, /RAGFLOW_IMAGE_ALLOWED_EXTENSIONS/);
    assert.match(source, /BOOKSTACK_TOKEN_ID/);
    assert.match(source, /sameOrigin/);
});

test('formal publish hashes, replaces and records associated image documents', () => {
    const publish = readFileSync(join(app, 'Application', 'Rag', 'PublishWikiAsset.php'), 'utf8');
    const gateway = readFileSync(join(app, 'Infrastructure', 'RagFlow', 'RagFlowGateway.php'), 'utf8');
    const migration = readFileSync(join(root, 'bookstack-overlay', 'database', 'migrations', '2026_07_05_000006_create_drv_kb_rag_snapshot_and_audit_events_tables.php'), 'utf8');
    const upgradeMigration = readFileSync(join(root, 'bookstack-overlay', 'database', 'migrations', '2026_07_06_000007_add_image_documents_to_drv_kb_rag_snapshot.php'), 'utf8');

    assert.match(publish, /ArticleImageCollector/);
    assert.match(publish, /image_documents_json/);
    assert.match(publish, /publishHash/);
    assert.match(publish, /deleteDocuments/);
    assert.match(publish, /uploadBinary/);
    assert.match(publish, /RAG_IMAGE_UPLOAD_FAILED/);
    assert.match(gateway, /function uploadBinary/);
    assert.match(gateway, /function deleteDocuments/);
    assert.match(migration, /image_documents_json/);
    assert.match(upgradeMigration, /Schema::hasColumn/);
});

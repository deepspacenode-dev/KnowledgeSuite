import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const app = join(root, 'bookstack-overlay', 'app', 'AI', 'Governance');
const profilePath = join(root, '..', '..', 'contracts', 'ragflow', 'chat-assistant.v2.json');

test('BookStack exposes an authenticated same-origin RAGFlow chat proxy', () => {
  const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');
  const controllerPath = join(app, 'Http', 'Controllers', 'V2', 'ChatController.php');
  assert.ok(existsSync(controllerPath));
  const controller = readFileSync(controllerPath, 'utf8');
  const gateway = readFileSync(join(app, 'Infrastructure', 'RagFlow', 'RagFlowGateway.php'), 'utf8');

  assert.match(routes, /chat\/completions/);
  assert.match(routes, /\['web', 'auth'\]/);
  assert.match(controller, /drvknowledge\.chat-request\.v2/);
  assert.match(controller, /max:4000/);
  assert.match(gateway, /function chatCompletion/);
  assert.match(gateway, /\/api\/v1\/chat\/completions/);
  assert.match(gateway, /RAGFLOW_CHAT_ID/);
  assert.match(gateway, /RAGFLOW_CHAT_BASE_URL/);
  assert.match(gateway, /RAGFLOW_CHAT_API_KEY/);
  assert.match(gateway, /function chatClient/);
  assert.match(gateway, /'stream'\s*=>\s*false/);
  assert.match(gateway, /isAllowedBookStackUrl/);
});

test('BookStack governance entry forwards only supported dashboard views', () => {
  const controller = readFileSync(join(app, 'Http', 'Controllers', 'GovernancePageController.php'), 'utf8');
  assert.match(controller, /private const KNOWN_VIEWS/);
  for (const view of ['overview', 'assets', 'contributions', 'quality', 'rag', 'knowledge-graph', 'gaps', 'reports']) {
    assert.match(controller, new RegExp(`'${view.replace('-', '\\-')}'`));
  }
  assert.match(controller, /in_array\(\$requestedView, self::KNOWN_VIEWS, true\)/);
  assert.match(controller, /'view'\s*=>\s*\$view/);
});

test('versioned chat profile is conservative, quoted, and knowledge grounded', () => {
  assert.ok(existsSync(profilePath));
  const profile = JSON.parse(readFileSync(profilePath, 'utf8'));
  assert.equal(profile.schema_version, 'drvknowledge.ragflow-chat-profile.v2');
  assert.equal(profile.prompt_config.quote, true);
  assert.equal(profile.prompt_config.parameters[0].key, 'knowledge');
  assert.match(profile.prompt_config.system, /\{knowledge\}/);
  assert.match(profile.prompt_config.system, /不得编造/);
  assert.match(profile.prompt_config.system, /BookStack/);
  assert.equal(profile.llm_setting.temperature, 0.1);
  assert.equal(profile.similarity_threshold, 0.32);
  assert.equal(profile.vector_similarity_weight, 0.30);
  assert.equal(profile.top_n, 6);
  assert.equal(profile.top_k, 128);
});

test('browser assistant uses runtime Widget configuration and never commits RAGFlow credentials', () => {
  const source = readFileSync(join(root, 'bookstack-overlay', 'public', 'ai-assistant', 'ai-assistant-governance-entry.js'), 'utf8');
  assert.match(source, /\/api\/ai-governance\/v2\/assistant\/config/);
  assert.match(source, /data-assistant-widget-host/);
  assert.match(source, /document\.createElement\('iframe'\)/);
  assert.doesNotMatch(source, /\/api\/ai-governance\/v2\/chat\/completions/);
  assert.doesNotMatch(source, /chatPayload|session_token|renderMarkdown/);
  assert.doesNotMatch(source, /RAGFLOW_WIDGET_AUTH|RAGFLOW_API_KEY|Authorization:\s*Bearer|auth=[A-Za-z0-9_-]{16,}/);
});

import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const app = join(root, 'bookstack-overlay', 'app', 'AI', 'Governance');

test('authenticated assistant config exposes a validated official RAGFlow widget', () => {
  const routes = readFileSync(join(root, 'bookstack-overlay', 'routes', 'ai-governance.php'), 'utf8');
  const controllerPath = join(app, 'Http', 'Controllers', 'V2', 'AssistantConfigController.php');
  const configPath = join(app, 'Application', 'Assistant', 'AssistantConfig.php');

  assert.ok(existsSync(controllerPath), 'AssistantConfigController.php');
  assert.ok(existsSync(configPath), 'AssistantConfig.php');
  assert.match(routes, /Route::get\('assistant\/config', AssistantConfigController::class\)/);
  assert.match(routes, /Route::prefix\('api\/ai-governance\/v2'\)->middleware\(\['web', 'auth'\]\)/);

  const controller = readFileSync(controllerPath, 'utf8');
  const config = readFileSync(configPath, 'utf8');
  assert.match(controller, /AssistantConfig/);
  assert.match(controller, /ApiResponse::success\(\$config->toArray\(\)\)/);
  assert.match(config, /drvknowledge\.assistant-config\.v2/);
  for (const name of [
    'RAGFLOW_WIDGET_ENABLED',
    'RAGFLOW_WIDGET_BASE_URL',
    'RAGFLOW_WIDGET_PATH',
    'RAGFLOW_WIDGET_SHARED_ID',
    'RAGFLOW_WIDGET_AUTH',
    'RAGFLOW_WIDGET_ALLOW_MEDIA',
    'RAGFLOW_WIDGET_LOAD_TIMEOUT_MS',
    'RAGFLOW_WEB_URL',
  ]) assert.match(config, new RegExp(name));
  assert.match(config, /\/chats\/widget/);
  assert.match(config, /env\('RAGFLOW_WIDGET_PATH', '\/chats\/widget'\)/);
  assert.match(config, /FILTER_VALIDATE_URL/);
  assert.match(config, /parse_url/);
  assert.match(config, /http_build_query\([^)]*PHP_QUERY_RFC3986/s);
  assert.match(config, /'from'\s*=>\s*'chat'/);
  assert.match(config, /'mode'\s*=>\s*'window'/);
  assert.match(config, /'locale'\s*=>\s*'zh'/);
  assert.match(config, /max\(3000, min\(\(int\) env\('RAGFLOW_WIDGET_LOAD_TIMEOUT_MS', 12000\), 60000\)\)/);
});

test('widget configuration never contains a committed environment credential', () => {
  const config = readFileSync(join(app, 'Application', 'Assistant', 'AssistantConfig.php'), 'utf8');
  assert.doesNotMatch(config, /auth=[A-Za-z0-9_-]{16,}/);
  assert.doesNotMatch(config, /ragflow-[A-Za-z0-9_-]{12,}/i);
});

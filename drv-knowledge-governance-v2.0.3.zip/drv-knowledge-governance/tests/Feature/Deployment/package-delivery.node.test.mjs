import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');

test('delivery package includes install, rollback, migration and operator documents', () => {
    for (const path of [
        'scripts/install.ps1',
        'scripts/uninstall.ps1',
        'scripts/install.sh',
        'scripts/uninstall.sh',
        'scripts/migrate-json.php',
        'scripts/verify-package.ps1',
        'README.md',
        'DEPLOY.md',
        'TEST_CHECKLIST.md',
        'CHANGELOG.md',
        '.env.example',
    ]) {
        assert.ok(existsSync(join(root, path)), path);
    }
});

test('delivery archive excludes development artifacts while retaining dotfile configuration examples', () => {
    const verify = readFileSync(join(root, 'scripts', 'verify-package.ps1'), 'utf8');

    assert.match(verify, /\.superpowers/);
    assert.match(verify, /excludedRootDirectories/);
    assert.match(verify, /ZipFileExtensions/);
    assert.match(verify, /SHA256SUMS\.json/);
});

test('Linux container installers validate the BookStack root and preserve database data on uninstall', () => {
    const install = readFileSync(join(root, 'scripts', 'install.sh'), 'utf8');
    const uninstall = readFileSync(join(root, 'scripts', 'uninstall.sh'), 'utf8');

    assert.match(install, /DRVDOCS_AI_GOVERNANCE_START/);
    assert.match(install, /app\/Config\/app\.php/);
    assert.match(install, /AiGovernanceServiceProvider::class/);
    assert.doesNotMatch(install, /cat >> .*routes\/web\.php/);
    assert.match(install, /artisan migrate --force/);
    assert.match(uninstall, /PRESERVED/);
    assert.doesNotMatch(uninstall, /DROP TABLE|migrate:rollback/i);
});

test('all delivery paths include the governance floating-entry stylesheet', () => {
    const dockerfile = readFileSync(join(root, 'docker', 'bookstack', 'Dockerfile'), 'utf8');
    const installSh = readFileSync(join(root, 'scripts', 'install.sh'), 'utf8');
    const installPs = readFileSync(join(root, 'scripts', 'install.ps1'), 'utf8');
    const uninstallSh = readFileSync(join(root, 'scripts', 'uninstall.sh'), 'utf8');
    const uninstallPs = readFileSync(join(root, 'scripts', 'uninstall.ps1'), 'utf8');

    assert.match(dockerfile, /ai-assistant-governance-entry\.css/);
    assert.match(installSh, /public\/ai-assistant\/ai-assistant-governance-entry\.css/);
    assert.match(installPs, /public\\ai-assistant\\ai-assistant-governance-entry\.css/);
    assert.match(uninstallSh, /public\/ai-assistant\/ai-assistant-governance-entry\.css/);
    assert.match(uninstallPs, /public\\ai-assistant\\ai-assistant-governance-entry\.css/);
});

test('all delivery paths include the Bloub avatar runtime and attribution directory', () => {
    const dockerfile = readFileSync(join(root, 'docker', 'bookstack', 'Dockerfile'), 'utf8');
    const installSh = readFileSync(join(root, 'scripts', 'install.sh'), 'utf8');
    const installPs = readFileSync(join(root, 'scripts', 'install.ps1'), 'utf8');
    const uninstallSh = readFileSync(join(root, 'scripts', 'uninstall.sh'), 'utf8');
    const uninstallPs = readFileSync(join(root, 'scripts', 'uninstall.ps1'), 'utf8');

    for (const source of [dockerfile, installSh, installPs, uninstallSh, uninstallPs]) {
        assert.match(source, /vendor[\\/]bloub/);
    }
});

test('governance image packages the runtime cache-permission hook and marks it executable', () => {
    const dockerfile = readFileSync(join(root, 'docker', 'bookstack', 'Dockerfile'), 'utf8');
    const initScriptPath = join(root, 'docker', 'bookstack', 'root', 'custom-cont-init.d', '90-drv-governance-permissions');

    assert.ok(existsSync(initScriptPath), initScriptPath);
    assert.match(dockerfile, /COPY docker\/bookstack\/root\/custom-cont-init\.d\/90-drv-governance-permissions \/custom-cont-init\.d\/90-drv-governance-permissions/);
    assert.match(dockerfile, /chmod 0755 \/custom-cont-init\.d\/90-drv-governance-permissions/);

    const initScript = readFileSync(initScriptPath, 'utf8');
    assert.match(initScript, /chown -R abc:abc \/app\/www\/bootstrap\/cache/);
    assert.match(initScript, /chmod -R u\+rwX,g\+rwX \/app\/www\/bootstrap\/cache/);
});

test('installer requires backups and marks only owned provider integration', () => {
    const install = readFileSync(join(root, 'scripts', 'install.ps1'), 'utf8');
    const uninstall = readFileSync(join(root, 'scripts', 'uninstall.ps1'), 'utf8');

    assert.match(install, /DRVDOCS_AI_GOVERNANCE_START/);
    assert.match(install, /app\\Config\\app\.php/);
    assert.match(install, /AiGovernanceServiceProvider::class/);
    assert.match(install, /Backup/);
    assert.match(install, /SupportsShouldProcess/);
    assert.match(install, /WhatIfPreference/);
    assert.match(uninstall, /DRVDOCS_AI_GOVERNANCE_START/);
    assert.doesNotMatch(uninstall, /drop.*drv_kb_/i);
});

test('legacy migration defaults to dry-run and never promotes raw reviews into formal Wiki review state', () => {
    const source = readFileSync(join(root, 'scripts', 'migrate-json.php'), 'utf8');

    assert.match(source, /--apply/);
    assert.match(source, /legacy\.review\.imported/);
    assert.match(source, /DB::transaction/);
    assert.doesNotMatch(source, /drv_kb_reviews.*insert/s);
});

<?php

declare(strict_types=1);

$bookStackRoot = getenv('BOOKSTACK_ROOT') ?: '/app/www';
require rtrim($bookStackRoot, '/\\') . '/vendor/autoload.php';

$packageRoot = dirname(__DIR__);
spl_autoload_register(static function (string $class) use ($packageRoot): void {
    $prefix = 'BookStack\\AI\\Governance\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = str_replace('\\', DIRECTORY_SEPARATOR, substr($class, strlen($prefix))) . '.php';
    $path = $packageRoot . '/bookstack-overlay/app/AI/Governance/' . $relative;
    if (is_file($path)) {
        require $path;
    }
});

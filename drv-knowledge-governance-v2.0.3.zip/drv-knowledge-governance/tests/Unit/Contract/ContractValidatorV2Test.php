<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Tests\Unit\Contract;

use BookStack\AI\Governance\Application\Contract\ContractValidatorV2;
use DomainException;
use PHPUnit\Framework\TestCase;

final class ContractValidatorV2Test extends TestCase
{
    public function test_valid_worker_result_is_accepted(): void
    {
        (new ContractValidatorV2())->assertWikiResult($this->fixtureResult());
        self::assertTrue(true);
    }

    public function test_unknown_write_field_is_rejected(): void
    {
        $result = $this->fixtureResult();
        $result['publish_directly'] = true;
        $this->expectException(DomainException::class);
        $this->expectExceptionMessage('CONTRACT_INVALID');
        (new ContractValidatorV2())->assertWikiResult($result);
    }

    public function test_worker_cannot_enable_rag(): void
    {
        $result = $this->fixtureResult();
        $result['front_matter']['rag_enabled'] = true;
        $this->expectException(DomainException::class);
        (new ContractValidatorV2())->assertWikiResult($result);
    }

    public function test_offline_intake_is_accepted(): void
    {
        (new ContractValidatorV2())->assertIntake($this->fixtureIntake());
        self::assertTrue(true);
    }

    public function test_unknown_intake_compiler_is_rejected(): void
    {
        $intake = $this->fixtureIntake();
        $intake['requested_workflow'] = 'external_cloud';
        $this->expectException(DomainException::class);
        $this->expectExceptionMessage('CONTRACT_INVALID');
        (new ContractValidatorV2())->assertIntake($intake);
    }

    public function test_out_of_range_quality_score_is_rejected(): void
    {
        $result = $this->fixtureResult();
        $result['quality_report']['score'] = 101;
        $this->expectException(DomainException::class);
        $this->expectExceptionMessage('CONTRACT_INVALID');
        (new ContractValidatorV2())->assertWikiResult($result);
    }

    public function test_unknown_nested_source_field_is_rejected(): void
    {
        $result = $this->fixtureResult();
        $result['sources'][0]['publish'] = true;
        $this->expectException(DomainException::class);
        $this->expectExceptionMessage('CONTRACT_INVALID');
        (new ContractValidatorV2())->assertWikiResult($result);
    }

    public function test_incomplete_intake_client_is_rejected(): void
    {
        $intake = $this->fixtureIntake();
        unset($intake['client']['version']);
        $this->expectException(DomainException::class);
        $this->expectExceptionMessage('CONTRACT_INVALID');
        (new ContractValidatorV2())->assertIntake($intake);
    }

    /** @return array<string, mixed> */
    private function fixtureIntake(): array
    {
        return [
            'schema_version' => 'drvknowledge.intake-request.v2',
            'trace_id' => 'trace-intake-001',
            'client_submission_id' => 'intake-test-001',
            'page_id' => 42,
            'canonical_url' => 'http://bookstack.local/books/a/page/b',
            'title' => '诊断案例',
            'material_type' => 'cases',
            'content_hash' => str_repeat('a', 64),
            'requested_workflow' => 'offline',
            'source_key' => 'bookstack_page:42',
            'content_ref' => 'bookstack:page:42',
            'client' => ['name' => 'test', 'version' => '2.0.0'],
        ];
    }

    /** @return array<string, mixed> */
    private function fixtureResult(): array
    {
        return [
            'schema_version' => 'drvknowledge.wiki-result.v2',
            'trace_id' => 'trace-contract-001',
            'task_id' => '7',
            'result_id' => 'result:7:1',
            'generated_at' => '2026-08-30T08:00:00Z',
            'source_key' => 'bookstack_page:42',
            'source_version' => 1,
            'compiler' => ['system' => 'drvknowledge_worker', 'workflow' => 'test', 'model' => null],
            'status' => 'draft',
            'title' => '诊断案例',
            'markdown' => "# 诊断案例\n",
            'front_matter' => [
                'title' => '诊断案例', 'status' => 'draft', 'rag_enabled' => false,
                'source_key' => 'bookstack_page:42', 'material_type' => 'cases',
            ],
            'sources' => [[
                'title' => '诊断案例', 'url' => 'http://bookstack.local/books/a/page/b',
                'source_key' => 'bookstack_page:42', 'section' => null,
            ]],
            'quality_report' => ['score' => 80, 'warnings' => [], 'reject_reasons' => []],
            'relations' => [],
        ];
    }
}

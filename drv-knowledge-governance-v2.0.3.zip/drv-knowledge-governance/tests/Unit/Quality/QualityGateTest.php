<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Tests\Unit\Quality;

use BookStack\AI\Governance\Application\Quality\QualityGate;
use PHPUnit\Framework\TestCase;

final class QualityGateTest extends TestCase
{
    public function test_missing_source_is_blocked(): void
    {
        $result = (new QualityGate())->evaluate(['metadata' => [], 'sources' => []]);
        self::assertFalse($result['allowed']);
        self::assertContains('missing_source', $result['reject_reasons']);
    }

    public function test_complete_reviewed_document_is_allowed(): void
    {
        $result = (new QualityGate())->evaluate([
            'metadata' => [
                'owner' => 'owner', 'status' => 'reviewed', 'module' => 'driver',
                'platform' => 'linux', 'material_type' => 'manual', 'rag_enabled' => true,
            ],
            'sources' => ['bookstack_page:1'],
        ]);
        self::assertTrue($result['allowed']);
        self::assertSame(100, $result['quality_score']);
    }

    public function test_reviewed_may_keep_rag_disabled_as_warning(): void
    {
        $result = (new QualityGate())->evaluate([
            'metadata' => [
                'owner' => 'owner', 'status' => 'draft', 'module' => 'driver',
                'platform' => 'linux', 'material_type' => 'manual', 'rag_enabled' => false,
            ],
            'sources' => ['bookstack_page:1'],
        ], 'reviewed');
        self::assertTrue($result['allowed']);
        self::assertContains('rag_disabled_in_source', $result['warnings']);
    }

    public function test_verified_uses_strict_threshold(): void
    {
        $result = (new QualityGate())->evaluate([
            'metadata' => ['owner' => null, 'module' => null, 'platform' => 'linux', 'material_type' => 'manual'],
            'sources' => ['bookstack_page:1'],
        ], 'verified');
        self::assertFalse($result['allowed']);
        self::assertContains('verified_score_below_minimum', $result['reject_reasons']);
    }
}

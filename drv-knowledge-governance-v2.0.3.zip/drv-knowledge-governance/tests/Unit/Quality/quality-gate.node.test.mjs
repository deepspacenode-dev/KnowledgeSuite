import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const domain = join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Application', 'Quality');
const rules = JSON.parse(readFileSync(join(domain, 'quality-rules.json'), 'utf8'));

const evaluate = (document) => {
  const warnings = [];
  const rejected = [];
  let score = 100;
  for (const field of rules.required_metadata) {
    if (document.metadata?.[field] === undefined || document.metadata[field] === '') {
      score -= rules.penalties.missing_required_metadata;
      warnings.push(`missing:${field}`);
    }
  }
  if (!document.sources?.length) {
    score -= rules.penalties.missing_source;
    rejected.push('missing_source');
  }
  if (document.metadata?.status === 'deprecated') rejected.push('deprecated');
  if (document.metadata?.rag_enabled === false) warnings.push('rag_disabled_in_source');
  if (score < rules.minimum_score) rejected.push('score_below_minimum');
  return { score: Math.max(0, score), warnings, rejected };
};

test('missing source always blocks ingestion', () => {
  const result = evaluate({ metadata: { owner: 'a', status: 'reviewed', module: 'm', platform: 'p', material_type: 'manual', rag_enabled: true }, sources: [] });
  assert.ok(result.rejected.includes('missing_source'));
});

test('deprecated is blocked while source rag flag is only a governance warning', () => {
  assert.ok(evaluate({ metadata: { status: 'deprecated' }, sources: ['x'] }).rejected.includes('deprecated'));
  assert.ok(evaluate({ metadata: { rag_enabled: false }, sources: ['x'] }).warnings.includes('rag_disabled_in_source'));
  assert.ok(!evaluate({ metadata: { rag_enabled: false }, sources: ['x'] }).rejected.includes('rag_disabled'));
});

test('complete reviewed document passes the deterministic gate', () => {
  const result = evaluate({
    metadata: { owner: 'a', status: 'reviewed', module: 'm', platform: 'p', material_type: 'manual', rag_enabled: true },
    sources: ['bookstack_page:1'],
  });
  assert.equal(result.score, 100);
  assert.deepEqual(result.rejected, []);
});

test('PHP quality gate consumes the shared deterministic rules and never calls a model', () => {
  const source = readFileSync(join(domain, 'QualityGate.php'), 'utf8');
  assert.match(source, /quality-rules\.json/);
  assert.doesNotMatch(source, /OpenAI|chat\/completions|RAGFlow.*model|curl/i);
});

test('review gate builds its document from the stored asset, not browser content', () => {
  const source = readFileSync(join(root, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Application', 'Review', 'MarkReview.php'), 'utf8');
  assert.match(source, /documentFromAsset/);
  assert.doesNotMatch(source, /\$command\['document'\]/);
});

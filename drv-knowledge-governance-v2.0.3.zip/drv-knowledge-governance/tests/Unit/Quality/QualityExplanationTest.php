<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Tests\Unit\Quality;

use BookStack\AI\Governance\Application\Quality\QualityExplanation;
use PHPUnit\Framework\TestCase;

final class QualityExplanationTest extends TestCase
{
    public function test_blocking_reasons_are_explained_in_chinese(): void
    {
        $result = (new QualityExplanation())->describeCheck([
            'score' => 60,
            'warnings_json' => json_encode(['missing:owner'], JSON_THROW_ON_ERROR),
            'reject_reasons_json' => json_encode(['missing_source', 'score_below_minimum'], JSON_THROW_ON_ERROR),
        ]);

        self::assertSame('blocked', $result['gate_result']);
        self::assertStringContainsString('无法入库', $result['conclusion']);
        self::assertContains('缺少可追溯来源', $result['blocking_reasons']);
        self::assertSame('缺少负责人', $result['problems'][2]['title']);
        self::assertSame('警告', $result['problems'][2]['severity']);
    }

    public function test_help_uses_the_same_gate_thresholds_and_rules(): void
    {
        $help = (new QualityExplanation())->help();

        self::assertSame(70, $help['minimum_score']);
        self::assertSame(90, $help['verified_minimum_score']);
        self::assertSame('负责人', $help['metadata_rules'][0]['name']);
        self::assertTrue($help['hard_blocks'][0]['blocking']);
        self::assertStringContainsString('缺少可追溯来源', $help['hard_blocks'][0]['name']);
        self::assertSame('文章仍为草稿', $help['workflow_rules'][1]['name']);
    }
}

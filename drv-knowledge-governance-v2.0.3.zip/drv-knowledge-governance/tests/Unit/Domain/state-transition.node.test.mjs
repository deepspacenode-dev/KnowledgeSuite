import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const packageRoot = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const domainRoot = join(packageRoot, 'bookstack-overlay', 'app', 'AI', 'Governance', 'Domain');
const machine = JSON.parse(readFileSync(join(domainRoot, 'state-machines.json'), 'utf8'));

const canMove = (kind, from, to) => machine[kind].transitions[from]?.includes(to) ?? false;

test('compile state machine follows the approved retry lifecycle', () => {
  assert.equal(canMove('compile', 'queued', 'running'), true);
  assert.equal(canMove('compile', 'running', 'succeeded'), true);
  assert.equal(canMove('compile', 'running', 'retry_wait'), true);
  assert.equal(canMove('compile', 'retry_wait', 'queued'), true);
  assert.equal(canMove('compile', 'retry_wait', 'failed'), false);
  assert.equal(canMove('compile', 'failed', 'queued'), false);
  assert.equal(canMove('compile', 'queued', 'succeeded'), false);
});

test('review state machine requires pending review and supports source recheck', () => {
  assert.equal(canMove('review', 'draft', 'pending_review'), true);
  assert.equal(canMove('review', 'pending_review', 'reviewed'), true);
  assert.equal(canMove('review', 'pending_review', 'verified'), false);
  assert.equal(canMove('review', 'reviewed', 'verified'), true);
  assert.equal(canMove('review', 'verified', 'need_recheck'), true);
  assert.equal(canMove('review', 'need_fix', 'pending_review'), true);
});

test('only reviewed and verified assets may enter formal RAG publishing', () => {
  assert.deepEqual(machine.review.formal_publish_allowed, ['reviewed', 'verified']);
  for (const status of ['draft', 'pending_review', 'need_fix', 'need_recheck', 'deprecated']) {
    assert.equal(machine.review.formal_publish_allowed.includes(status), false, status);
  }
});

test('formal RAG queueing checks review status before any technical transition', () => {
  const source = readFileSync(join(domainRoot, 'StateTransition.php'), 'utf8');
  assert.match(source, /assertFormalRagTransitionAllowed/);
  assert.match(source, /assertFormalPublishAllowed\(\$reviewStatus\)/);
  assert.match(source, /self::assertAllowed\('rag'/);
});

test('RAG ready requires parsing and every valid state can be disabled', () => {
  assert.equal(canMove('rag', 'not_ingested', 'queued'), true);
  assert.equal(canMove('rag', 'queued', 'parsing'), true);
  assert.equal(canMove('rag', 'parsing', 'ready'), true);
  assert.equal(canMove('rag', 'queued', 'ready'), false);

  for (const status of machine.rag.states.filter((value) => value !== 'disabled')) {
    assert.equal(canMove('rag', status, 'disabled'), true, status);
  }
});

test('PHP domain files declare every approved value', () => {
  const expected = {
    AssetType: ['source', 'wiki'],
    CompileStatus: ['queued', 'running', 'succeeded', 'retry_wait', 'failed'],
    ReviewStatus: ['draft', 'pending_review', 'reviewed', 'verified', 'need_fix', 'need_recheck', 'deprecated'],
    RagStatus: ['not_ingested', 'queued', 'parsing', 'ready', 'stale', 'failed', 'disabled'],
    ActionResult: ['created', 'skipped', 'updated', 'moved', 'failed'],
  };

  for (const [type, values] of Object.entries(expected)) {
    const source = readFileSync(join(domainRoot, `${type}.php`), 'utf8');
    for (const value of values) assert.match(source, new RegExp(`= '${value}'`), `${type}:${value}`);
  }
});

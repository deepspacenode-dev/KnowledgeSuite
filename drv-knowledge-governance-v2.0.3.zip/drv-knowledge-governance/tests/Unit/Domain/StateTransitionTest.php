<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Tests\Unit\Domain;

use BookStack\AI\Governance\Domain\CompileStatus;
use BookStack\AI\Governance\Domain\RagStatus;
use BookStack\AI\Governance\Domain\ReviewStatus;
use BookStack\AI\Governance\Domain\StateTransition;
use DomainException;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

final class StateTransitionTest extends TestCase
{
    #[DataProvider('allowedTransitions')]
    public function test_allowed_transition(string $machine, string $from, string $to): void
    {
        StateTransition::assertAllowed($machine, $from, $to);
        self::addToAssertionCount(1);
    }

    public static function allowedTransitions(): iterable
    {
        yield ['compile', CompileStatus::Queued->value, CompileStatus::Running->value];
        yield ['compile', CompileStatus::Running->value, CompileStatus::RetryWait->value];
        yield ['review', ReviewStatus::Draft->value, ReviewStatus::PendingReview->value];
        yield ['review', ReviewStatus::Reviewed->value, ReviewStatus::Verified->value];
        yield ['rag', RagStatus::Queued->value, RagStatus::Parsing->value];
        yield ['rag', RagStatus::Parsing->value, RagStatus::Ready->value];
    }

    public function test_disallowed_transition_throws(): void
    {
        $this->expectException(DomainException::class);
        StateTransition::assertAllowed('review', ReviewStatus::Draft->value, ReviewStatus::Verified->value);
    }

    public function test_draft_cannot_be_published_to_rag(): void
    {
        $this->expectException(DomainException::class);
        StateTransition::assertFormalPublishAllowed(ReviewStatus::Draft);
    }

    public function test_draft_cannot_enter_formal_rag_queue(): void
    {
        $this->expectException(DomainException::class);
        StateTransition::assertFormalRagTransitionAllowed(
            ReviewStatus::Draft,
            RagStatus::NotIngested,
            RagStatus::Queued,
        );
    }

    public function test_ready_requires_successful_technical_snapshot(): void
    {
        $this->expectException(DomainException::class);
        StateTransition::assertRagReadyAllowed(
            ReviewStatus::Reviewed,
            RagStatus::Parsing,
            RagStatus::Ready,
            false,
        );
    }
}

<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Tests\Unit\Compatibility;

use PHPUnit\Framework\TestCase;

final class CompatibilityManifestTest extends TestCase
{
    public function test_manifest_declares_safe_installation_contract(): void
    {
        $manifest = json_decode(
            file_get_contents(__DIR__ . '/../../../compat/supported-bookstack.json'),
            true,
            512,
            JSON_THROW_ON_ERROR,
        );

        self::assertSame('>=8.2 <8.6', $manifest['php']);
        self::assertNotEmpty($manifest['bookstack']);
        self::assertNotEmpty($manifest['required_paths']);
        self::assertTrue($manifest['provider_registration']['required']);
        self::assertNotEmpty($manifest['provider_registration']['strategies']);

        foreach ($manifest['provider_registration']['strategies'] as $strategy) {
            self::assertNotEmpty($strategy['id']);
            self::assertNotEmpty($strategy['probe']);
            self::assertNotEmpty($strategy['required_paths']);
        }

        self::assertTrue($manifest['requires_backup']);
        self::assertTrue($manifest['supports_uninstall']);
    }
}

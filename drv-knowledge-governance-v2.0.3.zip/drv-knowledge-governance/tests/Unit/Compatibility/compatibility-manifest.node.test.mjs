import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const packageRoot = join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const readPackageFile = (...parts) => readFileSync(join(packageRoot, ...parts), 'utf8');

test('Composer and PHPUnit expose the isolated package test harness', () => {
  const composer = JSON.parse(readPackageFile('composer.json'));
  const phpunit = readPackageFile('phpunit.xml');
  const bootstrap = readPackageFile('tests', 'bootstrap.php');

  assert.equal(composer.require.php, '>=8.2 <8.6');
  assert.equal(
    composer.autoload['psr-4']['BookStack\\AI\\Governance\\'],
    'bookstack-overlay/app/AI/Governance/',
  );
  assert.match(phpunit, /bootstrap="tests\/bootstrap\.php"/);
  assert.match(phpunit, /<directory>tests\/Unit<\/directory>/);
  assert.match(bootstrap, /vendor[\\/]autoload\.php/);
  assert.match(bootstrap, /BOOKSTACK_ROOT/);
});

test('compatibility manifest declares installation and rollback gates', () => {
  const manifest = JSON.parse(readPackageFile('compat', 'supported-bookstack.json'));

  assert.equal(manifest.php, '>=8.2 <8.6');
  assert.ok(manifest.bookstack && Object.keys(manifest.bookstack).length > 0);
  assert.ok(manifest.required_paths?.length > 0);
  assert.equal(manifest.provider_registration?.required, true);
  assert.ok(manifest.provider_registration?.strategies?.length > 0);
  for (const strategy of manifest.provider_registration.strategies) {
    assert.ok(strategy.id);
    assert.ok(strategy.required_paths?.length > 0);
    assert.ok(strategy.probe?.patterns?.length > 0);
  }
  assert.equal(manifest.requires_backup, true);
  assert.equal(manifest.supports_uninstall, true);
});

test('preflight scripts redact inputs and contain no deployment actions', () => {
  const preflightPaths = [
    join(packageRoot, 'scripts', 'preflight-bookstack.sh'),
    join(packageRoot, 'scripts', 'preflight-integrations.ps1'),
  ];
  const forbiddenMutation = /\b(docker\s+cp|podman\s+cp|Copy-Item|Move-Item|Remove-Item|scp|rsync|kubectl\s+(?:apply|cp)|artisan\s+migrate|composer\s+install)\b/i;
  const forbiddenShellDeployment = /^\s*(?:sudo\s+)?(?:cp|mv|rm|install|scp|rsync|apt(?:-get)?|apk|dnf|yum)\b/im;
  const forbiddenEnvironmentDump = /\b(printenv|GetEnvironmentVariables|Get-ChildItem\s+Env:|env\s*\|)\b/i;

  for (const scriptPath of preflightPaths) {
    const script = readFileSync(scriptPath, 'utf8');
    assert.doesNotMatch(script, forbiddenMutation, scriptPath);
    assert.doesNotMatch(script, forbiddenShellDeployment, scriptPath);
    assert.doesNotMatch(script, forbiddenEnvironmentDump, scriptPath);
    assert.match(script, /read[_ -]?only/i, scriptPath);
    assert.match(script, /redact|not_collected|not_recorded/i, scriptPath);
  }

  const bookstackPreflight = readPackageFile('scripts', 'preflight-bookstack.sh');
  assert.match(bookstackPreflight, /preflight-report\.json/);
  assert.match(bookstackPreflight, /PHP_VERSION_UNSUPPORTED/);
  assert.match(bookstackPreflight, /BOOKSTACK_VERSION_UNSUPPORTED/);
  assert.match(bookstackPreflight, /LARAVEL_VERSION_UNSUPPORTED/);
  assert.match(bookstackPreflight, /REQUIRED_PATH_MISSING/);
  assert.match(bookstackPreflight, /PROVIDER_REGISTRATION_STRUCTURE_UNSUPPORTED/);
});

test('integration preflight emits capability evidence without leaking or changing inputs', (t) => {
  if (process.platform !== 'win32') {
    t.skip('PowerShell integration probe is verified on Windows');
    return;
  }

  const fixtureRoot = mkdtempSync(join(tmpdir(), 'governance-preflight-'));
  t.after(() => rmSync(fixtureRoot, { recursive: true, force: true }));
  const drvRoot = join(fixtureRoot, 'drvagent');
  mkdirSync(drvRoot);

  const secret = 'DO_NOT_LEAK_INTEGRATION_SECRET_7f0a';
  const openApiPath = join(fixtureRoot, 'ragflow-openapi.json');
  const workerPath = join(drvRoot, 'worker.py');
  const grantsPath = join(fixtureRoot, 'show-grants.txt');
  const reportPath = join(fixtureRoot, 'report.json');
  const fixtures = new Map([
    [openApiPath, JSON.stringify({
      paths: {
        '/api/v1/documents': { post: { description: secret } },
        '/api/v1/documents/{id}': { put: {}, delete: {} },
      },
    })],
    [workerPath, `# ${secret}\nclaim = '/tasks/claim'\nheartbeat = '/tasks/heartbeat'\nresult = '/tasks/result'\n`],
    [grantsPath, `GRANT SELECT, CREATE ON bookstack.* TO 'worker'@'%' IDENTIFIED BY '${secret}'\n`],
  ]);
  for (const [path, content] of fixtures) writeFileSync(path, content);

  const result = spawnSync('powershell.exe', [
    '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
    '-File', join(packageRoot, 'scripts', 'preflight-integrations.ps1'),
    '-RagFlowOpenApiPath', openApiPath,
    '-DrvAgentRoot', drvRoot,
    '-DatabaseGrantEvidencePath', grantsPath,
    '-OutputPath', reportPath,
  ], { encoding: 'utf8' });

  assert.equal(result.status, 0, result.stderr || result.stdout);
  const reportText = readFileSync(reportPath, 'utf8');
  const report = JSON.parse(reportText.replace(/^\uFEFF/, ''));
  assert.equal(report.status, 'supported');
  assert.equal(report.ragflow.document_replace.supported, true);
  assert.equal(report.ragflow.document_delete.supported, true);
  assert.equal(report.drvagent.worker_path_supported, true);
  assert.equal(report.database.create_table_grant, true);
  assert.doesNotMatch(`${result.stdout}${result.stderr}${reportText}`, new RegExp(secret));
  for (const [path, content] of fixtures) assert.equal(readFileSync(path, 'utf8'), content);
});

test('BookStack test harness uses read-only mounts without copying production files', () => {
  const harness = readPackageFile('scripts', 'test-in-bookstack.ps1');
  assert.match(harness, /--mount/);
  assert.match(harness, /readonly/);
  assert.match(harness, /--volumes-from/);
  assert.match(harness, /vendor[\\/]bin[\\/]phpunit/);
  assert.match(harness, /'Persistence'/);
  assert.match(harness, /MigratePretend/);
  assert.match(harness, /migrate.*--pretend/s);
  assert.doesNotMatch(harness, /\b(docker\s+cp|podman\s+cp|Copy-Item|composer\s+install)\b/i);

  const bootstrap = readPackageFile('tests', 'bootstrap.php');
  assert.match(bootstrap, /bootstrap[\\/]app\.php/);
  assert.match(bootstrap, /Contracts\\Console\\Kernel/);
});

test('database preflight rejects CREATE TEMPORARY TABLES as migration authority', (t) => {
  if (process.platform !== 'win32') {
    t.skip('PowerShell integration probe is verified on Windows');
    return;
  }

  const fixtureRoot = mkdtempSync(join(tmpdir(), 'governance-grant-preflight-'));
  t.after(() => rmSync(fixtureRoot, { recursive: true, force: true }));
  const drvRoot = join(fixtureRoot, 'drvagent');
  mkdirSync(drvRoot);
  writeFileSync(join(drvRoot, 'worker.py'), "claim='/tasks/claim'\nresult='/tasks/result'\n");
  writeFileSync(join(fixtureRoot, 'ragflow.json'), JSON.stringify({
    paths: {
      '/api/v1/documents': { post: {} },
      '/api/v1/documents/{id}': { delete: {} },
    },
  }));
  writeFileSync(join(fixtureRoot, 'grants.txt'), 'GRANT SELECT, CREATE TEMPORARY TABLES ON bookstack.* TO user');

  const result = spawnSync('powershell.exe', [
    '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
    '-File', join(packageRoot, 'scripts', 'preflight-integrations.ps1'),
    '-RagFlowOpenApiPath', join(fixtureRoot, 'ragflow.json'),
    '-DrvAgentRoot', drvRoot,
    '-DatabaseGrantEvidencePath', join(fixtureRoot, 'grants.txt'),
    '-OutputPath', join(fixtureRoot, 'report.json'),
  ], { encoding: 'utf8' });

  assert.equal(result.status, 1);
  const report = JSON.parse(readFileSync(join(fixtureRoot, 'report.json'), 'utf8').replace(/^\uFEFF/, ''));
  assert.equal(report.database.create_table_grant, false);
});

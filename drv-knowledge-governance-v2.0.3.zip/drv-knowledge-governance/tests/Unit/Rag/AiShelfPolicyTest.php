<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Tests\Unit\Rag;

use BookStack\AI\Governance\Application\Rag\AiShelfPolicy;
use DomainException;
use PHPUnit\Framework\TestCase;
use ReflectionClass;

final class AiShelfPolicyTest extends TestCase
{
    public function test_ai_shelf_is_allowed(): void
    {
        AiShelfPolicy::assertHierarchyAllowed([
            ['bookshelf_name' => '【AI】经验案例'],
        ]);
        self::assertTrue(true);
    }

    public function test_normal_shelf_is_rejected(): void
    {
        $this->expectException(DomainException::class);
        $this->expectExceptionMessage('RAG_SHELF_NOT_ALLOWED');
        AiShelfPolicy::assertHierarchyAllowed([
            ['bookshelf_name' => '团队文档'],
        ]);
    }

    public function test_hierarchy_dependency_cannot_fall_back_to_null_during_container_resolution(): void
    {
        $constructor = (new ReflectionClass(AiShelfPolicy::class))->getConstructor();

        self::assertNotNull($constructor);
        self::assertFalse($constructor->getParameters()[0]->isDefaultValueAvailable());
    }
}

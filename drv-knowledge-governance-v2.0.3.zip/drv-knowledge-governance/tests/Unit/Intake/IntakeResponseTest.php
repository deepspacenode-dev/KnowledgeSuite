<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Tests\Unit\Intake;

use BookStack\AI\Governance\Application\Intake\IntakeResponse;
use PHPUnit\Framework\TestCase;

final class IntakeResponseTest extends TestCase
{
    public function test_replay_overrides_the_original_response_flag(): void
    {
        $response = IntakeResponse::asReplay([
            'intake_id' => '7',
            'replayed' => false,
            'task_id' => '9',
        ], 7);

        self::assertTrue($response['replayed']);
        self::assertSame('7', $response['intake_id']);
        self::assertSame('9', $response['task_id']);
    }

    public function test_replay_recovers_the_intake_id_for_legacy_rows(): void
    {
        $response = IntakeResponse::asReplay([], 11);

        self::assertSame('11', $response['intake_id']);
        self::assertTrue($response['replayed']);
    }

    public function test_current_compile_status_overrides_the_creation_snapshot(): void
    {
        $response = IntakeResponse::withCurrentCompileStatus([
            'intake_id' => '4',
            'compile_status' => 'queued',
        ], 'succeeded');

        self::assertSame('succeeded', $response['compile_status']);
        self::assertSame('4', $response['intake_id']);
    }
}

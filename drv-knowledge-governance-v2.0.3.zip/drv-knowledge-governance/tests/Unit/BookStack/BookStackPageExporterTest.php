<?php

declare(strict_types=1);

namespace BookStack\AI\Governance\Tests\Unit\BookStack;

use BookStack\AI\Governance\Infrastructure\BookStack\BookStackPageExporter;
use PHPUnit\Framework\TestCase;

final class BookStackPageExporterTest extends TestCase
{
    public function test_named_tags_become_closed_domain_metadata_with_owner_fallback(): void
    {
        $metadata = BookStackPageExporter::domainMetadata([
            ['name' => '模块', 'value' => ' Network '],
            ['name' => 'platform', 'value' => 'Linux'],
            ['name' => '芯片', 'value' => 'RTL8367S'],
            ['name' => '项目', 'value' => 'Switch-Gateway'],
            ['name' => 'ignored', 'value' => 'must-not-leak'],
        ], 9);

        self::assertSame([
            'owner' => 'user:9',
            'module' => 'network',
            'platform' => 'linux',
            'chip' => 'rtl8367s',
            'project' => 'switch-gateway',
        ], $metadata);
    }

    public function test_explicit_owner_tag_overrides_numeric_owner(): void
    {
        $metadata = BookStackPageExporter::domainMetadata([
            ['name' => '负责人', 'value' => ' Liubo '],
        ], 9);

        self::assertSame('liubo', $metadata['owner']);
    }
}

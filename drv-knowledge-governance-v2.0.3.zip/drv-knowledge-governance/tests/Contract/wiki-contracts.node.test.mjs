import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const contracts = join(root, 'contracts');
const schemaNames = [
  'wiki-task.schema.json', 'wiki-result.schema.json', 'wiki-compile-job.schema.json',
  'quality-gate.schema.json', 'knowledge-delta.schema.json', 'knowledge-bundle.schema.json',
  'internal-event.schema.json',
];

test('all approved contracts are valid JSON Schema documents', () => {
  for (const name of schemaNames) {
    const schema = JSON.parse(readFileSync(join(contracts, name), 'utf8'));
    assert.match(schema.$schema, /json-schema/);
    assert.equal(schema.type, 'object');
    assert.ok(Array.isArray(schema.required), name);
  }
});

test('Wiki tasks and results preserve source identity and review requirements', () => {
  const task = JSON.parse(readFileSync(join(contracts, 'wiki-task.schema.json'), 'utf8'));
  const result = JSON.parse(readFileSync(join(contracts, 'wiki-result.schema.json'), 'utf8'));
  const taskText = JSON.stringify(task);
  const resultText = JSON.stringify(result);
  for (const field of ['source_key', 'content_hash']) assert.match(taskText, new RegExp(field));
  for (const field of ['sources', 'front_matter', 'status']) assert.match(resultText, new RegExp(field));
  assert.match(taskText, /review_required/);
});

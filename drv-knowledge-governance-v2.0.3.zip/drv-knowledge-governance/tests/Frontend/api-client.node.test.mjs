import assert from 'node:assert/strict';
import test from 'node:test';

import { ApiClient, ApiError } from '../../bookstack-overlay/public/ai-governance/app/api-client.js';

test('ApiClient unwraps the governance success envelope', async () => {
    const fetchImpl = async () => new Response(JSON.stringify({ success: true, data: { total: 9 } }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
    });
    const client = new ApiClient({ fetchImpl, baseUrl: '/api/ai-governance/v1' });

    assert.deepEqual(await client.get('/summary'), { total: 9 });
});
test('ApiClient sends JSON and the CSRF token for write requests', async () => {
    let request;
    const fetchImpl = async (url, init) => {
        request = { url, init };
        return new Response(JSON.stringify({ success: true, data: { saved: true } }), { status: 200 });
    };
    const client = new ApiClient({ fetchImpl, baseUrl: '/api/ai-governance/v1', csrfToken: 'csrf-123' });

    await client.post('/gaps', { title: '缺口' });

    assert.equal(request.url, '/api/ai-governance/v1/gaps');
    assert.equal(request.init.headers['X-CSRF-TOKEN'], 'csrf-123');
    assert.equal(request.init.headers['Content-Type'], 'application/json');
    assert.equal(request.init.body, JSON.stringify({ title: '缺口' }));
});

test('ApiClient sends the XSRF cookie through Laravel X-XSRF-TOKEN header', async () => {
    const previousDocument = globalThis.document;
    let request;
    globalThis.document = {
        cookie: 'theme=light; XSRF-TOKEN=cookie-token-456',
        querySelector: () => null,
    };
    const fetchImpl = async (url, init) => {
        request = { url, init };
        return new Response(JSON.stringify({ success: true, data: { saved: true } }), { status: 200 });
    };

    try {
        const client = new ApiClient({ fetchImpl });
        await client.post('/assets/8/reviews', { review_status: 'reviewed' });
        assert.equal(request.init.headers['X-XSRF-TOKEN'], 'cookie-token-456');
        assert.equal(request.init.headers['X-CSRF-TOKEN'], undefined);
    } finally {
        globalThis.document = previousDocument;
    }
});

test('ApiClient accepts a CSRF token supplied after session bootstrap', async () => {
    let request;
    const client = new ApiClient({
        fetchImpl: async (url, init) => {
            request = { url, init };
            return new Response(JSON.stringify({ success: true, data: {} }), { status: 200 });
        },
    });

    client.setCsrfToken('session-token-789');
    await client.patch('/gaps/3', { gap_status: 'closed' });
    assert.equal(request.init.headers['X-CSRF-TOKEN'], 'session-token-789');
});

test('ApiClient sends authenticated JSON DELETE requests with CSRF protection', async () => {
    let request;
    const client = new ApiClient({
        csrfToken: 'delete-token',
        fetchImpl: async (url, init) => {
            request = { url, init };
            return new Response(JSON.stringify({ success: true, data: { removed: true } }), { status: 200 });
        },
    });

    const result = await client.delete('/assets/8/rag', { reason: '内容已废弃' });
    assert.deepEqual(result, { removed: true });
    assert.equal(request.init.method, 'DELETE');
    assert.equal(request.init.headers['X-CSRF-TOKEN'], 'delete-token');
    assert.equal(request.init.body, JSON.stringify({ reason: '内容已废弃' }));
});

test('ApiClient exposes a stable error for rejected API envelopes', async () => {
    const fetchImpl = async () => new Response(JSON.stringify({
        success: false,
        error: { code: 'FORBIDDEN', message: '仅管理员可执行此操作' },
    }), { status: 403 });
    const client = new ApiClient({ fetchImpl });

    await assert.rejects(client.get('/summary'), (error) => {
        assert.ok(error instanceof ApiError);
        assert.equal(error.code, 'FORBIDDEN');
        assert.equal(error.status, 403);
        return true;
    });
});

test('ApiClient preserves BookStack top-level error details and explains CSRF expiry', async () => {
    const fetchImpl = async () => new Response(JSON.stringify({
        success: false,
        error_code: 'CSRF_TOKEN_MISMATCH',
        message: 'CSRF token mismatch.',
        retryable: true,
    }), { status: 419 });
    const client = new ApiClient({ fetchImpl });

    await assert.rejects(client.post('/assets/8/reviews', {}), (error) => {
        assert.ok(error instanceof ApiError);
        assert.equal(error.code, 'CSRF_TOKEN_MISMATCH');
        assert.equal(error.status, 419);
        assert.match(error.message, /会话校验失败/);
        return true;
    });
});

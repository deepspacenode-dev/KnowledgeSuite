import assert from 'node:assert/strict';
import test from 'node:test';

import { buildRouteUrl, parseRoute } from '../../bookstack-overlay/public/ai-governance/app/router.js';

test('parseRoute accepts known views and preserves current page context', () => {
    const route = parseRoute('http://localhost/ai-governance/?view=quality&page_id=42&mode=current_page');

    assert.deepEqual(route, {
        view: 'quality',
        pageId: '42',
        mode: 'current_page',
    });
});
test('parseRoute falls back to overview for an unknown view', () => {
    assert.equal(parseRoute('http://localhost/ai-governance/?view=unknown').view, 'overview');
});

test('buildRouteUrl keeps page identity while changing view', () => {
    const url = buildRouteUrl('assets', {
        href: 'http://localhost/ai-governance/?view=overview&page_id=81&mode=current_page',
    });

    assert.equal(url, '/ai-governance/?view=assets&page_id=81&mode=current_page');
});

test('buildRouteUrl preserves demo mode while switching views', () => {
    const url = buildRouteUrl('contributions', {
        href: 'http://localhost/ai-governance/index.html?demo=1&view=overview',
    });

    assert.equal(url, '/ai-governance/index.html?view=contributions&demo=1');
});

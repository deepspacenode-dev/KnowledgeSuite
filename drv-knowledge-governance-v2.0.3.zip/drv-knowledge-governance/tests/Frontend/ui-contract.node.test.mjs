import assert from 'node:assert/strict';
import { readdir, readFile } from 'node:fs/promises';
import test from 'node:test';

import { assetDetailView, assetsView, contributionsView, gapsView, qualityHelpView, qualityView, ragView } from '../../bookstack-overlay/public/ai-governance/app/views.js';
import { DemoApi } from '../../bookstack-overlay/public/ai-governance/app/demo-data.js';
import { safeHref, statusBadge } from '../../bookstack-overlay/public/ai-governance/app/ui.js';

const root = new URL('../../bookstack-overlay/public/ai-governance/', import.meta.url);

test('governance shell is local, versionless and exposes every approved view', async () => {
    const html = await readFile(new URL('index.html', root), 'utf8');
    const main = await readFile(new URL('app/main.js', root), 'utf8');

    assert.doesNotMatch(html, /V1\.9\.1|UI Mockup/i);
    assert.doesNotMatch(html, /https?:\/\//i);
    assert.match(html, /assets\/css\/governance\.css/);
    assert.match(html, /vendor\/lucide\/lucide\.min\.js/);
    for (const view of ['overview', 'assets', 'contributions', 'quality', 'rag', 'gaps', 'reports', 'knowledge-graph']) {
        assert.match(main, new RegExp(`\\b${view}\\s*:`));
    }
});

test('visual contract uses blue work surfaces without grid decoration', async () => {
    const css = await readFile(new URL('assets/css/governance.css', root), 'utf8');

    assert.match(css, /--topbar:\s*#[0-9a-f]{6}/i);
    assert.match(css, /--sidebar:\s*#[0-9a-f]{6}/i);
    assert.match(css, /prefers-reduced-motion:\s*reduce/);
    assert.doesNotMatch(css, /repeating-linear-gradient|background-image:\s*(?:linear|radial)-gradient/i);
    assert.doesNotMatch(css, /sidebar-scan|topbar-scan|\.sidebar::after|\.topbar::after/);
    assert.doesNotMatch(css, /nav-item__signal|system-pulse|animation:\s*signal|@keyframes signal|inset 3px 0/);
    assert.match(css, /#governance-app\s*\{[^}]*font-size:\s*16px/s);
    assert.match(css, /\.section-panel__body\s*\{[^}]*font-size:\s*14px/s);
    assert.match(css, /\.modal__body\s*\{[^}]*font-size:\s*14px/s);
    assert.match(css, /table\s*\{[^}]*font-size:\s*13px/s);
    assert.match(css, /\.view-state--loading/);
    assert.match(css, /\.view-state--empty/);
    assert.match(css, /\.view-state--error/);
});

async function readFrontendSourceFiles(directory = root) {
    const entries = await readdir(directory, { withFileTypes: true });
    const files = [];
    for (const entry of entries) {
        const url = new URL(entry.name, directory);
        if (entry.isDirectory()) {
            if (entry.name === 'vendor') continue;
            files.push(...await readFrontendSourceFiles(new URL(`${entry.name}/`, directory)));
        } else if (/\.(html|css|js)$/.test(entry.name)) {
            files.push(url);
        }
    }
    return files;
}

test('topbar exposes a direct return button to the DrvDocs home page', async () => {
    const shell = await readFile(new URL('app/app-shell.js', root), 'utf8');

    assert.match(shell, /href="\/"/);
    assert.match(shell, /返回 DrvDocs/);
    assert.match(shell, /home/);
    assert.doesNotMatch(shell, /user-button|permission-label|<strong>BookStack<\/strong>/);
});

test('shell markup does not render decorative light-strip indicators', async () => {
    const shell = await readFile(new URL('app/app-shell.js', root), 'utf8');
    const html = await readFile(new URL('index.html', root), 'utf8');
    const main = await readFile(new URL('app/main.js', root), 'utf8');

    assert.doesNotMatch(shell, /nav-item__signal|system-pulse/);
    assert.match(html, /governance\.css\?v=/);
    assert.match(html, /app\/main\.js\?v=/);
    assert.match(main, /views\.js\?v=/);
    assert.match(main, /demo-data\.js\?v=/);
});

test('governance background uses an isolated reduced-motion particle wave layer', async () => {
    const html = await readFile(new URL('index.html', root), 'utf8');
    const css = await readFile(new URL('assets/css/governance.css', root), 'utf8');
    const main = await readFile(new URL('app/main.js', root), 'utf8');
    const wave = await readFile(new URL('app/particle-wave.js', root), 'utf8');

    assert.match(html, /wave-particle-canvas/);
    assert.match(main, /particle-wave\.js\?v=/);
    assert.match(css, /\.wave-particle-canvas\s*\{/);
    assert.match(css, /pointer-events:\s*none/);
    assert.match(wave, /prefers-reduced-motion:\s*reduce/);
    assert.match(wave, /requestAnimationFrame/);
});

test('contribution view uses exact BookStack account names instead of synthesized user ids', () => {
    const html = contributionsView([
        { owner_id: 10086, owner_name: 'A04217', document_count: 3, asset_count: 5 },
    ]);

    assert.match(html, /A04217/);
    assert.doesNotMatch(html, /用户\s*#/);
});

test('RAG status presentation uses persisted field names and explicit lifecycle labels', () => {
    assert.match(statusBadge('not_ingested'), />未入库</);
    assert.match(statusBadge('uploaded'), />已上传</);
    assert.match(statusBadge('unstart'), />未开始</);
    assert.match(statusBadge('stale'), />已过期</);
    assert.match(statusBadge(null), />-<\/span>/);

    const html = ragView([{ asset_id: 7, parse_status: 'parsed', last_action_result: 'updated' }]);
    assert.match(html, />已解析</);
    assert.match(html, />已更新</);
    assert.doesNotMatch(html, />未知</);
});

test('quality and RAG rows lead with filenames and keep asset ids as secondary audit data', () => {
    const quality = qualityView([{
        asset_id: 7,
        asset_title: 'RTL8367S 网络故障案例.md',
        current_version: 3,
        score: 62,
        gate_result: 'blocked',
        conclusion: '无法入库：缺少可追溯来源。',
        page_url: '/books/network/page/rtl8367s',
        problems: [{ severity: '阻断', title: '缺少可追溯来源', deduction: 40, fix: '补充来源链接。' }],
    }], { canWrite: true });
    const rag = ragView([{
        asset_id: 8,
        asset_title: 'A2 芯片手册.md',
        current_version: 2,
        dataset_id: 'manuals',
        document_id: 'doc-a2',
        parse_status: 'ready',
        last_action_result: 'created',
        can_publish: true,
    }], { canWrite: true });
    const blockedRag = ragView([{
        asset_id: 9,
        asset_title: '未通过审核.md',
        current_version: 1,
        dataset_id: 'manuals',
        document_id: null,
        parse_status: 'failed',
        last_action_result: 'failed',
        can_publish: false,
    }], { canWrite: true });

    assert.match(quality, /RTL8367S 网络故障案例\.md/);
    assert.match(quality, /无法入库/);
    assert.match(quality, /缺少可追溯来源/);
    assert.match(quality, /data-action="quality-help"/);
    assert.match(quality, /href="\/books\/network\/page\/rtl8367s"/);
    assert.match(quality, /查看原文<\/a>/);
    assert.doesNotMatch(quality, /<strong>文档 #7<\/strong>/);
    assert.match(rag, /A2 芯片手册\.md/);
    assert.match(rag, /#8 · v2/);
    assert.match(rag, /data-dataset-id="manuals"/);
    assert.match(rag, /data-action="remove-rag"/);
    assert.doesNotMatch(blockedRag, /data-action="retry-rag"/);
});

test('manual quality view renders one chapter unit with page evidence and one review entry', () => {
    const html = qualityView([{
        unit_key: 'chapter:12:301',
        unit_type: 'chapter',
        unit_title: 'DDR 配置',
        bookshelf_id: 12,
        bookshelf_name: '芯片手册',
        book_name: 'A2 芯片手册',
        member_count: 8,
        checked_page_count: 8,
        issue_page_count: 3,
        blocked_page_count: 1,
        score: 54,
        gate_result: 'blocked',
        conclusion: '本章节无法通过质量门禁：3/8 个页面存在问题，其中 1 个页面含硬阻断。',
        chapter_url: '/books/a2/chapter/ddr',
        members: [
            { page_id: 101, page_title: 'DDR 初始化', page_url: '/books/a2/page/ddr-init', asset_id: 201, score: 54, gate_result: 'blocked', conclusion: '无法入库：缺少可追溯来源。', problems: [{ title: '缺少可追溯来源', severity: '阻断', blocking: true, fix: '补充来源链接。' }] },
            { page_id: 102, page_title: 'DDR 时序', page_url: '/books/a2/page/ddr-timing', asset_id: 202, score: 76, gate_result: 'warning', conclusion: '存在质量扣分项。', problems: [{ title: '缺少负责人', severity: '警告', deduction: 8, fix: '补充 owner。' }] },
            { page_id: 103, page_title: 'DDR 训练', page_url: '/books/a2/page/ddr-training', asset_id: 203, score: 80, gate_result: 'warning', conclusion: '存在质量扣分项。', problems: [{ title: '缺少适用平台', severity: '警告', deduction: 8, fix: '补充 platform。' }] },
        ],
    }], { canWrite: true });

    assert.match(html, /<strong>DDR 配置<\/strong>/);
    assert.match(html, /章节质量 · A2 芯片手册 · 3\/8 个页面有问题/);
    assert.match(html, /查看章节内 3 个问题页面/);
    assert.match(html, /DDR 初始化/);
    assert.match(html, /DDR 时序/);
    assert.match(html, /DDR 训练/);
    assert.match(html, /data-action="open-review-unit"/);
    assert.match(html, /data-review-unit="chapter:12:301"/);
    assert.match(html, /data-bookshelf-id="12"/);
    assert.match(html, />前往章节审核<\/button>/);
    assert.match(html, /href="\/books\/a2\/chapter\/ddr"/);
    assert.match(html, /href="\/books\/a2\/page\/ddr-init"/);
    assert.equal((html.match(/查看原文<\/a>/g) || []).length, 3);
    assert.doesNotMatch(html, /data-open-asset/);
});

test('quality source links reject script URLs before rendering', () => {
    assert.equal(safeHref('/books/a2/page/ddr'), '/books/a2/page/ddr');
    assert.equal(safeHref('https://bookstack.internal/books/a2/page/ddr'), 'https://bookstack.internal/books/a2/page/ddr');
    assert.equal(safeHref('javascript:alert(1)'), '');
    assert.equal(safeHref('//evil.example/books/a2/page/ddr'), '');
});

test('knowledge gap cards expose administrator-only audited deletion controls', async () => {
    const writable = gapsView([{ gap_id: 9, title: '缺少案例', missing_content: '待补充', priority: 'high', gap_status: 'closed' }], { canWrite: true });
    const readonly = gapsView([{ gap_id: 9, title: '缺少案例', missing_content: '待补充', priority: 'high', gap_status: 'closed' }], { canWrite: false });
    const main = await readFile(new URL('app/main.js', root), 'utf8');

    assert.match(writable, /data-action="delete-gap"/);
    assert.match(writable, /data-gap-id="9"/);
    assert.doesNotMatch(readonly, /data-action="delete-gap"/);
    assert.match(main, /api\.delete\(`\/gaps\/\$\{id\}`/);
    assert.match(main, /删除原因/);
    assert.match(main, /删除后无法在看板中恢复/);
});

test('quality help explains scoring, hard blocks, and non-scoring workflow limits', () => {
    const html = qualityHelpView({
        minimum_score: 70,
        verified_minimum_score: 90,
        metadata_rules: [],
        section_rules: [],
        hard_blocks: [{ name: '缺少可追溯来源', trigger: '没有来源', deduction: 40, blocking: true, fix: '补充来源' }],
        workflow_rules: [{ name: '文章仍为草稿', trigger: '尚未提交审阅', deduction: null, blocking: false, fix: '提交审阅' }],
    });

    assert.match(html, /普通审阅 ≥ 70 分/);
    assert.match(html, /硬阻断条件/);
    assert.match(html, /流程状态提示/);
    assert.match(html, /文章仍为草稿/);
});

test('asset detail exposes real Markdown publish and safe removal actions only to writers', () => {
    const detail = {
        asset: { asset_id: 42, asset_type: 'wiki', title: '网络故障排查.md' },
        review: { review_status: 'reviewed' },
        allowed_actions: [],
        rag_action: { can_publish: true, dataset_id: 'cases', is_removed: false, has_snapshot: true },
    };
    const writable = assetDetailView(detail, true);
    const readonly = assetDetailView(detail, false);

    assert.match(writable, /入库并解析|重新入库/);
    assert.match(writable, /从 RAGFlow 移除/);
    assert.match(writable, /data-dataset-id="cases"/);
    assert.doesNotMatch(readonly, /data-action="retry-rag"/);
    assert.doesNotMatch(readonly, /data-action="remove-rag"/);
});

test('governance shell contains a runtime-only RAGFlow website link', async () => {
    const shell = await readFile(new URL('app/app-shell.js', root), 'utf8');
    const main = await readFile(new URL('app/main.js', root), 'utf8');

    assert.match(shell, /id="ragflow-web-link"/);
    assert.match(shell, /target="_blank"/);
    assert.match(shell, /noopener noreferrer/);
    assert.match(main, /integrations\?\.ragflow\?\.web_url/);
});

test('demo RAG snapshots mirror the persisted last_action_result contract', async () => {
    const items = await new DemoApi().get('/rag/status');

    assert.equal(items.every((item) => Object.hasOwn(item, 'last_action_result')), true);
    assert.equal(items.some((item) => Object.hasOwn(item, 'action_result')), false);
});

test('review controls never render without a valid persisted asset id', async () => {
    const withoutId = assetDetailView({ asset: { asset_type: 'wiki', title: 'Draft' } }, true);
    const withId = assetDetailView({
        asset: { asset_id: 42, asset_type: 'source', title: 'Reviewed' },
        allowed_actions: ['reviewed'],
    }, true);
    const main = await readFile(new URL('app/main.js', root), 'utf8');

    assert.doesNotMatch(withoutId, /data-action="review-/);
    assert.match(withId, /data-asset-id="42"/);
    assert.match(withId, /data-action="review-reviewed"/);
    assert.doesNotMatch(withId, /data-action="review-verified"/);
    assert.doesNotMatch(withId, /data-action="review-need-fix"/);
    assert.match(main, /assetId === 'undefined'/);
    assert.match(main, /文档ID无效，无法提交审阅/);
});

test('review view renders chapter units and only backend-approved actions', () => {
    const html = assetsView({
        total: 1,
        items: [{
            unit_key: 'chapter:12:301', unit_type: 'chapter', unit_title: 'DDR 配置',
            bookshelf_id: 12, bookshelf_name: '芯片手册', book_name: 'A2 芯片手册',
            member_count: 8, asset_count: 8, review_status: 'pending_review',
            allowed_actions: ['reviewed', 'need_fix'],
        }],
    }, { canWrite: true, shelves: [{ id: 12, name: '芯片手册' }], filters: { bookshelf_id: '12' } });

    assert.match(html, /章节评审/);
    assert.match(html, /DDR 配置/);
    assert.match(html, /8 个页面/);
    assert.match(html, /data-review-unit="chapter:12:301"/);
    assert.match(html, /data-review-status="reviewed"/);
    assert.doesNotMatch(html, /data-review-status="verified"/);
});

test('approved chapter review units expose one-click RAGFlow ingestion in the review page', async () => {
    const publishable = assetsView({ total: 1, items: [{
        unit_key: 'chapter:12:301', unit_type: 'chapter', unit_title: 'DDR 配置',
        bookshelf_id: 12, bookshelf_name: '芯片手册', book_name: 'A2 芯片手册',
        member_count: 8, asset_count: 8, publishable_count: 8,
        review_status: 'reviewed', allowed_actions: ['verified', 'need_recheck'], can_publish: true,
    }] }, { canWrite: true, shelves: [], filters: {} });
    const blocked = assetsView({ total: 1, items: [{
        unit_key: 'chapter:12:302', unit_type: 'chapter', unit_title: '未审核章节',
        bookshelf_id: 12, member_count: 4, asset_count: 4, publishable_count: 0,
        review_status: 'pending_review', allowed_actions: ['reviewed'], can_publish: false,
    }] }, { canWrite: true, shelves: [], filters: {} });
    const main = await readFile(new URL('app/main.js', root), 'utf8');

    assert.match(publishable, /data-action="publish-review-unit"/);
    assert.match(publishable, />一键入库 RAGFlow<\/button>/);
    assert.doesNotMatch(blocked, /data-action="publish-review-unit"/);
    assert.match(main, /\/review-units\/rag\/publish/);
    assert.match(main, /已提交.*RAGFlow.*解析/);
});

test('bookshelf filters are exposed in review contribution quality RAG report and graph views', async () => {
    const views = await readFile(new URL('app/views.js', root), 'utf8');
    const controls = await readFile(new URL('app/knowledge-graph-controls.js', root), 'utf8');
    const main = await readFile(new URL('app/main.js', root), 'utf8');

    for (const id of ['asset-filters', 'contribution-filters', 'quality-filters', 'rag-filters', 'report-form']) {
        assert.match(views, new RegExp(id), id);
    }
    assert.match(views, /shelfSelect\(context\)/);
    assert.match(views, /书架范围/);
    assert.match(controls, /name="bookshelf_id"/);
    assert.match(main, /filters\/bookshelves/);
    assert.match(main, /review-units/);
});

test('demo API supplies shelves, review units and respects a shelf filter', async () => {
    const api = new DemoApi();
    const shelves = await api.get('/filters/bookshelves');
    const units = await api.get('/review-units', { bookshelf_id: String(shelves[0].id) });

    assert.ok(shelves.length > 0);
    assert.ok(units.items.length > 0);
    assert.equal(units.items.every((unit) => String(unit.bookshelf_id) === String(shelves[0].id)), true);

    const report = await api.post('/reports', {
        report_type: '周报', period_start: '2026-08-20', period_end: '2026-08-27', bookshelf_id: String(shelves[0].id),
    });
    assert.match(report.markdown, new RegExp(`书架范围：${shelves[0].name}`));
});

test('governance frontend display names use DrvDocs instead of BookStack', async () => {
    const files = await readFrontendSourceFiles();
    for (const file of files) {
        const source = await readFile(file, 'utf8');
        assert.doesNotMatch(source, /BookStack/, `${file.pathname} should not expose BookStack wording`);
    }
});

test('knowledge graph view is navigation-visible and lazy loaded with local vendors', async () => {
    const shell = await readFile(new URL('app/app-shell.js', root), 'utf8');
    const main = await readFile(new URL('app/main.js', root), 'utf8');
    const css = await readFile(new URL('assets/css/knowledge-graph.css', root), 'utf8');
    const graph = await readFile(new URL('app/knowledge-graph.js', root), 'utf8');

    assert.match(shell, /knowledge-graph/);
    assert.match(shell, /知识图谱/);
    assert.match(shell, /orbit/);
    assert.match(main, /import\('\.\/knowledge-graph\.js\?v=20260827-sphere-i'\)/);
    assert.doesNotMatch(main, /from ['"]\.\/knowledge-graph/);
    assert.match(main, /unmountKnowledgeGraph/);
    assert.match(graph, /vendor\/3d-force-graph/);
    assert.match(graph, /mountKnowledgeGraph/);
    assert.match(graph, /unmountKnowledgeGraph/);
    assert.match(graph, /\/knowledge-graph/);
    assert.match(graph, /onNodeDblClick\(\(node\) => handleNodeDoubleClick/);
    assert.match(graph, /toggleChapterPages/);
    assert.match(graph, /buildChapterExpandFilters/);
    assert.match(graph, /runtime\.expandedChapters\.clear\(\)/, 'filter reload must discard stale expansion state');
    assert.match(graph, /loadGeneration/, 'stale chapter responses must not overwrite a newly filtered graph');
    assert.match(css, /\.knowledge-graph/);
    assert.match(css, /radial-gradient/);
});

test('knowledge graph vendor files are local and documented', async () => {
    const forceGraph = await readFile(new URL('vendor/3d-force-graph/3d-force-graph.module.js', root), 'utf8');
    const three = await readFile(new URL('vendor/three/three.module.js', root), 'utf8');
    const license = await readFile(new URL('vendor/3d-force-graph/LICENSE', root), 'utf8');

    assert.match(forceGraph, /ForceGraph3D/);
    assert.match(three, /local/i);
    assert.match(license, /local vendor/i);
});

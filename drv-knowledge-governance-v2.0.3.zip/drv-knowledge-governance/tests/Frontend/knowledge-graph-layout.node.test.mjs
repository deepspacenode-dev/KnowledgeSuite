import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';

import {
    buildChapterExpandFilters,
    collapseChapterExpansion,
    mergeChapterExpansion,
    prepareRadialHierarchyGraph,
    prepareSphericalHierarchyGraph,
} from '../../bookstack-overlay/public/ai-governance/app/knowledge-graph.js';
import { DemoApi } from '../../bookstack-overlay/public/ai-governance/app/demo-data.js';
import { nodeColor, TYPE_COLORS } from '../../bookstack-overlay/public/ai-governance/app/knowledge-graph-theme.js';
import {
    cameraAnglesForNode,
    constrainNodeToLayoutRadius,
    fitTextToWidth,
    perspectiveScale,
    relativeToCameraTarget,
    safeZoomForExtents,
} from '../../bookstack-overlay/public/ai-governance/vendor/3d-force-graph/3d-force-graph.module.js';

const root = new URL('../../bookstack-overlay/public/ai-governance/', import.meta.url);
const radius3d = (node) => Math.hypot(node.fx || 0, node.fy || 0, node.fz || 0);

test('knowledge graph keeps a DrvDocs center node and lays assets into spherical hierarchy shells', () => {
    const graph = prepareSphericalHierarchyGraph({
        nodes: [
            { id: 'root:knowledge-base', type: 'root', title: 'Knowledge Root', review_status: 'verified', rag_status: 'parsed' },
            { id: 'bookshelf:manuals', type: 'bookshelf', title: 'Manuals', review_status: 'approved', rag_status: 'parsed' },
            { id: 'book:sdk', type: 'book', title: 'SDK', bookshelf_id: 'manuals', review_status: 'approved', rag_status: 'parsed' },
            { id: 'chapter:sdk:boot', type: 'chapter', title: 'Boot', bookshelf_id: 'manuals', book_id: 'sdk', review_status: 'pending', rag_status: 'parsing' },
            { id: 'page:101', type: 'page', title: 'Bring-up', bookshelf_id: 'manuals', book_id: 'sdk', review_status: 'verified', rag_status: 'parsed' },
        ],
        links: [
            { source: 'root:knowledge-base', target: 'bookshelf:manuals', type: 'contains' },
            { source: 'bookshelf:manuals', target: 'book:sdk', type: 'contains' },
            { source: 'book:sdk', target: 'chapter:sdk:boot', type: 'contains' },
            { source: 'chapter:sdk:boot', target: 'page:101', type: 'contains' },
        ],
        stats: {},
        meta: {},
    });

    const center = graph.nodes.find((node) => node.type === 'root');
    assert.ok(center, 'center node should be visible');
    assert.equal(center.title, 'DrvDocs');
    assert.equal(Math.round(center.fx), 0);
    assert.equal(Math.round(center.fy), 0);
    assert.equal(graph.links.some((link) => String(link.source).startsWith('root:') && String(link.target).startsWith('bookshelf:')), true);

    const radii = Object.fromEntries(graph.nodes.map((node) => [node.type, Math.round(radius3d(node))]));
    assert.equal(radii.root, 0, 'DrvDocs center should stay in the middle');
    assert.ok(radii.bookshelf < radii.book, 'bookshelf should be the innermost visible ring');
    assert.ok(radii.book < radii.chapter, 'book should sit outside bookshelf');
    assert.ok(radii.chapter < radii.page, 'page should be the outermost ring');
    assert.equal(new Set(graph.nodes.map((node) => node.layout_mode)).has('spherical-hierarchy'), true);
    assert.equal(new Set(graph.nodes.map((node) => node.layout_variant)).has('spherical-cloud'), true);
    assert.deepEqual(
        prepareRadialHierarchyGraph({ nodes: graph.nodes, links: graph.links }).nodes.map((node) => node.id),
        graph.nodes.map((node) => node.id),
        'the compatibility export should use the spherical layout',
    );
});

test('spherical cloud is deterministic and separates shelf branches in real 3D space', () => {
    const payload = {
        nodes: [
            { id: 'root:knowledge-base', type: 'root', title: 'Root' },
            { id: 'bookshelf:a', type: 'bookshelf', title: 'Shelf A' },
            { id: 'bookshelf:b', type: 'bookshelf', title: 'Shelf B' },
            { id: 'bookshelf:c', type: 'bookshelf', title: 'Shelf C' },
            { id: 'book:a:1', type: 'book', title: 'Book A', bookshelf_id: 'a' },
            { id: 'book:b:2', type: 'book', title: 'Book B', bookshelf_id: 'b' },
            { id: 'book:c:3', type: 'book', title: 'Book C', bookshelf_id: 'c' },
            { id: 'chapter:a:1:x', type: 'chapter', title: 'Chapter A', bookshelf_id: 'a', book_id: 1 },
            { id: 'chapter:b:2:y', type: 'chapter', title: 'Chapter B', bookshelf_id: 'b', book_id: 2 },
            { id: 'chapter:c:3:z', type: 'chapter', title: 'Chapter C', bookshelf_id: 'c', book_id: 3 },
        ],
        links: [
            { source: 'root:knowledge-base', target: 'bookshelf:a', type: 'contains' },
            { source: 'root:knowledge-base', target: 'bookshelf:b', type: 'contains' },
            { source: 'root:knowledge-base', target: 'bookshelf:c', type: 'contains' },
            { source: 'bookshelf:a', target: 'book:a:1', type: 'contains' },
            { source: 'bookshelf:b', target: 'book:b:2', type: 'contains' },
            { source: 'bookshelf:c', target: 'book:c:3', type: 'contains' },
            { source: 'book:a:1', target: 'chapter:a:1:x', type: 'contains' },
            { source: 'book:b:2', target: 'chapter:b:2:y', type: 'contains' },
            { source: 'book:c:3', target: 'chapter:c:3:z', type: 'contains' },
        ],
    };

    const first = prepareSphericalHierarchyGraph(payload);
    const second = prepareSphericalHierarchyGraph(payload);
    const coordinates = (graph) => graph.nodes.map(({ id, fx, fy, fz }) => ({ id, fx, fy, fz }));
    assert.deepEqual(coordinates(first), coordinates(second), 'the same hierarchy must not jump between reloads');

    const shelves = first.nodes.filter((node) => node.type === 'bookshelf');
    assert.equal(new Set(shelves.map((node) => `${node.fx.toFixed(3)},${node.fy.toFixed(3)},${node.fz.toFixed(3)}`)).size, 3);
    assert.ok(
        Math.max(...shelves.map((node) => node.fy)) - Math.min(...shelves.map((node) => node.fy)) > 35,
        'shelves should occupy different sphere latitudes',
    );
    for (const type of ['bookshelf', 'book', 'chapter']) {
        const levelNodes = first.nodes.filter((node) => node.type === type);
        assert.equal(levelNodes.some((node) => Math.abs(node.fz) > 1), true, `${type} should use visible depth`);
    }
});

test('local graph renderer keeps precomputed hierarchy coordinates instead of randomizing them', async () => {
    const forceGraph = await readFile(new URL('vendor/3d-force-graph/3d-force-graph.module.js', root), 'utf8');
    const graphModule = await readFile(new URL('app/knowledge-graph.js', root), 'utf8');

    assert.match(graphModule, /3d-force-graph\.module\.js\?v=20260827-sphere-i/);
    assert.match(forceGraph, /node\.fx/);
    assert.match(forceGraph, /node\.layout_mode/);
    assert.match(forceGraph, /spherical-hierarchy/);
    assert.match(forceGraph, /spherical-cloud/);
    assert.match(forceGraph, /drawHierarchyGuides/);
    assert.match(forceGraph, /drawOrbitPath/);
    assert.match(forceGraph, /fitHierarchyZoom/);
    assert.match(forceGraph, /drawNodeLabels/);
    assert.match(forceGraph, /this\.width < 520/);
    assert.match(forceGraph, /this\.selectedNode/);
    assert.match(forceGraph, /const highlighted = this\.hoveredNode/);
    assert.match(forceGraph, /point\.depth > 120/);
    assert.match(forceGraph, /highlighted \|\| selected \? 1\.6 : 0\.45/);
    assert.doesNotMatch(forceGraph, /this\.transforms\.rotateX = angles\.rotateX/);
    assert.match(forceGraph, /rotateX = -0\.28/);
    assert.match(forceGraph, /rotateY = 0\.26/);
    assert.match(forceGraph, /书架层/);
});

test('spherical interactions preserve radius, focus a node, and fit narrow canvases', () => {
    const dragged = constrainNodeToLayoutRadius({
        layout_variant: 'spherical-cloud',
        layout_radius: 160,
        x: 300,
        y: 400,
        z: 120,
    });
    assert.ok(Math.abs(Math.hypot(dragged.x, dragged.y, dragged.z) - 160) < 1e-8);
    assert.deepEqual([dragged.fx, dragged.fy, dragged.fz], [dragged.x, dragged.y, dragged.z]);

    const node = { x: 120, y: -75, z: 210 };
    const angles = cameraAnglesForNode(node);
    const x1 = node.x * Math.cos(angles.rotateY) - node.z * Math.sin(angles.rotateY);
    const z1 = node.x * Math.sin(angles.rotateY) + node.z * Math.cos(angles.rotateY);
    const y1 = node.y * Math.cos(angles.rotateX) - z1 * Math.sin(angles.rotateX);
    assert.ok(Math.abs(x1) < 1e-8, 'focused node should project to the horizontal center');
    assert.ok(Math.abs(y1) < 1e-8, 'focused node should project to the vertical center');
    assert.deepEqual(relativeToCameraTarget(node, node), { x: 0, y: 0, z: 0 });

    const zoom = safeZoomForExtents(320, 420, 900, 760, 32);
    assert.ok(zoom < 0.35, 'narrow canvases must be allowed to zoom out far enough');
    assert.ok(900 * zoom <= 160 - 32 + 1e-8);
    assert.ok(760 * zoom <= 210 - 32 + 1e-8);
});

test('interaction labels truncate by measured width instead of character count', () => {
    const measure = (value) => Array.from(value).length * 12;
    const label = fitTextToWidth('这是一个非常长的章节标题需要在窄屏中显示', 120, measure);
    assert.ok(label.endsWith('…'));
    assert.ok(measure(label) <= 120);
});

test('spherical perspective keeps depth visible without extreme magnification', () => {
    assert.ok(perspectiveScale(-326, 1) < 1.7);
    assert.ok(perspectiveScale(326, 1) > 0.7);
});

test('chapter expansion uses chapter id while direct pages use their book scope', () => {
    assert.deepEqual(
        buildChapterExpandFilters({ type: 'chapter', chapter_id: 386, book_id: 22 }, { limit: '300', include_pages: '0' }),
        { limit: '800', include_pages: '1', chapter_id: '386' },
    );
    assert.deepEqual(
        buildChapterExpandFilters({ type: 'chapter', chapter_id: null, book_id: 22, direct_pages: true }, { limit: '300' }),
        { limit: '800', include_pages: '1', book_id: '22', direct_pages: '1' },
    );
    assert.equal(buildChapterExpandFilters({ type: 'chapter', chapter_id: null, book_id: null }), null);
    assert.deepEqual(
        buildChapterExpandFilters({ type: 'chapter', chapter_id: 386, book_id: 22, bookshelf_id: 7 }, { limit: '300' }),
        { limit: '800', include_pages: '1', bookshelf_id: '7', chapter_id: '386' },
    );
});

test('expanded chapter pages are merged, laid out on the page ring, then removable', () => {
    const base = prepareRadialHierarchyGraph({
        nodes: [
            { id: 'root:knowledge-base', type: 'root', title: 'Root' },
            { id: 'bookshelf:1', type: 'bookshelf', title: 'Shelf' },
            { id: 'book:2', type: 'book', title: 'Book', bookshelf_id: 1 },
            { id: 'chapter:1:2:386', type: 'chapter', title: 'Chapter', bookshelf_id: 1, book_id: 2, chapter_id: 386 },
        ],
        links: [
            { source: 'root:knowledge-base', target: 'bookshelf:1', type: 'contains' },
            { source: 'bookshelf:1', target: 'book:2', type: 'contains' },
            { source: 'book:2', target: 'chapter:1:2:386', type: 'contains' },
        ],
    });
    const expansion = mergeChapterExpansion(base, base.nodes.at(-1), {
        nodes: [
            { id: 'chapter:1:2:386', type: 'chapter', title: 'Chapter', chapter_id: 386 },
            { id: 'page:901', type: 'page', title: 'Page 901', page_id: 901, chapter_id: 386 },
        ],
        links: [{ source: 'chapter:1:2:386', target: 'page:901', type: 'contains' }],
    });

    assert.deepEqual(expansion.pageIds, ['page:901']);
    const page = expansion.data.nodes.find((node) => node.id === 'page:901');
    assert.ok(page, 'expanded page should be inserted');
    assert.equal(page.layout_level, 4);
    assert.equal(page.layout_radius, 356);
    assert.ok(Math.abs(radius3d(page) - 356) < 14, 'page jitter must remain close to its spherical shell');
    assert.equal(expansion.data.links.some((link) => link.source === 'chapter:1:2:386' && link.target === 'page:901'), true);

    const collapsed = collapseChapterExpansion(expansion.data, expansion.pageIds);
    assert.equal(collapsed.nodes.some((node) => node.id === 'page:901'), false);
    assert.equal(collapsed.links.some((link) => link.target === 'page:901'), false);
});

test('demo graph mirrors lazy chapter expansion instead of returning every page initially', async () => {
    const api = new DemoApi();
    const initial = await api.get('/knowledge-graph', { include_pages: '0' });
    assert.equal(initial.nodes.some((node) => node.type === 'page'), false);

    const chapter = await api.get('/knowledge-graph', { include_pages: '1', chapter_id: '301' });
    assert.equal(chapter.nodes.some((node) => node.type === 'page' && Number(node.chapter_id) === 301), true);

    const direct = await api.get('/knowledge-graph', { include_pages: '1', book_id: 'cases', direct_pages: '1' });
    assert.equal(direct.nodes.some((node) => node.type === 'page' && node.direct_pages === true), true);

    const manuals = await api.get('/knowledge-graph', { include_pages: '0', bookshelf_id: 'manuals' });
    assert.equal(manuals.nodes.some((node) => node.id === 'bookshelf:manuals'), true);
    assert.equal(manuals.nodes.some((node) => node.id === 'bookshelf:cases'), false);
    assert.equal(manuals.nodes.every((node) => node.type === 'root' || node.bookshelf_name === '芯片手册' || node.id === 'bookshelf:manuals'), true);
    assert.equal(manuals.stats.verified_count, 1);
    assert.equal(manuals.stats.partial_count, 2);
});

test('node fill colors express hierarchy type while the RAG ring remains independent', () => {
    assert.notEqual(TYPE_COLORS.bookshelf, TYPE_COLORS.book);
    assert.notEqual(TYPE_COLORS.book, TYPE_COLORS.chapter);
    assert.notEqual(TYPE_COLORS.chapter, TYPE_COLORS.page);
    assert.equal(nodeColor({ type: 'book', review_status: 'pending' }), TYPE_COLORS.book);
    assert.equal(nodeColor({ type: 'book', review_status: 'verified' }), TYPE_COLORS.book);
});

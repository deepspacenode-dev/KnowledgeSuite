import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import test from 'node:test';

const enabled = process.env.DRV_RUN_BROWSER_E2E === '1';

test('Bloub avatar renders, follows the pointer, opens the official Widget, and reacts to governance events', { skip: !enabled }, async () => {
    const require = createRequire(import.meta.url);
    const { chromium } = require('playwright');
    const fixture = join(dirname(fileURLToPath(import.meta.url)), 'fixtures', 'grokbot-preview.html');
    assert.ok(existsSync(fixture), fixture);

    const browser = await chromium.launch({
        headless: true,
        ...(process.env.DRV_CHROMIUM_EXECUTABLE ? { executablePath: process.env.DRV_CHROMIUM_EXECUTABLE } : {}),
    });
    const page = await browser.newPage({ viewport: { width: 1280, height: 820 } });
    const errors = [];
    page.on('pageerror', (error) => errors.push(error.message));
    page.on('console', (message) => {
        if (message.type() === 'error') errors.push(message.text());
    });

    try {
        await page.goto(pathToFileURL(fixture).href);
        const root = page.locator('#drvKnowledgeAssistant');
        const trigger = page.locator('#aiGovernanceCenterBtn');
        const panel = page.locator('#drvKnowledgeAssistantPanel');
        await root.waitFor({ state: 'visible' });
        assert.equal(await page.title(), 'Drv Knowledge Bloub Avatar Preview');
        assert.equal(await trigger.getAttribute('aria-expanded'), 'false');

        const avatar = page.locator('.drv-bloub-avatar');
        await avatar.waitFor({ state: 'visible' });
        const eye = avatar.locator('mask > path').nth(1);
        const initialTransform = await eye.getAttribute('transform');
        const box = await trigger.boundingBox();
        assert.ok(box);
        await page.mouse.move(box.x - 70, box.y + box.height / 2);
        await page.waitForTimeout(240);
        const followedTransform = await eye.getAttribute('transform');
        assert.notEqual(followedTransform, initialTransform);

        await trigger.click();
        assert.equal(await trigger.getAttribute('aria-expanded'), 'true');
        await panel.waitFor({ state: 'visible' });
        assert.equal(await panel.locator('[data-feature]').count(), 6);
        const widget = panel.locator('iframe.drv-assistant__widget-frame');
        await widget.waitFor({ state: 'attached' });
        assert.match(await widget.getAttribute('src'), /^http:\/\/127\.0\.0\.1:9\/chats\/widget\?/);
        assert.equal(await widget.getAttribute('referrerpolicy'), 'no-referrer');
        assert.equal(await widget.getAttribute('allow'), '');
        assert.equal(await panel.locator('form').count(), 0);
        assert.equal(await panel.getByText('RAGFlow 官方组件').count(), 1);

        await page.locator('[data-preview-feature="knowledge-graph"]').click();
        assert.equal(await page.locator('[data-avatar-host]').getAttribute('data-state'), 'burst');
        await page.waitForFunction(() => document.querySelector('[data-avatar-host]')?.getAttribute('data-state') === 'thinking');

        await page.locator('[data-preview-feature="overview"][data-preview-phase="error"]').click();
        assert.equal(await page.locator('[data-avatar-host]').getAttribute('data-state'), 'burst');
        await page.waitForFunction(() => document.querySelector('[data-avatar-host]')?.getAttribute('data-state') === 'alert');

        const mappings = await page.evaluate(() => ({
            loading: window.DrvKnowledgeAvatar.stateForFeature('assets', 'loading'),
            success: window.DrvKnowledgeAvatar.stateForFeature('assets', 'success'),
            error: window.DrvKnowledgeAvatar.stateForFeature('assets', 'error'),
        }));
        assert.deepEqual(mappings, { loading: 'thinking', success: 'notify', error: 'alert' });

        if (process.env.DRV_GROKBOT_SCREENSHOT) {
            await page.screenshot({ path: process.env.DRV_GROKBOT_SCREENSHOT, fullPage: true });
        }
        assert.deepEqual(errors, []);
    } finally {
        await browser.close();
    }
});

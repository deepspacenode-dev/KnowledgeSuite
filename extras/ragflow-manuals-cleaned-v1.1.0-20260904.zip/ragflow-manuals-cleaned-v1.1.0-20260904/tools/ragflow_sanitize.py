#!/usr/bin/env python3
"""Create non-destructive, offline RAGFlow-safe derivatives of Markdown manuals."""

from __future__ import annotations

import argparse
from bisect import bisect_right
import hashlib
from html import unescape
from html.parser import HTMLParser
import ipaddress
import json
from pathlib import Path
import re
import shutil
import tempfile
from typing import Any, Callable, Iterable
from urllib.parse import urlsplit


VERSION = "1.1.0"
SCHEMA_VERSION = "drvknowledge.ragflow-sanitize.v1"
DEFAULT_SOFT_LIMIT = 1800
DEFAULT_HARD_LIMIT = 2200
DEFAULT_SHARD_LIMIT = 1024 * 1024
MANUAL_SIZE_THRESHOLD = 2 * 1024 * 1024
IMAGE_COUNT_THRESHOLD = 100

FENCE_START_RE = re.compile(r"^[ \t]{0,3}(?P<fence>`{3,}|~{3,})(?P<info>.*)$")
EMPTY_ANCHOR_RE = re.compile(
    r"<a\b(?P<attrs>[^>]*)>\s*</a\s*>",
    re.IGNORECASE,
)
ANCHOR_ID_RE = re.compile(r"\b(?:name|id)\s*=\s*(['\"])(?P<value>.*?)\1", re.IGNORECASE)
STRUCTURAL_OPEN_TAG_RE = re.compile(
    r"<(?!/)(?P<tag>table|thead|tbody|tfoot|tr|th|td|p|ul|ol|li|div|span)\b"
    r"(?:[^>\"']|\"[^\"]*\"|'[^']*')*>",
    re.IGNORECASE,
)
HTML_IMAGE_RE = re.compile(
    r"<img\b(?P<attrs>(?:[^>\"']|\"[^\"]*\"|'[^']*')*)>",
    re.IGNORECASE,
)
HTML_ATTR_RE = re.compile(
    r"\b(?P<name>[\w:-]+)\s*=\s*(?:\"(?P<double>[^\"]*)\"|'(?P<single>[^']*)'|(?P<bare>[^\s\"'=<>`]+))",
    re.DOTALL,
)
REFERENCE_DEFINITION_RE = re.compile(
    r"^[ \t]{0,3}\[(?P<label>(?:\\.|[^\]])+)\]:[ \t]*"
    r"(?P<url><[^>\n]+>|[^ \t\n]+)"
    r"(?:[ \t]+(?:\"(?P<double>[^\"]*)\"|'(?P<single>[^']*)'|\((?P<paren>[^)]*)\)))?[ \t]*$",
    re.MULTILINE,
)
HTML_TABLE_TAG_RE = re.compile(
    r"</?table(?=[\s>/])(?:[^>\"']|\"[^\"]*\"|'[^']*')*>",
    re.IGNORECASE,
)
HTML_ANY_TAG_RE = re.compile(r"<[^>]+>")
PSEUDO_TAG_NAMES = "table|td|tr|th|tbody|thead|div"
PSEUDO_SHIFT_RE = re.compile(
    rf"<<(?=(?:{PSEUDO_TAG_NAMES})(?![\s>/]))",
    re.IGNORECASE,
)
PSEUDO_SINGLE_RE = re.compile(
    rf"(?<!<)<(?=(?:{PSEUDO_TAG_NAMES})(?![\s>/]))",
    re.IGNORECASE,
)
PRIVATE_BULLET = "\uf06c"
FRONT_MATTER_RE = re.compile(r"\A---\n.*?\n---\n\n", re.DOTALL)


class SanitizeError(RuntimeError):
    """Raised when preserving content and satisfying the hard gate is impossible."""


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_text(value: str) -> str:
    return sha256_bytes(value.encode("utf-8"))


def normalize_newlines(value: str) -> str:
    return value.replace("\r\n", "\n").replace("\r", "\n")


def _decode_markdown(raw_bytes: bytes, path: Path) -> str:
    try:
        return normalize_newlines(raw_bytes.decode("utf-8-sig"))
    except UnicodeDecodeError as exc:
        raise SanitizeError(f"source must be UTF-8: {path}") from exc


def read_markdown(path: Path) -> str:
    return _decode_markdown(path.read_bytes(), path)


def write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding="utf-8", newline="\n")


def write_json(path: Path, value: Any) -> None:
    write_text(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def _fence_marker(line: str) -> tuple[str, int] | None:
    match = FENCE_START_RE.match(line)
    if not match:
        return None
    fence = match.group("fence")
    return fence[0], len(fence)


def _is_closing_fence(line: str, marker: tuple[str, int]) -> bool:
    char, length = marker
    return bool(re.match(rf"^[ \t]{{0,3}}{re.escape(char)}{{{length},}}\s*$", line))


def _fenced_segments(value: str, context: str = "document") -> list[tuple[bool, str]]:
    """Split Markdown into plain/fenced segments without changing any character."""
    lines = normalize_newlines(value).split("\n")
    segments: list[tuple[bool, str]] = []
    current: list[str] = []
    active: tuple[str, int] | None = None
    opening_line = 0

    def flush(is_fence: bool) -> None:
        if current:
            segments.append((is_fence, "\n".join(current)))
            current.clear()

    for line_number, line in enumerate(lines, start=1):
        marker = _fence_marker(line)
        if active is None and marker is not None:
            flush(False)
            active = marker
            opening_line = line_number
            current.append(line)
            continue
        current.append(line)
        if active is not None and _is_closing_fence(line, active):
            flush(True)
            active = None
    if active is not None:
        raise SanitizeError(f"{context} contains unclosed fenced code block opened at line {opening_line}")
    flush(False)
    return segments


def _map_outside_fences(value: str, transform: Callable[[str], tuple[str, dict[str, Any]]]) -> tuple[str, dict[str, Any]]:
    lines = normalize_newlines(value).split("\n")
    output: list[str] = []
    counts: dict[str, Any] = {}
    active: tuple[str, int] | None = None

    for line_number, line in enumerate(lines, start=1):
        marker = _fence_marker(line)
        if active is None and marker is not None:
            active = marker
            output.append(line)
            continue
        if active is not None:
            output.append(line)
            if _is_closing_fence(line, active):
                active = None
            continue
        transformed, line_counts = transform(line)
        output.append(transformed)
        for key, count in line_counts.items():
            if key == "_ocr_triplet_records":
                records = counts.setdefault(key, [])
                for record in count:
                    records.append({"line": line_number, **record})
            else:
                counts[key] = counts.get(key, 0) + count

    return "\n".join(output), counts


def _collapse_tripled_regions_detailed(line: str) -> tuple[str, list[dict[str, object]]]:
    if not line:
        return line, []
    pieces: list[str] = []
    records: list[dict[str, object]] = []
    position = 0

    def collapse_region(start_pos: int, end_pos: int) -> None:
        nonlocal position
        before = line[start_pos:end_pos]
        after_parts: list[str] = []
        run_start = 0
        for index in range(1, len(before) + 1):
            if index == len(before) or before[index] != before[run_start]:
                after_parts.append(before[run_start] * ((index - run_start) // 3))
                run_start = index
        after = "".join(after_parts)
        pieces.append(line[position:start_pos])
        pieces.append(after)
        records.append(
            {
                "start_column": start_pos + 1,
                "end_column": end_pos,
                "before_chars": len(before),
                "after_chars": len(after),
                "before_sha256": sha256_text(before),
                "after_sha256": sha256_text(after),
            }
        )
        position = end_pos

    candidate_start = 0
    candidate_end = 0
    candidate_runs = 0
    run_start = 0
    for index in range(1, len(line) + 1):
        if index < len(line) and line[index] == line[run_start]:
            continue
        run_length = index - run_start
        if run_length >= 3 and run_length % 3 == 0:
            if candidate_runs == 0:
                candidate_start = run_start
            candidate_end = index
            candidate_runs += 1
        else:
            if candidate_runs >= 12 and candidate_end - candidate_start >= 36:
                collapse_region(candidate_start, candidate_end)
            candidate_runs = 0
        run_start = index
    if candidate_runs >= 12 and candidate_end - candidate_start >= 36:
        collapse_region(candidate_start, candidate_end)

    if not records:
        return line, []
    pieces.append(line[position:])
    return "".join(pieces), records


def _collapse_tripled_regions(line: str) -> tuple[str, int]:
    collapsed, records = _collapse_tripled_regions_detailed(line)
    return collapsed, len(records)


def _clean_bookstack_line(line: str) -> tuple[str, dict[str, Any]]:
    counts: dict[str, Any] = {
        "pseudo_html_tags": 0,
        "private_bullets": 0,
        "ocr_triplet_spans": 0,
        "_ocr_triplet_records": [],
    }
    line, shift_count = PSEUDO_SHIFT_RE.subn("&lt;&lt;", line)
    line, single_count = PSEUDO_SINGLE_RE.subn("&lt;", line)
    counts["pseudo_html_tags"] = shift_count + single_count
    counts["private_bullets"] = line.count(PRIVATE_BULLET)
    line = line.replace(PRIVATE_BULLET, "•")
    line, triplet_records = _collapse_tripled_regions_detailed(line)
    counts["ocr_triplet_spans"] = len(triplet_records)
    counts["_ocr_triplet_records"] = triplet_records
    return line, counts


def _deduplicate_empty_anchors(value: str, seen: set[str] | None = None) -> tuple[str, int]:
    seen = seen if seen is not None else set()
    removed = 0

    def replace(match: re.Match[str]) -> str:
        nonlocal removed
        id_match = ANCHOR_ID_RE.search(match.group("attrs"))
        if not id_match:
            return match.group(0)
        key = id_match.group("value").strip()
        if not key or key not in seen:
            if key:
                seen.add(key)
            return match.group(0)
        removed += 1
        return ""

    return EMPTY_ANCHOR_RE.sub(replace, value), removed


def clean_for_bookstack(source: str) -> tuple[str, dict[str, Any]]:
    """Create a readable derivative while preserving visible technical content."""
    cleaned, counts = _map_outside_fences(source, _clean_bookstack_line)
    segments = _fenced_segments(cleaned, "BookStack derivative")
    seen_anchors: set[str] = set()
    rebuilt: list[str] = []
    duplicate_anchors = 0
    for is_fence, segment in segments:
        if is_fence:
            rebuilt.append(segment)
            continue
        segment, removed = _deduplicate_empty_anchors(segment, seen_anchors)
        duplicate_anchors += removed
        rebuilt.append(segment)
    cleaned = "\n".join(rebuilt)
    counts["duplicate_empty_anchors"] = duplicate_anchors
    for key in ("pseudo_html_tags", "private_bullets", "ocr_triplet_spans"):
        counts.setdefault(key, 0)
    counts.setdefault("_ocr_triplet_records", [])
    return cleaned, counts


def _parse_markdown_image_body(body: str) -> tuple[str, str]:
    value = body.strip()
    title = ""
    match = re.match(r"^(?P<url>.+?)\s+(['\"])(?P<title>.*?)\2\s*$", value)
    if match:
        return match.group("url").strip().strip("<>"), match.group("title").strip()
    return value.strip("<>"), title


def _classify_image_url(url: str) -> str:
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"}:
        return "relative"
    host = parsed.hostname or ""
    if host.casefold() in {"localhost", "localhost.localdomain"}:
        return "private_url"
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return "public_url"
    return "private_url" if (address.is_private or address.is_loopback or address.is_link_local) else "public_url"


def _image_caption(alt: str, title: str) -> str:
    label = (alt or title).strip()
    return f"[图示：{label}]" if label else "[图示，原图见 BookStack 源页面]"


def _reference_key(value: str) -> str:
    return re.sub(r"\s+", " ", value.replace("\\]", "]")).strip().casefold()


def _reference_definitions(value: str) -> dict[str, tuple[str, str]]:
    definitions: dict[str, tuple[str, str]] = {}
    for match in REFERENCE_DEFINITION_RE.finditer(value):
        label = _reference_key(match.group("label"))
        url = match.group("url").strip().strip("<>")
        title = next(
            (candidate for candidate in (match.group("double"), match.group("single"), match.group("paren")) if candidate is not None),
            "",
        ).strip()
        definitions.setdefault(label, (url, title))
    return definitions


def _is_escaped(value: str, index: int) -> bool:
    slashes = 0
    cursor = index - 1
    while cursor >= 0 and value[cursor] == "\\":
        slashes += 1
        cursor -= 1
    return slashes % 2 == 1


def _find_unescaped(value: str, start: int, target: str) -> int | None:
    cursor = start
    while cursor < len(value):
        if value[cursor] == target and not _is_escaped(value, cursor):
            return cursor
        cursor += 1
    return None


def _find_closing_parenthesis(value: str, opening: int) -> int | None:
    depth = 0
    for cursor in range(opening, len(value)):
        if _is_escaped(value, cursor):
            continue
        char = value[cursor]
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return cursor
    return None


def _replace_markdown_images(
    value: str,
    *,
    line_offset: int,
    definitions: dict[str, tuple[str, str]],
) -> tuple[str, list[dict[str, object]]]:
    images: list[dict[str, object]] = []
    newlines = [index for index, char in enumerate(value) if char == "\n"]
    output: list[str] = []
    position = 0
    cursor = 0
    while cursor < len(value):
        start = value.find("![", cursor)
        if start < 0:
            break
        if _is_escaped(value, start):
            cursor = start + 2
            continue
        alt_end = _find_unescaped(value, start + 2, "]")
        if alt_end is None:
            raise SanitizeError(f"unclosed Markdown image alt text at line {line_offset + bisect_right(newlines, start) + 1}")
        alt = value[start + 2 : alt_end].replace("\\]", "]").strip()
        end = alt_end + 1
        url = ""
        title = ""
        syntax = "markdown"
        reference = ""
        if end < len(value) and value[end] == "(":
            closing = _find_closing_parenthesis(value, end)
            if closing is None:
                raise SanitizeError(f"unclosed Markdown image target at line {line_offset + bisect_right(newlines, start) + 1}")
            url, title = _parse_markdown_image_body(value[end + 1 : closing])
            end = closing + 1
        elif end < len(value) and value[end] == "[":
            reference_end = _find_unescaped(value, end + 1, "]")
            if reference_end is None:
                raise SanitizeError(f"unclosed Markdown image reference at line {line_offset + bisect_right(newlines, start) + 1}")
            reference = value[end + 1 : reference_end].strip() or alt
            url, title = definitions.get(_reference_key(reference), ("", ""))
            end = reference_end + 1
            syntax = "markdown_reference"
        elif _reference_key(alt) in definitions:
            reference = alt
            url, title = definitions[_reference_key(alt)]
            syntax = "markdown_reference"
        else:
            cursor = alt_end + 1
            continue
        output.append(value[position:start])
        output.append(_image_caption(alt, title))
        kind = _classify_image_url(url) if url else "unresolved_reference"
        images.append(
            {
                "line": line_offset + bisect_right(newlines, start) + 1,
                "syntax": syntax,
                "kind": kind,
                "url": url,
                "alt": alt,
                "title": title,
                **({"reference": reference} if reference else {}),
            }
        )
        position = end
        cursor = end
    output.append(value[position:])
    return "".join(output), images


def _html_attributes(value: str) -> dict[str, str]:
    attributes: dict[str, str] = {}
    for match in HTML_ATTR_RE.finditer(value):
        raw = next(
            (candidate for candidate in (match.group("double"), match.group("single"), match.group("bare")) if candidate is not None),
            "",
        )
        attributes[match.group("name").casefold()] = raw
    return attributes


def _replace_images(
    value: str,
    line_offset: int = 0,
    definitions: dict[str, tuple[str, str]] | None = None,
) -> tuple[str, list[dict[str, object]]]:
    images: list[dict[str, object]] = []
    replaced, markdown_images = _replace_markdown_images(
        value,
        line_offset=line_offset,
        definitions=definitions if definitions is not None else _reference_definitions(value),
    )
    images.extend(markdown_images)
    html_newlines = [index for index, char in enumerate(replaced) if char == "\n"]

    def html_replace(match: re.Match[str]) -> str:
        attrs = _html_attributes(match.group("attrs"))
        url = attrs.get("src", "").strip()
        alt = attrs.get("alt", "").strip()
        title = attrs.get("title", "").strip()
        images.append(
            {
                "line": line_offset + bisect_right(html_newlines, match.start()) + 1,
                "syntax": "html",
                "kind": _classify_image_url(url) if url else "missing_source",
                "url": url,
                "alt": alt,
                "title": title,
            }
        )
        return _image_caption(alt, title)

    return HTML_IMAGE_RE.sub(html_replace, replaced), images


def _strip_ragflow_html_noise(value: str) -> str:
    value = EMPTY_ANCHOR_RE.sub("", value)

    def structural_tag(match: re.Match[str]) -> str:
        return f"<{match.group('tag').lower()}>"

    return STRUCTURAL_OPEN_TAG_RE.sub(structural_tag, value)


def clean_for_ragflow(
    source: str,
    *,
    source_is_bookstack_cleaned: bool = False,
) -> tuple[str, list[dict[str, object]]]:
    """Create a text-first derivative that never asks RAGFlow to load images."""
    cleaned = source if source_is_bookstack_cleaned else clean_for_bookstack(source)[0]
    segments = _fenced_segments(cleaned, "RAGFlow derivative")
    definitions = _reference_definitions("\n".join(segment for is_fence, segment in segments if not is_fence))
    output: list[str] = []
    images: list[dict[str, object]] = []
    line_offset = 0
    for index, (is_fence, segment) in enumerate(segments):
        if is_fence:
            output.append(segment)
        else:
            segment, found = _replace_images(segment, line_offset=line_offset, definitions=definitions)
            output.append(_strip_ragflow_html_noise(segment))
            images.extend(found)
        line_offset += segment.count("\n")
        if index + 1 < len(segments):
            line_offset += 1
    return "\n".join(output), images


class _TableTextParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str]] = []
        self.current_row: list[str] | None = None
        self.current_cell: list[str] | None = None
        self.current_caption: list[str] | None = None
        self.captions: list[str] = []
        self.current_row_is_header = False
        self.in_thead = False
        self.header_rows: set[int] = set()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.casefold()
        if tag == "thead":
            self.in_thead = True
        elif tag == "tr":
            self.current_row = []
            self.current_row_is_header = self.in_thead
        elif tag in {"td", "th"}:
            if self.current_row is None:
                self.current_row = []
            self.current_cell = []
            if tag == "th":
                self.current_row_is_header = True
        elif tag == "caption":
            self.current_caption = []
        elif tag == "br" and self.current_cell is not None:
            self.current_cell.append(" ")

    def handle_endtag(self, tag: str) -> None:
        tag = tag.casefold()
        if tag == "thead":
            self.in_thead = False
        elif tag == "caption" and self.current_caption is not None:
            caption = re.sub(r"\s+", " ", "".join(self.current_caption)).strip()
            if caption:
                self.captions.append(caption)
            self.current_caption = None
        elif tag in {"td", "th"} and self.current_cell is not None:
            assert self.current_row is not None
            text = re.sub(r"\s+", " ", "".join(self.current_cell)).strip()
            self.current_row.append(text)
            self.current_cell = None
        elif tag == "tr" and self.current_row is not None:
            if any(cell for cell in self.current_row):
                row_index = len(self.rows)
                self.rows.append(self.current_row)
                if self.current_row_is_header:
                    self.header_rows.add(row_index)
            self.current_row = None
            self.current_row_is_header = False

    def handle_data(self, data: str) -> None:
        if self.current_cell is not None:
            self.current_cell.append(data)
        elif self.current_caption is not None:
            self.current_caption.append(data)


class _VisibleTextParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.casefold() in {"br", "p", "div", "li", "tr", "td", "th", "caption"}:
            self.parts.append(" ")

    def handle_endtag(self, tag: str) -> None:
        if tag.casefold() in {"p", "div", "li", "tr", "td", "th", "caption"}:
            self.parts.append(" ")

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def _max_html_table_depth(fragment: str) -> int:
    depth = 0
    maximum = 0
    for match in HTML_TABLE_TAG_RE.finditer(fragment):
        if match.group(0).lower().startswith("</"):
            depth = max(0, depth - 1)
        else:
            depth += 1
            maximum = max(maximum, depth)
    return maximum


def _visible_html_text(fragment: str) -> str:
    parser = _VisibleTextParser()
    try:
        parser.feed(fragment)
        parser.close()
        return re.sub(r"\s+", " ", "".join(parser.parts)).strip()
    except Exception:
        return re.sub(r"\s+", " ", unescape(HTML_ANY_TAG_RE.sub(" ", fragment))).strip()


def _html_table_spans(value: str) -> tuple[list[tuple[int, int]], int, int]:
    spans: list[tuple[int, int]] = []
    stack: list[int] = []
    unmatched_closes = 0
    for match in HTML_TABLE_TAG_RE.finditer(value):
        if match.group(0).lower().startswith("</"):
            if not stack:
                unmatched_closes += 1
                continue
            start = stack.pop()
            if not stack:
                spans.append((start, match.end()))
        else:
            stack.append(match.start())
    return spans, len(stack), unmatched_closes


def _table_to_lines(fragment: str) -> str:
    if _max_html_table_depth(fragment) > 1:
        plain = _visible_html_text(fragment)
        return "表格（嵌套结构展开）：\n- 内容：" + plain if plain else ""
    parser = _TableTextParser()
    try:
        parser.feed(fragment)
        parser.close()
    except Exception:
        parser.rows = []
    if not parser.rows:
        plain = _visible_html_text(fragment)
        return "表格：\n- 行 1：" + plain if plain else ""
    lines = [*(f"表题：{caption}" for caption in parser.captions), "表格："]
    for index, row in enumerate(parser.rows):
        label = "表头" if index in parser.header_rows else f"行 {index + 1}"
        lines.append(f"- {label}：" + " | ".join(row))
    return "\n".join(lines)


def _replace_html_tables(value: str) -> tuple[str, int]:
    spans, remaining, unmatched = _html_table_spans(value)
    if remaining or unmatched:
        raise SanitizeError(
            f"unbalanced HTML table tags after pseudo-tag protection: open={remaining} close={unmatched}"
        )
    if not spans:
        return value, 0
    pieces: list[str] = []
    position = 0
    for start, end in spans:
        pieces.append(value[position:start])
        pieces.append(_table_to_lines(value[start:end]))
        position = end
    pieces.append(value[position:])
    return "".join(pieces), len(spans)


def _replace_html_tables_outside_fences(value: str) -> tuple[str, int]:
    output: list[str] = []
    converted = 0
    for is_fence, segment in _fenced_segments(value, "HTML table conversion"):
        if is_fence:
            output.append(segment)
            continue
        segment, count = _replace_html_tables(segment)
        output.append(segment)
        converted += count
    return "\n".join(output), converted


def _split_pipe_row(line: str) -> list[str]:
    value = line.strip()
    if value.startswith("|"):
        value = value[1:]
    if value.endswith("|"):
        value = value[:-1]
    cells: list[str] = []
    current: list[str] = []
    code_ticks = 0
    index = 0
    while index < len(value):
        char = value[index]
        if char == "\\" and index + 1 < len(value):
            current.append(value[index : index + 2])
            index += 2
            continue
        if char == "`":
            end = index + 1
            while end < len(value) and value[end] == "`":
                end += 1
            run = end - index
            if code_ticks == 0:
                code_ticks = run
            elif code_ticks == run:
                code_ticks = 0
            current.append(value[index:end])
            index = end
            continue
        if char == "|" and code_ticks == 0:
            cells.append("".join(current).strip())
            current = []
        else:
            current.append(char)
        index += 1
    cells.append("".join(current).strip())
    return cells


def _is_pipe_row(line: str) -> bool:
    cells = _split_pipe_row(line)
    return len(cells) >= 2 and any(cells)


def _is_pipe_separator(line: str) -> bool:
    cells = _split_pipe_row(line)
    return len(cells) >= 2 and all(re.fullmatch(r":?-+:?", cell.replace(" ", "")) for cell in cells)


def _replace_markdown_tables(value: str) -> tuple[str, int]:
    lines = value.split("\n")
    output: list[str] = []
    active_fence: tuple[str, int] | None = None
    index = 0
    converted = 0
    while index < len(lines):
        line = lines[index]
        marker = _fence_marker(line)
        if active_fence is None and marker is not None:
            active_fence = marker
            output.append(line)
            index += 1
            continue
        if active_fence is not None:
            output.append(line)
            if _is_closing_fence(line, active_fence):
                active_fence = None
            index += 1
            continue
        if index + 1 < len(lines) and _is_pipe_row(line) and _is_pipe_separator(lines[index + 1]):
            rows = [_split_pipe_row(line)]
            cursor = index + 2
            while cursor < len(lines) and _is_pipe_row(lines[cursor]):
                rows.append(_split_pipe_row(lines[cursor]))
                cursor += 1
            output.append("表格：")
            output.append("- 表头：" + " | ".join(rows[0]))
            for row_index, row in enumerate(rows[1:], start=1):
                output.append(f"- 行 {row_index}：" + " | ".join(row))
            converted += 1
            index = cursor
            continue
        output.append(line)
        index += 1
    if active_fence is not None:
        raise SanitizeError("unclosed fenced code block")
    return "\n".join(output), converted


def _markdown_table_atom_lengths(value: str) -> list[int]:
    lines = value.split("\n")
    lengths: list[int] = []
    index = 0
    while index + 1 < len(lines):
        if not (_is_pipe_row(lines[index]) and _is_pipe_separator(lines[index + 1])):
            index += 1
            continue
        cursor = index + 2
        while cursor < len(lines) and _is_pipe_row(lines[cursor]):
            cursor += 1
        lengths.append(len("\n".join(lines[index:cursor])))
        index = cursor
    return lengths


def _protected_atom_inventory(value: str) -> dict[str, int]:
    counts = {"fenced_blocks": 0, "html_tables": 0, "markdown_tables": 0, "max_chars": 0}
    for is_fence, segment in _fenced_segments(value, "protected-atom audit"):
        if is_fence:
            counts["fenced_blocks"] += 1
            counts["max_chars"] = max(counts["max_chars"], len(segment))
            continue
        spans, _remaining, _unmatched = _html_table_spans(segment)
        counts["html_tables"] += len(spans)
        for start, end in spans:
            counts["max_chars"] = max(counts["max_chars"], end - start)
        markdown_lengths = _markdown_table_atom_lengths(segment)
        counts["markdown_tables"] += len(markdown_lengths)
        if markdown_lengths:
            counts["max_chars"] = max(counts["max_chars"], max(markdown_lengths))
    return counts


def _best_split_position(value: str, soft_limit: int) -> int:
    window = value[:soft_limit]
    minimum = max(1, soft_limit // 3)
    patterns = [r"\n\n", r"\n", r"[。；！？]", r"[.!?;]\s", r"[,，]\s?", r"\s"]
    for pattern in patterns:
        matches = list(re.finditer(pattern, window))
        if matches and matches[-1].end() >= minimum:
            return matches[-1].end()
    return soft_limit


def _neutralize_accidental_fence_starts(value: str) -> str:
    lines: list[str] = []
    for line in value.split("\n"):
        match = FENCE_START_RE.match(line)
        if not match:
            lines.append(line)
            continue
        fence = match.group("fence")
        entity = "&#96;" if fence[0] == "`" else "&#126;"
        start = match.start("fence")
        lines.append(line[:start] + entity * len(fence) + line[match.end("fence") :])
    return "\n".join(lines)


def _split_plain(value: str, soft_limit: int) -> list[str]:
    content = value.strip()
    chunks: list[str] = []
    cursor = 0
    while cursor < len(content):
        remaining_length = len(content) - cursor
        if remaining_length <= soft_limit:
            chunks.append(_neutralize_accidental_fence_starts(content[cursor:]))
            break
        window = content[cursor : cursor + soft_limit]
        split_at = _best_split_position(window, soft_limit)
        part = content[cursor : cursor + split_at].strip()
        if not part:
            split_at = soft_limit
            part = content[cursor : cursor + split_at]
        chunks.append(_neutralize_accidental_fence_starts(part))
        cursor += split_at
        while cursor < len(content) and content[cursor].isspace():
            cursor += 1
    return chunks


def _split_fence(lines: list[str], soft_limit: int, hard_limit: int) -> list[str]:
    opening = lines[0]
    closing = lines[-1]
    content = lines[1:-1]
    wrapper_cost = len(opening) + len(closing) + 2
    available = max(1, soft_limit - wrapper_cost)
    hard_available = max(1, hard_limit - wrapper_cost)
    for line in content:
        if len(line) > hard_available:
            raise SanitizeError(
                f"single fenced-code line is {len(line)} characters; hard limit after wrappers is {hard_available}"
            )
    parts: list[str] = []
    current: list[str] = []
    current_size = 0
    for line in content:
        added = len(line) + (1 if current else 0)
        if current and current_size + added > available:
            parts.append(opening + "\n" + "\n".join(current) + "\n" + closing)
            current = []
            current_size = 0
        current.append(line)
        current_size += len(line) + (1 if len(current) > 1 else 0)
    if current or not parts:
        parts.append(opening + "\n" + "\n".join(current) + "\n" + closing)
    return parts


def _split_blocks(value: str, soft_limit: int, hard_limit: int) -> list[str]:
    lines = value.split("\n")
    atoms: list[str] = []
    plain: list[str] = []
    index = 0

    def flush_plain() -> None:
        if not plain:
            return
        atoms.extend(_split_plain("\n".join(plain), soft_limit))
        plain.clear()

    while index < len(lines):
        marker = _fence_marker(lines[index])
        if marker is None:
            plain.append(lines[index])
            index += 1
            continue
        flush_plain()
        fence_lines = [lines[index]]
        index += 1
        closed = False
        while index < len(lines):
            fence_lines.append(lines[index])
            if _is_closing_fence(lines[index], marker):
                closed = True
                index += 1
                break
            index += 1
        if not closed:
            raise SanitizeError("unclosed fenced code block")
        atoms.extend(_split_fence(fence_lines, soft_limit, hard_limit))
    flush_plain()
    atoms = [atom for atom in atoms if atom.strip()]
    oversized = [len(atom) for atom in atoms if len(atom) > hard_limit]
    if oversized:
        raise SanitizeError(f"sanitizer produced atom above hard limit: {max(oversized)}")
    return atoms


def build_ragflow_body(
    source: str,
    soft_limit: int,
    hard_limit: int,
    *,
    source_is_bookstack_cleaned: bool = False,
) -> dict[str, object]:
    if soft_limit < 256 or hard_limit < soft_limit or hard_limit > DEFAULT_HARD_LIMIT:
        raise SanitizeError(
            f"limits must satisfy 256 <= soft_limit <= hard_limit <= {DEFAULT_HARD_LIMIT}"
        )
    safe, images = clean_for_ragflow(source, source_is_bookstack_cleaned=source_is_bookstack_cleaned)
    safe, html_tables = _replace_html_tables_outside_fences(safe)
    safe, markdown_tables = _replace_markdown_tables(safe)
    atoms = _split_blocks(safe, soft_limit, hard_limit)
    body = "\n\n".join(atoms).strip() + "\n"
    return {
        "body": body,
        "atoms": atoms,
        "images": images,
        "html_tables_converted": html_tables,
        "markdown_tables_converted": markdown_tables,
        "body_sha256": sha256_text(body),
        "max_atom_chars": max((len(atom) for atom in atoms), default=0),
    }


def _image_inventory(value: str) -> list[dict[str, object]]:
    images: list[dict[str, object]] = []
    line_offset = 0
    segments = _fenced_segments(value, "image inventory")
    definitions = _reference_definitions("\n".join(segment for is_fence, segment in segments if not is_fence))
    for index, (is_fence, segment) in enumerate(segments):
        if not is_fence:
            _safe, found = _replace_images(segment, line_offset=line_offset, definitions=definitions)
            images.extend(found)
        line_offset += segment.count("\n")
        if index + 1 < len(segments):
            line_offset += 1
    return images


def _html_table_balance(value: str) -> tuple[int, int]:
    remaining = 0
    unmatched = 0
    for is_fence, segment in _fenced_segments(value, "HTML table audit"):
        if is_fence:
            continue
        _spans, segment_remaining, segment_unmatched = _html_table_spans(segment)
        remaining += segment_remaining
        unmatched += segment_unmatched
    return remaining, unmatched


def _count_pseudo_tags(value: str) -> int:
    total = 0
    active: tuple[str, int] | None = None
    for line in normalize_newlines(value).split("\n"):
        marker = _fence_marker(line)
        if active is None and marker is not None:
            active = marker
            continue
        if active is not None:
            if _is_closing_fence(line, active):
                active = None
            continue
        total += len(PSEUDO_SHIFT_RE.findall(line)) + len(PSEUDO_SINGLE_RE.findall(line))
    return total


def _fence_balance(value: str) -> tuple[int, bool]:
    count = 0
    active: tuple[str, int] | None = None
    for line in normalize_newlines(value).split("\n"):
        marker = _fence_marker(line)
        if active is None and marker is not None:
            active = marker
            count += 1
        elif active is not None and _is_closing_fence(line, active):
            active = None
            count += 1
    return count, active is None


def audit_source(
    path: Path,
    hard_limit: int = DEFAULT_HARD_LIMIT,
    *,
    source: str | None = None,
    raw_bytes: bytes | None = None,
) -> dict[str, object]:
    if hard_limit < 256 or hard_limit > DEFAULT_HARD_LIMIT:
        raise SanitizeError(f"hard_limit must satisfy 256 <= hard_limit <= {DEFAULT_HARD_LIMIT}")
    raw_bytes = path.read_bytes() if raw_bytes is None else raw_bytes
    source = _decode_markdown(raw_bytes, path) if source is None else source
    images = _image_inventory(source)
    lines = source.split("\n")
    fence_marks, fences_balanced = _fence_balance(source)
    remaining_tables, unmatched_tables = _html_table_balance(source)
    pseudo_tags = _count_pseudo_tags(source)
    private_bullets = source.count(PRIVATE_BULLET)
    protected_atoms = _protected_atom_inventory(source)
    max_line = max((len(line) for line in lines), default=0)
    risks: list[str] = []
    if len(raw_bytes) > MANUAL_SIZE_THRESHOLD:
        risks.append("source_over_2mib")
    if max_line > hard_limit:
        risks.append("line_over_hard_limit")
    if protected_atoms["max_chars"] > hard_limit:
        risks.append("protected_atom_over_hard_limit")
    if len(images) > IMAGE_COUNT_THRESHOLD:
        risks.append("image_count_over_100")
    if any(item["kind"] in {"private_url", "relative", "unresolved_reference", "missing_source"} for item in images):
        risks.append("non_public_images")
    if pseudo_tags:
        risks.append("pseudo_html_tags")
    if private_bullets:
        risks.append("private_use_bullets")
    if not fences_balanced:
        risks.append("unbalanced_fences")
    if remaining_tables or unmatched_tables:
        risks.append("unbalanced_html_tables")
    return {
        "schema_version": SCHEMA_VERSION,
        "sanitizer_version": VERSION,
        "source": str(path.resolve()),
        "source_sha256": sha256_bytes(raw_bytes),
        "source_bytes": len(raw_bytes),
        "lines": len(lines),
        "max_line_chars": max_line,
        "images": {
            "total": len(images),
            "private": sum(item["kind"] == "private_url" for item in images),
            "relative": sum(item["kind"] == "relative" for item in images),
            "public": sum(item["kind"] == "public_url" for item in images),
        },
        "pseudo_html_tags": pseudo_tags,
        "private_bullets": private_bullets,
        "protected_atoms": protected_atoms,
        "fence_marks": fence_marks,
        "fences_balanced": fences_balanced,
        "remaining_html_table_opens": remaining_tables,
        "unmatched_html_table_closes": unmatched_tables,
        "risks": risks,
        "requires_sanitization": bool(risks),
    }


def _shard_atoms(atoms: Iterable[str], shard_limit: int) -> list[str]:
    if shard_limit < 1024:
        raise SanitizeError("shard_limit must be at least 1024 bytes")
    shards: list[str] = []
    current: list[str] = []
    for atom in atoms:
        candidate = "\n\n".join(current + [atom]).strip() + "\n"
        if current and len(candidate.encode("utf-8")) > shard_limit:
            shards.append("\n\n".join(current).strip() + "\n")
            current = [atom]
        else:
            current.append(atom)
    if current:
        shards.append("\n\n".join(current).strip() + "\n")
    return shards


def _front_matter(source_name: str, source_hash: str, part: int, part_count: int) -> str:
    return (
        "---\n"
        f"schema_version: {SCHEMA_VERSION}\n"
        f"sanitizer_version: {VERSION}\n"
        f"source_file: {json.dumps(source_name, ensure_ascii=False)}\n"
        f"source_sha256: {source_hash}\n"
        f"part: {part}\n"
        f"part_count: {part_count}\n"
        "---\n\n"
    )


def _audit_markdown(audit: dict[str, object]) -> str:
    source = audit["source"]
    ragflow = audit["ragflow"]
    changes = audit["changes"]
    warnings = audit["warnings"]
    lines = [
        "# RAGFlow 文档清洗审计",
        "",
        f"- 结果：`{audit['result']}`",
        f"- 源文件：`{source['name']}`",
        f"- 源 SHA-256：`{source['sha256']}`",
        f"- 清洗器版本：`{audit['sanitizer_version']}`",
        f"- RAGFlow 分片：`{ragflow['part_count']}`",
        f"- 最大结构原子：`{ragflow['max_atom_chars']}` 字符",
        "",
        "## 规则命中",
        "",
    ]
    for key, value in changes.items():
        lines.append(f"- `{key}`：{value}")
    lines.extend(["", "## 警告", ""])
    if warnings:
        lines.extend(f"- {warning}" for warning in warnings)
    else:
        lines.append("- 无")
    lines.extend(["", "## 分片", ""])
    for part in ragflow["parts"]:
        lines.append(f"- `{part['name']}`：{part['bytes']} bytes，SHA-256 `{part['sha256']}`")
    return "\n".join(lines) + "\n"


def _structural_atoms_from_output(value: str, context: str = "output") -> list[str]:
    lines = normalize_newlines(value).split("\n")
    atoms: list[str] = []
    active: tuple[str, int] | None = None
    fence_lines: list[str] = []
    opening_line = 0
    for line_number, line in enumerate(lines, start=1):
        marker = _fence_marker(line)
        if active is None and marker is not None:
            active = marker
            opening_line = line_number
            fence_lines = [line]
            continue
        if active is not None:
            fence_lines.append(line)
            if _is_closing_fence(line, active):
                atoms.append("\n".join(fence_lines))
                active = None
                fence_lines = []
            continue
        if line.strip():
            atoms.append(line)
    if active is not None:
        raise SanitizeError(f"{context} contains unclosed fenced code block opened at line {opening_line}")
    return atoms


def gate_output(output_dir: Path, hard_limit: int = DEFAULT_HARD_LIMIT) -> dict[str, object]:
    if hard_limit < 256 or hard_limit > DEFAULT_HARD_LIMIT:
        raise SanitizeError(f"hard_limit must satisfy 256 <= hard_limit <= {DEFAULT_HARD_LIMIT}")
    output_dir = output_dir.resolve()
    required = [
        output_dir / "source.sha256",
        output_dir / "document.cleaned.md",
        output_dir / "images.jsonl",
        output_dir / "audit.json",
        output_dir / "audit.md",
        output_dir / "ragflow",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise SanitizeError("missing output artifacts: " + ", ".join(missing))
    audit = json.loads((output_dir / "audit.json").read_text(encoding="utf-8"))
    if audit.get("sanitizer_version") != VERSION:
        raise SanitizeError(
            f"sanitizer version mismatch: artifact={audit.get('sanitizer_version')} verifier={VERSION}"
        )
    expected_source_hash = (output_dir / "source.sha256").read_text(encoding="utf-8").strip()
    if audit.get("source", {}).get("sha256") != expected_source_hash:
        raise SanitizeError("source hash sidecar does not match audit")
    artifact_paths = {
        "document_cleaned": output_dir / "document.cleaned.md",
        "images_jsonl": output_dir / "images.jsonl",
    }
    expected_artifacts = audit.get("artifacts", {})
    for name, path in artifact_paths.items():
        expected = expected_artifacts.get(name, {})
        if sha256_bytes(path.read_bytes()) != expected.get("sha256"):
            raise SanitizeError(f"artifact hash mismatch: {path.name}")
        if path.stat().st_size != expected.get("bytes"):
            raise SanitizeError(f"artifact size mismatch: {path.name}")
    parts = sorted((output_dir / "ragflow").glob("part-*.md"))
    if len(parts) != audit.get("ragflow", {}).get("part_count"):
        raise SanitizeError("part count does not match audit")
    expected_parts = {item["name"]: item for item in audit["ragflow"]["parts"]}
    bodies: list[str] = []
    structural_atoms: list[str] = []
    for index, path in enumerate(parts, start=1):
        content = path.read_text(encoding="utf-8")
        expected = expected_parts.get(path.name)
        if not expected or sha256_bytes(path.read_bytes()) != expected["sha256"]:
            raise SanitizeError(f"part hash mismatch: {path.name}")
        if path.stat().st_size != expected.get("bytes"):
            raise SanitizeError(f"part size mismatch: {path.name}")
        if path.stat().st_size > audit.get("limits", {}).get("shard_bytes", 0):
            raise SanitizeError(f"part exceeds audited shard limit: {path.name}")
        if f"part: {index}\n" not in content or f"part_count: {len(parts)}\n" not in content:
            raise SanitizeError(f"part metadata mismatch: {path.name}")
        body = FRONT_MATTER_RE.sub("", normalize_newlines(content), count=1)
        if body == content:
            raise SanitizeError(f"part front matter missing: {path.name}")
        for is_fence, segment in _fenced_segments(body, path.name):
            if is_fence:
                continue
            if "![" in segment or re.search(r"<img\b", segment, re.IGNORECASE):
                raise SanitizeError(f"part still contains loadable image syntax: {path.name}")
            if re.search(r"<table(?=[\s>/])", segment, re.IGNORECASE):
                raise SanitizeError(f"part still contains protected HTML table: {path.name}")
        bodies.append(body.rstrip("\n"))
        structural_atoms.extend(_structural_atoms_from_output(body, path.name))
    reconstructed = "\n\n".join(bodies).strip() + "\n"
    if sha256_text(reconstructed) != audit["ragflow"]["body_sha256"]:
        raise SanitizeError("RAGFlow part reconstruction hash mismatch")
    limits = audit.get("limits", {})
    cleaned_source = (output_dir / "document.cleaned.md").read_text(encoding="utf-8")
    projection = build_ragflow_body(
        cleaned_source,
        int(limits.get("soft_chars", 0)),
        int(limits.get("hard_chars", 0)),
        source_is_bookstack_cleaned=True,
    )
    if projection["body"] != reconstructed:
        raise SanitizeError("RAGFlow parts do not match deterministic projection of document.cleaned.md")
    inventory = [
        json.loads(line)
        for line in (output_dir / "images.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if projection["images"] != inventory:
        raise SanitizeError("images.jsonl does not match deterministic projection of document.cleaned.md")
    max_atom = max((len(atom) for atom in structural_atoms), default=0)
    if max_atom > hard_limit:
        raise SanitizeError(f"output structural atom exceeds hard limit: {max_atom} > {hard_limit}")
    return {
        "result": "PASS",
        "output_dir": str(output_dir),
        "source_sha256": expected_source_hash,
        "part_count": len(parts),
        "max_atom_chars": max_atom,
        "hard_limit": hard_limit,
    }


def clean_document(
    source_path: Path,
    output_dir: Path,
    *,
    soft_limit: int = DEFAULT_SOFT_LIMIT,
    hard_limit: int = DEFAULT_HARD_LIMIT,
    shard_limit: int = DEFAULT_SHARD_LIMIT,
) -> dict[str, object]:
    source_path = source_path.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    if not source_path.is_file():
        raise SanitizeError(f"source file not found: {source_path}")
    if source_path.suffix.casefold() not in {".md", ".markdown", ".mdx"}:
        raise SanitizeError("sanitizer accepts Markdown files only")
    if output_dir.exists():
        raise SanitizeError(f"output already exists; refusing to overwrite: {output_dir}")
    try:
        if source_path.is_relative_to(output_dir):
            raise SanitizeError("output directory must not contain the source file")
    except AttributeError:
        if str(source_path).startswith(str(output_dir) + str(Path.sep)):
            raise SanitizeError("output directory must not contain the source file")

    raw_bytes = source_path.read_bytes()
    source_hash = sha256_bytes(raw_bytes)
    source = _decode_markdown(raw_bytes, source_path)
    source_audit = audit_source(source_path, hard_limit, source=source, raw_bytes=raw_bytes)
    cleaned, changes = clean_for_bookstack(source)
    ocr_triplet_ledger = list(changes.pop("_ocr_triplet_records", []))
    ragflow = build_ragflow_body(
        cleaned,
        soft_limit,
        hard_limit,
        source_is_bookstack_cleaned=True,
    )
    header_budget = len(_front_matter(source_path.name, source_hash, 999999999, 999999999).encode("utf-8"))
    max_atom_bytes = max((len(str(atom).encode("utf-8")) for atom in ragflow["atoms"]), default=0)
    if max_atom_bytes + header_budget > shard_limit:
        raise SanitizeError(
            f"shard_limit is too small for one preserved atom: need at least {max_atom_bytes + header_budget} bytes"
        )
    shards = _shard_atoms(ragflow["atoms"], shard_limit - header_budget)
    warnings = list(source_audit["risks"])
    image_kinds: dict[str, int] = {}
    for item in ragflow["images"]:
        kind = str(item["kind"])
        image_kinds[kind] = image_kinds.get(kind, 0) + 1

    output_dir.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=f".{output_dir.name}.tmp-", dir=output_dir.parent))
    try:
        write_text(temporary / "source.sha256", source_hash + "\n")
        write_text(temporary / "document.cleaned.md", cleaned.rstrip() + "\n")
        with (temporary / "images.jsonl").open("w", encoding="utf-8", newline="\n") as stream:
            for image in ragflow["images"]:
                stream.write(json.dumps(image, ensure_ascii=False) + "\n")

        artifacts = {
            "document_cleaned": {
                "path": "document.cleaned.md",
                "bytes": (temporary / "document.cleaned.md").stat().st_size,
                "sha256": sha256_bytes((temporary / "document.cleaned.md").read_bytes()),
            },
            "images_jsonl": {
                "path": "images.jsonl",
                "bytes": (temporary / "images.jsonl").stat().st_size,
                "sha256": sha256_bytes((temporary / "images.jsonl").read_bytes()),
            },
        }

        part_records: list[dict[str, object]] = []
        part_count = len(shards)
        for index, body in enumerate(shards, start=1):
            name = f"part-{index:04d}.md"
            content = _front_matter(source_path.name, source_hash, index, part_count) + body
            path = temporary / "ragflow" / name
            write_text(path, content)
            if path.stat().st_size > shard_limit:
                raise SanitizeError(
                    f"RAGFlow part exceeds shard limit: {name} {path.stat().st_size} > {shard_limit} bytes"
                )
            part_records.append(
                {
                    "name": name,
                    "bytes": path.stat().st_size,
                    "sha256": sha256_bytes(path.read_bytes()),
                }
            )

        audit: dict[str, object] = {
            "schema_version": SCHEMA_VERSION,
            "sanitizer_version": VERSION,
            "result": "PASS",
            "source": {
                "name": source_path.name,
                "path": str(source_path),
                "sha256": source_hash,
                "bytes": len(raw_bytes),
            },
            "source_audit": source_audit,
            "limits": {
                "soft_chars": soft_limit,
                "hard_chars": hard_limit,
                "shard_bytes": shard_limit,
            },
            "changes": {
                **changes,
                "images_neutralized": len(ragflow["images"]),
                "html_tables_converted": ragflow["html_tables_converted"],
                "markdown_tables_converted": ragflow["markdown_tables_converted"],
            },
            "transform_ledger": {
                "pseudo_html_tags": {
                    "count": changes["pseudo_html_tags"],
                    "rule": "escape-parser-ambiguous-less-than-outside-fences",
                },
                "private_bullets": {
                    "count": changes["private_bullets"],
                    "rule": "map-u+f06c-to-visible-bullet-outside-fences",
                },
                "duplicate_empty_anchors": {
                    "count": changes["duplicate_empty_anchors"],
                    "rule": "retain-first-identical-empty-anchor-outside-fences",
                },
                "ocr_triplet_spans": ocr_triplet_ledger,
                "images": {"count": len(ragflow["images"]), "inventory": "images.jsonl"},
                "tables": {
                    "html": ragflow["html_tables_converted"],
                    "markdown": ragflow["markdown_tables_converted"],
                    "rule": "row-oriented-text-ragflow-derivative-only",
                },
            },
            "artifacts": artifacts,
            "images": {"total": len(ragflow["images"]), "by_kind": image_kinds},
            "warnings": warnings,
            "ragflow": {
                "body_sha256": ragflow["body_sha256"],
                "part_count": part_count,
                "atom_count": len(ragflow["atoms"]),
                "max_atom_chars": ragflow["max_atom_chars"],
                "parts": part_records,
            },
        }
        write_json(temporary / "audit.json", audit)
        write_text(temporary / "audit.md", _audit_markdown(audit))
        gate_output(temporary, hard_limit)
        if sha256_bytes(source_path.read_bytes()) != source_hash:
            raise SanitizeError("source changed during sanitization; refusing to publish mixed-version artifacts")
        temporary.replace(output_dir)
        return audit
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise


def clean_batch(
    source_dir: Path,
    output_dir: Path,
    include: list[str],
    *,
    soft_limit: int,
    hard_limit: int,
    shard_limit: int,
) -> dict[str, object]:
    source_dir = source_dir.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    if output_dir.exists():
        raise SanitizeError(f"batch output already exists; refusing to overwrite: {output_dir}")
    if not source_dir.is_dir():
        raise SanitizeError(f"source directory not found: {source_dir}")
    candidates: dict[str, list[Path]] = {}
    for path in source_dir.rglob("*.md"):
        candidates.setdefault(path.name, []).append(path)
    duplicate_selected = {
        name: paths
        for name, paths in candidates.items()
        if name in include and len(paths) > 1
    }
    if duplicate_selected:
        details = "; ".join(
            f"{name}: " + ", ".join(str(path.relative_to(source_dir)) for path in paths)
            for name, paths in sorted(duplicate_selected.items())
        )
        raise SanitizeError("selected basename is ambiguous; use unique source basenames: " + details)
    available = {name: paths[0] for name, paths in candidates.items()}
    missing = [name for name in include if name not in available]
    if missing:
        raise SanitizeError("selected source files not found: " + ", ".join(missing))
    output_dir.mkdir(parents=True)
    documents: list[dict[str, object]] = []
    try:
        for name in include:
            target = output_dir / Path(name).stem
            audit = clean_document(
                available[name],
                target,
                soft_limit=soft_limit,
                hard_limit=hard_limit,
                shard_limit=shard_limit,
            )
            documents.append(
                {
                    "source": name,
                    "output": target.name,
                    "source_sha256": audit["source"]["sha256"],
                    "part_count": audit["ragflow"]["part_count"],
                    "max_atom_chars": audit["ragflow"]["max_atom_chars"],
                    "warnings": audit["warnings"],
                }
            )
        aggregate = {
            "schema_version": SCHEMA_VERSION,
            "sanitizer_version": VERSION,
            "result": "PASS",
            "source_dir": str(source_dir),
            "output_dir": str(output_dir),
            "documents": documents,
        }
        write_json(output_dir / "aggregate-audit.json", aggregate)
        markdown = ["# RAGFlow 大型手册清洗汇总", "", "| 文档 | 分片 | 最大原子 | 警告数 |", "| --- | ---: | ---: | ---: |"]
        for item in documents:
            markdown.append(
                f"| {item['source']} | {item['part_count']} | {item['max_atom_chars']} | {len(item['warnings'])} |"
            )
        write_text(output_dir / "aggregate-audit.md", "\n".join(markdown) + "\n")
        manifest_files = {
            path.relative_to(output_dir).as_posix(): sha256_bytes(path.read_bytes())
            for path in sorted(output_dir.rglob("*"))
            if path.is_file() and path.name != "SHA256SUMS.json"
        }
        write_json(
            output_dir / "SHA256SUMS.json",
            {
                "schema_version": "drvknowledge.artifact-integrity.v1",
                "algorithm": "sha256",
                "files": manifest_files,
            },
        )
        return aggregate
    except Exception:
        shutil.rmtree(output_dir, ignore_errors=True)
        raise


def _limits(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--soft-limit", type=int, default=DEFAULT_SOFT_LIMIT)
    parser.add_argument("--hard-limit", type=int, default=DEFAULT_HARD_LIMIT)
    parser.add_argument("--shard-limit", type=int, default=DEFAULT_SHARD_LIMIT)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=VERSION)
    subparsers = parser.add_subparsers(dest="command", required=True)

    audit_parser = subparsers.add_parser("audit", help="Inspect a Markdown source without writing files")
    audit_parser.add_argument("source")
    audit_parser.add_argument("--hard-limit", type=int, default=DEFAULT_HARD_LIMIT)

    clean_parser = subparsers.add_parser("clean", help="Create one non-destructive sanitized bundle")
    clean_parser.add_argument("source")
    clean_parser.add_argument("output")
    _limits(clean_parser)

    gate_parser = subparsers.add_parser("gate", help="Verify an existing sanitized bundle")
    gate_parser.add_argument("output")
    gate_parser.add_argument("--hard-limit", type=int, default=DEFAULT_HARD_LIMIT)

    batch_parser = subparsers.add_parser("batch", help="Clean explicitly selected Markdown files")
    batch_parser.add_argument("source_dir")
    batch_parser.add_argument("output_dir")
    batch_parser.add_argument("--include", required=True, help="Comma-separated source basenames")
    _limits(batch_parser)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        if args.command == "audit":
            result = audit_source(Path(args.source), args.hard_limit)
        elif args.command == "clean":
            result = clean_document(
                Path(args.source),
                Path(args.output),
                soft_limit=args.soft_limit,
                hard_limit=args.hard_limit,
                shard_limit=args.shard_limit,
            )
        elif args.command == "gate":
            result = gate_output(Path(args.output), args.hard_limit)
        else:
            include = [item.strip() for item in args.include.split(",") if item.strip()]
            if not include:
                raise SanitizeError("--include must select at least one Markdown file")
            result = clean_batch(
                Path(args.source_dir),
                Path(args.output_dir),
                include,
                soft_limit=args.soft_limit,
                hard_limit=args.hard_limit,
                shard_limit=args.shard_limit,
            )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (SanitizeError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"result": "FAIL", "error": str(exc)}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

# RAGFlow 超长芯片手册清洗与入库门禁 V1

当前清洗器版本：`1.1.0`。

## 结论

A2、A3、A5、M3、E2 的反复失败不是一个参数问题，而是四类因素叠加：

1. RAGFlow v0.27.1 的 Markdown 解析器会保护整块 HTML/Markdown 表格和代码围栏；单个受保护结构可以绕过 `chunk_token_num` 的软目标。
2. one-api 后端对 embedding 输入的实际容忍度低于 bge-m3 标称上下文，而且与中文重复模式、HTML 密度等内容形态有关。
3. RAGFlow 在 Markdown 分块前可能尝试读取图片；内网绝对 URL 会遇到 SSRF/网络限制，单独上传 Markdown 时相对图片又不存在。
4. 转换产物包含伪 HTML、重复空锚点、Word 私用区字符和少量高置信度 OCR 三倍重复，进一步放大了解析器的保护范围和输入体积。

因此，正式规则是“源文件清洗 + RAGFlow 专用衍生物 + 文档级参数模板 + 硬门禁”，不能再通过静默截断 embedding 输入掩盖问题。

## 已确认的五份样本特征

| 文档 | 关键风险 | 本次清洗结果 |
| --- | --- | --- |
| A2 | 5,698 个 HTML 表格、2,940 个图片引用、145K 量级重复空锚点；`1<<table\_out_norm` 一类文本会被宽松 HTML 正则误识别为 `<table...>` | 8 个分片；最大结构原子 1,810 字符 |
| A3 | 7,813 个内网图片引用；2,205 个 Markdown 表格；Word 私用区项目符号 | 4 个分片；最大结构原子 1,799 字符 |
| A5 | 607 个相对图片引用；2,715 个 Markdown 表格；目录点线超长 | 6 个分片；最大结构原子 1,799 字符 |
| M3 | 连续大段文本、441 个 Markdown 表格；914 个 `U+F06C` 字符 | 6 个分片；最大结构原子 1,799 字符 |
| E2 | 5,440 个 Markdown 表格、431 个相对图片引用、965 个 `U+F06C`；存在高置信度三倍重复 OCR 片段 | 6 个分片；最大结构原子 1,799 字符 |

上述“清洗结果”仅代表离线结构门禁通过。是否能在内网 RAGFlow 与当前 one-api 组合上全部解析为 `DONE`，仍需按本文的 RC 流程实测。

## 入库前强制触发条件

Markdown 技术手册命中任意条件时，禁止原文件直接上传 RAGFlow，必须先运行清洗器：

- 文件大于 2 MiB；
- 任一物理行超过 2,200 字符；
- 任一完整代码围栏、HTML 表格或 Markdown 表格超过 2,200 字符；
- 图片引用超过 100 个；
- 存在相对图片、内网 IP 图片或其他 RAGFlow 不可达图片；
- 存在疑似伪 HTML 标签；
- HTML 表格或代码围栏不平衡；
- 已知由 PDF/Word/网页转换而来且表格密集。

`audit` 的 `requires_sanitization=true` 是阻断信号。不得靠调大 embedding 限制、跳过报错或截断正文放行。

## 清洗规则

清洗器位于：

```text
components/skills/skills/drv-knowledge-ingestion/resources/
technical-manual-engine/scripts/ragflow_sanitize.py
```

它只使用 Python 标准库，可以完全离线运行，并生成两种用途不同的衍生物：

- `document.cleaned.md`：保留给 BookStack 阅读与后续人工审查；保留真实表格和图片语义。
- `ragflow/part-*.md`：只用于 RAGFlow；把表格变为行文本，把图片变为文字占位，避免解析阶段联网取图。

规则如下：

1. 源文件只读：一次读取绑定原始字节 SHA-256，发布前再次校验；处理中源文件变化则整批失败，永不覆盖原文件。
2. 伪 HTML 保护：仅在代码围栏外转义 `1<<table_name` 等会误触发解析器的 `<`；真实 `<table>` 不在 BookStack 衍生物中改写。
3. 重复空锚点：同名空锚点只保留第一个。正文、标题和技术标识不删除。
4. `U+F06C`：转换为可见项目符号 `•`。
5. OCR 三倍重复：只有连续至少 12 个字符运行、每个运行长度均可被 3 整除时才折叠；普通重复、寄存器值和代码不处理。
6. `xxx`：禁止全局删除。`/dev/xxx`、`0x0XXX19f5`、`Vx.x.x` 等可能是有效技术内容。
7. 图片：支持带括号 URL、引用式 Markdown 图片和带引号/不带引号的 HTML 图片属性；RAGFlow 衍生物不保留可加载图片语法，改为 `[图示：说明]`，原 URL、alt、title、引用标签和分类写入 `images.jsonl`。无法解析的引用进入阻断记录，不静默放行。
8. 表格：RAGFlow 衍生物把 HTML/Markdown 表格按行展开；不尝试伪造表头或恢复不确定的跨行语义。
9. 分块：优先在行、句号和空格处切分，软上限 1,800 字符，硬上限 2,200 字符；调用者只能降低、不能提高硬上限，不静默丢字。
10. 代码：只按完整代码行切分；单个代码行超过硬上限时直接失败，要求人工处理。
11. 文件分片：默认每个 RAGFlow Markdown 文件不超过约 1 MiB，减少单任务内存和失败重试范围。
12. 完整性：校验代码围栏平衡、围栏内示例不被清洗、围栏外无可加载图片或 HTML `<table>`、最大结构原子、分片总字节上限、分片重组 hash 和每个文件 SHA-256。

## 命令

单文件审计：

```bash
python ragflow_sanitize.py audit manual.md
```

通过 A 组件清洗单文件：

```bash
drvki sanitize-manual manual.md output/manual
```

五份问题手册批量处理：

```bash
python ragflow_sanitize.py batch SOURCE_DIR OUTPUT_DIR \
  --include 01_A2.md,03_A5.md,04_M3.md,05_A3.md,06-E2.md
```

重新验证已有产物：

```bash
python ragflow_sanitize.py gate OUTPUT_DIR/01_A2
```

输出目录包括：

```text
OUTPUT_DIR/
├── aggregate-audit.json
├── aggregate-audit.md
├── SHA256SUMS.json
└── 01_A2/
    ├── source.sha256
    ├── document.cleaned.md
    ├── images.jsonl
    ├── audit.json
    ├── audit.md
    └── ragflow/part-*.md
```

## RAGFlow 参数模板

对 `ragflow/part-*.md` 使用 `sanitized-chip-manual-v1`：

```json
{
  "chunk_method": "naive",
  "parser_config": {
    "layout_recognize": "DeepDOC",
    "chunk_token_num": 256,
    "delimiter": "\n",
    "auto_keywords": 0,
    "auto_questions": 0,
    "html4excel": false,
    "raptor": { "use_raptor": false },
    "graphrag": { "use_graphrag": false },
    "parent_child": { "use_parent_child": false }
  }
}
```

RAGFlow v0.27.1 解析任务读取的是文档级 `parser_config`。必须给每一个上传后的 part 执行文档级 PATCH；只修改数据集默认配置不能保证已经创建的文档生效。

## 明日内网 RC 验证步骤

1. 新建并行测试数据集，例如 `manuals_sanitized_rc`；不覆盖、不删除生产数据集和原文档。
2. 每份手册只上传其 `ragflow/part-*.md`，不要把 `document.cleaned.md` 当作 RAGFlow 输入。
3. 对每个 part 应用 `sanitized-chip-manual-v1`，核对返回的文档级 `chunk_token_num=256`。
4. 分手册启动解析，先 A2，再 A3/A5/M3/E2；不要五份一起并发，以便定位失败边界。
5. 每份完成后核对所有 part 为 `DONE`，且日志中没有 embedding 400、图片下载/SSRF、超长输入和任务超时。
6. 抽查手册开头、中部、末尾、寄存器表和图片附近文字；确认不是“解析成功但正文被截断”。
7. 用芯片名、寄存器名、接口名各做一组召回，确认命中文档与段落合理。

若仍发生 embedding 400，先保留失败 part 和请求长度证据，再针对该 part 用 `--soft-limit 1400 --hard-limit 1800` 重建。禁止恢复 `t[:2000]` 静默截断补丁。

## 验收标准

- 五份手册的全部 part 均为 `DONE`；
- 无 embedding 400、图片可达性错误、超长结构错误；
- 原文件 SHA-256 与 `source.sha256` 一致；
- `gate` 与 `SHA256SUMS.json` 校验通过；
- 开头/中部/末尾均可召回；
- 表格关键寄存器行没有丢失；
- 生产数据集在 RC 验证前保持不变。

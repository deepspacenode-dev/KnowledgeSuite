# RAGFlow 文档清洗审计

- 结果：`PASS`
- 源文件：`04_M3.md`
- 源 SHA-256：`024c9b3f8aedc14a08d4217c2030af9301778c53521ffe8a2817bafdd7861efb`
- 清洗器版本：`1.1.0`
- RAGFlow 分片：`6`
- 最大结构原子：`1799` 字符

## 规则命中

- `pseudo_html_tags`：0
- `private_bullets`：914
- `ocr_triplet_spans`：0
- `duplicate_empty_anchors`：0
- `images_neutralized`：0
- `html_tables_converted`：0
- `markdown_tables_converted`：441

## 警告

- source_over_2mib
- line_over_hard_limit
- protected_atom_over_hard_limit
- private_use_bullets

## 分片

- `part-0001.md`：1047458 bytes，SHA-256 `eee87f7d06eef6ec7acfd11918c1b3fa6ce984dd217fc48486ee0d321da18e08`
- `part-0002.md`：1047470 bytes，SHA-256 `1a71802eb264b8bfe54f87e5618c92426aba13ebd0744861bc4056a2d95abd14`
- `part-0003.md`：1048496 bytes，SHA-256 `f938fa896ea21e27a22281cf6a8d061a57c3b9bfb34d8234df2d7e002e1d54b6`
- `part-0004.md`：1048380 bytes，SHA-256 `805e580ff0722b4821cf812d7a086a0f9114969a2553c410df443b1b506fe479`
- `part-0005.md`：1047624 bytes，SHA-256 `b544af4358ef1455c3d5e0d269b58bb726442aa8b00aeb1037992ebfd145740c`
- `part-0006.md`：1005310 bytes，SHA-256 `7e15c5bead8411e62c244403248157832347e358448afcbd1a63cbf04789f0ee`

# RAGFlow 文档清洗审计

- 结果：`PASS`
- 源文件：`03_A5.md`
- 源 SHA-256：`577cde55f8180a8df3c0a8a476f4bdc5f32a3f53dc34008172c85304f89a507b`
- 清洗器版本：`1.1.0`
- RAGFlow 分片：`6`
- 最大结构原子：`1799` 字符

## 规则命中

- `pseudo_html_tags`：0
- `private_bullets`：0
- `ocr_triplet_spans`：0
- `duplicate_empty_anchors`：0
- `images_neutralized`：607
- `html_tables_converted`：0
- `markdown_tables_converted`：2715

## 警告

- source_over_2mib
- line_over_hard_limit
- protected_atom_over_hard_limit
- image_count_over_100
- non_public_images

## 分片

- `part-0001.md`：1047066 bytes，SHA-256 `9daea388bc5bd054def4cd8b999beb67e6581f5ceac59ffb155b3ac64372fc1b`
- `part-0002.md`：1047053 bytes，SHA-256 `64378445ae98a75b9de018267421088d7ca4543eac23568735f84c2d4a8db22e`
- `part-0003.md`：1048364 bytes，SHA-256 `ed4011b936f4f86513999c7bd4ec37180905d8898eda9d5057ded888d2074d7a`
- `part-0004.md`：1047911 bytes，SHA-256 `bbbe1fd6f3ec14fc4e71a63eed5ee88508b5bd93e8f1b114a67d84b8af7303ef`
- `part-0005.md`：1048284 bytes，SHA-256 `c7e9eb71e3a3b1452c4d09e77ecf3f1aec95858313338827f67b16b4ee9c9bc8`
- `part-0006.md`：461269 bytes，SHA-256 `0807ad52ef89973436bf3b9e8761354a818efc3a6186e30d54f2f32d12d28146`

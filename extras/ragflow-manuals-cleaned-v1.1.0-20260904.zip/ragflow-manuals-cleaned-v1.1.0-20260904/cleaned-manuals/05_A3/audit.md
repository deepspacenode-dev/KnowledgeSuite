# RAGFlow 文档清洗审计

- 结果：`PASS`
- 源文件：`05_A3.md`
- 源 SHA-256：`f3307545a1aa1bf493c014e3d7a2b33ec7f5e78b344bbe8ffd4185a2a4a8411e`
- 清洗器版本：`1.1.0`
- RAGFlow 分片：`4`
- 最大结构原子：`1799` 字符

## 规则命中

- `pseudo_html_tags`：0
- `private_bullets`：777
- `ocr_triplet_spans`：0
- `duplicate_empty_anchors`：0
- `images_neutralized`：7813
- `html_tables_converted`：0
- `markdown_tables_converted`：2205

## 警告

- source_over_2mib
- line_over_hard_limit
- protected_atom_over_hard_limit
- image_count_over_100
- non_public_images
- private_use_bullets

## 分片

- `part-0001.md`：1046743 bytes，SHA-256 `22fdffee952fbca7f4f56e82b7ca7d02bfe6c9c87ef993638f68e584b9b4bf4d`
- `part-0002.md`：1047619 bytes，SHA-256 `bed5afae139084fb0a032b928cd3d092e628fdcc591484d0491980abf474b15d`
- `part-0003.md`：1047297 bytes，SHA-256 `5d1ee63afc21494d3118a39bc865f4fe6660d221edf8bd2acba816b44063b174`
- `part-0004.md`：647226 bytes，SHA-256 `57dc17e09e15827c65a046baec9f299145479c95a17ad847c6fd9a127af87c71`

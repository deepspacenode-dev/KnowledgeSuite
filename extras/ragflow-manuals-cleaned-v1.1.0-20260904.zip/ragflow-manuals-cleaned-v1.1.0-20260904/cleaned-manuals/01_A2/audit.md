# RAGFlow 文档清洗审计

- 结果：`PASS`
- 源文件：`01_A2.md`
- 源 SHA-256：`b326d2701f8469ef2052e76032e9efa4bdf45a5057233817cffd3952bb8a9dfd`
- 清洗器版本：`1.1.0`
- RAGFlow 分片：`8`
- 最大结构原子：`1810` 字符

## 规则命中

- `pseudo_html_tags`：5649
- `private_bullets`：0
- `ocr_triplet_spans`：0
- `duplicate_empty_anchors`：144577
- `images_neutralized`：2940
- `html_tables_converted`：5698
- `markdown_tables_converted`：5

## 警告

- source_over_2mib
- line_over_hard_limit
- protected_atom_over_hard_limit
- image_count_over_100
- non_public_images
- pseudo_html_tags

## 分片

- `part-0001.md`：1047589 bytes，SHA-256 `54c1016bcc8bcaf68c2e321ae9dda7821b91b2315177ed2ede34b583cbb49ee0`
- `part-0002.md`：1048034 bytes，SHA-256 `c78019861a0584a5ee3d857a62ea6c4ae867a13e46d031df858b454c069d7b83`
- `part-0003.md`：1048536 bytes，SHA-256 `b10b6bd58ce34afa833e4b74cc673ade24e837fb828927be3a35dc3801004465`
- `part-0004.md`：1047591 bytes，SHA-256 `a6deff217095a7e822041ffeaec982ffc3e68497037a5d9b9e697659ac4f310b`
- `part-0005.md`：1048344 bytes，SHA-256 `780c61d74a2e68b3b23354e0c29be4530d0f52870583154879cad95f36e3ac08`
- `part-0006.md`：1047152 bytes，SHA-256 `1242c527dcf6bf2cca71430029ddb729ed97653345669c7fb4c9d53b291583ef`
- `part-0007.md`：1045891 bytes，SHA-256 `f1217f05b890d6f1bf9ebdf12d88bfe4adf94979fee70063740de60972ba1729`
- `part-0008.md`：817417 bytes，SHA-256 `459f2b230824e5dfb31e49e571a5900bbbe372758c144e6c2a1654324797558b`

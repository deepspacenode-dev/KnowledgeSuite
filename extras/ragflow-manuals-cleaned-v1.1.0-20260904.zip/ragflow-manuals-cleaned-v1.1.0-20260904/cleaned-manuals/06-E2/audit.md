# RAGFlow 文档清洗审计

- 结果：`PASS`
- 源文件：`06-E2.md`
- 源 SHA-256：`edcfc9fe56fb1831246e2b2cb023d849d91998683378f73152551ad426cb2eb8`
- 清洗器版本：`1.1.0`
- RAGFlow 分片：`6`
- 最大结构原子：`1799` 字符

## 规则命中

- `pseudo_html_tags`：0
- `private_bullets`：965
- `ocr_triplet_spans`：351
- `duplicate_empty_anchors`：0
- `images_neutralized`：431
- `html_tables_converted`：0
- `markdown_tables_converted`：5440

## 警告

- source_over_2mib
- line_over_hard_limit
- protected_atom_over_hard_limit
- image_count_over_100
- non_public_images
- private_use_bullets

## 分片

- `part-0001.md`：1048006 bytes，SHA-256 `135d5c7fa697795d8a77418abc91e01486a29aea4b32a1c90c9cea716b97f730`
- `part-0002.md`：1048172 bytes，SHA-256 `e8e74f0eb2bdb8874c2ea42895c64cc9745b0ba52fd88ecfe6dbc0a53eb27d14`
- `part-0003.md`：1048160 bytes，SHA-256 `1eef04f59aaa9820a7acd44dd45e486d3854df47c270e07d00512f5c4d47d408`
- `part-0004.md`：1045100 bytes，SHA-256 `a906122cde60c98073df05279a79a58f518a625630e747aa0855c591ef75584e`
- `part-0005.md`：1046601 bytes，SHA-256 `16266de9ab4add6d9a6a71220abc956a802709bde3128441ba03520f5aa3626f`
- `part-0006.md`：934535 bytes，SHA-256 `e4ae6cb180b23a39e78779765851a898f797d739b7ec5301d4138fa50caca094`

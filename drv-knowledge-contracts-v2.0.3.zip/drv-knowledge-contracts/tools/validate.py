"""Small dependency-free validator for the Contracts V2 Draft-07 subset.

The release pipeline may run on a disconnected host before a wheelhouse is
installed.  This validator intentionally implements only the keywords used by
the versioned contracts in this repository and fails closed on unsupported
schema keywords that affect validation.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


CONTRACTS_DIR = Path(__file__).resolve().parents[1]
SCHEMA_BY_VERSION = {
    f"drvknowledge.{name}": CONTRACTS_DIR / f"{name}.schema.json"
    for name in (
        "intake-request.v2",
        "wiki-task.v2",
        "wiki-result.v2",
        "knowledge-bundle.v2",
        "governance-status.v2",
        "error-envelope.v2",
    )
}


class ContractValidationError(ValueError):
    """Raised when a payload does not satisfy its declared contract."""


def _fail(path: str, message: str) -> None:
    raise ContractValidationError(f"{path}: {message}")


def _matches_type(value: Any, expected: str) -> bool:
    return {
        "object": isinstance(value, dict),
        "array": isinstance(value, list),
        "string": isinstance(value, str),
        "integer": isinstance(value, int) and not isinstance(value, bool),
        "number": isinstance(value, (int, float)) and not isinstance(value, bool),
        "boolean": isinstance(value, bool),
        "null": value is None,
    }.get(expected, False)


def _validate_format(value: str, format_name: str, path: str) -> None:
    if format_name == "uri":
        parsed = urlparse(value)
        if not parsed.scheme or (parsed.scheme in {"http", "https"} and not parsed.netloc):
            _fail(path, "must be a URI")
    elif format_name == "date-time":
        try:
            dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            _fail(path, "must be an RFC 3339 date-time")
    else:
        _fail(path, f"validator does not support format {format_name!r}")


def _validate(value: Any, schema: dict[str, Any], path: str = "$") -> None:
    if "const" in schema and value != schema["const"]:
        _fail(path, f"must equal {schema['const']!r}")
    if "enum" in schema and value not in schema["enum"]:
        _fail(path, f"must be one of {schema['enum']!r}")

    expected = schema.get("type")
    if expected is not None:
        allowed = expected if isinstance(expected, list) else [expected]
        if not any(_matches_type(value, item) for item in allowed):
            _fail(path, f"must have type {' or '.join(allowed)}")

    if isinstance(value, dict):
        properties = schema.get("properties", {})
        for required in schema.get("required", []):
            if required not in value:
                _fail(f"{path}.{required}", "is required")
        additional = schema.get("additionalProperties", True)
        for key, item in value.items():
            child_path = f"{path}.{key}"
            if key in properties:
                _validate(item, properties[key], child_path)
            elif additional is False:
                _fail(child_path, "unknown field is not allowed")
            elif isinstance(additional, dict):
                _validate(item, additional, child_path)

    if isinstance(value, list):
        if "minItems" in schema and len(value) < schema["minItems"]:
            _fail(path, f"must contain at least {schema['minItems']} items")
        item_schema = schema.get("items")
        if item_schema:
            for index, item in enumerate(value):
                _validate(item, item_schema, f"{path}[{index}]")

    if isinstance(value, str):
        if "minLength" in schema and len(value) < schema["minLength"]:
            _fail(path, f"must contain at least {schema['minLength']} characters")
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            _fail(path, f"must contain no more than {schema['maxLength']} characters")
        if "pattern" in schema and re.search(schema["pattern"], value) is None:
            _fail(path, f"must match pattern {schema['pattern']!r}")
        if "format" in schema:
            _validate_format(value, schema["format"], path)

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            _fail(path, f"must be >= {schema['minimum']}")
        if "maximum" in schema and value > schema["maximum"]:
            _fail(path, f"must be <= {schema['maximum']}")


def validate_contract(payload: dict[str, Any]) -> None:
    version = payload.get("schema_version") if isinstance(payload, dict) else None
    if not isinstance(version, str):
        _fail("$.schema_version", "is required and must be a string")
    schema_path = SCHEMA_BY_VERSION.get(version)
    if schema_path is None:
        _fail("$.schema_version", f"unsupported contract {version!r}")
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    _validate(payload, schema)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate a Drv Knowledge V2 JSON payload offline")
    parser.add_argument("payload", type=Path)
    args = parser.parse_args(argv)
    try:
        payload = json.loads(args.payload.read_text(encoding="utf-8"))
        validate_contract(payload)
    except (OSError, json.JSONDecodeError, ContractValidationError) as exc:
        print(f"INVALID: {exc}")
        return 2
    print(f"VALID: {payload['schema_version']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

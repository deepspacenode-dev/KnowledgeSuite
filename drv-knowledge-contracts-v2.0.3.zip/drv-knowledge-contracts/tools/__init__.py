"""Offline tooling for Drv Knowledge Contracts."""

# V2.0.3 RAGFlow 官方 Widget 与 Recall V4 设计

## 背景

V2.0.2 的 BookStack 悬浮助手由 Bloub 形象、治理快捷入口和自研 Chat 面板组成。自研面板通过 BookStack 后端代理 RAGFlow Chat API，并自行渲染消息和引用。内网部署证明该链路可以工作，但 Markdown、引用、会话、流式输出和 RAGFlow 版本兼容都会形成长期维护负担。

RAGFlow 官方已提供网页 Widget。其生成代码使用主 Widget iframe，并通过 `CREATE_CHAT_WINDOW`、`TOGGLE_CHAT`、`SCROLL_PASSTHROUGH` 和 `WIDGET_READY` 消息管理独立聊天窗口。官方 Widget 自身负责 Markdown、引用、会话和输入交互。因此 V2.0.3 采用“Bloub 作为统一入口，官方 Widget 作为聊天实现”的组合。

同时，内网部署记录暴露了两个必须固化的问题：治理页 `view` 查询参数在 BookStack 重定向时丢失；Chat 与文档治理可能需要连接不同的 RAGFlow 实例。Skill Recall V3 虽然已有多查询、Lane、元数据过滤和本地重排，但低阈值、缺失元数据候选和宽松回退仍可能造成跨领域误召回。

## 目标

- 保留 Bloub 的视觉入口、状态反馈和治理快捷功能。
- BookStack 内的知识问答使用 RAGFlow 官方 Widget，不再维护自研消息渲染。
- Widget 的 URL、共享身份和浏览器凭据全部由部署环境配置，不写入源码、Git、ZIP 或 OCI。
- 同时兼容内网现有 `/chats/widget` 和新版 RAGFlow `/next-chats/widget` 路径。
- 固化治理子页 `view` 透传和 Chat 独立 RAGFlow 实例能力。
- 将 Skill 召回升级为 Recall V4，降低“网络问题命中无关 SoC/视频手册”等跨领域漂移。
- 提供可离线执行的配置应用、预检、回归评测、升级和回滚材料。
- 以当前 V2.0.2 P2 章节质量治理为基线，发布完整 V2.0.3。

## 非目标

- 不修改 RAGFlow 官方前端源码。
- 不把 RAGFlow Widget 资源复制进 BookStack 镜像。
- 不在 V2.0.3 实现 RAGFlow 单点登录或 BookStack 用户到 RAGFlow 用户的账号映射。
- 不启用摄像头或麦克风，除非部署管理员明确配置。
- 不改变 V2 Contracts 的主次版本。
- 不在本次引入 V2.1 Source Hub、Git/SVN Source 或通用文档转换后台。

## 方案

### 1. 悬浮助手与官方 Widget

Bloub 继续作为唯一悬浮入口。点击小人打开现有 BookStack 助手浮层，浮层保留治理状态、功能入口和底部治理中心链接。“知识问答”区域改为懒加载 RAGFlow 官方 Widget 的 `mode=window` iframe。该模式是官方主 Widget 在收到点击后创建的窗口模式，避免页面上再出现第二个 RAGFlow 圆形按钮。

前端不再提交 `/api/ai-governance/v2/chat/completions`，不再维护 `session_token`、Markdown 解析或引用列表。旧 Chat API 和网关方法暂时保留，作为 2.0.x 升级兼容与紧急回滚能力，但默认 UI 不调用。

Widget 尚未配置、配置无效或加载超时时，浮层显示中文诊断和“打开 RAGFlow”入口，治理快捷功能不受影响。

### 2. 运行时配置

新增受 BookStack 登录保护的只读配置接口：

`GET /api/ai-governance/v2/assistant/config`

返回内容仅包含当前页面可以使用的浏览器配置：

```json
{
  "schema_version": "drvknowledge.assistant-config.v2",
  "chat_mode": "ragflow_widget",
  "widget": {
    "enabled": true,
    "src": "http://ragflow.example/chats/widget?...&mode=window",
    "origin": "http://ragflow.example",
    "allow_media": false,
    "load_timeout_ms": 12000
  },
  "ragflow_web_url": "http://ragflow.example/"
}
```

后端从以下环境变量构造并验证 URL：

- `RAGFLOW_WIDGET_ENABLED`
- `RAGFLOW_WIDGET_BASE_URL`
- `RAGFLOW_WIDGET_PATH`
- `RAGFLOW_WIDGET_SHARED_ID`
- `RAGFLOW_WIDGET_AUTH`
- `RAGFLOW_WIDGET_STREAMING`
- `RAGFLOW_WIDGET_MUTED`
- `RAGFLOW_WIDGET_ALLOW_MEDIA`
- `RAGFLOW_WIDGET_LOAD_TIMEOUT_MS`
- `RAGFLOW_WIDGET_TITLE`
- `RAGFLOW_WIDGET_SUBTITLE`
- `RAGFLOW_WIDGET_FOOTER`
- `RAGFLOW_WIDGET_FOOTER_LINK`

`BASE_URL` 必须是没有用户名和密码的绝对 HTTP(S) URL；`PATH` 只能是 `/chats/widget` 或 `/next-chats/widget`，也允许管理员通过显式白名单配置兼容路径。`SHARED_ID` 和 `AUTH` 不能为空且只接受安全字符。后端强制写入 `from=chat`、`mode=window`、主题色和中文语言参数，前端不能覆盖来源域。

真实值只写入部署 `.env`。`.env.example` 使用空值，Secret scan 检查 `auth=`、`ragflow-` API Key 和已知凭据模式。

### 3. 浏览器安全边界

- 配置接口必须经过 BookStack Web 登录和现有 CSRF/会话边界。
- iframe 使用 `referrerpolicy="no-referrer"` 和按需创建，关闭浮层不销毁会话。
- 默认 `allow` 为空；仅 `RAGFLOW_WIDGET_ALLOW_MEDIA=true` 时添加 `microphone; camera`。
- iframe `src` 必须与配置接口返回的 `origin` 完全一致。
- 若后续兼容官方 master 消息协议，必须同时校验 `event.origin`、`event.source`、消息类型和返回 URL；V2.0.3 的直接 window 模式不信任或执行任意 `postMessage` URL。
- 部署预检验证 BookStack CSP、RAGFlow `frame-ancestors`/`X-Frame-Options`、DNS/端口和浏览器可达性。
- 官方 `auth` 是面向浏览器的 BETA Token，无法对最终用户隐藏。必须最小权限、可轮换，并优先通过 HTTPS 传输。

### 4. 内网部署改动反向合入

`GovernancePageController` 增加治理视图白名单并透传 `view`，允许 `overview`、`assets`、`contributions`、`quality`、`rag`、`knowledge-graph`、`gaps` 和 `reports`。未知值丢弃，避免把任意字符串传播到治理 SPA。

`RagFlowGateway::chatCompletion()` 支持 `RAGFLOW_CHAT_BASE_URL` 和 `RAGFLOW_CHAT_API_KEY`，空值时回退 `RAGFLOW_BASE_URL` 和 `RAGFLOW_API_KEY`。文档上传、解析、删除和状态回查继续使用治理实例。

附件中的自研 Markdown CSS/JavaScript 不合入。静态资源缓存键统一更新为 V2.0.3，并由测试保证 Head、入口和前端模块一致。

### 5. RAGFlow Chat Profile V2

新增 `contracts/ragflow/chat-assistant.v2.json`，保留旧 V1 作为升级参考。V2 继续要求 `{knowledge}`、真实 BookStack 引用和证据不足响应，同时增加：

- 首先识别芯片、平台、模块和问题类型，再组织答案。
- 明确禁止把网络、视频、Sensor、Boot、Storage 等不同模块证据互相替代。
- 证据存在芯片或平台冲突时，不给出确定结论。
- 默认按“结论、依据、建议步骤、风险/待确认”输出。
- 空回答直接引导补充芯片、平台、模块、现象和日志，并登记知识缺口。

默认起始参数使用中等严格配置：`similarity_threshold=0.32`、`vector_similarity_weight=0.30`、`top_n=6`、`top_k=128`、`rerank_candidates_count=64`。若内网提供兼容 reranker，则通过部署变量填充 `rerank_id`；未配置时保持空值。参数不是永久常量，发布包提供相同问题集的应用前后评测脚本和回滚配置。

### 6. Skill Recall V4

Recall V4 保留 V3 多查询和 Lane，但增加三段式相关性门禁：

1. **严格阶段**：芯片、项目或模块已识别时，对具备对应元数据的候选要求精确匹配；显式冲突立即淘汰。
2. **受控回退**：严格阶段不足三个文档时，才允许缺失元数据候选进入，并在 trace 中标记 `metadata_fallback`。显式冲突始终不恢复。
3. **答案门禁**：最终候选必须达到可配置最低分；第一名与后续候选需要达到最小分差或获得多查询共识，否则返回 `ambiguous_match`，不把偏移内容包装成可靠答案。

新增任务参数 Profile：

- `manual_lookup`：提高关键词占比和标识符匹配要求。
- `diagnosis`：兼顾语义症状和案例 Lane。
- `platform_migration`：强化项目、平台和版本元数据。
- `review`：优先案例、补丁和技术记录。

查询标准化把领域互斥信息写入 `excluded_modules`。例如识别为 `network` 时，视频/ISP/Sensor 候选只有在查询明确同时提到这些模块时才允许进入。规则存放在 YAML 配置中，不针对 A2/A3/E2/M3/A5 或单一文档硬编码。

### 7. 召回反馈与评测

每次 Recall Trace 增加：

- 使用的参数 Profile。
- 严格阶段和回退阶段候选数。
- 因领域冲突、元数据冲突、最低分或分差被淘汰的候选。
- 最终证据门禁状态。

新增本地 JSONL 反馈存储，默认位于运行时数据目录，不进入安装包。记录 query、标准化结果、返回文档身份、用户反馈、时间和 trace ID；不记录 API Key、完整正文或用户凭据。CLI 提供 `feedback` 子命令，支持“相关、无关、缺少答案、链接错误”四类反馈。无结果和明确无关反馈继续联动知识缺口采集。

离线测试集扩展为正向、跨领域负向、未知问题和链接完整性四类。发布门禁至少验证 Top-3 命中率不下降、跨领域错误命中率为零、所有公开结果有真实来源链接、未知问题返回 no-match/ambiguous 而不是错误答案。

## 部署与升级

升级脚本先备份 BookStack 数据库、上传目录、`.env` 和当前镜像标签，再导入 V2.0.3 OCI。部署只允许修改 `.env`/Secret，不修改业务源码。Widget 预检分为：配置语法、服务器连通性、浏览器 iframe 策略和真实问答冒烟。

旧 V2.0.2 容器保留一个验收周期。回滚只切回旧镜像并恢复旧静态资源版本；本次不新增破坏性数据库迁移。

## 验收标准

1. 点击 Bloub 后在 BookStack 浮层内出现官方 RAGFlow Chat，页面没有第二个悬浮聊天按钮。
2. 官方 Widget 能显示 Markdown、引用、会话并打开 RAGFlow 返回的来源。
3. 未配置、来源不允许、加载超时和 RAGFlow 离线都有中文可操作提示，治理功能仍可用。
4. 真实 Widget Token/API Key 不出现在 Git、ZIP、OCI、日志和示例配置中。
5. 治理快捷按钮可进入各自子页，不再全部落到 overview。
6. Chat 独立 RAGFlow 配置不影响文档发布实例。
7. “网络无流量”负向测试不会返回仅属于视频、ISP 或 Sensor 的候选。
8. 低置信或候选冲突时 Skill 返回 `ambiguous_match`/`no_match` 并保留诊断 trace。
9. P2 章节级质量审核全部保留，现有治理、Python、PHP/Laravel、前端和发布测试通过。
10. 完整离线包可校验 CRC、SHA-256、SBOM、许可证、OCI 标签和 Secret scan。

## 2026-09-08 治理易用性增补

V2.0.3 同时收敛内网实测的四个高优先级问题：质量问题直达 BookStack 原文；全部浏览器可见 RAGFlow 入口统一为 `http://10.222.120.25/`；已通过质量门禁的审核单元可在审批页一键入库 RAGFlow；知识缺口支持管理员带原因删除并保留审计记录。

一键入库以审核单元为边界：普通文章为页，配置的芯片手册书架为章节。仅当单元内所有 Wiki 成员已通过审批且没有质量硬阻断时才显示可用操作；发布使用已有幂等 RAG 通道，不新建绕过审核的接口。

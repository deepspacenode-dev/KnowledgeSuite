# 云端模拟内网部署验证设计

## 目标

在 `http://81.70.45.118:6875` 上模拟公司内网的 V2.0 部署流程：先恢复项目约定的 BookStack 书架与书籍，再用不可变 Governance 镜像和独立 offline Worker 升级现有两容器环境，最终跑通页面创建、Intake、Worker 编译和权威状态查询。RAGFlow 保持未配置，正式发布与召回不在本轮范围内。

## 已确认基线

- BookStack v26.03.3、PHP 8.5.5、MariaDB 11.4.9。
- `bookstack` 与 `bookstack_mariadb` 均为 healthy。
- BookStack 和 MariaDB 当前镜像内容 digest 与项目固定基线一致。
- 现有数据为空：0 个书架、0 本书、0 个页面。
- 数据使用宿主机绑定目录：`app-data -> /config`、`db-data -> /var/lib/mysql`。
- 现有 Compose 项目目录为 `/home/ubuntu/apps/bookstack`，对外端口保持 `6875`。

## 选定方案

采用原址、可回滚、最小覆盖升级：保留现有 `compose.yaml`、数据库服务、端口和绑定目录，新增 `compose.governance.yaml` 覆盖文件，将 `bookstack` 服务切换到固定 Governance 镜像，并新增独立 `knowledge-worker` 服务。部署不使用运行时文件覆盖，不使用 `latest`，不新建第二套数据库。

## 网站结构恢复

所有创建操作按名称查询后再执行，重复运行不产生重复实体。

| 书架 | 初始书籍 | 用途 |
| --- | --- | --- |
| `【AI】经验案例` | `经验案例库` | cases |
| `【AI】手册资料` | `芯片手册` | manuals |
| `【AI】技术资料` | `技术专题` | tech_notes |
| `【AI】项目资料` | `项目文档` | project_docs |
| `【SYS】工程工具` | `工程工具` | docs，不允许正式 AI RAG 发布 |

`AI_GOVERNANCE_CHAPTER_REVIEW_SHELVES` 设置为 `【AI】手册资料`，确保手册书架按章节聚合评审。

## 安全和秘密

- BookStack 用户令牌只存在于本次客户端进程环境，不上传服务器、不写入仓库和报告。
- Worker HMAC 密钥在服务器用系统随机源生成，只写入权限为 `0600` 的 `.env.drv-v2`。
- RAGFlow、OpenAI 兼容接口的地址和密钥保持空值。
- 当前通过聊天传递的 BookStack 令牌和 SSH 密码在验收完成后必须轮换。

## 备份与回滚

写操作前创建时间戳备份目录，保存：

- MariaDB 全库一致性转储；
- BookStack `app-data` 归档；
- 原始 `compose.yaml`、容器镜像 ID/digest 和容器清单；
- 网站结构创建前后的 API 清单。

部署失败时先停止并删除 Worker，再仅使用原始 `compose.yaml` 重建 `bookstack` 服务。若数据验证失败，则停止 BookStack/MariaDB，从备份恢复数据库和 `app-data` 后重新启动。

## 验证链路

1. 五个书架和五本初始书籍可通过 BookStack API 枚举。
2. Governance 镜像和 Worker 镜像在目标 Linux 主机本地构建成功。
3. Compose 合并配置不改变 MariaDB 镜像、绑定目录和公网端口。
4. Laravel 迁移只新增九个 `drv_kb_*` 表。
5. 创建一篇 `【AI】经验案例` 验证页面。
6. 首次 Intake 返回 202；相同请求重放返回 200 且 `replayed=true`。
7. offline Worker 将任务推进为 compile `succeeded`、review `pending_review`、RAG `not_ingested`。
8. 普通 BookStack 页面与登录入口持续可用，正式服务健康检查保持通过。

## 成功标准

- 无源码差异、无公共 CDN/运行时下载、无凭据落库到仓库。
- 备份可定位且校验非空，回滚命令经过 Compose 配置验证。
- 网站目录、Governance API、Worker 和状态真源链路均在目标主机实际执行。
- RAGFlow 未配置时系统稳定停留在待审核/未入 RAG 状态，而不是伪造发布成功。

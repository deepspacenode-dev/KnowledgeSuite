# Drv Knowledge Suite V2.0 双平面设计

## 目标

将开发者侧 Skills/CLI/Worker（A）与 BookStack 治理控制面（B）保持独立部署，通过版本化 Contracts V2 形成可验证闭环。V2.0 只覆盖入库、编译、审核、RAG 发布、召回、离线降级与可复现部署；VSCode、MCP 和 Source Hub 延后至 V2.1。

## 边界

- A 使用个人 BookStack 凭据创建草稿页，随后调用 B 的 Intake API。
- B 从 BookStack 重新导出页面，校验身份与内容后登记治理资产和编译任务。
- A Worker 通过 HMAC Worker API 领取 `wiki-task.v2`，调用可替换的模型/RAGFlow 编译适配器，并回传 `wiki-result.v2`。
- B 数据库是编译、审核、质量和 RAG 状态唯一真源；Front Matter 只保存内容快照。
- A Retrieval 直接调用 RAGFlow，并批量读取 B 的治理状态，生成 `knowledge-bundle.v2`。

## 离线与部署

- 正式基线为 Linux x86_64 + Docker Compose。
- B 构建为固定 BookStack 基线的不可变镜像；A Worker 独立构建镜像。
- `external-ragflow` 用于云端 RC；`full-stack` 用于具备资源的自托管环境。
- 运行时不得访问 CDN、软件仓库或公共镜像仓库。B/RAGFlow 不可达时，A 使用本地缓存和 SQLite outbox 降级。

## 版本与发布

- A、B、Contracts 首个联合基线为 2.0.0，主次版本同步、补丁独立。
- 云端通过后发布 `2.0.0-rc.N`；内网 RAGFlow 兼容与冒烟测试通过后发布 `2.0.0`。

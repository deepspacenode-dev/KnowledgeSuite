# Chapter-Level Quality Review Units Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make configured chip-manual shelves expose one quality issue per chapter, while preserving page-level issue evidence and routing all approval actions through the existing chapter review unit.

**Architecture:** Add a focused quality-unit query that reuses `BookStackHierarchyQuery` and `ReviewUnitResolver`, keeps `drv_kb_quality_checks` page-granular, and aggregates only at read time. A pure `QualityUnitAggregator` owns the worst-member gate calculation; the frontend renders chapter summaries with expandable page evidence and redirects reviewers to the existing chapter review screen.

**Tech Stack:** PHP 8.2+/Laravel query builder, BookStack hierarchy tables, vanilla ES modules, Node.js test runner, Docker/OCI release tooling.

---

## File Structure

- Create `components/governance/bookstack-overlay/app/AI/Governance/Application/Quality/QualityUnitAggregator.php`: deterministic chapter/page quality summary logic without database dependencies.
- Create `components/governance/bookstack-overlay/app/AI/Governance/Application/Quality/QualityIssueUnitQuery.php`: visible-page lookup, latest effective asset/check selection, and review-unit grouping.
- Modify `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V1/QualityController.php`: delegate quality issue reads to the new query.
- Modify `components/governance/bookstack-overlay/public/ai-governance/app/views.js`: render one chapter card with page-level evidence.
- Modify `components/governance/bookstack-overlay/public/ai-governance/app/main.js`: route “前往章节审核” to the filtered review-unit view.
- Modify `components/governance/bookstack-overlay/public/ai-governance/app/demo-data.js`: represent manual quality issues as chapter units.
- Modify cache-version references in the governance frontend and head provider so upgraded installations load the new UI.
- Extend backend-source and frontend behavior tests under `components/governance/tests`.

### Task 1: Backend Chapter Quality Aggregation

**Files:**
- Create: `components/governance/bookstack-overlay/app/AI/Governance/Application/Quality/QualityUnitAggregator.php`
- Create: `components/governance/bookstack-overlay/app/AI/Governance/Application/Quality/QualityIssueUnitQuery.php`
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V1/QualityController.php`
- Test: `components/governance/tests/Feature/Api/V1/read-api.node.test.mjs`

- [ ] **Step 1: Write the failing backend contract test**

Add a test that requires `QualityController` to delegate to `QualityIssueUnitQuery`, and requires the new query/aggregator sources to contain `ReviewUnitResolver`, `member_count`, `issue_page_count`, `checked_page_count`, `members`, minimum-score calculation, and blocked-member calculation.

- [ ] **Step 2: Run the focused test and verify RED**

Run:

```powershell
$node='C:\Users\23840\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
& $node --test components/governance/tests/Feature/Api/V1/read-api.node.test.mjs
```

Expected: FAIL because `QualityIssueUnitQuery.php` and `QualityUnitAggregator.php` do not exist and the controller still queries quality checks directly.

- [ ] **Step 3: Implement the pure aggregator**

Implement `QualityUnitAggregator::summarize(array $unit): array` so that:

```php
$scores = array_values(array_filter($unit['scores'], 'is_numeric'));
$unit['score'] = $scores === [] ? null : min(array_map('intval', $scores));
$unit['issue_page_count'] = count($unit['members']);
$unit['blocked_page_count'] = count(array_filter(
    $unit['members'],
    static fn (array $member): bool => ($member['gate_result'] ?? '') === 'blocked',
));
$unit['gate_result'] = $unit['blocked_page_count'] > 0 ? 'blocked' : 'warning';
```

For chapter units, generate a Chinese chapter conclusion using member, issue, and blocked counts. For page units, retain the sole page member’s title, asset identity, conclusion, problems, version, and checked time for API compatibility. Remove the internal `scores` field before returning.

- [ ] **Step 4: Implement the quality-unit query**

Implement `QualityIssueUnitQuery::execute(array $filters): array` with this sequence:

1. Resolve visible page IDs for the optional `bookshelf_id`.
2. Load page/book/chapter/membership structure.
3. Select one effective asset per page, preferring Wiki, newest version, then newest asset ID.
4. Select one latest quality check per effective asset.
5. Use `ReviewUnitResolver::unitForPage()` for the grouping key.
6. Count every page in `member_count`, every page with a check in `checked_page_count`, and append only pages with warnings/reject reasons to `members`.
7. Pass non-empty units to `QualityUnitAggregator`, order by newest `checked_at`, and limit the response to 200 units.

Each issue member must contain:

```php
[
    'page_id' => $pageId,
    'page_title' => $page['page_name'],
    'asset_id' => (int) $asset->asset_id,
    'asset_title' => (string) $asset->title,
    'current_version' => (int) $asset->current_version,
    'score' => $described['score'],
    'gate_result' => $described['gate_result'],
    'conclusion' => $described['conclusion'],
    'problems' => $described['problems'],
    'checked_at' => $described['checked_at'],
]
```

- [ ] **Step 5: Delegate the controller and verify GREEN**

Replace the direct database query in `QualityController` with:

```php
public function __invoke(Request $request, QualityIssueUnitQuery $query): JsonResponse
{
    return ApiResponse::success($query->execute($request->query()));
}
```

Run the focused Node test again. Expected: PASS.

- [ ] **Step 6: Commit backend aggregation**

```powershell
git add components/governance/bookstack-overlay/app/AI/Governance/Application/Quality components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V1/QualityController.php components/governance/tests/Feature/Api/V1/read-api.node.test.mjs
git commit -m "feat: aggregate manual quality issues by chapter"
```

### Task 2: Chapter Quality Presentation and Review Routing

**Files:**
- Modify: `components/governance/bookstack-overlay/public/ai-governance/app/views.js`
- Modify: `components/governance/bookstack-overlay/public/ai-governance/app/main.js`
- Modify: `components/governance/bookstack-overlay/public/ai-governance/app/demo-data.js`
- Test: `components/governance/tests/Frontend/ui-contract.node.test.mjs`
- Test: `components/governance/tests/Feature/Integration/governance-entry.node.test.mjs`

- [ ] **Step 1: Write failing frontend behavior tests**

Add a `qualityView` test with one chapter containing three member pages. Assert that output contains the chapter title once, “3 个页面有问题”, all page titles inside details, `data-action="open-review-unit"`, the unit key and shelf ID, and no page-level `data-open-asset` audit action for the chapter.

Add a source test requiring `main.js` to handle `open-review-unit`, set `state.filters.bookshelf_id` and `state.filters.search`, and call `navigate('assets')`.

- [ ] **Step 2: Run focused tests and verify RED**

Run:

```powershell
$node='C:\Users\23840\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
& $node --test components/governance/tests/Frontend/ui-contract.node.test.mjs components/governance/tests/Feature/Integration/governance-entry.node.test.mjs
```

Expected: FAIL because the current quality view renders one asset card and only supports `data-open-asset`.

- [ ] **Step 3: Render chapter cards and member evidence**

Add a chapter branch in `qualityView` that renders:

```html
<strong>章节标题</strong>
<small>章节质量 · 手册名称 · 3/8 个页面有问题</small>
<details class="quality-unit-details">
  <summary>查看章节内 3 个问题页面</summary>
  <!-- one evidence block per member, with page title, score, conclusion and fixes -->
</details>
<button data-action="open-review-unit" data-review-unit="..." data-bookshelf-id="...">前往章节审核</button>
```

Keep the existing page presentation and “查看文章” behavior for `unit_type=page`.

- [ ] **Step 4: Route the chapter action to the review view**

In `main.js`, handle `open-review-unit` by setting:

```js
state.filters = {
    bookshelf_id: button.dataset.bookshelfId || '',
    search: button.dataset.reviewUnitTitle || '',
};
navigate('assets');
```

This uses the existing review-unit API and does not create a page-level approval path.

- [ ] **Step 5: Update demo data and verify GREEN**

Replace manual page-level demo quality entries with one chapter unit containing page evidence. Run both focused tests; expected: PASS.

- [ ] **Step 6: Commit frontend behavior**

```powershell
git add components/governance/bookstack-overlay/public/ai-governance/app components/governance/tests/Frontend/ui-contract.node.test.mjs components/governance/tests/Feature/Integration/governance-entry.node.test.mjs
git commit -m "feat: present manual quality issues as chapter units"
```

### Task 3: Cache Version, Verification, and Full Patch Package

**Files:**
- Modify: frontend cache-version references under `components/governance/bookstack-overlay`
- Modify: `components/governance/DEPLOY.md`
- Modify: `components/governance/PATCH_NOTES_20260908.md`
- Modify: `components/governance/SHA256SUMS.json`
- Create: `dist/drv-knowledge-suite-v2.0.2-governance-p2-offline-bundle.zip`

- [ ] **Step 1: Add a failing cache-version assertion**

Update the integration test to require one consistent `20260908-chapter-quality-v1` query version for the governance head entry, index page, and ES module imports. Run the test and confirm it fails against the old `20260907-usability-v1` value.

- [ ] **Step 2: Update cache references and documentation**

Replace the governance UI cache key consistently, document chapter-level quality behavior, and record that P2 supersedes P1 without changing the V2.0.2 contracts or database schema.

- [ ] **Step 3: Regenerate the governance manifest**

Run `write_governance_manifest()` from `tools/release/build_v2_release.py` with the bundled Python runtime, then verify every listed SHA-256 against its file.

- [ ] **Step 4: Run full verification**

Run all governance Node tests and release/contract Python tests. Build the immutable image tag `drvknowledge/bookstack-governance:2.0.2-governance-p2`; require the Docker build’s full PHP lint stage to pass. Inspect the image for the chapter quality query, chapter action, and new cache version.

- [ ] **Step 5: Build and verify the complete offline bundle**

Create a full bundle containing unchanged Skills/Worker/Contracts 2.0.2 artifacts plus governance source/image `2.0.2-governance-p2`. Verify outer CRC, nested ZIP CRC, every manifest checksum, OCI checksum, source revision, deployment image tag, and known-secret scan.

- [ ] **Step 6: Commit release metadata**

```powershell
git add components/governance docs/superpowers/plans/2026-09-08-chapter-quality-review-units.md
git commit -m "chore: prepare chapter quality governance patch"
```

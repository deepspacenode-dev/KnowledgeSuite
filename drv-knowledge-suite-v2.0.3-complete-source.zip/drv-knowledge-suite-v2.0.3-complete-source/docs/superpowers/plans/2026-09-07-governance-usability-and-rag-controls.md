# Governance Usability and RAG Controls Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make governance records identifiable by filename, explain quality gates in Chinese, expose safe RAGFlow navigation/removal/publish actions, and remove the Bloub mouse-focus ring.

**Architecture:** Keep `drv_kb_assets` and audit history authoritative while treating deletion as an idempotent RAG unpublish. Add one quality presentation service backed by the existing JSON rule source, enrich read queries with asset identity, and expose only a validated RAGFlow web URL to the browser. Frontend actions continue through the authenticated V1 governance API.

**Tech Stack:** PHP 8.2+/Laravel query builder and HTTP client, MariaDB, vanilla ES modules, Node `node:test`, BookStack provider overlay.

---

### Task 1: Lock the required API and UI contracts with failing tests

**Files:**
- Modify: `components/governance/tests/Feature/Api/V1/read-api.node.test.mjs`
- Modify: `components/governance/tests/Feature/Rag/rag-publish.node.test.mjs`
- Modify: `components/governance/tests/Frontend/api-client.node.test.mjs`
- Modify: `components/governance/tests/Frontend/ui-contract.node.test.mjs`
- Modify: `components/governance/tests/Feature/Integration/governance-entry.node.test.mjs`

- [ ] **Step 1: Add failing read-contract assertions**

Assert that quality/RAG controllers join `drv_kb_assets`, select `asset_title`, expose `quality/rules`, and use a presenter that returns `conclusion` plus `problems`.

- [ ] **Step 2: Add failing RAG removal assertions**

Assert that routes contain `DELETE assets/{asset_id}/rag`, the removal service calls `deleteDocuments`, sets `rag_enabled` false, records `deleted`, and writes a `rag.removed` audit event.

- [ ] **Step 3: Add failing frontend assertions**

Assert that `ApiClient.delete()` sends DELETE with CSRF, quality/RAG views render `asset_title`, quality has a `quality-help` action, RAG buttons carry `dataset_id`, and the asset drawer exposes publish/removal actions only to writers.

- [ ] **Step 4: Add failing Bloub assertion**

Assert that the trigger has explicit `:focus` and `:focus-visible` rules with no outline.

- [ ] **Step 5: Run focused tests and confirm RED**

Run:

```powershell
node --test components/governance/tests/Feature/Api/V1/read-api.node.test.mjs components/governance/tests/Feature/Rag/rag-publish.node.test.mjs components/governance/tests/Frontend/api-client.node.test.mjs components/governance/tests/Frontend/ui-contract.node.test.mjs components/governance/tests/Feature/Integration/governance-entry.node.test.mjs
```

Expected: FAIL because the routes, fields, delete method, help action and focus override do not yet exist.

### Task 2: Add Chinese quality presentation and gate help

**Files:**
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Application/Quality/quality-rules.json`
- Create: `components/governance/bookstack-overlay/app/AI/Governance/Application/Quality/QualityExplanation.php`
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V1/QualityController.php`
- Create: `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V1/QualityRulesController.php`
- Modify: `components/governance/bookstack-overlay/routes/ai-governance.php`

- [ ] **Step 1: Extend the rule file with Chinese help metadata**

Keep current numerical rule keys and add labels/fixes for `owner`, `module`, `platform`, `material_type`, `适用范围`, `来源`, `风险`, hard blocks and score thresholds.

- [ ] **Step 2: Implement `QualityExplanation`**

Provide `describeCheck(object $row): array` and `help(): array`. Translate dynamic codes such as `missing:owner` and `missing_section:风险`; return a final Chinese conclusion based on reject reasons, warnings and score.

- [ ] **Step 3: Enrich and deduplicate the quality query**

Join `drv_kb_assets`, select `title AS asset_title`, `page_id`, `current_version`, alias `content_score AS score`, select only the latest `quality_check_id` per asset, and exclude rows whose warning and reject JSON arrays are both empty.

- [ ] **Step 4: Expose the help endpoint**

Register `GET /api/ai-governance/v1/quality/rules` under the existing authenticated read group.

- [ ] **Step 5: Run read tests and confirm GREEN**

Run the V1 read test and `php -l` for both new PHP files. Expected: PASS with no syntax errors.

### Task 3: Implement safe RAG removal and usable re-publish

**Files:**
- Create: `components/governance/bookstack-overlay/app/AI/Governance/Application/Rag/RemoveWikiAssetFromRag.php`
- Create: `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V1/RagRemovalController.php`
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V1/RagCommandController.php`
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Application/Rag/PublishWikiAsset.php`
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V1/RagController.php`
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V1/AssetController.php`
- Modify: `components/governance/bookstack-overlay/routes/ai-governance.php`

- [ ] **Step 1: Implement idempotent removal**

Validate a Wiki asset and latest snapshot, decode image document IDs, delete all remote documents, then transactionally set front matter `rag_enabled=false`, write a `disabled/deleted` snapshot and append `rag.removed` with the reason. Return `already_removed=true` without a remote call if the latest state is disabled/deleted.

- [ ] **Step 2: Block accidental re-upload**

In `PublishWikiAsset`, reject documents whose top-level or front-matter `rag_enabled` value is false.

- [ ] **Step 3: Make retry dataset resolution resilient**

Accept an optional `dataset_id`; resolve it from the request, latest snapshot, then `RAGFLOW_DEFAULT_DATASET_ID`. Return a Chinese configuration error when all are empty.

- [ ] **Step 4: Enrich RAG status and asset details**

Join asset title/version/page ID into RAG status. Asset details return `rag_action` with `can_publish`, resolved dataset ID, and current removal state.

- [ ] **Step 5: Register the DELETE route**

Add `DELETE /api/ai-governance/v1/assets/{asset_id}/rag` under authenticated routes; controller enforces administrator permission and validates a required Chinese-capable reason string.

- [ ] **Step 6: Run RAG tests and syntax checks**

Expected: RAG contract tests PASS; all touched PHP files return `No syntax errors detected`.

### Task 4: Expose a safe RAGFlow website link

**Files:**
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V1/SummaryController.php`
- Modify: `components/governance/bookstack-overlay/public/ai-governance/app/app-shell.js`
- Modify: `components/governance/bookstack-overlay/public/ai-governance/app/main.js`
- Modify: `components/governance/.env.example`
- Modify: `deploy/.env.example`
- Modify: `deploy/compose.yaml`

- [ ] **Step 1: Return sanitized integration metadata**

Read `RAGFLOW_WEB_URL`, fall back to `RAGFLOW_BASE_URL`, and return only an `http`/`https` URL in `summary.integrations.ragflow.web_url`.

- [ ] **Step 2: Render and activate the navigation button**

Add a hidden topbar anchor and reveal it after summary bootstrap when a valid URL is present. Use `target="_blank"` and `rel="noopener noreferrer"`.

- [ ] **Step 3: Wire the environment variable**

Add `RAGFLOW_WEB_URL` to both environment templates and the governance BookStack service in Compose.

- [ ] **Step 4: Run integration and frontend tests**

Expected: link contract and offline external-URL scans PASS because the URL is runtime data, not a hard-coded CDN.

### Task 5: Implement the Chinese quality/help and RAG actions in the browser

**Files:**
- Modify: `components/governance/bookstack-overlay/public/ai-governance/app/api-client.js`
- Modify: `components/governance/bookstack-overlay/public/ai-governance/app/views.js`
- Modify: `components/governance/bookstack-overlay/public/ai-governance/app/main.js`
- Modify: `components/governance/bookstack-overlay/public/ai-governance/assets/css/governance.css`
- Modify: `components/governance/bookstack-overlay/public/ai-governance/app/demo-data.js`

- [ ] **Step 1: Add DELETE support to the API client**

Implement `delete(path, body = {})` by delegating to `request(path, {method: 'DELETE', body})`; existing CSRF handling applies automatically.

- [ ] **Step 2: Render filename-based rows**

Use `asset_title` as the primary label and show `#asset_id · vN` as secondary audit information in quality and RAG views.

- [ ] **Step 3: Render Chinese quality conclusions**

Show the server conclusion first, then categorized blocking reasons and deductions/fixes. Add a `data-action="quality-help"` button.

- [ ] **Step 4: Add publish and removal actions**

Pass row dataset IDs into retry requests. Add trash buttons only for administrators and non-removed rows. In the drawer, show “入库并解析/重新入库” and “从 RAGFlow 移除” according to `rag_action`.

- [ ] **Step 5: Add modal handlers**

Load `/quality/rules` on help click and render thresholds plus rule cards. For removal, require a reason and explicit confirmation, call DELETE, close the drawer, reload the current view and show Chinese success/failure feedback.

- [ ] **Step 6: Update demo data and styles**

Keep `?demo=1` functional with enriched records, quality help and delete/publish responses. Add compact conclusion, issue-detail and help-card styles.

- [ ] **Step 7: Run frontend tests**

Expected: API client and UI contract tests PASS.

### Task 6: Remove the Bloub mouse-focus circle

**Files:**
- Modify: `components/governance/bookstack-overlay/public/ai-assistant/ai-assistant-governance-entry.css`
- Modify: `components/governance/tests/Feature/Integration/governance-entry.node.test.mjs`

- [ ] **Step 1: Override mouse and keyboard focus outlines**

Add a trigger `:focus` rule with `outline: none !important` and `box-shadow: none !important`; keep keyboard feedback via brightness/translation in `:focus-visible`, also without an outline.

- [ ] **Step 2: Run the entry integration test**

Expected: PASS and no circular focus outline selector remains.

### Task 7: Verify, document and package

**Files:**
- Modify: `components/governance/README.md`
- Modify: `components/governance/DEPLOY.md`
- Regenerate: `components/governance/PACKAGE_MANIFEST.txt`
- Regenerate: `components/governance/SHA256SUMS.json`

- [ ] **Step 1: Document the operation semantics**

Document filename display, RAG removal preservation, `RAGFLOW_WEB_URL`, quality-help rules and the review-to-parse chain.

- [ ] **Step 2: Run all Node governance tests**

Run:

```powershell
node --test components/governance/tests/**/*.mjs
```

Expected: all tests PASS.

- [ ] **Step 3: Run PHP verification**

Run `php -l` for every PHP file changed in this plan and the available PHPUnit suite through the project-provided BookStack test script/container. Expected: no syntax or test failures.

- [ ] **Step 4: Run browser verification**

Open the local governance demo and Bloub preview. Confirm filenames, Chinese conclusions/help, RAGFlow link behavior, admin action visibility, and no blue focus circle after mouse click.

- [ ] **Step 5: Refresh integrity manifests and build the release bundle**

Use the existing manifest/release scripts, verify SHA-256, and give the artifact a new unambiguous RC name rather than overwriting the prior 2.0.2 bundle.

- [ ] **Step 6: Commit verified implementation**

Commit only source, tests, docs and generated manifests; keep large release ZIP/OCI artifacts outside Git.

# RAGFlow Manual Sanitization Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build an offline, non-destructive sanitizer and hard gate for oversized Markdown chip manuals, then generate verified RAGFlow-safe packages for A2, A3, A5, M3, and E2.

**Architecture:** Add a standalone standard-library sanitizer to the existing technical-manual engine. It produces a human-reviewable cleaned Markdown derivative, image sidecars, and RAGFlow-only text shards whose structural atoms are capped at 2200 characters. The existing ingestion CLI exposes the sanitizer but keeps BookStack/RAGFlow network writes outside this local preparation step.

**Tech Stack:** Python 3.12 standard library, existing `drv-knowledge-ingestion` CLI, `unittest`, JSON/Markdown audit artifacts, ZIP release packaging.

---

## File Structure

- Create `components/skills/skills/drv-knowledge-ingestion/resources/technical-manual-engine/scripts/ragflow_sanitize.py`: audit, clean, shard, gate, and batch CLI.
- Create `components/skills/tests/test_ragflow_sanitize.py`: behavior and CLI regression tests.
- Modify `components/skills/tests/run_all.py`: include the new regression suite.
- Modify `components/skills/skills/drv-knowledge-ingestion/scripts/ingest_cli.py`: expose `sanitize-manual` without making network calls.
- Modify `components/skills/skills/drv-knowledge-ingestion/SKILL.md`: document the mandatory preflight for oversized manuals.
- Modify `components/skills/skills/drv-knowledge-ingestion/README.md`: add offline examples and output contract.
- Modify `components/skills/skills/drv-knowledge-ingestion/resources/technical-manual-engine/ENGINE.md`: add the RAGFlow derivative stage.
- Modify `components/skills/PACKAGE_MANIFEST.txt`: regenerate packaged file hashes after implementation.
- Create `docs/RAGFLOW_MANUAL_SANITIZATION_V1.md`: operational guide and internal validation checklist.
- Generate `知识库文档/清洗输出-v1/`: non-source test artifacts for the five manuals.
- Generate `dist/ragflow-manuals-cleaned-v1-20260904.zip`: portable internal-test bundle.

### Task 1: Establish failing sanitizer tests

**Files:**
- Create: `components/skills/tests/test_ragflow_sanitize.py`

- [ ] **Step 1: Write tests for the source-safety and root-cause rules**

Create tests that dynamically import `ragflow_sanitize.py` and assert the wished-for API:

```python
def test_pseudo_html_tag_is_escaped_but_real_table_is_preserved():
    source = "value = 1<<table\\_out\\_norm\n<table><tr><td>REG_A</td></tr></table>"
    cleaned, changes = module.clean_for_bookstack(source)
    assert "1&lt;&lt;table\\_out\\_norm" in cleaned
    assert "<table>" in cleaned
    assert changes["pseudo_html_tags"] == 1

def test_xxx_placeholders_are_never_globally_removed():
    cleaned, _ = module.clean_for_bookstack("/dev/xxx 0x0XXX19f5 Vx.x.x")
    assert cleaned == "/dev/xxx 0x0XXX19f5 Vx.x.x"

def test_private_and_relative_images_become_captions_only_for_ragflow():
    source = "![](http://10.0.0.8/a.png \"Pin Map\")\n![Clock](./img/clock.png)"
    safe, images = module.clean_for_ragflow(source)
    assert "![" not in safe
    assert "[图示：Pin Map]" in safe
    assert "[图示：Clock]" in safe
    assert [item["kind"] for item in images] == ["private_url", "relative"]
```

- [ ] **Step 2: Add tests for bullets, tripled OCR runs, tables, fences, and shard integrity**

```python
def test_only_high_confidence_tripled_ocr_span_is_collapsed():
    source = "wwwuuubbbiiissshhheeennnggg@@@aaaxxxeeerrraaa---ttteeeccchhh...cccooommm /dev/xxx"
    cleaned, changes = module.clean_for_bookstack(source)
    assert "wubisheng@axera-tech.com" in cleaned
    assert "/dev/xxx" in cleaned
    assert changes["ocr_triplet_spans"] == 1

def test_ragflow_atoms_never_exceed_hard_limit():
    source = "<table>" + "".join(f"<tr><td>REG_{i}</td><td>{'数值' * 80}</td></tr>" for i in range(40)) + "</table>"
    result = module.build_ragflow_body(source, soft_limit=1800, hard_limit=2200)
    assert max(map(len, result["atoms"])) <= 2200
    assert "REG_39" in result["body"]

def test_oversized_single_code_line_is_rejected_without_truncation():
    with self.assertRaises(module.SanitizeError):
        module.build_ragflow_body("```c\n" + "A" * 2300 + "\n```", 1800, 2200)
```

- [ ] **Step 3: Run the test and verify RED**

Run:

```powershell
python components/skills/tests/test_ragflow_sanitize.py
```

Expected: FAIL because `ragflow_sanitize.py` does not exist.

### Task 2: Implement the sanitizer core and artifact contract

**Files:**
- Create: `components/skills/skills/drv-knowledge-ingestion/resources/technical-manual-engine/scripts/ragflow_sanitize.py`

- [ ] **Step 1: Implement root-cause-safe transformations**

Define the public API used by tests:

```python
VERSION = "1.0.0"
DEFAULT_SOFT_LIMIT = 1800
DEFAULT_HARD_LIMIT = 2200
DEFAULT_SHARD_LIMIT = 1024 * 1024

class SanitizeError(RuntimeError):
    pass

def clean_for_bookstack(source: str) -> tuple[str, dict[str, int]]:
    """Normalize false HTML tags, duplicate empty anchors, U+F06C bullets,
    and only high-confidence tripled OCR spans. Never alter xxx placeholders."""

def clean_for_ragflow(source: str) -> tuple[str, list[dict[str, object]]]:
    """Remove nonsemantic HTML attributes and turn image syntax into captions."""

def build_ragflow_body(source: str, soft_limit: int, hard_limit: int) -> dict[str, object]:
    """Convert tables to row-oriented text, balance split fences, and return atoms/body."""
```

- [ ] **Step 2: Implement non-destructive output generation**

```python
def clean_document(source_path: Path, output_dir: Path, *, soft_limit=1800,
                   hard_limit=2200, shard_limit=1024 * 1024) -> dict[str, object]:
    if source_path.resolve() == output_dir.resolve() or output_dir in source_path.resolve().parents:
        raise SanitizeError("output must not overwrite the source")
    # Write source.sha256, document.cleaned.md, images.jsonl, ragflow/part-NNNN.md,
    # audit.json, and audit.md. Re-read every output and run gate_output before return.
```

The audit must include source SHA-256, source byte size, rule version, counts for each transformation, all warnings, part hashes, maximum atom size, and an explicit `PASS`/`FAIL` result.

- [ ] **Step 3: Implement independent output gate and CLI**

```python
def gate_output(output_dir: Path, hard_limit: int = 2200) -> dict[str, object]:
    """Re-read artifacts, validate hashes, balanced fences, part sequence,
    reconstruction hash, and maximum atom length."""

# Commands:
# audit SOURCE
# clean SOURCE OUTPUT_DIR
# gate OUTPUT_DIR
# batch SOURCE_DIR OUTPUT_DIR --include 01_A2.md,03_A5.md,04_M3.md,05_A3.md,06-E2.md
```

- [ ] **Step 4: Run the sanitizer tests and verify GREEN**

Run the single test file. Expected: all tests pass with no warnings or network access.

### Task 3: Expose the sanitizer through A-side ingestion

**Files:**
- Modify: `components/skills/skills/drv-knowledge-ingestion/scripts/ingest_cli.py`
- Modify: `components/skills/tests/test_ragflow_sanitize.py`

- [ ] **Step 1: Write a failing CLI integration test**

```python
def test_ingest_cli_sanitize_manual_runs_offline(tmp_path):
    result = subprocess.run([
        sys.executable, str(INGEST_CLI), "sanitize-manual", str(source),
        str(tmp_path / "out")
    ], capture_output=True, text=True)
    assert result.returncode == 0
    payload = json.loads(result.stdout)
    assert payload["result"] == "PASS"
```

- [ ] **Step 2: Verify the CLI test fails because the command is absent**

Run the integration test and require argparse to reject `sanitize-manual`.

- [ ] **Step 3: Add the minimal CLI wrapper**

```python
def cmd_sanitize_manual(args):
    engine = SKILL_DIR / "resources/technical-manual-engine/scripts/ragflow_sanitize.py"
    cmd = [sys.executable, str(engine), "clean", args.file, args.output,
           "--soft-limit", str(args.soft_limit),
           "--hard-limit", str(args.hard_limit)]
    proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, check=False)
    print(proc.stdout, end="")
    return proc.returncode
```

Register `sanitize-manual FILE OUTPUT`, include it in `/kb ingest` command mapping, and keep it local-only.

- [ ] **Step 4: Verify the CLI test and full A suite pass**

Run the sanitizer tests followed by `components/skills/tests/run_all.py`.

### Task 4: Document the gate and package the script

**Files:**
- Modify: `components/skills/skills/drv-knowledge-ingestion/SKILL.md`
- Modify: `components/skills/skills/drv-knowledge-ingestion/README.md`
- Modify: `components/skills/skills/drv-knowledge-ingestion/resources/technical-manual-engine/ENGINE.md`
- Create: `docs/RAGFLOW_MANUAL_SANITIZATION_V1.md`
- Modify: `components/skills/PACKAGE_MANIFEST.txt`

- [ ] **Step 1: Document the mandatory decision rule**

State that Markdown manuals must be sanitized before RAGFlow ingestion when any of these is true: source size over 2 MiB, any protected/line atom over 2200 characters, more than 100 images, private/relative images without bundled assets, pseudo tags, or unbalanced fences/tables.

- [ ] **Step 2: Document internal test procedure**

Include: copy bundle, verify SHA-256, create a new non-production dataset, upload all parts of one manual, PATCH document-level parser config, parse, verify every part reaches DONE, and compare chunk/token counts. Do not delete or overwrite the existing dataset.

- [ ] **Step 3: Regenerate `PACKAGE_MANIFEST.txt` with the existing release tooling**

Run the component release/build mechanism that owns the manifest; do not hand-edit hashes.

### Task 5: Generate and validate the five real manual packages

**Files:**
- Generate: `知识库文档/清洗输出-v1/`
- Generate: `dist/ragflow-manuals-cleaned-v1-20260904.zip`

- [ ] **Step 1: Run batch cleaning on explicit user-selected files**

Run:

```powershell
python ragflow_sanitize.py batch "知识库文档/01_主控SoC与平台芯片" `
  "知识库文档/清洗输出-v1" `
  --include "01_A2.md,03_A5.md,04_M3.md,05_A3.md,06-E2.md"
```

Rules remain feature-based; `--include` only selects user-requested inputs.

- [ ] **Step 2: Verify original hashes remain unchanged and all five output gates pass**

Compare source hashes captured before cleaning with `source.sha256`, run `gate` on each output directory, and require maximum atom length at or below 2200.

- [ ] **Step 3: Create the portable ZIP**

Include all five output directories, the sanitizer script, operational guide, aggregate report, and a SHA-256 manifest. Read every ZIP entry to verify integrity.

### Task 6: Final regression and evidence review

**Files:**
- Verify all modified files and generated artifacts.

- [ ] **Step 1: Run the complete A test suite**

Expected: `SUITE_TEST_SUMMARY failed=0` and `RETRIEVAL_SUMMARY failed=0`.

- [ ] **Step 2: Run fresh real-document gates and ZIP integrity checks**

Expected: five `PASS` gate results, no atom above 2200, no source hash change, and a readable archive.

- [ ] **Step 3: Review the diff and scope**

Run `git diff --check` and inspect `git status --short`. Confirm no source manual was added, edited, deleted, or moved by the implementation.

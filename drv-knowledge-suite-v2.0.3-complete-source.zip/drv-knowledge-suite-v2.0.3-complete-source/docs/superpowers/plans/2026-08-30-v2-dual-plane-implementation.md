# Drv Knowledge Suite V2.0 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build independently deployable A Skills/CLI/Worker and B BookStack Governance components connected by Contracts V2, with offline-safe packaging and a cloud-to-intranet release path.

**Architecture:** A creates BookStack drafts and submits idempotent intake requests to B. B owns governance state, queues compile tasks, accepts A Worker results, gates review, and publishes approved Wiki assets to RAGFlow. Shared Draft-07 schemas and golden fixtures are the compatibility boundary.

**Tech Stack:** Python 3.10+, SQLite, PHP 8.x/Laravel/BookStack, MariaDB, JSON Schema Draft-07, Docker Compose, PowerShell and POSIX shell release tooling.

---

### Task 1: Repository and security baseline

- [x] Import the verified V1 component archives into `components/skills` and `components/governance`.
- [x] Record archive hashes and component provenance without committing the private deployment credential document.
- [x] Add version, compatibility, secret-scan, external-link-scan and package-integrity policies.
- [x] Run the imported baseline test suites and record environmental limitations.

### Task 2: Contracts V2

- [x] Add failing schema tests for intake, wiki task/result, knowledge bundle, governance status and error envelopes.
- [x] Add Draft-07 schemas, golden fixtures and compatibility manifest.
- [x] Add Python V1 bundle conversion and PHP/Python fixture validation.
- [x] Verify invalid versions, missing identifiers and unknown write fields are rejected.

### Task 3: A client and offline outbox

- [x] Add failing tests for deterministic submission IDs, Intake payloads and SQLite outbox transitions.
- [x] Implement the V2 governance client and idempotent outbox replay.
- [x] Update ingestion submit/status flows to use B as state authority.
- [x] Implement Knowledge Bundle V2 and the temporary V1 output adapter.

### Task 4: A Worker

- [x] Add failing tests for HMAC signing, task claim, heartbeat, retry and draft-only results.
- [x] Implement the Worker API client and compiler adapter interface.
- [x] Add RAGFlow Workflow and OpenAI-compatible compiler adapters without embedding credentials.
- [x] Package the Worker runtime for an immutable container image.

### Task 5: B Governance V2

- [x] Add failing PHP tests for Intake idempotency, source re-export, status bulk resolve and Worker schema validation.
- [x] Add V2 routes authenticated by BookStack user tokens and HMAC internal routes.
- [x] Implement Intake, orphan reconciliation, standard task payloads and authoritative status snapshots.
- [x] Apply state-specific quality gates, AI-shelf publish restrictions and RAGFlow version probing.

### Task 6: Deployment and upgrade

- [x] Build a pinned BookStack governance image with no runtime overlay copying.
- [x] Add `external-ragflow` and `full-stack` Compose profiles plus a lightweight Fake RAGFlow.
- [x] Add offline OCI export/import, Python wheelhouse verification and configuration-only promotion tooling.
- [x] Add clean install, A upgrade, B upgrade, backup and rollback checks.

### Task 7: End-to-end verification

- [ ] Execute the full draft-to-recall path and idempotency tests. Cloud validation currently reaches `pending_review`; reviewed/verified, RAG publish and recall remain pending while RAGFlow is unconfigured.
- [ ] Execute B/RAGFlow outage, replay, stale-review, delete-failure and permission scenarios. Automated coverage exists; the final single-user real-environment pass remains pending.
- [x] Run secret, external-network, SBOM, checksum and package verification.
- [ ] Produce RC artifacts and an intranet smoke-test checklist. Source ZIPs and the checklist are ready; final OCI export remains pending on the release host.

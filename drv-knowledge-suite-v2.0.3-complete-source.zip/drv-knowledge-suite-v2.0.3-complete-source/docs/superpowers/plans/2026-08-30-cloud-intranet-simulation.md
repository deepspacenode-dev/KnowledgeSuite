# 云端模拟内网部署验证 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在现有空 BookStack 云环境中恢复项目目录、部署不可变 Governance 与 offline Worker，并实际验证 V2 Intake 到待审核状态的闭环。

**Architecture:** 保留 `/home/ubuntu/apps/bookstack/compose.yaml`、MariaDB 和绑定数据目录，通过一个 Compose override 替换 BookStack 镜像并增加 Worker。BookStack API 用户令牌只从本地会话注入，服务器仅持有新生成的 Worker HMAC 密钥；RAGFlow 配置保持为空。

**Tech Stack:** Docker Compose、BookStack v26.03.3、Laravel 12、PHP 8.5、MariaDB 11.4、Python 3.12、PowerShell 7、BookStack REST API。

---

### Task 1: 冻结现状并创建可恢复备份

**Files:**
- Read: `/home/ubuntu/apps/bookstack/compose.yaml`
- Create: `/home/ubuntu/backups/drv-v2-cloud-$TIMESTAMP/`, where `TIMESTAMP=$(date -u +%Y%m%dT%H%M%SZ)`.

- [ ] **Step 1: 记录只读基线**

Run on the host:

```bash
cd /home/ubuntu/apps/bookstack
sudo docker compose ps
sudo docker compose config --images
sudo docker inspect --format '{{.Name}} {{.Config.Image}} {{.Id}}' bookstack bookstack_mariadb
```

Expected: 两个容器 healthy；镜像分别为 BookStack v26.03.3 和 MariaDB 11.4.9。

- [ ] **Step 2: 创建备份目录并保存部署元数据**

```bash
BACKUP_DIR="/home/ubuntu/backups/drv-v2-cloud-$(date -u +%Y%m%dT%H%M%SZ)"
install -d -m 0700 "$BACKUP_DIR"
cp -a /home/ubuntu/apps/bookstack/compose.yaml "$BACKUP_DIR/compose.yaml"
sudo docker inspect bookstack bookstack_mariadb > "$BACKUP_DIR/docker-inspect.json"
sudo docker compose -f /home/ubuntu/apps/bookstack/compose.yaml config > "$BACKUP_DIR/compose-rendered.yaml"
```

Expected: `$BACKUP_DIR` 只允许当前用户访问，三个文件非空。

- [ ] **Step 3: 转储数据库**

```bash
sudo docker exec bookstack_mariadb sh -lc \
  'exec mariadb-dump -uroot -p"$MARIADB_ROOT_PASSWORD" --all-databases --single-transaction --routines --events' \
  > "$BACKUP_DIR/all-databases.sql"
test -s "$BACKUP_DIR/all-databases.sql"
sha256sum "$BACKUP_DIR/all-databases.sql" > "$BACKUP_DIR/SHA256SUMS"
```

Expected: SQL 文件非空且 SHA-256 已记录，命令输出不包含密码。

- [ ] **Step 4: 在短暂停机窗口备份 `/config`**

```bash
cd /home/ubuntu/apps/bookstack
sudo docker compose stop bookstack
tar -C /home/ubuntu/apps/bookstack -czf "$BACKUP_DIR/app-data.tar.gz" app-data
sudo docker compose up -d bookstack
test -s "$BACKUP_DIR/app-data.tar.gz"
curl -fsS http://127.0.0.1:6875/login >/dev/null
```

Expected: BookStack 恢复 healthy，登录页返回成功。

### Task 2: 幂等恢复网站目录

**Files:**
- No repository files modified.
- Runtime input: local process environment variable `BOOKSTACK_API_TOKEN`.

- [ ] **Step 1: 使用 API 再次确认空基线**

Run locally with the token held only in process memory:

```powershell
$headers = @{Authorization = "Token $env:BOOKSTACK_API_TOKEN"}
$base = 'http://81.70.45.118:6875/api'
(Invoke-RestMethod -Headers $headers -Uri "$base/shelves?count=100").total
(Invoke-RestMethod -Headers $headers -Uri "$base/books?count=100").total
```

Expected before restoration: `0` and `0`.

- [ ] **Step 2: 创建五本初始书籍**

For each pair below, assign its values to `$bookName` and `$purpose`, query all books by exact `name`, and only when absent POST `@{name=$bookName; description=$purpose} | ConvertTo-Json` to `/api/books`:

```text
经验案例库 -> cases
芯片手册   -> manuals
技术专题   -> tech_notes
项目文档   -> project_docs
工程工具   -> docs
```

Expected: five unique book IDs.

- [ ] **Step 3: 创建并绑定五个书架**

For each exact shelf name, assign the matching numeric values to `$bookId` and `$shelfId`. POST JSON containing `name`, `description` and `books: @($bookId)` to `/api/shelves` only when absent. If the shelf exists, PUT the same book ID set to `/api/shelves/$shelfId`.

Expected mapping:

```text
【AI】经验案例 -> 经验案例库
【AI】手册资料 -> 芯片手册
【AI】技术资料 -> 技术专题
【AI】项目资料 -> 项目文档
【SYS】工程工具 -> 工程工具
```

- [ ] **Step 4: 验证幂等性**

Run the same restoration routine a second time.

Expected: totals remain exactly five shelves and five books; every shelf contains exactly its mapped book.

### Task 3: 将已验证源码传输到目标主机并构建镜像

**Files:**
- Source: `components/governance/**`
- Source: `components/skills/worker/**`
- Create: `/home/ubuntu/releases/drv-knowledge-suite-v2.0.0-rc.1/`

- [ ] **Step 1: 创建最小传输包并计算哈希**

Run locally:

```powershell
tar -czf drv-v2-cloud-deploy.tar.gz components/governance components/skills/worker
Get-FileHash drv-v2-cloud-deploy.tar.gz -Algorithm SHA256
scp drv-v2-cloud-deploy.tar.gz ubuntu@81.70.45.118:/tmp/
```

Expected: 传输包只包含两个镜像构建上下文，不包含 `.env`、`dist`、备份或凭据。

- [ ] **Step 2: 在服务器校验并展开传输包**

```bash
RELEASE_DIR=/home/ubuntu/releases/drv-knowledge-suite-v2.0.0-rc.1
install -d -m 0750 "$RELEASE_DIR"
tar -xzf /tmp/drv-v2-cloud-deploy.tar.gz -C "$RELEASE_DIR"
find "$RELEASE_DIR" -type f -name '.env' -o -name '*.key' -o -name '*.pem'
```

Expected: `find` 无输出。

- [ ] **Step 3: 构建不可变 Governance 镜像**

```bash
sudo docker build \
  -t drvknowledge/bookstack-governance:2.0.0-rc.1 \
  -f "$RELEASE_DIR/components/governance/docker/bookstack/Dockerfile" \
  "$RELEASE_DIR/components/governance"
```

Expected: PHP lint 构建门禁通过，镜像基线 digest 为固定 BookStack digest。

- [ ] **Step 4: 断网构建 Worker 镜像**

```bash
sudo docker build --network=none \
  -t drvknowledge/worker:2.0.0-rc.1 \
  -f "$RELEASE_DIR/components/skills/worker/Dockerfile" \
  "$RELEASE_DIR/components/skills/worker"
```

Expected: 构建过程中不访问软件仓库或下载依赖。

### Task 4: 使用 Compose override 升级并迁移

**Files:**
- Create: `/home/ubuntu/apps/bookstack/compose.governance.yaml`
- Create: `/home/ubuntu/apps/bookstack/.env.drv-v2` mode `0600`

- [ ] **Step 1: 生成 Worker 密钥文件**

```bash
cd /home/ubuntu/apps/bookstack
umask 077
printf 'AI_GOVERNANCE_WORKER_KEY=%s\n' "$(openssl rand -hex 32)" > .env.drv-v2
chmod 0600 .env.drv-v2
```

Expected: 文件只包含新生成的 Worker 密钥，不包含 BookStack 用户令牌或 RAGFlow 凭据。

- [ ] **Step 2: 写入 Compose override**

The override must contain exactly these runtime decisions:

```yaml
services:
  bookstack:
    image: drvknowledge/bookstack-governance:2.0.0-rc.1
    environment:
      AI_GOVERNANCE_WORKER_KEY: ${AI_GOVERNANCE_WORKER_KEY}
      AI_GOVERNANCE_DEFAULT_COMPILER: offline
      AI_GOVERNANCE_CHAPTER_REVIEW_SHELVES: "【AI】手册资料"
      RAGFLOW_BASE_URL: ""
      RAGFLOW_API_KEY: ""
      RAGFLOW_DEFAULT_DATASET_ID: ""
  knowledge-worker:
    image: drvknowledge/worker:2.0.0-rc.1
    restart: unless-stopped
    depends_on:
      bookstack:
        condition: service_healthy
    environment:
      GOVERNANCE_BASE_URL: http://bookstack
      GOVERNANCE_WORKER_ID: drv-worker-cloud-01
      GOVERNANCE_WORKER_KEY: ${AI_GOVERNANCE_WORKER_KEY}
      WORKER_COMPILER: offline
      WORKER_POLL_SECONDS: 2
      RAGFLOW_BASE_URL: ""
      RAGFLOW_API_KEY: ""
      RAGFLOW_WORKFLOW_ID: ""
```

- [ ] **Step 3: 渲染配置并执行变更前门禁**

```bash
sudo docker compose --env-file .env --env-file .env.drv-v2 \
  -f compose.yaml -f compose.governance.yaml config > /tmp/drv-v2-compose-rendered.yaml
grep -F 'drvknowledge/bookstack-governance:2.0.0-rc.1' /tmp/drv-v2-compose-rendered.yaml
grep -F '/home/ubuntu/apps/bookstack/db-data' /tmp/drv-v2-compose-rendered.yaml
grep -F '0.0.0.0:6875' /tmp/drv-v2-compose-rendered.yaml
```

Expected: 新镜像生效，数据库绑定目录和公网端口不变。

- [ ] **Step 4: 替换 BookStack 并启动 Worker**

```bash
sudo docker compose --env-file .env --env-file .env.drv-v2 \
  -f compose.yaml -f compose.governance.yaml up -d --no-build bookstack knowledge-worker
```

Expected: MariaDB 不重建，BookStack 和 Worker 使用固定 RC 镜像。

- [ ] **Step 5: 执行迁移和缓存刷新**

```bash
sudo docker compose --env-file .env --env-file .env.drv-v2 \
  -f compose.yaml -f compose.governance.yaml exec -T bookstack \
  php /app/www/artisan migrate --force
sudo docker compose --env-file .env --env-file .env.drv-v2 \
  -f compose.yaml -f compose.governance.yaml exec -T bookstack \
  php /app/www/artisan optimize:clear
```

Expected: 迁移成功，无 BookStack 核心表删除或改写。

- [ ] **Step 6: 验证九个治理表和服务健康**

Run a MariaDB metadata query for tables matching `drv_kb_%`.

Expected: exactly nine tables；BookStack healthy；Worker 日志无鉴权、Schema 或连接错误。

### Task 5: 执行真实 offline 主链路

**Files:**
- No repository files modified.
- Create one BookStack validation page in `经验案例库`.

- [ ] **Step 1: 创建验证页面**

Assign the numeric ID of `经验案例库` to `$casesBookId`, then POST the following PowerShell object to `/api/pages` using the personal BookStack token:

```powershell
$pageRequest = @{
  book_id = $casesBookId
  name = 'V2 云端离线编译验证案例'
  markdown = "# V2 云端离线编译验证案例`n`n## 问题现象`n模拟内网环境中的链路异常。`n`n## 根因分析`n验证 Governance Intake 与 offline Worker。`n`n## 解决方案`n由 Worker 生成待审核 Wiki 草稿。`n"
}
```

Expected: page is readable and belongs to `【AI】经验案例`.

- [ ] **Step 2: 读取服务器实际 Markdown 并构造 Intake**

Assign the created numeric page ID to `$pageId`, GET `/api/pages/$pageId`, and calculate lowercase SHA-256 over the exact UTF-8 `markdown` value. Use the returned `url`, `name` and `$pageId` in `intake-request.v2`; set `requested_workflow` to `offline` and make `Idempotency-Key` equal `client_submission_id`.

- [ ] **Step 3: 提交并验证幂等重放**

POST the exact request twice to `/api/ai-governance/v2/intakes`.

Expected: first response HTTP 202 with `compile_status=queued`; second response HTTP 200 with `replayed=true` and the same task ID.

- [ ] **Step 4: 等待 Worker 完成并查询权威状态**

POST `@{content_refs=@("bookstack:page:$pageId")} | ConvertTo-Json` to `/api/ai-governance/v2/status/resolve` until the task is terminal.

Expected:

```text
compile_status=succeeded
review_status=pending_review
rag_status=not_ingested
```

- [ ] **Step 5: 验证离线行为**

Inspect Worker logs and the BookStack governance tables.

Expected: compiler is `offline`; no RAGFlow URL is contacted；结果含来源页 ID、source version 和待审核 Wiki 资产。

### Task 6: 交付证据、回滚演练和收尾

**Files:**
- Create: `docs/CLOUD_INTRANET_SIMULATION_REPORT_2026-08-31.md`

- [ ] **Step 1: 采集脱敏证据**

Record versions, image IDs, Compose services, shelf/book/page totals, migration table list, Intake replay result, final governance status and health checks. Do not record tokens, passwords, HMAC values or raw container environments.

- [ ] **Step 2: 验证回滚命令但不破坏成功环境**

```bash
cd /home/ubuntu/apps/bookstack
sudo docker compose -f compose.yaml config >/dev/null
```

Document the executable rollback sequence:

```bash
sudo docker compose --env-file .env --env-file .env.drv-v2 -f compose.yaml -f compose.governance.yaml stop knowledge-worker
sudo docker compose --env-file .env --env-file .env.drv-v2 -f compose.yaml -f compose.governance.yaml rm -f knowledge-worker
sudo docker compose -f compose.yaml up -d --no-deps bookstack
```

Expected: 原始 Compose 可独立渲染，原 BookStack 镜像仍可用。

- [ ] **Step 3: 清理传输临时文件**

Remove only `/tmp/drv-v2-cloud-deploy.tar.gz`. Retain the versioned release directory, backup directory, Compose override and generated HMAC secret for subsequent validation.

- [ ] **Step 4: 提醒轮换外部凭据**

验收报告明确要求撤销本轮 BookStack API token，并轮换 SSH 登录密码；该轮换由管理员在验证结束后执行。

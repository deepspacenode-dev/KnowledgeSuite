# RAGFlow Widget and Recall V4 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Release Drv Knowledge Suite V2.0.3 with the Bloub-triggered official RAGFlow Widget, hardened intranet configuration, Recall V4 relevance gates, the existing P2 chapter-quality patch, and a verified complete offline bundle.

**Architecture:** BookStack exposes one authenticated runtime configuration endpoint that validates environment-only Widget settings and returns a same-session browser configuration. The existing Bloub shell lazy-loads RAGFlow's official `mode=window` iframe and stops rendering chat itself. Recall V4 keeps the current multi-query lanes, adds deterministic strict/fallback relevance gates and feedback capture, and remains fully usable without external libraries.

**Tech Stack:** PHP 8.2+/Laravel, BookStack extension providers/routes, vanilla JavaScript/CSS, Python 3 standard library, JSON/YAML configuration, Node.js test runner, Docker/OCI, PowerShell/Bash deployment scripts.

---

## File Structure

- Create `components/governance/bookstack-overlay/app/AI/Governance/Application/Assistant/AssistantConfig.php`: validate Widget environment settings and build the browser URL.
- Create `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V2/AssistantConfigController.php`: authenticated read endpoint.
- Modify `components/governance/bookstack-overlay/routes/ai-governance.php`: expose `GET assistant/config` under `web,auth`.
- Modify `components/governance/bookstack-overlay/public/ai-assistant/ai-assistant-governance-entry.js`: replace proxy chat with lazy official Widget iframe.
- Modify `components/governance/bookstack-overlay/public/ai-assistant/ai-assistant-governance-entry.css`: style Widget loading, ready, error, and mobile states.
- Modify `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/GovernancePageController.php`: whitelist and forward governance views.
- Modify `components/governance/bookstack-overlay/app/AI/Governance/Infrastructure/RagFlow/RagFlowGateway.php`: allow a separate legacy Chat API instance.
- Create `contracts/ragflow/chat-assistant.v2.json`: conservative V2 Chat profile.
- Create `tools/ragflow/apply_chat_profile.py`: idempotently inspect and patch the configured RAGFlow Chat.
- Create `tools/ragflow/check_widget.py`: offline-safe syntax check plus optional live HTTP policy probe.
- Create `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall/configs/relevance_profiles.yaml`: task-specific V4 thresholds and exclusions.
- Create `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall/relevance_gate.py`: strict matching, controlled fallback, and answer gate.
- Create `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall/feedback_store.py`: credential-safe JSONL feedback persistence.
- Modify Recall pipeline, reranker, trace, CLI, environment templates, tests, release scripts, manifests, deployment docs, version files, and Compose definitions.

### Task 1: Authenticated Widget Runtime Configuration

**Files:**
- Create: `components/governance/bookstack-overlay/app/AI/Governance/Application/Assistant/AssistantConfig.php`
- Create: `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V2/AssistantConfigController.php`
- Modify: `components/governance/bookstack-overlay/routes/ai-governance.php`
- Test: `components/governance/tests/Feature/Rag/ragflow-widget.node.test.mjs`

- [ ] **Step 1: Write the failing configuration contract tests**

Create a Node source-contract test that requires the route to use `['web', 'auth']`, the controller to return schema `drvknowledge.assistant-config.v2`, and `AssistantConfig` to validate base URL, allowed path, shared ID, auth, media permission, timeout and RAGFlow web URL. Require the implementation to build query values through `http_build_query`, not string concatenation.

- [ ] **Step 2: Run the focused test and verify RED**

```powershell
$node='C:\Users\23840\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
& $node --test components/governance/tests/Feature/Rag/ragflow-widget.node.test.mjs
```

Expected: FAIL because the controller and configuration class do not exist.

- [ ] **Step 3: Implement the configuration value object**

Implement `AssistantConfig::toArray(): array` with these rules:

```php
$enabled = filter_var(env('RAGFLOW_WIDGET_ENABLED', false), FILTER_VALIDATE_BOOL);
$base = rtrim(trim((string) env('RAGFLOW_WIDGET_BASE_URL', '')), '/');
$path = '/' . ltrim(trim((string) env('RAGFLOW_WIDGET_PATH', '/next-chats/widget')), '/');
$allowedPaths = ['/chats/widget', '/next-chats/widget'];
$timeout = max(3000, min((int) env('RAGFLOW_WIDGET_LOAD_TIMEOUT_MS', 12000), 60000));
```

Reject URL user-info, fragments, non-HTTP(S) schemes, unknown paths and missing shared/auth fields by returning `enabled=false` with a Chinese `reason`. When valid, append `shared_id`, `from=chat`, `auth`, `locale=zh`, `mode=window`, `streaming`, `muted`, title/footer and color values using `http_build_query(..., PHP_QUERY_RFC3986)`.

- [ ] **Step 4: Implement the controller and route**

The controller returns:

```php
return ApiResponse::success($config->toArray());
```

Register `Route::get('assistant/config', AssistantConfigController::class)` in the existing `web,auth` V2 group.

- [ ] **Step 5: Run the focused test and verify GREEN**

Run the command from Step 2. Expected: PASS.

- [ ] **Step 6: Commit the backend contract**

```powershell
git add components/governance/bookstack-overlay/app/AI/Governance/Application/Assistant components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/V2/AssistantConfigController.php components/governance/bookstack-overlay/routes/ai-governance.php components/governance/tests/Feature/Rag/ragflow-widget.node.test.mjs
git commit -m "feat: expose secure ragflow widget configuration"
```

### Task 2: Bloub-Triggered Official Widget

**Files:**
- Modify: `components/governance/bookstack-overlay/public/ai-assistant/ai-assistant-governance-entry.js`
- Modify: `components/governance/bookstack-overlay/public/ai-assistant/ai-assistant-governance-entry.css`
- Modify: `components/governance/tests/Feature/Integration/governance-entry.node.test.mjs`
- Modify: `components/governance/tests/Feature/Rag/ragflow-chat.node.test.mjs`

- [ ] **Step 1: Replace proxy assumptions with failing Widget tests**

Require `assistantConfigUrl()` and `normalizeAssistantConfig()` helpers; require a lazily created iframe with `mode=window`, `referrerPolicy='no-referrer'`, `loading='lazy'`, strict origin equality and conditional media permissions. Assert the browser source no longer contains `CHAT_API`, `chatPayload`, `session_token`, `data-assistant-chat-form`, `innerHTML = renderMarkdown`, or direct RAGFlow credentials.

- [ ] **Step 2: Run focused tests and verify RED**

```powershell
$node='C:\Users\23840\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
& $node --test components/governance/tests/Feature/Integration/governance-entry.node.test.mjs components/governance/tests/Feature/Rag/ragflow-chat.node.test.mjs components/governance/tests/Feature/Rag/ragflow-widget.node.test.mjs
```

Expected: FAIL because the current entry still renders and submits the custom Chat form.

- [ ] **Step 3: Implement the Widget host state machine**

Render a host containing loading, iframe and error nodes. Fetch `/api/ai-governance/v2/assistant/config` only when the assistant opens for the first time. Validate `new URL(config.widget.src).origin === config.widget.origin`, then create the iframe. Add `allow="microphone; camera"` only when `allow_media` is true. On `load`, mark the host ready and set the avatar to `proud`; on timeout or error, show the returned Chinese reason and set `alerting` without disabling governance buttons.

- [ ] **Step 4: Preserve one floating entry and accessible controls**

Keep the Bloub trigger, close button, Escape handling, outside-click behavior, focus restoration, current-page status and all governance actions. Do not mount RAGFlow's `mode=master` button. On narrow screens, size the official window to `min(380px, calc(100vw - 20px))` and cap it at the available viewport height.

- [ ] **Step 5: Run focused tests and verify GREEN**

Run Step 2. Expected: PASS.

- [ ] **Step 6: Commit the browser integration**

```powershell
git add components/governance/bookstack-overlay/public/ai-assistant components/governance/tests/Feature/Integration/governance-entry.node.test.mjs components/governance/tests/Feature/Rag
git commit -m "feat: embed official ragflow chat behind bloub"
```

### Task 3: Internal Deployment Fixes and Compatibility

**Files:**
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Http/Controllers/GovernancePageController.php`
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Infrastructure/RagFlow/RagFlowGateway.php`
- Modify: `components/governance/tests/Feature/Integration/governance-entry.node.test.mjs`
- Modify: `components/governance/tests/Feature/Rag/ragflow-chat.node.test.mjs`

- [ ] **Step 1: Add failing regression assertions**

Require the page controller to whitelist all eight current governance views and forward only a known `view`. Require legacy `chatCompletion()` to prefer `RAGFLOW_CHAT_BASE_URL` and `RAGFLOW_CHAT_API_KEY`, falling back to global values, while upload/delete/status methods remain on the global client.

- [ ] **Step 2: Run tests and verify RED**

Run the three focused Node files. Expected: FAIL on missing `KNOWN_VIEWS` and missing independent Chat variables.

- [ ] **Step 3: Implement the redirect fix**

Add:

```php
private const KNOWN_VIEWS = [
    'overview', 'assets', 'contributions', 'quality', 'rag',
    'knowledge-graph', 'gaps', 'reports',
];
```

Only add `view` to the redirect query when `in_array($view, self::KNOWN_VIEWS, true)`.

- [ ] **Step 4: Implement the separate legacy Chat client**

Add private `chatBaseUrl()` and `chatClient()` helpers. `chatClient()` uses the Chat-specific key when non-empty, otherwise the constructor/global key, and throws `RAGFlow chat is not configured.` without including a secret. Change only `chatCompletion()` to call these helpers.

- [ ] **Step 5: Run tests and verify GREEN**

Run the focused Node suite. Expected: PASS.

- [ ] **Step 6: Commit internal deployment fixes**

```powershell
git add components/governance/bookstack-overlay/app/AI/Governance components/governance/tests/Feature
git commit -m "fix: preserve governance views and split chat endpoint"
```

### Task 4: Chat Profile V2 and Deployment Probes

**Files:**
- Create: `contracts/ragflow/chat-assistant.v2.json`
- Create: `tools/ragflow/apply_chat_profile.py`
- Create: `tools/ragflow/check_widget.py`
- Modify: `components/governance/tests/Feature/Rag/ragflow-chat.node.test.mjs`
- Create: `tests/release/test_ragflow_tools.py`

- [ ] **Step 1: Write failing profile and tool tests**

Test exact V2 defaults: schema version, `{knowledge}`, evidence-conflict/no-answer rules, threshold `0.32`, vector weight `0.30`, Top N `6`, Top K `128`, candidates `64`, empty reranker. Test URL validation for both supported Widget paths, rejection of credentials in URLs, redacted error output, dry-run profile diff and idempotent no-change behavior.

- [ ] **Step 2: Run tests and verify RED**

```powershell
$python='C:\Users\23840\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
& $python -m unittest tests.release.test_ragflow_tools -v
```

Expected: FAIL because the files do not exist.

- [ ] **Step 3: Add the profile and idempotent apply tool**

`apply_chat_profile.py` reads `RAGFLOW_CHAT_BASE_URL`, `RAGFLOW_CHAT_API_KEY`, `RAGFLOW_CHAT_ID` and the JSON profile. It retrieves the current Chat, prints a secret-free field diff, and patches only when `--apply` is supplied. Support `--dry-run` and `--rollback-profile`; never print headers or URL query credentials.

- [ ] **Step 4: Add the Widget checker**

`check_widget.py` always performs offline syntax validation. With `--live`, it requests the configured Widget URL without logging the auth value, reports HTTP status, redirect origin, `X-Frame-Options` and CSP `frame-ancestors`, and exits non-zero for a cross-origin redirect or framing denial.

- [ ] **Step 5: Run tests and verify GREEN**

Run Step 2 and the focused governance Rag tests. Expected: PASS.

- [ ] **Step 6: Commit Chat tooling**

```powershell
git add contracts/ragflow tools/ragflow tests/release/test_ragflow_tools.py components/governance/tests/Feature/Rag
git commit -m "feat: add conservative ragflow chat profile v2"
```

### Task 5: Recall V4 Relevance Gates

**Files:**
- Create: `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall/configs/relevance_profiles.yaml`
- Create: `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall/relevance_gate.py`
- Modify: `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall/query_normalizer.py`
- Modify: `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall/recall_reranker.py`
- Modify: `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall/pipeline.py`
- Modify: `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall/recall_trace.py`
- Modify: `components/skills/tests/test_retrieval.py`

- [ ] **Step 1: Add failing strict/fallback/answer-gate tests**

Add real candidate dictionaries proving: network rejects explicit Sensor/ISP modules; matching network metadata wins; missing metadata is admitted only when strict results are below three; explicit chip conflicts never return; low score returns `no_match`; insufficient winner margin returns `ambiguous_match`; multi-query consensus can satisfy the margin gate; trace lists every rejected candidate and selected profile.

- [ ] **Step 2: Run the focused retrieval suite and verify RED**

```powershell
$python='C:\Users\23840\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
& $python components/skills/tests/run_retrieval.py
```

Expected: FAIL because Recall V4 gate functions and statuses are missing.

- [ ] **Step 3: Add versioned profiles and excluded domains**

Define profiles for `diagnosis`, `manual_lookup`, `driver_development`, `platform_migration` and `review`, each containing `min_score`, `min_margin`, `fallback_min_documents`, `require_metadata_fields` and `excluded_modules`. Extend normalized queries with `excluded_modules`, but remove an exclusion when the raw query explicitly names that module.

- [ ] **Step 4: Implement deterministic candidate gates**

Expose:

```python
def apply_relevance_gate(normalized_query: dict, candidates: list[dict]) -> dict:
    return {
        "accepted": accepted,
        "rejected": rejected,
        "strict_count": strict_count,
        "fallback_used": fallback_used,
        "answer_status": "ok" | "no_match" | "ambiguous_match",
        "profile": profile_name,
    }
```

Every rejection contains `document_id`, `title` and one of `explicit_domain_conflict`, `explicit_chip_conflict`, `metadata_missing_strict`, `below_min_score`, or `insufficient_margin`. Never expose full chunk text in trace.

- [ ] **Step 5: Integrate after reranking and before deduplication**

Build the public bundle only from accepted candidates. Set `knowledge_status` to `ambiguous_match` when the answer gate refuses conflicting candidates. Preserve degraded/unavailable dependency semantics. Set trace version to `recall-v4` and attach the gate summary.

- [ ] **Step 6: Run tests and verify GREEN**

Run Step 2 plus `components/skills/tests/run_all.py`. Expected: PASS.

- [ ] **Step 7: Commit Recall V4**

```powershell
git add components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall components/skills/tests/test_retrieval.py
git commit -m "feat: add recall v4 relevance gates"
```

### Task 6: Recall Feedback Capture and Regression Corpus

**Files:**
- Create: `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/recall/feedback_store.py`
- Modify: `components/skills/skills/drv-knowledge-retrieval/scripts/drvkb_entry.py`
- Modify: `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/tests/recall/recall-testset.json`
- Modify: `components/skills/skills/drv-knowledge-retrieval/resources/drvkb/tests/recall/live-recall-testset.template.json`
- Modify: `components/skills/tests/test_retrieval.py`

- [ ] **Step 1: Add failing feedback tests**

Test the four accepted labels `relevant`, `irrelevant`, `missing_answer`, `bad_link`; invalid labels fail; output is one JSON object per line; API keys, authorization headers, full content and secrets are absent; the default path is under `DRVKB_RUNTIME_DIR`; and no feedback file is created by normal read-only recall.

- [ ] **Step 2: Run retrieval tests and verify RED**

Run `components/skills/tests/run_retrieval.py`. Expected: FAIL because the feedback command does not exist.

- [ ] **Step 3: Implement the store and CLI**

Add:

```text
drvkr feedback --trace-id TRACE --label irrelevant --query "网络无流量" --document-id DOC --note "命中了 ISP 手册"
```

Persist only trace ID, label, normalized query, document identity, note and UTC timestamp. Create the runtime directory with user-only permissions where supported. For `missing_answer` and `irrelevant`, call the existing knowledge-gap collector with a sanitized summary.

- [ ] **Step 4: Expand the regression corpus**

Add at least twelve cases covering network, Sensor, Boot, Storage, chip-exact lookup, cross-domain negatives, an unknown question and a source-link failure. Each negative case declares `forbidden_modules` and `expected_status`.

- [ ] **Step 5: Run tests and verify GREEN**

Run the complete Skills suite. Expected: PASS.

- [ ] **Step 6: Commit feedback capture**

```powershell
git add components/skills
git commit -m "feat: capture recall feedback for tuning"
```

### Task 7: V2.0.3 Configuration, Documentation, and Version Alignment

**Files:**
- Modify: `components/skills/VERSION`
- Modify: component `VERSION` files and user-visible `v2.0.2` strings under `components/skills`
- Modify: `deploy/.env.example`
- Modify: `deploy/compose.yaml`
- Modify: `components/governance/.env.example`
- Modify: `components/governance/DEPLOY.md`
- Modify: `components/governance/bookstack-overlay/app/AI/Governance/Infrastructure/BookStack/GovernanceHeadContentProvider.php`
- Modify: `tools/release/build_v2_release.py`
- Modify: `tools/release/build_offline_bundle.py`
- Modify: `tests/release/test_release_and_deploy.py`
- Create: `docs/V2.0.3_DEPLOYMENT_AND_ACCEPTANCE.md`
- Create: `docs/V2.0.3_CHANGELOG.md`

- [x] **Step 1: Update release tests first**

Require all component versions and default image tags to equal `2.0.3`; require every Widget and separate Chat environment variable in Compose/templates; require one cache key `20260908-v203-widget-v1`; require the deployment guide to include backup, Widget path selection, Token rotation, HTTP warning, CSP/frame check, Chat profile dry-run/apply, Recall evaluation and rollback.

- [x] **Step 2: Run release tests and verify RED**

```powershell
$python='C:\Users\23840\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
& $python -m unittest tests.release.test_release_and_deploy -v
```

Expected: FAIL on the current 2.0.2 versions and missing variables.

- [x] **Step 3: Align version/configuration files**

Set suite, Skills, Worker, Governance, Contracts and Fake RAGFlow release tags to `2.0.3`. Add Widget variables with empty credentials and safe defaults. Pass variables into BookStack only; do not put `RAGFLOW_WIDGET_AUTH` in frontend source or image build arguments. Add `RAGFLOW_CHAT_BASE_URL` and `RAGFLOW_CHAT_API_KEY` only for compatibility.

- [x] **Step 4: Write deployment and rollback instructions**

Document clean installation and V2.0.2 upgrade. The upgrade order is backup, load OCI, edit `.env`, run Widget offline/live probe, run Chat profile dry-run, start containers, verify BookStack routes/UI, apply Chat profile, run Recall testset, then retain the old image for one acceptance cycle. State that existing BookStack database and uploads are mounted unchanged and are never overwritten by image import.

- [ ] **Step 5: Refresh cache keys, manifests and tests**

Update Head CSS/JS cache keys and all release expectations. Run governance, Skills and release tests. Expected: PASS.

- [ ] **Step 6: Commit release alignment**

```powershell
git add components contracts deploy docs tools tests
git commit -m "chore: align drv knowledge suite v2.0.3"
```

### Task 8: Full Verification and Complete Offline Bundle

**Files:**
- Regenerate: `components/skills/PACKAGE_MANIFEST.txt`
- Regenerate: `components/governance/SHA256SUMS.json`
- Create: `dist/drv-knowledge-suite-v2.0.3-complete-offline-bundle.zip`

- [ ] **Step 1: Run all source tests**

Run the complete Governance Node suite, Skills Python suite, Worker tests, Contracts tests and release tests with the bundled runtimes. Require exit code zero; report optional browser/environment skips separately.

- [ ] **Step 2: Run security and offline scans**

Scan tracked and staged files, nested ZIPs and OCI layers for the user-provided Widget Token, BookStack Token, SSH password, `RAGFLOW_WIDGET_AUTH` values, API keys, external CDN references and forbidden unpinned `latest` tags. Permit only variable names and empty examples.

- [ ] **Step 3: Build immutable OCI artifacts**

Build `drvknowledge/bookstack-governance:2.0.3`, `drvknowledge/worker:2.0.3` and `drvknowledge/fake-ragflow:2.0.3`. Require PHP lint inside the BookStack image and run container-level route/source checks. Export `.oci.tar.zst` artifacts without starting or replacing any existing BookStack container.

- [ ] **Step 4: Regenerate manifests and source packages**

Run `tools/release/build_v2_release.py`, then verify every component SHA-256, SBOM entry, license asset, source revision, image tag and archive CRC.

- [ ] **Step 5: Build the complete offline bundle**

Run `tools/release/build_offline_bundle.py --release-label 2.0.3-complete-offline-bundle`. Include the five official component artifacts, deployment scripts, V2.0.3 guides, checksum manifest, P2 chapter-quality functionality, Chat profile tools and Recall V4 testset.

- [ ] **Step 6: Perform clean extraction verification**

Extract to a fresh temporary directory, run ZIP CRC tests, compare all hashes, inspect OCI metadata, run the offline Widget syntax check and confirm no deployment operation targets an existing BookStack volume or container.

- [ ] **Step 7: Commit release metadata**

```powershell
git add components/skills/PACKAGE_MANIFEST.txt components/governance/SHA256SUMS.json docs
git commit -m "chore: prepare v2.0.3 offline release"
```

- [ ] **Step 8: Deliver evidence**

Report the absolute ZIP path, SHA-256, size, Git revision, exact test counts, OCI tags, skipped external validation and the required internal deployment values without printing any credential.

# GrokBot Style Exploration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build an isolated browser prototype that lets the user compare three production-plausible GrokBot visual directions with real gaze, blink, and governance-state motion.

**Architecture:** Create one self-contained HTML prototype under the local `.superpowers` workspace and serve it through the visual-companion server. The harness renders a realistic BookStack page, mounts exactly one GrokBot variant at a time, and uses the fixed prototype picker for instant switching. No production BookStack JavaScript or CSS imports the prototype.

**Tech Stack:** Static HTML, SVG, vanilla CSS, vanilla JavaScript, visual-companion local server, browser UI automation.

---

### Task 1: Prepare the isolated prototype workspace

**Files:**
- Modify: `.gitignore`
- Create: `.superpowers/prototypes/grokbot-style-exploration.html`

- [ ] **Step 1: Ignore local visual exploration artifacts**

Add the following entry to `.gitignore`:

```gitignore
.superpowers/
```

- [ ] **Step 2: Create a minimal failing prototype shell**

Create a full HTML document with a `#stage` element and a startup assertion that expects three variant render functions:

```js
if (!Array.isArray(variants) || variants.length !== 3) {
  throw new Error('Expected exactly three GrokBot variants');
}
```

- [ ] **Step 3: Open the shell and verify the assertion fails**

Run the visual-companion server and open the prototype. Expected: the console reports `Expected exactly three GrokBot variants` until Task 2 defines all variants.

- [ ] **Step 4: Commit workspace hygiene**

```bash
git add .gitignore docs/superpowers/plans/2026-09-04-grokbot-style-exploration.md
git commit -m "chore: isolate local visual prototypes"
```

### Task 2: Implement the three GrokBot variants

**Files:**
- Create: `.superpowers/prototypes/grokbot-style-exploration.html`

- [ ] **Step 1: Build the realistic BookStack context**

Render a blue BookStack header, left navigation, technical article content, and the 86-pixel bottom-right assistant placement. Use real product-shaped labels such as `RTL8367S 调试指南`, `审核入库`, `知识图谱`, and `RAG 解析状态`.

- [ ] **Step 2: Add shared state and gaze behavior**

Define a shared controller with these supported states:

```js
const STATES = {
  idle: { label: '随时可以帮忙', tone: 'ready' },
  thinking: { label: '正在思考', tone: 'working' },
  searching: { label: '正在检索', tone: 'working' },
  success: { label: '处理完成', tone: 'success' },
  alerting: { label: '发现阻断问题', tone: 'danger' }
};
```

Use pointer movement only when `(hover: hover) and (pointer: fine)` matches. Update SVG eye transforms dynamically and smooth the head follow with `requestAnimationFrame`. Disable positional movement when `prefers-reduced-motion` matches.

- [ ] **Step 3: Implement 温润智核**

Use large soft oval eyes, layered blue glass gradients, restrained highlight, low-amplitude breathing, double blink, and delayed head follow. State transitions use transform and opacity with the shared strong easing tokens:

```css
--ease-out: cubic-bezier(0.23, 1, 0.32, 1);
--ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);
```

- [ ] **Step 4: Implement 工程伙伴**

Use narrower focused eyes, a clearer knowledge-flow mark, a subtle data ring, reduced idle motion, and stronger scanning feedback during `searching`. Keep the default expression approachable by rounding the inner eye corners.

- [ ] **Step 5: Implement 灵动精灵**

Use larger closer-set eyes, brighter edge light, a small reactive orbit accent, quicker gaze, a single-wink idle variation, and a brief elastic success response. Keep recurring idle movement below the amplitude of the one-time success motion.

- [ ] **Step 6: Add state controls**

Provide five functional controls that immediately drive the mounted robot:

```html
<button data-state="idle">默认</button>
<button data-state="thinking">思考</button>
<button data-state="searching">检索</button>
<button data-state="success">成功</button>
<button data-state="alerting">异常</button>
```

- [ ] **Step 7: Verify the three-variant assertion passes**

Reload the prototype. Expected: no startup exception, one variant renders, and all five state controls update the label and visual state.

### Task 3: Add the fixed picker harness

**Files:**
- Modify: `.superpowers/prototypes/grokbot-style-exploration.html`

- [ ] **Step 1: Copy the picker markup and styles verbatim**

Use the exact `proto-picker` structure from `prototype/PICKER.md`, with these three variant names:

```html
<button class="proto-picker-item" data-active aria-current="true">温润智核</button>
<button class="proto-picker-item">工程伙伴</button>
<button class="proto-picker-item">灵动精灵</button>
```

Include the divider and replay button because all variants contain state motion.

- [ ] **Step 2: Copy the picker behavior contract verbatim**

Use the reference wiring so number keys, arrows, `R`, URL persistence, highlight positioning, and keyed remounting behave exactly as specified.

- [ ] **Step 3: Verify switching is instant**

Switch repeatedly using clicks, number keys, and arrows. Expected: the picker highlight moves over 250ms, while the robot variant itself swaps immediately and remounts cleanly.

### Task 4: Browser verification and delivery

**Files:**
- Modify: `.superpowers/prototypes/grokbot-style-exploration.html` only if verification reveals defects

- [ ] **Step 1: Run structural checks**

Confirm the document contains exactly three picker items excluding replay, five state buttons, a reduced-motion media query, pointer capability gating, and no `http://`, `https://`, CDN, external font, or remote asset references.

- [ ] **Step 2: Test each variant in the browser**

For every variant, exercise all five states, move the pointer around the robot, replay the motion, and confirm the visible status label matches the active state.

- [ ] **Step 3: Check responsive presentation**

Verify the desktop layout and a narrow mobile viewport. Expected: the assistant remains visible, the state controls wrap, and the picker does not obscure the robot.

- [ ] **Step 4: Check the browser console**

Expected: no JavaScript exceptions, failed resource requests, or accessibility warnings caused by the prototype.

- [ ] **Step 5: Capture each final direction**

Capture one screenshot per variant in the default state so the three directions can be compared outside the live picker.

- [ ] **Step 6: Hand off for user selection**

Provide the local URL, keyboard controls, honest tradeoffs for each direction, and stop before modifying production GrokBot files.

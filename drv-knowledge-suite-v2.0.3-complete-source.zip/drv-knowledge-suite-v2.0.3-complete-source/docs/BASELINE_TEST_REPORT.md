# V2.0 imported baseline test report

Recorded on 2026-08-30 before V2 behavior changes.

- Governance Node suite: 108 tests passed.
- Skills retrieval suite: 36 of 37 passed with `PYTHONUTF8=1`; the pre-existing slash-command help test failed.
- Skills full ingestion suite could not load PyMuPDF in the Windows host runtime.
- POSIX installer execution is not applicable to the Windows host.
- PHP was not installed on the local host. PHP/Laravel/MariaDB verification is therefore a container/cloud release gate, not a source-string substitute.
- Both imported ZIP archives matched their recorded SHA-256 and internal manifests.

The cloud target later observed for compatibility probing is BookStack `v26.03.3` on PHP `8.5.5` with MariaDB `11.4.9`. No cloud credentials are recorded here.

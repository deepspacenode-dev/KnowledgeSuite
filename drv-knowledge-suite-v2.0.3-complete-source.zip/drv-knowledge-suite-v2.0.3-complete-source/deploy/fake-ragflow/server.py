from __future__ import annotations

import hashlib
import json
import os
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse


DOCUMENTS: dict[str, dict] = {}


class Handler(BaseHTTPRequestHandler):
    server_version = "DrvFakeRAGFlow/2.0"

    def log_message(self, format, *args):
        return

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> bytes:
        length = int(self.headers.get("Content-Length", "0"))
        return self.rfile.read(length)

    def _json_body(self) -> dict:
        body = self._body()
        if not body:
            return {}
        try:
            value = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return value if isinstance(value, dict) else {}

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/health":
            return self._json(200, {"ok": True})
        if path == "/api/v1/system/version":
            return self._json(200, {"data": {"version": "fake-2.0.3"}})
        if path.endswith("/documents"):
            return self._json(200, {"data": {"docs": list(DOCUMENTS.values())}})
        return self._json(404, {"code": 404, "message": "not found"})

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/api/v1/retrieval":
            request = self._json_body()
            dataset_ids = set(request.get("dataset_ids") or [])
            chunks = []
            for document in DOCUMENTS.values():
                if document.get("run") != "DONE" or (dataset_ids and document.get("dataset_id") not in dataset_ids):
                    continue
                metadata = document.get("meta_fields") or {}
                conditions = (request.get("metadata_condition") or {}).get("conditions") or []
                if any(str(metadata.get(condition.get("name"), "")).lower() != str(condition.get("value", "")).lower() for condition in conditions if condition.get("comparison_operator") == "="):
                    continue
                chunks.append({
                    "id": "chunk-" + document["id"],
                    "chunk_id": "chunk-" + document["id"],
                    "document_id": document["id"],
                    "dataset_id": document["dataset_id"],
                    "document_keyword": metadata.get("title") or document.get("name") or "Fake document",
                    "content": document.get("content") or "Fake indexed content",
                    "similarity": 0.91,
                    "document_metadata": metadata,
                })
            return self._json(200, {"code": 0, "data": {"chunks": chunks[: int(request.get("page_size", 30))]}})
        if path == "/api/v1/chat/completions":
            request = self._json_body()
            document = next((item for item in DOCUMENTS.values() if item.get("run") == "DONE"), None)
            chunks = [] if document is None else [{
                "id": "chunk-" + document["id"],
                "doc_id": document["id"],
                "document_id": document["id"],
                "document_keyword": (document.get("meta_fields") or {}).get("title") or "Fake document",
                "document_metadata": document.get("meta_fields") or {},
            }]
            question = str(request.get("question") or "")
            session_id = str(request.get("session_id") or hashlib.sha256(question.encode("utf-8")).hexdigest()[:24])
            return self._json(200, {"code": 0, "data": {
                "answer": "Fake knowledge answer: " + question,
                "session_id": session_id,
                "chat_id": request.get("chat_id", ""),
                "reference": {"chunks": chunks, "doc_aggs": []},
            }})
        if path.startswith("/api/v1/workflows/") and path.endswith("/run"):
            self._body()
            return self._json(200, {"data": {"markdown": "# Fake compiled draft\n\nOffline test result."}})
        parse_match = re.fullmatch(r"/api/v1/datasets/([^/]+)/chunks", path)
        if parse_match:
            request = self._json_body()
            for document_id in request.get("document_ids") or []:
                if document_id in DOCUMENTS:
                    DOCUMENTS[document_id]["run"] = "DONE"
                    DOCUMENTS[document_id]["status"] = "ready"
            return self._json(200, {"code": 0, "data": True})
        if path.endswith("/documents"):
            body = self._body()
            parts = path.strip("/").split("/")
            dataset_id = parts[3] if len(parts) >= 5 else "default"
            document_id = hashlib.sha256(body or path.encode()).hexdigest()[:24]
            DOCUMENTS[document_id] = {
                "id": document_id,
                "dataset_id": dataset_id,
                "name": "fake-upload.md",
                "content": body.decode("utf-8", errors="ignore"),
                "meta_fields": {},
                "parser_config": {},
                "chunk_method": "naive",
                "run": "UNSTART",
                "status": "queued",
            }
            return self._json(200, {"code": 0, "data": [{"id": document_id}]})
        return self._json(404, {"code": 404, "message": "not found"})

    def do_PATCH(self):
        path = urlparse(self.path).path
        match = re.fullmatch(r"/api/v1/datasets/([^/]+)/documents/([^/]+)", path)
        if not match:
            return self._json(404, {"code": 404, "message": "not found"})
        request = self._json_body()
        document = DOCUMENTS.get(match.group(2))
        if document is None or document.get("dataset_id") != match.group(1):
            return self._json(404, {"code": 102, "message": "document not found"})
        document["meta_fields"] = request.get("meta_fields") or document.get("meta_fields") or {}
        document["chunk_method"] = request.get("chunk_method") or document.get("chunk_method")
        document["parser_config"] = request.get("parser_config") or document.get("parser_config") or {}
        return self._json(200, {"code": 0, "data": True})

    def do_DELETE(self):
        path = urlparse(self.path).path
        if path.endswith("/documents"):
            request = self._json_body()
            ids = request.get("ids") or list(DOCUMENTS)
            for document_id in ids:
                DOCUMENTS.pop(str(document_id), None)
            return self._json(200, {"code": 0, "data": True})
        return self._json(404, {"code": 404, "message": "not found"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "9380"))
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()

#!/bin/sh
set -eu

OUTPUT=${1:-dist}
mkdir -p "$OUTPUT"

export_image() {
  image=$1
  name=$2
  docker image inspect "$image" >/dev/null
  docker save "$image" | zstd -19 -T0 -o "$OUTPUT/$name"
  sha256sum "$OUTPUT/$name" > "$OUTPUT/$name.sha256"
}

export_image drvknowledge/worker:2.0.3 drv-knowledge-worker-v2.0.3.oci.tar.zst
export_image drvknowledge/bookstack-governance:2.0.3 drv-knowledge-bookstack-v2.0.3.oci.tar.zst

printf '%s\n' "OCI archives exported under: $OUTPUT"

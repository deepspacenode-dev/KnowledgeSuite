from __future__ import annotations

import copy
import json
import unittest
from pathlib import Path

from contracts.tools.validate import ContractValidationError, validate_contract


ROOT = Path(__file__).resolve().parents[2]
FIXTURES = ROOT / "contracts" / "fixtures"


class ContractValidationTests(unittest.TestCase):
    def load_fixture(self, name: str) -> dict:
        return json.loads((FIXTURES / f"{name}.json").read_text(encoding="utf-8"))

    def test_all_golden_fixtures_validate_offline(self) -> None:
        for name in (
            "intake-request.v2.valid",
            "wiki-task.v2.valid",
            "wiki-result.v2.valid",
            "knowledge-bundle.v2.valid",
            "governance-status.v2.valid",
            "error-envelope.v2.valid",
        ):
            with self.subTest(fixture=name):
                validate_contract(self.load_fixture(name))

    def test_invalid_schema_version_is_rejected(self) -> None:
        payload = self.load_fixture("intake-request.v2.valid")
        payload["schema_version"] = "drvknowledge.intake-request.v1"
        with self.assertRaisesRegex(ContractValidationError, "schema_version"):
            validate_contract(payload)

    def test_missing_bookstack_identity_is_rejected(self) -> None:
        payload = self.load_fixture("intake-request.v2.valid")
        del payload["page_id"]
        with self.assertRaisesRegex(ContractValidationError, "page_id"):
            validate_contract(payload)

    def test_unknown_write_field_is_rejected(self) -> None:
        payload = self.load_fixture("wiki-result.v2.valid")
        payload["publish_directly"] = True
        with self.assertRaisesRegex(ContractValidationError, "publish_directly"):
            validate_contract(payload)

    def test_nested_draft_only_gate_is_enforced(self) -> None:
        payload = copy.deepcopy(self.load_fixture("wiki-result.v2.valid"))
        payload["front_matter"]["rag_enabled"] = True
        with self.assertRaisesRegex(ContractValidationError, "rag_enabled"):
            validate_contract(payload)

    def test_unknown_domain_metadata_is_rejected(self) -> None:
        payload = self.load_fixture("wiki-task.v2.valid")
        payload["source"]["domain_metadata"]["untrusted_filter"] = "bypass"
        with self.assertRaisesRegex(ContractValidationError, "untrusted_filter"):
            validate_contract(payload)


if __name__ == "__main__":
    unittest.main()

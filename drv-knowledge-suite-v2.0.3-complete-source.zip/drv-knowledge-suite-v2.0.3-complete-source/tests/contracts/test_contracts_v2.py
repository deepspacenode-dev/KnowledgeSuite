from __future__ import annotations

import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
CONTRACTS = ROOT / "contracts"


class ContractSchemaTests(unittest.TestCase):
    def load(self, name: str) -> dict:
        path = CONTRACTS / f"{name}.schema.json"
        self.assertTrue(path.is_file(), f"missing contract schema: {path}")
        return json.loads(path.read_text(encoding="utf-8"))

    def test_all_v2_contracts_exist_and_use_draft_07(self) -> None:
        for name in (
            "intake-request.v2",
            "wiki-task.v2",
            "wiki-result.v2",
            "knowledge-bundle.v2",
            "governance-status.v2",
            "error-envelope.v2",
        ):
            schema = self.load(name)
            self.assertEqual(
                schema["$schema"],
                "http://json-schema.org/draft-07/schema#",
            )
            self.assertFalse(schema.get("additionalProperties", True))

    def test_intake_contract_requires_trace_and_bookstack_identity(self) -> None:
        schema = self.load("intake-request.v2")
        self.assertEqual(schema["properties"]["schema_version"]["const"], "drvknowledge.intake-request.v2")
        self.assertEqual(
            set(schema["required"]),
            {
                "schema_version",
                "trace_id",
                "client_submission_id",
                "page_id",
                "canonical_url",
                "title",
                "content_hash",
                "material_type",
            },
        )
        self.assertEqual(schema["properties"]["page_id"]["minimum"], 1)
        self.assertIn("offline", schema["properties"]["requested_workflow"]["enum"])

    def test_wiki_task_allows_the_offline_cloud_compiler(self) -> None:
        schema = self.load("wiki-task.v2")
        compilers = schema["properties"]["compile_policy"]["properties"]["compiler"]["enum"]
        self.assertEqual(set(compilers), {"ragflow_workflow", "openai_compatible", "offline"})

    def test_wiki_task_carries_closed_domain_metadata(self) -> None:
        schema = self.load("wiki-task.v2")
        domain = schema["properties"]["source"]["properties"]["domain_metadata"]
        self.assertFalse(domain["additionalProperties"])
        self.assertEqual(
            set(domain["properties"]),
            {"owner", "module", "platform", "chip", "project"},
        )

    def test_knowledge_bundle_contract_uses_content_ref_and_structured_source(self) -> None:
        schema = self.load("knowledge-bundle.v2")
        item = schema["properties"]["items"]["items"]
        self.assertIn("content_ref", item["required"])
        content_ref_pattern = item["properties"]["content_ref"]["pattern"]
        self.assertIn("bookstack:page:[1-9][0-9]*", content_ref_pattern)
        self.assertIn("local:manual:", content_ref_pattern)
        self.assertEqual(item["properties"]["source"]["type"], "object")
        self.assertIn("system", item["properties"]["source"]["required"])

    def test_compatibility_manifest_declares_independent_patch_versions(self) -> None:
        path = CONTRACTS / "compatibility.json"
        self.assertTrue(path.is_file(), f"missing compatibility manifest: {path}")
        manifest = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(manifest["contract_version"], "2.0.0")
        self.assertEqual(manifest["components"]["skills"], ">=2.0.0 <2.1.0")
        self.assertEqual(manifest["components"]["governance"], ">=2.0.0 <2.1.0")


if __name__ == "__main__":
    unittest.main()

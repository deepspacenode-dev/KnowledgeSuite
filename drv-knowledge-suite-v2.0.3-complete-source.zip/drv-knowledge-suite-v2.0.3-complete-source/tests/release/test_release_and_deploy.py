from __future__ import annotations

import importlib.util
import json
import os
import re
import sys
import tempfile
import threading
import unittest
import urllib.request
import zipfile
from http.server import ThreadingHTTPServer
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


class ReleaseAndDeploymentTests(unittest.TestCase):
    def test_release_binds_the_p0_cross_plane_patch_version(self) -> None:
        builder = load_module("build_v2_release_versions_test", ROOT / "tools" / "release" / "build_v2_release.py")
        self.assertTrue(hasattr(builder, "SKILLS_VERSION"))
        self.assertEqual(builder.VERSION, "2.0.3")
        self.assertEqual(builder.SKILLS_VERSION, "2.0.3")
        source = (ROOT / "tools" / "release" / "build_v2_release.py").read_text(encoding="utf-8")
        self.assertIn('drv-knowledge-skills-v{SKILLS_VERSION}.zip', source)
        self.assertIn('drv-knowledge-suite-v{VERSION}-source.zip', source)

    def test_release_policy_scans_are_clean(self) -> None:
        verifier = load_module("verify_release_test", ROOT / "tools" / "release" / "verify_release.py")
        files = verifier.release_files()
        relative_files = {path.relative_to(ROOT).as_posix() for path in files}
        self.assertIn(
            "components/governance/bookstack-overlay/public/ai-governance/vendor/three/three.module.js",
            relative_files,
        )
        self.assertIn(
            "components/governance/bookstack-overlay/public/ai-governance/vendor/3d-force-graph/LICENSE",
            relative_files,
        )
        self.assertFalse(verifier.scan_forbidden_paths(files))
        self.assertFalse(verifier.scan_secrets(files))
        self.assertFalse(verifier.scan_external_runtime_urls(files))
        self.assertFalse(verifier.scan_images(files))

    def test_release_policy_rejects_forbidden_paths_even_without_secret_pattern(self) -> None:
        verifier = load_module("verify_release_forbidden_path_test", ROOT / "tools" / "release" / "verify_release.py")
        findings = verifier.scan_forbidden_paths([
            ROOT / "components" / "skills" / "runtime" / "state.json",
            ROOT / "components" / "governance" / ".env",
        ])
        self.assertEqual(len(findings), 2)

    def test_compose_has_external_full_and_test_profiles(self) -> None:
        compose = (ROOT / "deploy" / "compose.yaml").read_text(encoding="utf-8")
        environment = (ROOT / "deploy" / ".env.example").read_text(encoding="utf-8")
        self.assertIn("profiles: [external-ragflow, full-stack]", compose)
        self.assertIn("profiles: [test]", compose)
        self.assertIn("RAGFLOW_BASE_URL: ${RAGFLOW_BASE_URL:-}", compose)
        self.assertIn("RAGFLOW_CHAT_ID: ${RAGFLOW_CHAT_ID:-}", compose)
        self.assertIn("RAGFLOW_CHAT_TIMEOUT_SECONDS: ${RAGFLOW_CHAT_TIMEOUT_SECONDS:-120}", compose)
        self.assertIn("RAGFLOW_CHAT_BASE_URL: ${RAGFLOW_CHAT_BASE_URL:-}", compose)
        self.assertIn("RAGFLOW_CHAT_API_KEY: ${RAGFLOW_CHAT_API_KEY:-}", compose)
        self.assertIn("RAGFLOW_WIDGET_BASE_URL: ${RAGFLOW_WIDGET_BASE_URL:-}", compose)
        self.assertIn("RAGFLOW_WIDGET_AUTH: ${RAGFLOW_WIDGET_AUTH:-}", compose)
        for name in (
            "RAGFLOW_WIDGET_STREAMING", "RAGFLOW_WIDGET_MUTED", "RAGFLOW_WIDGET_ACCENT_COLOR",
            "RAGFLOW_WIDGET_BACKGROUND_COLOR", "RAGFLOW_WIDGET_TEXT_COLOR",
            "RAGFLOW_WIDGET_HEADER_TEXT_COLOR", "RAGFLOW_WIDGET_FOOTER_TEXT_COLOR",
            "RAGFLOW_WIDGET_TITLE", "RAGFLOW_WIDGET_SUBTITLE", "RAGFLOW_WIDGET_FOOTER",
            "RAGFLOW_WIDGET_FOOTER_LINK", "RAGFLOW_WIDGET_ALLOWED_PATHS",
        ):
            self.assertIn(name + ": ${" + name, compose)
            self.assertIn(name + "=", environment)
        self.assertIn("RAGFLOW_MARKDOWN_CHUNK_TOKENS: ${RAGFLOW_MARKDOWN_CHUNK_TOKENS:-512}", compose)
        self.assertIn("BOOKSTACK_PUBLIC_URL=", environment)
        self.assertIn("RAGFLOW_CHAT_ID=", environment)
        self.assertIn("RAGFLOW_BASE_URL=http://10.222.120.25", environment)
        self.assertIn("RAGFLOW_WEB_URL=http://10.222.120.25/", environment)
        self.assertIn("RAGFLOW_WIDGET_BASE_URL=http://10.222.120.25", environment)
        self.assertIn("RAGFLOW_API_KEY=\n", environment)
        self.assertIn("RAGFLOW_CHAT_API_KEY=\n", environment)
        self.assertIn("RAGFLOW_WIDGET_AUTH=\n", environment)
        self.assertNotIn("81.70.45.118", environment)
        self.assertIn("drvknowledge/bookstack-governance:2.0.3", compose)
        self.assertIn("drvknowledge/worker:2.0.3", compose)
        dockerfile = (ROOT / "components" / "governance" / "docker" / "bookstack" / "Dockerfile").read_text(encoding="utf-8")
        self.assertRegex(dockerfile.splitlines()[0], r"^FROM lscr\.io/linuxserver/bookstack@sha256:[a-f0-9]{64}$")
        self.assertIn("ARG DRV_GOVERNANCE_VERSION=2.0.3", dockerfile)
        self.assertNotIn(":latest", dockerfile)
        worker_dockerfile = (ROOT / "components" / "skills" / "worker" / "Dockerfile").read_text(encoding="utf-8")
        self.assertRegex(worker_dockerfile.splitlines()[0], r"^ARG PYTHON_IMAGE=python@sha256:[a-f0-9]{64}$")
        self.assertNotIn("pip install", worker_dockerfile)
        fake_dockerfile = (ROOT / "deploy" / "fake-ragflow" / "Dockerfile").read_text(encoding="utf-8")
        self.assertRegex(fake_dockerfile.splitlines()[0], r"^FROM python@sha256:[a-f0-9]{64}$")
        policy = (ROOT / "policies" / "release-security.json").read_text(encoding="utf-8")
        image_digests = re.findall(r"@sha256:([a-f0-9]+)", compose + policy)
        self.assertTrue(image_digests)
        self.assertTrue(all(len(digest) == 64 for digest in image_digests))
        self.assertIn(
            "mariadb@sha256:54ac814d243128263e18cf818f7abb611bf43a7a95ce8aa102d18f527b1516d1",
            compose,
        )

    def test_v203_uses_one_static_cache_key_and_ships_upgrade_docs(self) -> None:
        expected = "20260908-v203-widget-v1"
        files = [
            ROOT / "components/governance/bookstack-overlay/app/AI/Governance/Infrastructure/BookStack/GovernanceHeadContentProvider.php",
            ROOT / "components/governance/bookstack-overlay/public/ai-governance/index.html",
            ROOT / "components/governance/bookstack-overlay/public/ai-governance/app/main.js",
            ROOT / "components/governance/bookstack-overlay/public/ai-governance/app/app-shell.js",
            ROOT / "components/governance/bookstack-overlay/public/ai-governance/app/views.js",
        ]
        for path in files:
            text = path.read_text(encoding="utf-8")
            self.assertIn(expected, text, str(path))
            self.assertNotIn("20260908-chapter-quality-v1", text, str(path))
        deployment = ROOT / "docs/V2.0.3_DEPLOYMENT_AND_ACCEPTANCE.md"
        changelog = ROOT / "docs/V2.0.3_CHANGELOG.md"
        self.assertTrue(deployment.is_file() and changelog.is_file())
        deployment_text = deployment.read_text(encoding="utf-8")
        for required in ("查看原文", "一键入库", "知识缺口", "RAGFLOW_WIDGET_PATH=/chats/widget", "MariaDB", "/config", "回滚"):
            self.assertIn(required, deployment_text)

    def test_release_requires_and_packages_the_hashed_wheelhouse(self) -> None:
        release_builder = (ROOT / "tools" / "release" / "build_v2_release.py").read_text(encoding="utf-8")
        wheelhouse_builder = (ROOT / "tools" / "release" / "build_wheelhouse.py").read_text(encoding="utf-8")
        self.assertIn('ROOT / "wheelhouse"', release_builder)
        self.assertIn('"drv-knowledge-skills/wheelhouse"', release_builder)
        self.assertIn("SHA256SUMS.json", release_builder)
        self.assertIn('parser.add_argument("--platform",', wheelhouse_builder)
        self.assertIn("--only-binary=:all:", wheelhouse_builder)

    def test_source_zip_marks_shell_entrypoints_executable(self) -> None:
        builder = load_module("build_v2_release_permissions_test", ROOT / "tools" / "release" / "build_v2_release.py")
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir) / "component"
            base.mkdir()
            (base / "install.sh").write_text("#!/usr/bin/env bash\n", encoding="utf-8")
            builder.DIST = Path(temp_dir)
            archive_path = builder.build_zip("component.zip", [(base, "component", ())])
            with zipfile.ZipFile(archive_path) as archive:
                mode = archive.getinfo("component/install.sh").external_attr >> 16
        self.assertEqual(mode & 0o111, 0o111)

    def test_source_zip_is_reproducible_when_source_mtime_changes(self) -> None:
        builder = load_module("build_v2_release_reproducibility_test", ROOT / "tools" / "release" / "build_v2_release.py")
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir) / "component"
            base.mkdir()
            source = base / "README.md"
            source.write_text("stable content\n", encoding="utf-8")
            builder.DIST = Path(temp_dir)
            first = builder.build_zip("first.zip", [(base, "component", ())]).read_bytes()
            stat_result = source.stat()
            os.utime(source, (stat_result.st_atime + 120, stat_result.st_mtime + 120))
            second = builder.build_zip("second.zip", [(base, "component", ())]).read_bytes()
        self.assertEqual(first, second)

    def test_skills_manifest_excludes_separately_packaged_worker(self) -> None:
        manifest = (ROOT / "components" / "skills" / "PACKAGE_MANIFEST.txt").read_text(encoding="utf-8")
        listed_paths = [line.split(None, 1)[1] for line in manifest.splitlines() if line.strip()]
        self.assertFalse(any(path == "worker" or path.startswith("worker/") for path in listed_paths))

    def test_source_zip_excludes_local_secrets_and_runtime_state(self) -> None:
        builder = load_module("build_v2_release_secret_filter_test", ROOT / "tools" / "release" / "build_v2_release.py")
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir) / "component"
            (base / "secrets").mkdir(parents=True)
            (base / "runtime").mkdir()
            (base / ".env").write_text("SECRET=value\n", encoding="utf-8")
            (base / ".env.example").write_text("SECRET=<replace-me>\n", encoding="utf-8")
            (base / "secrets" / "worker.key").write_text("secret", encoding="utf-8")
            (base / "runtime" / "state.json").write_text("{}", encoding="utf-8")
            builder.DIST = Path(temp_dir)
            archive_path = builder.build_zip("component.zip", [(base, "component", ())])
            with zipfile.ZipFile(archive_path) as archive:
                names = set(archive.namelist())
        self.assertIn("component/.env.example", names)
        self.assertNotIn("component/.env", names)
        self.assertNotIn("component/secrets/worker.key", names)
        self.assertNotIn("component/runtime/state.json", names)

    def test_offline_bundle_binds_source_oci_sbom_and_internal_hashes(self) -> None:
        builder = load_module("build_offline_bundle_test", ROOT / "tools" / "release" / "build_offline_bundle.py")
        with tempfile.TemporaryDirectory() as temp_dir:
            dist = Path(temp_dir)
            payload_names = [
                "drv-knowledge-skills-v2.0.3.zip",
                "drv-knowledge-governance-v2.0.3.zip",
                "drv-knowledge-contracts-v2.0.3.zip",
                "drv-knowledge-suite-v2.0.3.spdx.json",
                "drv-knowledge-worker-v2.0.3.oci.tar.zst",
                "drv-knowledge-bookstack-v2.0.3.oci.tar.zst",
                "drv-knowledge-fake-ragflow-v2.0.3.oci.tar.zst",
                "drv-knowledge-suite-v2.0.3-source.zip",
                "ragflow-manuals-cleaned-v1.1.0-20260904.zip",
            ]
            for name in payload_names:
                (dist / name).write_bytes((name + "\n").encode("utf-8"))

            archive = builder.build_bundle(
                release_label="2.0.3",
                source_revision="deadbeef",
                dist=dist,
                worker_oci=dist / payload_names[4],
                bookstack_oci=dist / payload_names[5],
                fake_ragflow_oci=dist / payload_names[6],
                source_archive=dist / payload_names[7],
                documentation=[],
                supplements=[(dist / payload_names[8], "extras/" + payload_names[8])],
            )

            with zipfile.ZipFile(archive) as bundle:
                root = "drv-knowledge-suite-v2.0.3/"
                names = set(bundle.namelist())
                regular_payloads = payload_names[:-1]
                self.assertTrue({root + name for name in regular_payloads}.issubset(names))
                self.assertIn(root + "extras/" + payload_names[-1], names)
                self.assertIn(root + "RELEASE-MANIFEST.json", names)
                self.assertIn(root + "SHA256SUMS.txt", names)
                manifest = json.loads(bundle.read(root + "RELEASE-MANIFEST.json"))
                checksums = bundle.read(root + "SHA256SUMS.txt").decode("utf-8")
            sidecar_exists = archive.with_suffix(archive.suffix + ".sha256").is_file()

        self.assertEqual(manifest["source_revision"], "deadbeef")
        self.assertEqual(manifest["component_versions"]["skills"], "2.0.3")
        self.assertEqual(manifest["component_versions"]["governance"], "2.0.3")
        self.assertIn("drv-knowledge-bookstack-v2.0.3.oci.tar.zst", checksums)
        self.assertIn("drv-knowledge-fake-ragflow-v2.0.3.oci.tar.zst", checksums)
        self.assertIn("extras/ragflow-manuals-cleaned-v1.1.0-20260904.zip", checksums)
        self.assertTrue(sidecar_exists)

    def test_oci_import_script_uses_bundle_checksum_manifest(self) -> None:
        script = (ROOT / "deploy" / "scripts" / "import-oci.sh").read_text(encoding="utf-8")
        self.assertIn('CHECKSUMS=${2:-$INPUT/SHA256SUMS.txt}', script)
        self.assertIn('drv-knowledge-fake-ragflow-v2.0.3.oci.tar.zst', script)
        self.assertNotIn('$archive.sha256', script)

    def test_fake_ragflow_supports_version_workflow_ingestion_and_chat_without_network(self) -> None:
        fake = load_module("fake_ragflow_test", ROOT / "deploy" / "fake-ragflow" / "server.py")
        fake.DOCUMENTS.clear()
        server = ThreadingHTTPServer(("127.0.0.1", 0), fake.Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            base = f"http://127.0.0.1:{server.server_port}"
            with urllib.request.urlopen(base + "/api/v1/system/version", timeout=2) as response:
                version = json.loads(response.read())["data"]["version"]
            request = urllib.request.Request(
                base + "/api/v1/workflows/test/run",
                data=b"{}",
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=2) as response:
                markdown = json.loads(response.read())["data"]["markdown"]
            self.assertEqual(version, "fake-2.0.3")
            self.assertIn("Fake compiled draft", markdown)

            upload = urllib.request.Request(
                base + "/api/v1/datasets/manuals-v2/documents",
                data=b"# RTL8367S\nPHY link up but no traffic",
                method="POST",
            )
            with urllib.request.urlopen(upload, timeout=2) as response:
                document_id = json.loads(response.read())["data"][0]["id"]
            configure = urllib.request.Request(
                base + f"/api/v1/datasets/manuals-v2/documents/{document_id}",
                data=json.dumps({
                    "meta_fields": {
                        "page_id": "231",
                        "page_url": "http://book/books/network/page/rtl8367s",
                        "module": "network",
                    },
                    "chunk_method": "naive",
                    "parser_config": {"chunk_token_num": 512},
                }).encode(),
                headers={"Content-Type": "application/json"},
                method="PATCH",
            )
            with urllib.request.urlopen(configure, timeout=2) as response:
                self.assertEqual(json.loads(response.read())["code"], 0)
            parse = urllib.request.Request(
                base + "/api/v1/datasets/manuals-v2/chunks",
                data=json.dumps({"document_ids": [document_id]}).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(parse, timeout=2) as response:
                self.assertEqual(json.loads(response.read())["code"], 0)
            with urllib.request.urlopen(base + "/api/v1/datasets/manuals-v2/documents", timeout=2) as response:
                document = json.loads(response.read())["data"]["docs"][0]
            self.assertEqual(document["run"], "DONE")
            self.assertEqual(document["meta_fields"]["page_id"], "231")

            chat = urllib.request.Request(
                base + "/api/v1/chat/completions",
                data=json.dumps({"chat_id": "drv-chat", "question": "网络无流量如何排查", "stream": False}).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(chat, timeout=2) as response:
                chat_data = json.loads(response.read())["data"]
            self.assertIn("Fake knowledge answer", chat_data["answer"])
            self.assertEqual(chat_data["reference"]["chunks"][0]["document_metadata"]["page_id"], "231")
        finally:
            server.shutdown()
            server.server_close()

    def test_cloud_p0_overlay_reuses_existing_database_and_wires_fake_ragflow(self) -> None:
        overlay_path = ROOT / "deploy" / "cloud-validation" / "compose.p0-v202.yaml"
        self.assertTrue(overlay_path.is_file(), "cloud P0 validation overlay must be packaged")
        overlay = overlay_path.read_text(encoding="utf-8")
        self.assertIn("drvknowledge/bookstack-governance:2.0.3", overlay)
        self.assertIn("drvknowledge/worker:2.0.3", overlay)
        self.assertIn("drvknowledge/fake-ragflow:2.0.3", overlay)
        self.assertIn("RAGFLOW_BASE_URL: http://fake-ragflow:9380", overlay)
        self.assertIn('RAGFLOW_DEFAULT_DATASET_ID: "wiki-v2"', overlay)
        self.assertIn('RAGFLOW_CHAT_ID: "drv-chat"', overlay)
        self.assertIn("BOOKSTACK_PUBLIC_URL: ${APP_URL}", overlay)
        self.assertNotIn("volumes:", overlay)
        self.assertNotIn("mariadb:", overlay.split("services:", 1)[1].split("bookstack:", 1)[0])


if __name__ == "__main__":
    unittest.main()

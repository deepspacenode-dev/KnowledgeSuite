from __future__ import annotations

import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RagFlowToolTests(unittest.TestCase):
    def test_chat_profile_v2_is_conservative_and_grounded(self) -> None:
        profile = json.loads((ROOT / "contracts" / "ragflow" / "chat-assistant.v2.json").read_text(encoding="utf-8"))
        self.assertEqual(profile["schema_version"], "drvknowledge.ragflow-chat-profile.v2")
        self.assertIn("{knowledge}", profile["prompt_config"]["system"])
        self.assertIn("证据不足", profile["prompt_config"]["system"])
        self.assertIn("冲突", profile["prompt_config"]["system"])
        self.assertIn("BookStack", profile["prompt_config"]["system"])
        self.assertEqual(profile["similarity_threshold"], 0.32)
        self.assertEqual(profile["vector_similarity_weight"], 0.30)
        self.assertEqual(profile["top_n"], 6)
        self.assertEqual(profile["top_k"], 128)
        self.assertEqual(profile["rerank_candidates_count"], 64)
        self.assertEqual(profile["rerank_id"], "")

    def test_widget_url_validation_accepts_only_supported_safe_paths(self) -> None:
        module = load("check_widget_test", ROOT / "tools" / "ragflow" / "check_widget.py")
        for path in ("/chats/widget", "/next-chats/widget"):
            result = module.validate_widget_url(f"http://10.222.120.25{path}?shared_id=x&auth=secret&mode=window&from=chat")
            self.assertTrue(result["ok"], result)
        self.assertFalse(module.validate_widget_url("http://user:pass@10.222.120.25/chats/widget")["ok"])
        self.assertFalse(module.validate_widget_url("http://10.222.120.25/evil/widget")["ok"])
        self.assertFalse(module.validate_widget_url("file:///chats/widget")["ok"])

    def test_chat_profile_diff_is_idempotent_and_does_not_include_secrets(self) -> None:
        module = load("apply_chat_profile_test", ROOT / "tools" / "ragflow" / "apply_chat_profile.py")
        desired = {
            "name": "Drv Knowledge Copilot",
            "prompt_config": {"quote": True},
            "similarity_threshold": 0.32,
        }
        current = {"id": "chat-1", **desired, "tenant_id": "tenant"}
        self.assertEqual(module.compute_patch(current, desired), {})
        changed = module.compute_patch(current, {**desired, "similarity_threshold": 0.4})
        self.assertEqual(changed, {"similarity_threshold": 0.4})
        rendered = json.dumps(module.secret_free_diff(current, changed), ensure_ascii=False)
        self.assertNotIn("Authorization", rendered)
        self.assertNotIn("api_key", rendered.lower())

    def test_dry_run_never_updates_and_apply_updates_once(self) -> None:
        module = load("apply_chat_profile_transport_test", ROOT / "tools" / "ragflow" / "apply_chat_profile.py")
        calls: list[tuple[str, str, object]] = []

        def transport(method: str, url: str, key: str, payload=None, timeout=30):
            calls.append((method, url, payload))
            if method == "GET":
                return {"code": 0, "data": {"id": "chat-1", "name": "Old", "similarity_threshold": 0.1}}
            return {"code": 0, "data": True}

        desired = {"name": "New", "similarity_threshold": 0.32}
        result = module.apply_profile("http://10.222.120.25", "secret-key", "chat-1", desired, apply=False, transport=transport)
        self.assertEqual(result["status"], "dry_run")
        self.assertEqual([call[0] for call in calls], ["GET"])
        calls.clear()
        result = module.apply_profile("http://10.222.120.25", "secret-key", "chat-1", desired, apply=True, transport=transport)
        self.assertEqual(result["status"], "applied")
        self.assertEqual([call[0] for call in calls], ["GET", "PUT"])
        self.assertNotIn("secret-key", json.dumps(result))

    def test_redaction_removes_api_keys_and_widget_auth(self) -> None:
        apply_tool = load("apply_chat_profile_redact_test", ROOT / "tools" / "ragflow" / "apply_chat_profile.py")
        widget_tool = load("check_widget_redact_test", ROOT / "tools" / "ragflow" / "check_widget.py")
        self.assertNotIn("top-secret", apply_tool.redact("failed top-secret", ["top-secret"]))
        self.assertNotIn("widget-secret", widget_tool.redact_url("http://host/chats/widget?shared_id=x&auth=widget-secret"))


if __name__ == "__main__":
    unittest.main()

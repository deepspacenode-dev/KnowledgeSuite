# Drv Knowledge Suite V1.1.0 后续开发方案

> 基线版本：V1.0.8  
> 目标版本：V1.1.0  
> 方案日期：2026-08-28  
> 文档状态：可执行方案（待项目立项确认）

## 1. 执行摘要

Drv Knowledge Suite V1.0.8 已经具备知识检索、BookStack/RAGFlow 接入、本地手册召回、知识入库和严格的 full 依赖检查能力。V1.1.0 不再横向扩展为“嵌入式开发工作台”，而是围绕知识库本身补齐三类关键体验：

1. **知识看得见**：提供美观、快速的 VSCode 知识插件，支持 BookStack 目录树、召回结果、网页式快速预览和完整阅读，不再频繁跳转浏览器。
2. **知识接得进来**：通过 Source Hub 接入本地目录、Git 和 SVN 中的知识文档，并与 BookStack、RAGFlow、本地手册一起参与统一召回。
3. **知识说得清来源**：首次使用必须建立个人资料；每次入库记录实际贡献者、来源、版本和时间，解决目前多人提交后无法判断贡献归属的问题。

同时增加标准 MCP Server，使 CodeBuddy、VSCode 或其他 MCP 客户端可以调用统一的知识搜索、内容读取、来源同步和入库能力。MCP 不替代现有 `kb` CLI，而是与 CLI、CodeBuddy `/kb:*` 和 VSCode 插件共同复用一个核心层。

本方案建议采用“**先契约和界面原型，后后端与插件联调**”的实施顺序。单人开发预计 10～13 周，两人并行预计 6～8 周；外部服务改造、账号申请和测试环境等待不计入开发工时。

---

## 2. 项目边界与冻结决策

### 2.1 产品命名

| 场景 | 统一名称或语法 | 说明 |
|---|---|---|
| 产品 | Drv Knowledge Suite | 整体知识能力套件 |
| VSCode 插件 | Drv Knowledge | 面向用户的知识插件 |
| 终端命令 | `kb <action>` | `kb` 为 Knowledge Base 的缩写 |
| CodeBuddy 命令 | `/kb:<action>` | 与终端前缀保持一致 |
| MCP Server | `drv-knowledge` | 对外服务标识，不占用 `/kb:*` 命令空间 |
| 内部模块 | `drv-knowledge-*` | 仅内部实现使用 |
| 历史命令 | `/knowledge:*` | 只保留兼容解析，并输出弃用提示 |

### 2.2 V1.1.0 范围

V1.1.0 包含：

- 统一用户身份与贡献审计；
- BookStack 知识目录树和快速阅读；
- 内嵌 Web 阅读器；
- 本地目录、Git、SVN 知识来源；
- 多来源统一检索与召回；
- MCP Tools 与 Resources；
- VSCode 插件；
- 知识入库、来源状态、RAG 状态、贡献记录、收藏、历史和知识缺口；
- 安全、性能、视觉与兼容性测试。

### 2.3 明确不做的内容

以下能力不属于知识库产品边界，V1.1.0 不设计、不开发，也不在插件中预留伪入口：

- 代码 review、diff review、提交审查；
- 编译、构建、单元测试、测试生成；
- 故障诊断、版本适配、DTP、日志分析；
- SSH、串口、设备控制、烧录；
- 自动修改工程代码；
- 嵌入式开发任务编排或项目管理工作流。

DrvAgent 或 CodeBuddy 可以通过 MCP/Skill 调用知识能力来辅助上述工作，但工作流本身必须留在 Drv Knowledge Suite 之外。知识内容的“索引状态、重复风险、来源状态”可以展示；代码审查和审批流不进入本项目。

---

## 3. 目标与可量化验收指标

### 3.1 业务目标

| 目标 | V1.1.0 验收标准 |
|---|---|
| 降低知识查找成本 | 从输入查询到可阅读正文不超过 2 次用户操作；召回结果可在插件内直接打开 |
| 看清已有知识 | BookStack Shelf/Book/Chapter/Page 形成可展开目录树，支持搜索、筛选和快速预览 |
| 扩展知识来源 | 本地目录、Git、SVN 至少各完成一种真实环境接入和增量同步验收 |
| 明确贡献归属 | 所有写入动作必须包含稳定 `account_id` 与 `display_name`；无资料时写入被阻止 |
| 保持现有能力 | V1.0.8 的 82 个测试全部继续通过；旧配置和旧命令可迁移 |
| 控制产品边界 | 发布包中不存在 review/build/test/device 等非知识工具入口 |

### 3.2 性能与体验目标

以下指标在公司普通开发电脑、正常内网条件下验收：

| 场景 | 目标值 |
|---|---|
| BookStack 根目录首次加载 | P95 ≤ 2 秒 |
| 已缓存树节点展开 | P95 ≤ 300 毫秒 |
| 在线页面快速预览 | P95 ≤ 2 秒 |
| 已缓存页面预览 | P95 ≤ 500 毫秒 |
| Skill/MCP 召回到插件展示 | P95 ≤ 2 秒（不含上游 RAGFlow 自身超时） |
| 2,000 个 BookStack 页面 | 树按需加载，插件无明显卡顿，不一次性创建全部节点 |
| 10,000 个文本知识文件初次索引 | ≤ 5 分钟，进度可见，可取消 |
| 100 个文件以内增量同步 | ≤ 30 秒 |
| 插件常态内存增量 | 目标 ≤ 300 MB |
| 可访问性 | Light/Dark/High Contrast 均可读；键盘可完成树浏览、搜索和打开正文 |

指标无法达到时不得通过 RC；若受外部服务性能影响，报告中必须区分客户端耗时与服务端耗时。

---

## 4. 总体架构

```mermaid
flowchart TB
    A["使用入口\nCLI / CodeBuddy / MCP / VSCode"] --> B["Drv Knowledge Core\n统一业务与数据契约"]
    B --> C["Recall Engine\n检索、去重、排序"]
    B --> D["Content Gateway\n内容读取与安全渲染"]
    B --> E["Identity & Audit\n身份、贡献记录"]
    B --> F["Source Hub\n本地 / Git / SVN"]
    C --> G["BookStack / RAGFlow / 本地手册"]
    D --> G
    F --> H["本地索引与内容缓存"]
    C --> H
```

### 4.1 架构原则

1. **一个核心，多种入口**：CLI、MCP、CodeBuddy 和 VSCode 共享同一套 Python Core，不复制检索或入库逻辑。
2. **内容引用先于界面 URL**：系统内部使用稳定 `content_ref`，浏览器链接只是失败时的回退。
3. **凭据不进入 Webview**：BookStack、RAGFlow、Git、SVN 凭据只存在于 Extension Host/Core 进程。
4. **远程来源默认只读**：Source Hub 的同步是拉取和本地索引，不自动把 Git/SVN 内容上传 RAGFlow。
5. **树和正文分离**：目录结构可缓存，正文按需读取，保证 2,000+ 页面规模下仍可用。
6. **外部治理服务可降级**：BookStack 浏览和阅读不能依赖 Governance Cookie；治理状态不可用时只显示“未知”。
7. **先保持兼容，再优化通道**：插件第一阶段可以调用稳定的 `kb --json`；性能稳定后切换长驻 stdio Bridge。

### 4.2 建议新增目录

在 V1.0.8 现有 `lib/drv_knowledge_core` 基础上扩展：

```text
lib/drv_knowledge_core/
├── identity/              # 用户资料、写入守卫、贡献审计
├── sources/               # local/git/svn 适配器、同步与索引
├── content/               # content_ref、读取、清洗、链接与图片处理
├── catalog/               # BookStack 树、缓存、分页、虚拟视图
├── recall/                # 多来源召回、归一化、去重、解释
├── bridge/                # VSCode 使用的 stdio JSON-RPC
└── mcp_server/            # MCP Tools/Resources 适配层

vscode-extension/
├── src/extension/         # Extension Host、命令、状态与凭据边界
├── src/webview/           # 树、搜索、快速预览、完整阅读器
├── media/                 # 本地字体替代、图标、样式资源
└── test/                  # VSCode 集成、视觉和安全测试
```

---

## 5. 核心数据契约

契约先冻结，是减少 CLI、MCP、插件反复返工的关键。所有契约必须有 `schema_version`，新增字段保持向后兼容。

### 5.1 用户资料

存储位置：`~/.drvknowledge/profile.json`。只保存非敏感身份信息，不保存 BookStack Token、Cookie 或 Git 密码。

```json
{
  "schema_version": 1,
  "account_id": "l10791",
  "display_name": "刘博",
  "team": "BSP",
  "email": "",
  "created_at": "2026-08-28T10:00:00Z",
  "updated_at": "2026-08-28T10:00:00Z"
}
```

约束：

- `account_id` 必填、稳定、不可仅使用中文姓名，建议匹配 `^[a-zA-Z0-9._-]{2,64}$`；
- `display_name` 必填，用于界面展示；
- `team` 可选，但建议首次设置；
- 可从系统用户名或 `git config user.name` 预填，但必须让用户确认；
- 修改 `account_id` 时给出“贡献历史不会自动合并”的明确提示。

### 5.2 知识来源配置

存储位置：`~/.drvknowledge/sources.yaml`。

```yaml
schema_version: 1
sources:
  - id: bsp_docs
    name: BSP 团队知识文档
    type: git
    location: ssh://git.example.com/bsp/docs.git
    revision: main
    enabled: true
    include:
      - docs/**/*.md
      - manuals/**/*.{md,pdf,docx,pptx}
    exclude:
      - "**/build/**"
      - "**/.git/**"
    sync:
      mode: manual
      managed_cache: true
```

要求：

- 凭据使用 Git/SVN 已配置的凭据管理器、SSH Agent 或系统 SecretStorage，不写入 YAML；
- `id` 在用户范围内唯一；
- 所有来源均支持 `.kbignore`；
- 禁止符号链接逃逸注册根目录；
- 默认排除二进制、构建目录、依赖目录、超大文件和隐藏凭据文件；
- Git/SVN 默认只索引文档目录，源代码必须显式选择后才参与召回。

### 5.3 统一内容引用

```text
bookstack:page:26952
git:bsp_docs:a91fd02:docs/rtc.md
svn:legacy_docs:r1821:trunk/docs/ethernet.md
local:team_share:manuals/rtl8367s.md
ragflow:drv_cases:document_123:chunk_8
manual:rtl8367s:page_126
```

`content_ref` 必须可解析、可审计，并尽可能绑定来源版本。插件和 MCP 不直接把任意 URL 当作可信内容引用。

### 5.4 目录树节点

```json
{
  "schema_version": 1,
  "node_id": "bookstack:chapter:882",
  "kind": "chapter",
  "title": "RTC 与低功耗",
  "parent_id": "bookstack:book:129",
  "content_ref": null,
  "has_children": true,
  "child_count": 8,
  "status": "indexed",
  "updated_at": "2026-08-27T03:20:11Z"
}
```

`kind` 至少支持 `shelf | book | chapter | page | virtual_group`。未归属 Shelf 的 Book 放入“未分组书籍”虚拟节点。

### 5.5 召回结果包

```json
{
  "schema_version": 1,
  "bundle_id": "rb_20260828_001",
  "query": "RTC 电池电压异常",
  "created_at": "2026-08-28T10:10:00Z",
  "items": [
    {
      "item_id": "item_1",
      "title": "IPC 主板 RTC 电池电压检测异常",
      "content_ref": "bookstack:page:26952",
      "source_key": "bookstack:page:26952",
      "viewer_uri": "drvknowledge://open?ref=bookstack%3Apage%3A26952",
      "page_url": "http://bookstack.example/books/01/page/ipc-rtc",
      "score": 0.87,
      "score_explain": ["标题命中", "RTC 标签命中", "同平台"],
      "highlight_terms": ["RTC", "电池", "电压"],
      "contributor": {"account_id": "l10791", "display_name": "刘博"}
    }
  ]
}
```

`page_url` 仅作为插件不可用或内容读取失败时的回退；正常路径使用 `content_ref` 和 `viewer_uri`。

### 5.6 贡献审计事件

本地采用追加写入，不原地修改历史事件：

```json
{
  "schema_version": 1,
  "event_id": "evt_01J6...",
  "event": "knowledge_submit",
  "contributor_id": "l10791",
  "contributor_name": "刘博",
  "submitted_at": "2026-08-28T10:20:00Z",
  "client": "vscode-extension/1.1.0",
  "source": {
    "type": "git",
    "source_id": "bsp_docs",
    "path": "docs/rtc.md",
    "revision": "a91fd02",
    "sha256": "..."
  },
  "target": {"type": "bookstack", "page_id": 26952},
  "session_id": "ingest_..."
}
```

字段语义必须分开：

- `owner`：内容维护责任人；
- `contributor`：本次实际提交者；
- `source_author`：原始资料作者；
- `reviewer`：若外部系统存在审核人，仅作为来源元数据展示，不在本项目中实现审核流程。

---

## 6. 功能方案

### 6.1 用户身份与首次使用

#### 用户流程

1. 插件首次激活或用户首次执行写操作；
2. 检查 `profile.json`；
3. 若不存在，显示三步向导：账号标识 → 显示名称/团队 → 确认；
4. 执行只读 `kb help`、`kb doctor`、浏览公开知识不强制中断；
5. 入库、来源配置修改、收藏同步等写操作必须通过身份守卫；
6. 每次提交把身份写入 BookStack 页面元数据、RAG 元数据和本地审计记录。

#### CLI

```bash
kb profile show
kb profile setup
kb profile edit
kb profile validate
```

#### 可信度说明

V1.1.0 的个人资料解决“实际可追踪”问题，但在多人共用同一 BookStack Token 时无法完全防伪。后续如需强身份保证，应采用每人独立 Token 或接入统一身份系统；不能把本地 JSON 描述成强认证。

### 6.2 Source Hub：本地、Git、SVN 知识来源

#### 支持策略

| 来源 | V1.1.0 支持方式 | 同步方式 | 默认行为 |
|---|---|---|---|
| Local | 注册现有目录 | 文件系统扫描和增量哈希 | 本地只读索引 |
| Git | 现有工作树或托管缓存 Clone | `fetch` + 指定分支/提交 | 仅知识路径，本地召回 |
| SVN | 现有 Working Copy 或托管缓存 Checkout | `svn update`/指定 revision | 仅知识路径，本地召回 |

#### 同步流程

```mermaid
flowchart LR
    A["注册来源"] --> B["权限与路径预检"]
    B --> C["枚举与过滤"]
    C --> D["哈希识别变化"]
    D --> E["转换与分块"]
    E --> F["本地索引"]
    F --> G["召回可用"]
```

#### 索引实现

- 元数据和全文索引优先采用 Python 标准库 SQLite + FTS5，减少新的必装依赖；
- 每个文档记录逻辑路径、来源类型、来源 ID、revision、SHA-256、修改时间、转换器版本；
- 只重建新增、修改和删除项；
- Markdown/Text/HTML 可在 retrieval profile 中读取；
- PDF/DOCX/PPTX 的高质量转换必须运行在 full profile，并检查六个必备转换依赖；
- 索引失败不静默跳过，在插件来源页显示文件、原因和修复建议；
- Git/SVN 内容默认不会自动上传至 RAGFlow，避免源码或内部资料越权扩散。

#### 安全限制

- 来源目录必须显式加入白名单；
- 禁止读取 `.env`、私钥、凭据缓存等已知敏感文件；
- 默认单文件大小上限 50 MB，可配置但必须警告；
- 检测符号链接真实路径，禁止越过注册根目录；
- 远程地址仅交给系统 Git/SVN 客户端，日志中脱敏用户名、Token 和 URL 查询参数；
- Workspace Trust 未授予时，VSCode 插件只允许浏览已缓存知识，不执行 Clone/Update 或本地扫描。

### 6.3 多来源 Recall Engine

V1.1.0 在现有 Recall V3 上增加“来源车道”：

1. RAGFlow：语义/关键词召回；
2. BookStack：目录与页面元数据召回；
3. Local/Git/SVN：SQLite FTS5 本地召回；
4. 本地技术手册：页级召回；
5. Governance：知识缺口和状态补充，失败时降级。

排序策略分三步：

- 各来源内部先得到原始分数；
- 归一化到 0～1，并加入标题、芯片、平台、模块、标签、时间等显式特征；
- 使用 `source_key/content_ref/hash` 去重，保留最可信正文，其他来源显示为“同一知识的其他位置”。

插件必须展示“为什么命中”，至少包括标题命中、标签命中、正文命中、同平台/同芯片和来源权重，避免只给一个不可解释的分数。

### 6.4 Content Gateway 与内嵌 Web 阅读器

#### 读取方案

不直接 iframe 整个 BookStack 页面。Extension Host/Core 使用 API 拉取 Markdown/HTML，经统一处理后发送给 Webview：

1. 解析 `content_ref`；
2. 使用对应适配器读取内容；
3. 统一标题、正文、目录、附件、图片和元数据；
4. 清洗 HTML，移除脚本、事件属性、危险 URL；
5. 把图片下载到受控缓存，并转换为 Webview 可访问 URI；
6. 重写内部知识链接，点击后仍在插件中打开；
7. 生成阅读模型，交给 Webview 渲染。

#### 阅读器功能

- 右侧快速预览：单击树节点或召回结果即可查看摘要和正文；
- 完整编辑器阅读页：支持多标签、前进/后退、面包屑和滚动位置恢复；
- 专注阅读模式：隐藏来源侧栏，控制正文最大宽度和行高；
- 自动目录：根据 H1～H4 生成，随滚动高亮；
- 查询词高亮与“上一个/下一个命中”；
- 代码块复制、语言标识和横向滚动；
- 表格粘性表头、窄屏横向滚动；
- 图片缩放、原图查看和失败占位；
- 相关知识、来源信息、贡献者、更新时间和索引状态；
- 收藏、阅读历史、复制引用、打开原始页面；
- 离线时展示缓存版本和缓存时间，不伪装为实时内容。

#### 安全实现

- Webview 使用严格 Content Security Policy；
- Markdown 渲染器、代码高亮和清洗库全部随 VSIX 本地打包，不使用 CDN；
- Webview 不接触 BookStack/RAGFlow/Git/SVN Token；
- 禁止任意 `http(s)` 资源直接加载，图片由 Extension Host 代理和缓存；
- 外部链接点击前显示域名，内部 `content_ref` 直接在插件打开；
- 对脚本、SVG、Data URI、超大图片和恶意 Markdown 建立专项安全测试。

### 6.5 BookStack 知识目录树

目录结构：

```text
Shelf
└── Book
    ├── 直接 Page
    └── Chapter
        └── Page
```

无 Shelf 的书籍显示在“未分组书籍”。此外提供以下虚拟视图：

- 最近更新；
- 我的贡献；
- 我的收藏；
- 最近阅读；
- RAG 未索引/异常；
- 无归属或元数据缺失。

#### 交互细节

- 节点按需加载、分页和缓存，禁止启动时一次拉取所有 Page；
- Shelf/Book/Chapter 显示子项数量；Page 显示索引状态、贡献者或更新时间等轻量徽标；
- 支持标题、芯片、平台、模块、标签、贡献者和状态过滤；
- 单击快速预览，双击或“完整阅读”在编辑区打开；
- 右键菜单仅提供知识相关动作：复制链接、复制引用、收藏、查看来源、重新拉取、打开原站；
- 保存展开状态、选中节点和滚动位置；
- API/治理状态失败时保留已有缓存，并在节点旁显示可理解的降级状态；
- 目录树刷新使用差量更新，避免整棵树闪烁和失去焦点。

### 6.6 MCP Server

MCP 使用官方 SDK 实现，首版只提供 Tools 和 Resources，不提供 Prompts，避免与 `/kb:*` 命令体系发生冲突。

#### Tools

| Tool | 作用 | 写操作 |
|---|---|---|
| `kb_recall` | 多来源综合召回 | 否 |
| `kb_search` | 按来源和过滤条件搜索 | 否 |
| `kb_content_get` | 根据 `content_ref` 获取正文 | 否 |
| `kb_content_related` | 获取相关知识 | 否 |
| `kb_sources_list` | 查看已注册来源和状态 | 否 |
| `kb_sources_sync` | 同步指定来源到本地缓存 | 本地缓存 |
| `kb_ingest_analyze` | 分析待入库文件 | 否 |
| `kb_ingest_preview` | 生成入库预览 | 本地会话 |
| `kb_ingest_submit` | 确认后提交知识 | 是，必须身份与确认 |
| `kb_contributions` | 查询个人贡献记录 | 否 |
| `kb_gaps` | 查询知识缺口 | 否 |
| `kb_view_open` | 请求 VSCode 插件打开内容 | 本地 UI |

明确不提供 `diagnose/review/build/test/device` 类工具。

#### Resources

- `drvknowledge://catalog`：知识来源与目录摘要；
- `drvknowledge://content/{content_ref}`：标准化正文；
- `drvknowledge://bookstack/tree/{node_id}`：目录节点；
- `drvknowledge://recall/{bundle_id}`：最近召回结果包。

#### 启动方式

```bash
kb mcp serve --transport stdio
kb mcp doctor
```

MCP SDK 作为独立可选特性检查，不混入六个转换依赖。安装 `--with-mcp` 时若 SDK 缺失则阻止该特性启用，并给出清晰说明；安装器不自行联网安装。VSCode 插件仍可通过 `kb --json`/stdio Bridge 使用核心能力，因此不强依赖 MCP Host。

### 6.7 VSCode 插件：Drv Knowledge

#### 信息架构

| 主视图 | 核心功能 |
|---|---|
| 知识 | 统一搜索、BookStack 目录树、结果筛选、快速预览 |
| 阅读器 | 多标签正文、目录、相关知识、引用和来源信息 |
| 来源 | BookStack/RAGFlow/Local/Git/SVN 状态、注册、同步、错误详情 |
| 入库 | 拖放/当前文件分析、转换预览、元数据、重复提醒、确认提交 |
| 我的 | 个人资料、贡献、收藏、历史、知识缺口 |

“系统状态/设置”放入右上角和状态栏，不占用主导航。

#### 体现实际效用的功能

- 全局搜索和来源过滤；
- 选中代码、错误文本或芯片型号后执行“在知识库中搜索”；
- 当前 Markdown/PDF/DOCX/PPTX 一键进入入库分析；
- 召回卡片直接显示摘要、来源、命中原因、贡献者和状态；
- 搜索结果、目录树、相关知识均可直接内嵌阅读；
- 多文档标签页，适合在排查问题时并行参考资料；
- 收藏、最近阅读和阅读位置恢复；
- 复制“标题 + 稳定链接 + 来源”的标准引用；
- 来源同步进度、失败文件和修复建议；
- RAG 未索引、元数据缺失、疑似重复等知识维护提示；
- 状态栏显示知识服务是否可用，但不制造持续干扰。

#### 插件与 Core 通信

实施分两步：

1. Alpha：调用 `kb ... --json`，优先验证功能与契约；
2. Beta：增加 `kb bridge --stdio` 长驻 JSON-RPC，减少重复进程启动，支持流式进度和取消。

插件通过 VSCode URI Handler 接收 `drvknowledge://open` 请求。Skill/MCP 召回后写入短期 Recall Session；插件拿到 `bundle_id/content_ref` 后打开对应卡片或正文，不在 URI 中放大段正文和凭据。

### 6.8 入库中心

沿用 V1.0.8 的 `analyze → import → preview → submit → status` 生命周期，在插件中提供可视化引导，但不引入审核工作流。

功能：

- 拖放文件、选择文件、当前编辑器文件；
- 展示识别格式、建议知识类型、标题、模块、平台、芯片和标签；
- 预览转换后的 Markdown、图片、表格和元数据；
- 显示必备依赖检查结果和具体缺项；
- 提交前做标题、来源哈希和相似内容重复提示；
- 选择目标 Book/Chapter，并展示最终路径；
- 写操作要求用户资料和显式确认；
- 提交成功后自动在目录树定位并打开新页面；
- 显示 BookStack 保存状态和 RAG 索引状态，不实现 review/approval 操作。

### 6.9 我的贡献、收藏、历史和知识缺口

- **我的贡献**：按 `account_id` 汇总提交数量、文档类型、目标书籍和最近提交；
- **收藏**：V1.1.0 先本地保存 `content_ref`，后续再考虑服务端同步；
- **历史**：只记录内容引用、打开时间和阅读位置，提供清空能力；
- **知识缺口**：展示用户查询无结果、低置信度或治理服务返回的缺口；
- **隐私控制**：历史和查询记录默认本地保存，设置中可关闭或清空。

---

## 7. 视觉与阅读体验规范

界面美观性是 P0 验收条件，不是发布前的附加润色。

### 7.1 视觉方向

- 风格：克制、清晰、轻量的蓝灰知识工具；
- 使用 VSCode 原生颜色变量，适配 Light、Dark、High Contrast；
- 避免霓虹色、大面积渐变和过度“科技感”；
- 状态色只表达语义：成功、警告、错误、离线、未知；
- 图标统一采用 VSCode Codicon 或同一线性图标体系。

### 7.2 阅读排版

- 正文最大宽度建议 760～920 px，可由用户调节；
- 中文正文行高 1.65～1.8，段落间距稳定；
- 标题层级不超过四级视觉变化；
- 代码、表格、引用、提示框和图片采用统一圆角与边框；
- 长表格不压缩到不可读，提供横向滚动和粘性表头；
- 深色模式图片可增加背景衬底，避免透明图不可见；
- 页面元数据使用紧凑标签，不抢正文注意力。

### 7.3 页面状态

每个页面必须设计以下状态，禁止只设计“有数据”的理想画面：

- 初次引导；
- 加载骨架；
- 空结果；
- 权限不足；
- 服务离线；
- 缓存内容；
- 内容不存在/已移动；
- 转换失败；
- 部分图片失败；
- 超长内容和大表格。

### 7.4 原型评审门槛

正式开发 Webview 前必须完成可点击 HTML 原型，至少包含：

1. 知识主页与统一搜索；
2. BookStack 目录树；
3. 快速预览；
4. 完整阅读器；
5. 来源管理；
6. 入库预览；
7. 首次用户向导；
8. Light/Dark 两套主题。

原型通过用户确认后才能冻结前端组件和进入批量开发，避免后期因视觉和交互方向不满意重做。

---

## 8. 安装、依赖与发布策略

### 8.1 安装 Profile

```bash
./install.sh --profile retrieval
./install.sh --profile full
./install.sh --profile full --with-mcp
```

| Profile | 能力 | 依赖处理 |
|---|---|---|
| retrieval | 检索、阅读、目录树、文本来源 | 检查基础运行环境 |
| full | retrieval + PDF/DOCX/PPTX 等转换与入库 | 六个转换包必须全部满足 |
| `--with-mcp` | 在所选 Profile 上启用 MCP Server | 额外检查 MCP SDK |

### 8.2 Full 转换依赖的最终规则

以下六项是入库转换的必备条件：

1. beautifulsoup4
2. python-docx
3. python-pptx
4. PyMuPDF
5. pdfplumber
6. Pillow

发布包不附带这些 wheel，也不附带传递依赖包。安装器只执行检查：

- 已安装且版本兼容：记录 PASS，不执行任何安装；
- 缺失、无法导入或版本不兼容：在文件写入前中止 full 安装，退出码 20；
- 输出缺项、检测到的版本、要求范围和人工安装建议；
- 不执行 `pip install`、不访问 PyPI、不静默降级为 retrieval、不跳过转换器；
- 修复环境后重新运行同一安装命令即可继续。

建议保留两份清单：

- `requirements/full.required.txt`：允许的兼容范围；
- `requirements/full.lock.txt`：发布验收时使用的已验证版本。

### 8.3 发布物

- `drv-knowledge-suite-v1.1.0.zip`；
- `drv-knowledge-vscode-v1.1.0.vsix`；
- SHA-256 校验文件；
- 安装、升级、回滚说明；
- Profile/Source/Profile/MCP 数据契约；
- 测试和视觉验收报告；
- 不含第三方转换 wheel。

---

## 9. CLI、CodeBuddy 与兼容策略

### 9.1 命令原则

- 对用户统一使用 `kb`，避免 `knowledge`、`drvkr`、`drvki` 多套名称；
- 不为每个 UI 按钮增加 CodeBuddy 命令；
- 复杂功能通过稳定子命令和 JSON 契约提供；
- 历史 `/knowledge:*` 至少保留一个小版本，并明确提示迁移到 `/kb:*`。

### 9.2 建议新增 CLI

```text
kb profile ...
kb sources list|add|remove|sync|status ...
kb content get <content_ref> --json
kb catalog tree ...
kb mcp serve|doctor ...
kb bridge --stdio
```

CodeBuddy 侧只建议新增一个聚合入口 `/kb:sources`；其他已有检索、入库、状态命令保持不变，避免命令爆炸。

### 9.3 兼容要求

- 现有 `~/.drvknowledge/.env` 原值优先保留；
- 新增 `profile.json` 和 `sources.yaml` 不改写旧配置；
- V1.0.8 的 `source_key` 可直接映射到新的 `content_ref`；
- V1.0.8 召回结果缺少新字段时，插件以兼容适配器补默认值；
- 所有迁移均先备份、后写入；失败自动恢复；
- 升级后提供 `kb doctor --migration` 和 `kb config validate`。

---

## 10. 版本路线与实施排期

### 10.1 版本节奏

| 版本 | 定位 | 主要内容 |
|---|---|---|
| V1.0.9 | 兼容基础版 | 契约、Profile、Source Hub 骨架、Content Gateway 基础、迁移 |
| V1.1.0-alpha.1 | 可视原型版 | BookStack 树、快速预览、完整阅读器、CLI JSON 联调 |
| V1.1.0-beta.1 | 功能完整测试版 | Git/SVN、统一召回、MCP、stdio Bridge、入库中心 |
| V1.1.0-rc.1 | 验收候选版 | 性能、安全、视觉、迁移、文档、安装包 |
| V1.1.0 | 正式版 | 验收问题关闭，发布 ZIP、VSIX 和校验文件 |

### 10.2 阶段计划

| 阶段 | 工期（人日） | 关键任务 | 退出条件 |
|---|---:|---|---|
| P0 方案与原型 | 3～4 | 契约评审、信息架构、Light/Dark 可点击原型 | 范围冻结；7 个核心页面原型确认 |
| P1 核心契约与身份 | 5～6 | profile、写入守卫、audit、迁移、CLI | 无资料写入阻断；旧配置无损升级 |
| P2 内容网关与目录树 | 8～10 | BookStack API、树缓存、content_ref、清洗、图片代理 | 700 页实库流畅浏览；危险 HTML 被拦截 |
| P3 Source Hub | 7～9 | Local/Git/SVN、过滤、哈希、转换、FTS5 | 三种来源实测；增量同步达标 |
| P4 Recall 与 MCP | 5～7 | 多来源召回、去重、Tools/Resources、Recall Session | MCP Inspector 通过；插件可打开 MCP 召回内容 |
| P5 VSCode 插件 | 12～15 | 五大视图、快速预览、完整阅读器、Bridge、URI Handler | 核心用户旅程全部可用；主题和键盘验收通过 |
| P6 入库与个人中心 | 4～5 | 可视入库、贡献、收藏、历史、缺口、状态 | 完成真实提交和回读；贡献者可追踪 |
| P7 稳定与发布 | 5～7 | 性能、安全、视觉回归、安装、升级、回滚、文档 | RC 零阻断缺陷，正式包可复现构建 |

合计约 **49～63 人日**。建议人员配置：

- 1 名 Python/Core 开发；
- 1 名 TypeScript/VSCode 开发；
- 产品/视觉评审可由项目负责人阶段性参与；
- 测试由两名开发交叉执行，关键版本增加 1 名真实用户验收。

若只有一名开发，建议严格按 P0→P7 顺序，预计 10～13 周。若两人并行，P2/P3 与插件基础框架可在契约冻结后并行，预计 6～8 周。

### 10.3 工作分解清单

| ID | 任务 | 产出 |
|---|---|---|
| ARCH-01 | 冻结 Profile/Source/Content/Recall/Audit Schema | JSON Schema + 示例 + 兼容规则 |
| UX-01 | 完成插件信息架构和交互原型 | HTML 原型 + Light/Dark 截图 |
| ID-01 | Profile CLI、向导和校验 | `profile.py`、测试、迁移说明 |
| ID-02 | 写入守卫和追加审计 | audit log、BookStack/RAG 元数据映射 |
| CAT-01 | BookStack Shelf/Book/Chapter/Page 适配 | Catalog API 与契约测试 |
| CAT-02 | 懒加载、分页、缓存和虚拟视图 | 性能报告 |
| GW-01 | Content Gateway 与 HTML 清洗 | 标准阅读模型、安全测试 |
| GW-02 | 图片代理、内部链接和离线缓存 | 缓存策略、异常状态 |
| SRC-01 | Local 适配器与 `.kbignore` | 目录注册和增量索引 |
| SRC-02 | Git 适配器 | 工作树/托管缓存、revision 绑定 |
| SRC-03 | SVN 适配器 | Working Copy/托管缓存、revision 绑定 |
| REC-01 | 多来源分数归一和去重 | Recall V4 契约、回归报告 |
| MCP-01 | MCP Server Tools/Resources | Server、配置示例、Inspector 结果 |
| UI-01 | 树、搜索、筛选与结果卡片 | VSCode TreeView/Webview |
| UI-02 | 快速预览与完整阅读器 | Reader、标签、TOC、历史 |
| UI-03 | 来源、入库、我的视图 | 完整用户旅程 |
| BRG-01 | `kb bridge --stdio` 与取消/进度 | JSON-RPC 契约和压力测试 |
| QA-01 | 自动化、视觉、安全、性能测试 | 测试报告和缺陷清单 |
| REL-01 | ZIP/VSIX、升级和回滚 | 可复现发布物与 SHA-256 |

---

## 11. 测试与验收方案

### 11.1 自动化测试

1. **回归测试**：V1.0.8 的 82 个测试必须 100% 通过；
2. **契约测试**：所有 Schema 的正常、缺字段、未知字段和版本升级场景；
3. **适配器测试**：BookStack/Git/SVN/Local 使用固定 Fixture，覆盖分页、空目录、重命名、删除和网络失败；
4. **召回测试**：扩展现有 `recall-testset.md`，按来源、芯片、平台和重复文档统计 Top-K 命中；
5. **MCP 测试**：官方 MCP Inspector 校验工具列表、Schema、Resources、错误和取消；
6. **VSCode 集成测试**：命令、TreeView、Webview 消息、URI Handler、Workspace Trust；
7. **安全测试**：XSS、路径穿越、符号链接逃逸、恶意 Markdown、凭据泄漏、外链加载；
8. **安装测试**：retrieval/full/full+MCP、依赖齐全/缺失/版本错误、升级和回滚；
9. **性能测试**：700/2,000 BookStack 页面，1,000/10,000 来源文件，冷缓存/热缓存；
10. **恢复测试**：BookStack/RAGFlow/Governance/Git/SVN 单独离线时的降级表现。

### 11.2 视觉验收矩阵

| 维度 | 必测组合 |
|---|---|
| 主题 | Light、Dark、High Contrast |
| 尺寸 | 窄侧栏、标准宽度、宽屏编辑器 |
| 缩放 | 100%、125%、150%、200% |
| 内容 | 短文、超长文、长代码、宽表格、多图片、中英混排 |
| 状态 | 加载、空、失败、离线、缓存、权限不足 |
| 操作 | 鼠标、纯键盘、前进后退、多个阅读标签 |

视觉问题按功能缺陷管理：正文不可读、元素溢出、主题对比度不足、焦点丢失均属于阻断或严重缺陷。

### 11.3 端到端验收旅程

正式发布前至少完整走通：

1. 新用户安装 retrieval → 首次向导 → 搜索 → 目录树 → 插件内阅读；
2. 安装 full 且六依赖齐全 → DOCX/PDF 分析 → 预览 → 提交 → 树中定位 → 回读；
3. full 缺少任一依赖 → 安装前退出 20 → 不产生半安装状态；
4. 注册本地目录 → 首次索引 → 修改 1 个文件 → 增量同步 → 召回命中；
5. 注册 Git/SVN → 指定 revision → 同步 → 召回 → 查看来源版本；
6. CodeBuddy/Skill 召回 → `viewer_uri` → VSCode 插件打开正文；
7. MCP `kb_recall` → `kb_content_get` → 内容和引用一致；
8. BookStack 离线 → 展示缓存正文与明确状态 → 恢复后刷新；
9. 用户资料缺失 → 写入被阻止 → 设置资料 → 同一操作成功；
10. Governance Cookie 失效 → 目录树和正文正常，治理状态显示未知。

---

## 12. 风险与处置

| 风险 | 概率/影响 | 处置 |
|---|---|---|
| BookStack 页面量增加导致树卡顿 | 中/高 | 懒加载、分页、差量缓存；以 2,000 页作为强制压测门槛 |
| BookStack API 返回 HTML 不可信 | 中/高 | Extension Host 清洗、严格 CSP、禁脚本、图片代理、安全 Fixture |
| Governance Cookie 频繁过期 | 高/中 | 浏览/阅读不依赖 Governance；仅状态能力降级 |
| Git/SVN 凭据复杂 | 中/中 | 复用系统 Credential/SSH Agent；不自行保存密码；提供诊断信息 |
| 来源包含敏感代码或凭据 | 中/高 | 显式白名单、默认只选文档、`.kbignore`、敏感文件规则、无自动上传 |
| 多来源分数不可比 | 高/中 | 分来源归一、显式命中特征、离线测试集、结果解释 |
| 本地 profile 可伪造 | 中/中 | 明确它是可追踪而非强认证；后续迁移到每人 Token/SSO |
| MCP Host/SDK 版本变化 | 中/中 | 官方 SDK、协议层薄适配、独立 feature gate、CLI 保底 |
| VSCode Webview 迭代成本高 | 中/高 | P0 先做原型；组件化；契约冻结后开发；视觉回归 |
| 功能继续膨胀到开发工作台 | 高/高 | 非目标清单进入 PR/需求评审模板，新增功能必须证明是知识域 |
| 第三方转换依赖缺失 | 中/高 | full 安装前强检查并退出 20；不半安装、不自动下载 |

---

## 13. 升级、回滚与数据保护

### 13.1 从 V1.0.8 升级

1. 执行只读预检和依赖检查；
2. 备份当前技能、命令、配置和缓存索引；
3. 安装 Core/Skills；
4. 迁移配置但保留现有 `.env` 值；
5. 初次启动创建空的 Profile/Source Schema，不自动扫描目录；
6. 安装 VSIX；
7. 运行本地 doctor、插件自检和可选 live probe；
8. 只有用户确认后才注册来源或创建个人资料。

### 13.2 回滚原则

- 程序、配置和索引分开备份；
- `profile.json`、`sources.yaml` 和贡献审计采用向前兼容格式，不因程序回滚而删除；
- 本地索引可安全重建，不作为唯一事实来源；
- 安装失败自动恢复 V1.0.8 的 Skill 和命令；
- VSIX 可独立降级，Core 的 JSON 契约至少保留一个小版本兼容；
- 回滚脚本不删除用户收藏、历史和来源配置，除非用户明确要求。

---

## 14. 发布完成定义（Definition of Done）

V1.1.0 同时满足以下条件才可正式发布：

- 范围内功能全部完成，非目标功能没有混入；
- BookStack 树、快速预览和完整阅读器达到性能与视觉指标；
- Local/Git/SVN 三类来源真实环境验收通过；
- Skill、CLI、MCP、插件使用同一 `content_ref` 和 Recall 契约；
- 首次用户资料和所有写入守卫生效，贡献可追踪；
- full 六项转换依赖只检查、不打包、不自动安装，缺失退出 20；
- V1.0.8 既有测试与新增测试全部通过；
- 无已知严重 XSS、路径穿越、凭据泄漏或破坏性同步问题；
- Light/Dark/High Contrast 和长文档场景通过视觉验收；
- ZIP、VSIX、SHA-256、安装/升级/回滚文档齐全；
- 使用干净环境可复现构建和安装；
- 至少 2 名真实用户完成一周试用，阻断问题清零。

---

## 15. 建议立即启动的下一步

建议下一阶段只启动 **P0 + P1**，先不要同时铺开所有模块：

1. 冻结六个核心 Schema：Profile、Source、Content、Tree、Recall、Audit；
2. 制作 VSCode 插件 Light/Dark 可点击 HTML 原型；
3. 用当前真实 BookStack 数据验证 700 页目录树的懒加载方案；
4. 在 V1.0.8 上落地 Profile、写入守卫和兼容迁移，发布 V1.0.9；
5. 原型和契约评审通过后，再并行开发 Content Gateway、Source Hub 和插件。

第一个可演示里程碑应当是：**用户在 VSCode 中展开 BookStack 目录树，点击任意页面，在插件内以美观、可搜索、可前进后退的方式阅读；Skill 召回结果也能打开同一个阅读器。** 这个里程碑最直接体现项目价值，也能最早验证后续 MCP、Git/SVN 和入库中心所依赖的核心契约是否正确。

---

## 16. 技术依据

- [Model Context Protocol 架构](https://modelcontextprotocol.io/docs/learn/architecture)
- [CodeBuddy MCP 配置说明](https://cloud.tencent.com/document/product/1831/137039)
- [VSCode MCP Extension Guide](https://code.visualstudio.com/api/extension-guides/ai/mcp)
- [VSCode Webview Guide](https://code.visualstudio.com/api/extension-guides/webview)
- [VSCode Tree View Guide](https://code.visualstudio.com/api/extension-guides/tree-view)
- [VSCode Workspace Trust](https://code.visualstudio.com/api/extension-guides/workspace-trust)
- [VSCode API：URI Handler 等](https://code.visualstudio.com/api/references/vscode-api)


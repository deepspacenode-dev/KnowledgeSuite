#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
import urllib.request
from typing import Any


ALLOWED_PATHS = {"/chats/widget", "/next-chats/widget"}


def redact_url(value: str) -> str:
    parsed = urllib.parse.urlsplit(value)
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    redacted = [(key, "[REDACTED]" if key.lower() in {"auth", "token", "api_key"} else item) for key, item in query]
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urllib.parse.urlencode(redacted), ""))


def validate_widget_url(value: str) -> dict[str, Any]:
    try:
        parsed = urllib.parse.urlsplit(value.strip())
        errors: list[str] = []
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            errors.append("Widget 必须使用绝对 HTTP/HTTPS 地址。")
        if parsed.username or parsed.password:
            errors.append("Widget 地址不能包含用户名或密码。")
        if parsed.fragment:
            errors.append("Widget 地址不能包含 URL 片段。")
        if parsed.path not in ALLOWED_PATHS:
            errors.append("Widget 路径必须是 /chats/widget 或 /next-chats/widget。")
        query = dict(urllib.parse.parse_qsl(parsed.query, keep_blank_values=True))
        for key in ("shared_id", "auth"):
            if not query.get(key):
                errors.append(f"Widget 缺少 {key}。")
        if query.get("mode") not in {None, "", "window"}:
            errors.append("Widget 必须使用 mode=window。")
        if query.get("from") not in {None, "", "chat"}:
            errors.append("Widget 必须使用 from=chat。")
        origin = f"{parsed.scheme}://{parsed.hostname}{f':{parsed.port}' if parsed.port else ''}" if parsed.hostname else ""
        return {"ok": not errors, "errors": errors, "origin": origin, "path": parsed.path, "url": redact_url(value)}
    except (TypeError, ValueError) as error:
        return {"ok": False, "errors": [str(error)], "origin": "", "path": "", "url": ""}


def build_from_environment() -> str:
    base = (os.environ.get("RAGFLOW_WIDGET_BASE_URL") or "").strip().rstrip("/")
    path = "/" + (os.environ.get("RAGFLOW_WIDGET_PATH") or "/chats/widget").strip().lstrip("/")
    query = urllib.parse.urlencode({
        "shared_id": os.environ.get("RAGFLOW_WIDGET_SHARED_ID", ""),
        "auth": os.environ.get("RAGFLOW_WIDGET_AUTH", ""),
        "from": "chat",
        "mode": "window",
    })
    return f"{base}{path}?{query}"


def live_probe(url: str, timeout: int = 15) -> dict[str, Any]:
    request = urllib.request.Request(url, method="GET", headers={"User-Agent": "DrvKnowledgeSuite-Widget-Probe/2.0.3"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        final_url = response.geturl()
        headers = response.headers
        status = response.status
    source = urllib.parse.urlsplit(url)
    target = urllib.parse.urlsplit(final_url)
    source_origin = (source.scheme, source.hostname, source.port or (443 if source.scheme == "https" else 80))
    target_origin = (target.scheme, target.hostname, target.port or (443 if target.scheme == "https" else 80))
    x_frame = (headers.get("X-Frame-Options") or "").strip()
    csp = (headers.get("Content-Security-Policy") or "").strip()
    denied = x_frame.lower() == "deny" or "frame-ancestors 'none'" in csp.lower()
    return {
        "http_status": status,
        "final_url": redact_url(final_url),
        "same_origin_redirect": source_origin == target_origin,
        "x_frame_options": x_frame,
        "content_security_policy": csp,
        "framing_denied": denied,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate the RAGFlow official Widget configuration.")
    parser.add_argument("--url")
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--timeout", type=int, default=15)
    args = parser.parse_args(argv)
    try:
        url = args.url or build_from_environment()
        result = {"syntax": validate_widget_url(url)}
        if not result["syntax"]["ok"]:
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 2
        if args.live:
            result["live"] = live_probe(url, max(1, args.timeout))
            if not result["live"]["same_origin_redirect"] or result["live"]["framing_denied"]:
                print(json.dumps(result, ensure_ascii=False, indent=2))
                return 3
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as error:
        print(json.dumps({"status": "error", "message": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 4


if __name__ == "__main__":
    raise SystemExit(main())

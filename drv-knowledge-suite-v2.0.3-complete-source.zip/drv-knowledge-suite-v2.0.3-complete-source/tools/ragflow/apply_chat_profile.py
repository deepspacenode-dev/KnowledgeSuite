#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_PROFILE = ROOT / "contracts" / "ragflow" / "chat-assistant.v2.json"
PROFILE_FIELDS = (
    "name",
    "description",
    "dataset_ids",
    "llm_setting",
    "prompt_config",
    "similarity_threshold",
    "vector_similarity_weight",
    "top_n",
    "top_k",
    "rerank_candidates_count",
    "rerank_id",
)
Transport = Callable[[str, str, str, Any, int], dict[str, Any]]


def redact(message: str, secrets: list[str]) -> str:
    result = str(message)
    for secret in sorted({item for item in secrets if item}, key=len, reverse=True):
        result = result.replace(secret, "[REDACTED]")
    return result


def validate_base_url(value: str) -> str:
    parsed = urllib.parse.urlsplit(value.strip())
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("RAGFlow 地址必须是 HTTP/HTTPS 主机根地址。")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("RAGFlow 地址不能包含凭据、查询参数或片段。")
    path = parsed.path.rstrip("/")
    if path not in {"", "/"}:
        raise ValueError("RAGFlow 地址不要追加 API 路径。")
    port = f":{parsed.port}" if parsed.port else ""
    return f"{parsed.scheme}://{parsed.hostname}{port}"


def load_profile(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or not isinstance(payload.get("prompt_config"), dict):
        raise ValueError("Chat Profile 格式无效。")
    if "{knowledge}" not in str(payload["prompt_config"].get("system", "")):
        raise ValueError("Chat Profile 必须包含 {knowledge}。")
    return {key: payload[key] for key in PROFILE_FIELDS if key in payload}


def compute_patch(current: dict[str, Any], desired: dict[str, Any]) -> dict[str, Any]:
    return {key: desired[key] for key in PROFILE_FIELDS if key in desired and current.get(key) != desired[key]}


def _value_summary(value: Any) -> Any:
    if isinstance(value, dict):
        encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return {"keys": sorted(value), "sha256": hashlib.sha256(encoded.encode("utf-8")).hexdigest()}
    if isinstance(value, list):
        return {"count": len(value), "sha256": hashlib.sha256(json.dumps(value, sort_keys=True).encode("utf-8")).hexdigest()}
    return value


def secret_free_diff(current: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    return {
        key: {"before": _value_summary(current.get(key)), "after": _value_summary(value)}
        for key, value in patch.items()
    }


def request_json(method: str, url: str, key: str, payload: Any = None, timeout: int = 30) -> dict[str, Any]:
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={"Accept": "application/json", "Content-Type": "application/json", "Authorization": f"Bearer {key}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read().decode("utf-8")
    except urllib.error.HTTPError as error:
        body = error.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"RAGFlow HTTP {error.code}: {body[:300]}") from error
    return json.loads(body or "{}")


def _assert_success(payload: dict[str, Any]) -> None:
    if payload.get("code", 0) not in (0, None):
        raise RuntimeError(f"RAGFlow API code={payload.get('code')}: {payload.get('message', '')}")


def apply_profile(
    base_url: str,
    api_key: str,
    chat_id: str,
    desired: dict[str, Any],
    *,
    apply: bool,
    transport: Transport = request_json,
    timeout: int = 30,
) -> dict[str, Any]:
    base = validate_base_url(base_url)
    if not api_key or not chat_id:
        raise ValueError("RAGFLOW_CHAT_API_KEY/RAGFLOW_API_KEY 与 RAGFLOW_CHAT_ID 必须配置。")
    endpoint = f"{base}/api/v1/chats/{urllib.parse.quote(chat_id, safe='')}"
    current_payload = transport("GET", endpoint, api_key, None, timeout)
    _assert_success(current_payload)
    current = current_payload.get("data")
    if not isinstance(current, dict):
        raise RuntimeError("RAGFlow Chat 查询响应格式不兼容。")
    patch = compute_patch(current, desired)
    result = {"chat_id": chat_id, "changed_fields": sorted(patch), "diff": secret_free_diff(current, patch)}
    if not patch:
        return {**result, "status": "unchanged"}
    if not apply:
        return {**result, "status": "dry_run"}
    updated = transport("PUT", endpoint, api_key, patch, timeout)
    _assert_success(updated)
    return {**result, "status": "applied"}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Inspect or apply the versioned RAGFlow Chat profile.")
    parser.add_argument("--profile", type=Path, default=DEFAULT_PROFILE)
    parser.add_argument("--rollback-profile", type=Path)
    parser.add_argument("--base-url")
    parser.add_argument("--chat-id")
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    secrets: list[str] = []
    try:
        profile_path = args.rollback_profile or args.profile
        desired = load_profile(profile_path)
        base_url = args.base_url or os.environ.get("RAGFLOW_CHAT_BASE_URL") or os.environ.get("RAGFLOW_BASE_URL", "")
        api_key = os.environ.get("RAGFLOW_CHAT_API_KEY") or os.environ.get("RAGFLOW_API_KEY", "")
        chat_id = args.chat_id or os.environ.get("RAGFLOW_CHAT_ID", "")
        secrets.append(api_key)
        result = apply_profile(base_url, api_key, chat_id, desired, apply=args.apply and not args.dry_run, timeout=max(1, args.timeout))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as error:
        print(json.dumps({"status": "error", "message": redact(str(error), secrets)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

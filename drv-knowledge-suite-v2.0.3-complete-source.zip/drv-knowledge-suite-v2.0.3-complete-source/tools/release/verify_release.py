#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import ipaddress
from pathlib import Path
from urllib.parse import urlparse


ROOT = Path(__file__).resolve().parents[2]
POLICY = json.loads((ROOT / "policies" / "release-security.json").read_text(encoding="utf-8"))
TEXT_SUFFIXES = {".py", ".php", ".js", ".mjs", ".json", ".yaml", ".yml", ".toml", ".md", ".sh", ".ps1", ".html", ".css", ".txt", ".example"}
SKIP_PARTS = {".git", ".worktrees", "dist", "wheelhouse", "__pycache__", ".firecrawl"}
SECRET_PATTERNS = [
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(r"ragflow-[A-Za-z0-9]{24,}", re.I),
    re.compile(r"(?i)(?:password|token_secret|api_key)\s*[:=]\s*['\"][A-Za-z0-9._!@#$%^&*+-]{12,}['\"]"),
]
ENV_SECRET_RE = re.compile(r"(?im)^[ \t]*(?:[A-Z0-9_]*(?:PASSWORD|TOKEN_SECRET|API_KEY))[ \t]*=[ \t]*([^\r\n#]*)$")
URL_RE = re.compile(r"https?://[^\s'\"<>]+")


def release_files() -> list[Path]:
    roots = [ROOT / "components", ROOT / "contracts", ROOT / "deploy", ROOT / "docs", ROOT / "policies", ROOT / "tools", ROOT / "tests", ROOT / "baselines"]
    files = []
    for base in roots:
        if not base.exists():
            continue
        for path in base.rglob("*"):
            relative = path.relative_to(ROOT)
            root_vendor = relative.parts[:3] == ("components", "governance", "vendor")
            ragflow_vendor = relative.parts[:2] == ("deploy", "vendor") and relative.as_posix() != "deploy/vendor/README.md"
            if path.is_file() and not any(part in SKIP_PARTS for part in relative.parts) and not root_vendor and not ragflow_vendor:
                files.append(path)
    return sorted(files)


def scan_forbidden_paths(files: list[Path]) -> list[str]:
    findings = []
    forbidden = set(POLICY.get("forbidden_release_paths", []))
    for path in files:
        relative = path.relative_to(ROOT)
        for item in forbidden:
            if relative.name == item or item in relative.parts:
                findings.append(f"{relative}: forbidden release path {item}")
                break
    return findings


def scan_secrets(files: list[Path]) -> list[str]:
    findings = []
    for path in files:
        if path.suffix.lower() not in TEXT_SUFFIXES and path.name != ".env.example":
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for pattern in SECRET_PATTERNS:
            if pattern.search(text):
                findings.append(f"{path.relative_to(ROOT)}: matches {pattern.pattern}")
        if path.name.endswith(".example"):
            for match in ENV_SECRET_RE.finditer(text):
                value = match.group(1).strip("'\"")
                if value and not any(token in value.lower() for token in ("replace", "change", "example", "<", "${")):
                    findings.append(f"{path.relative_to(ROOT)}: example contains a non-placeholder secret value")
    return findings


def scan_external_runtime_urls(files: list[Path]) -> list[str]:
    findings = []
    allowed = tuple(POLICY["allowed_runtime_origins"])
    for path in files:
        relative = path.relative_to(ROOT)
        if "tests" in relative.parts:
            continue
        if path.suffix.lower() not in {".py", ".php", ".js", ".mjs", ".html", ".yaml", ".yml", ".example"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for url in URL_RE.findall(text):
            clean = url.rstrip("),.;")
            if clean.startswith(allowed) or clean.startswith((
                "http://json-schema.org",
                "https://json-schema.org",
                "http://www.w3.org/2000/svg",
                "http://www.w3.org/1999/xlink",
            )):
                continue
            parsed = urlparse(clean)
            host = parsed.hostname or ""
            if host.endswith(".internal") or (host and "." not in host):
                continue
            try:
                if ipaddress.ip_address(host).is_private:
                    continue
            except ValueError:
                pass
            if "github.com" in clean or "opencontainers.org" in clean:
                continue
            findings.append(f"{relative}: external runtime URL {clean}")
    return findings


def scan_images(files: list[Path]) -> list[str]:
    findings = []
    for path in files:
        if path.name not in {"Dockerfile", "compose.yaml", "compose.full-stack.yaml"} and path.suffix.lower() not in {".yaml", ".yml"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if re.search(r"(?m)^\s*(?:FROM|image:)\s+\S+:latest(?:\s|$)", text):
            findings.append(f"{path.relative_to(ROOT)}: latest image tag is forbidden")
    return findings


def build_sbom(files: list[Path]) -> dict:
    entries = []
    for path in files:
        raw = path.read_bytes()
        entries.append({
            "path": str(path.relative_to(ROOT)).replace("\\", "/"),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
        })
    version = (ROOT / "components" / "skills" / "VERSION").read_text(encoding="utf-8").strip()
    return {"spdxVersion": "SPDX-2.3", "name": f"drv-knowledge-suite-{version}", "files": entries}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sbom", type=Path)
    args = parser.parse_args()
    files = release_files()
    findings = scan_forbidden_paths(files) + scan_secrets(files) + scan_external_runtime_urls(files) + scan_images(files)
    if args.sbom:
        args.sbom.parent.mkdir(parents=True, exist_ok=True)
        args.sbom.write_text(json.dumps(build_sbom(files), ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    if findings:
        print("RELEASE VERIFICATION FAILED")
        print("\n".join(findings))
        return 2
    print(f"RELEASE VERIFICATION PASSED: {len(files)} files")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

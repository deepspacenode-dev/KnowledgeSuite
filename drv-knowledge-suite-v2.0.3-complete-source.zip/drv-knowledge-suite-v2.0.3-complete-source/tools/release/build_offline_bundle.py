#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import stat
import subprocess
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DIST = ROOT / "dist"
SUITE_VERSION = "2.0.3"
SKILLS_VERSION = (ROOT / "components" / "skills" / "VERSION").read_text(encoding="utf-8").strip()
ZIP_DATE_TIME = (1980, 1, 1, 0, 0, 0)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def add_file(archive: zipfile.ZipFile, path: Path, archive_name: str) -> None:
    info = zipfile.ZipInfo(archive_name, date_time=ZIP_DATE_TIME)
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    info.compress_type = zipfile.ZIP_STORED
    info.file_size = path.stat().st_size
    with path.open("rb") as source, archive.open(info, "w") as target:
        shutil.copyfileobj(source, target, length=1024 * 1024)


def add_bytes(archive: zipfile.ZipFile, content: bytes, archive_name: str) -> None:
    info = zipfile.ZipInfo(archive_name, date_time=ZIP_DATE_TIME)
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    info.compress_type = zipfile.ZIP_STORED
    archive.writestr(info, content)


def create_source_archive(release_label: str, revision: str, dist: Path) -> Path:
    target = dist / f"drv-knowledge-suite-v{release_label}-source.zip"
    subprocess.run(
        [
            "git",
            "archive",
            "--format=zip",
            f"--prefix=drv-knowledge-suite-v{release_label}-source/",
            "-o",
            str(target),
            revision,
        ],
        cwd=ROOT,
        check=True,
    )
    return target


def build_bundle(
    *,
    release_label: str,
    source_revision: str,
    dist: Path,
    worker_oci: Path,
    bookstack_oci: Path,
    fake_ragflow_oci: Path,
    source_archive: Path,
    documentation: list[tuple[Path, str]],
    supplements: list[tuple[Path, str]] | None = None,
) -> Path:
    required = [
        dist / f"drv-knowledge-skills-v{SKILLS_VERSION}.zip",
        dist / f"drv-knowledge-governance-v{SUITE_VERSION}.zip",
        dist / f"drv-knowledge-contracts-v{SUITE_VERSION}.zip",
        dist / f"drv-knowledge-suite-v{SUITE_VERSION}.spdx.json",
        worker_oci,
        bookstack_oci,
        fake_ragflow_oci,
        source_archive,
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing release artifacts:\n" + "\n".join(missing))

    root_name = f"drv-knowledge-suite-v{release_label}"
    target = dist / f"{root_name}-offline-bundle.zip"
    payloads: list[tuple[Path, str]] = [(path, path.name) for path in required]
    payloads.extend(documentation)
    payloads.extend(supplements or [])

    seen: set[str] = set()
    records: dict[str, dict[str, int | str]] = {}
    for path, archive_name in payloads:
        if not path.is_file():
            raise FileNotFoundError(path)
        normalized = archive_name.replace("\\", "/").lstrip("/")
        if normalized in seen:
            raise ValueError(f"Duplicate bundle path: {normalized}")
        seen.add(normalized)
        records[normalized] = {"sha256": sha256(path), "size": path.stat().st_size}

    manifest = {
        "release_label": release_label,
        "suite_version": SUITE_VERSION,
        "source_revision": source_revision,
        "component_versions": {
            "skills": SKILLS_VERSION,
            "worker": SUITE_VERSION,
            "governance": SUITE_VERSION,
            "contracts": SUITE_VERSION,
            "fake_ragflow": SUITE_VERSION,
        },
        "deployment_profiles": ["external-ragflow", "full-stack"],
        "files": records,
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    checksums_bytes = "".join(
        f"{record['sha256']}  {name}\n" for name, record in sorted(records.items())
    ).encode("utf-8")
    readme_bytes = (
        f"# Drv Knowledge Suite {release_label} offline bundle\n\n"
        "This archive binds the independently deployable Skills/Worker and BookStack Governance planes.\n\n"
        "1. Verify `SHA256SUMS.txt` before importing any artifact.\n"
        "2. Read `docs/DEPLOYMENT_V2.md` and the cloud validation report.\n"
        "3. Import the OCI files with `deploy/scripts/import-oci.sh . SHA256SUMS.txt`.\n"
        "4. Copy `deploy/.env.example` to `.env`; change only environment configuration, secrets, certificates, RAGFlow address, and dataset mapping.\n"
        "5. Back up MariaDB and BookStack `/config` before switching the immutable BookStack image. Existing articles are not initialized or overwritten by the overlay.\n\n"
        "The `extras/` directory contains the verified five-manual RAGFlow cleaning package (A2/A3/A5/E2/M3), including the sanitizer, audit records and upload-ready Markdown parts.\n\n"
        f"Source revision: `{source_revision}`\n"
    ).encode("utf-8")

    with zipfile.ZipFile(target, "w", allowZip64=True) as archive:
        prefix = root_name + "/"
        for path, archive_name in payloads:
            add_file(archive, path, prefix + archive_name.replace("\\", "/").lstrip("/"))
        add_bytes(archive, manifest_bytes, prefix + "RELEASE-MANIFEST.json")
        add_bytes(archive, checksums_bytes, prefix + "SHA256SUMS.txt")
        add_bytes(archive, readme_bytes, prefix + "README.md")

    digest = sha256(target)
    target.with_suffix(target.suffix + ".sha256").write_text(
        f"{digest}  {target.name}\n", encoding="utf-8", newline="\n"
    )
    return target


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the complete offline Drv Knowledge Suite bundle")
    parser.add_argument("--release-label", default=SUITE_VERSION)
    parser.add_argument("--revision", default="HEAD")
    parser.add_argument("--worker-oci", type=Path, required=True)
    parser.add_argument("--bookstack-oci", type=Path, required=True)
    parser.add_argument("--fake-ragflow-oci", type=Path, required=True)
    parser.add_argument("--cleaned-manuals", type=Path, required=True)
    args = parser.parse_args()

    DIST.mkdir(parents=True, exist_ok=True)
    source_revision = subprocess.check_output(
        ["git", "rev-parse", args.revision], cwd=ROOT, text=True
    ).strip()
    source_archive = create_source_archive(args.release_label, args.revision, DIST)
    documentation = [
        (ROOT / "docs" / "DEPLOYMENT_V2.md", "docs/DEPLOYMENT_V2.md"),
        (ROOT / "docs" / "RAGFLOW_V027_P0_DEPLOYMENT.md", "docs/RAGFLOW_V027_P0_DEPLOYMENT.md"),
        (ROOT / "docs" / "COMPATIBILITY_MATRIX.md", "docs/COMPATIBILITY_MATRIX.md"),
        (ROOT / "docs" / "ACCEPTANCE_CHECKLIST_V2.md", "docs/ACCEPTANCE_CHECKLIST_V2.md"),
        (
            ROOT / "docs" / "CLOUD_INTRANET_SIMULATION_REPORT_2026-08-31.md",
            "docs/CLOUD_INTRANET_SIMULATION_REPORT_2026-08-31.md",
        ),
        (
            ROOT / "docs" / "P0_CLOUD_ACCEPTANCE_V2.0.2_20260904.md",
            "docs/P0_CLOUD_ACCEPTANCE_V2.0.2_20260904.md",
        ),
        (
            ROOT / "docs" / "COMPLETE_DELIVERY_V2.0.2_20260904.md",
            "docs/COMPLETE_DELIVERY_V2.0.2_20260904.md",
        ),
        (ROOT / "docs" / "V2.0.3_DEPLOYMENT_AND_ACCEPTANCE.md", "docs/V2.0.3_DEPLOYMENT_AND_ACCEPTANCE.md"),
        (ROOT / "docs" / "V2.0.3_CHANGELOG.md", "docs/V2.0.3_CHANGELOG.md"),
        (ROOT / "components" / "governance" / "DEPLOY.md", "docs/GOVERNANCE_DEPLOY.md"),
        (ROOT / "deploy" / "compose.yaml", "deploy/compose.yaml"),
        (ROOT / "deploy" / "compose.full-stack.yaml", "deploy/compose.full-stack.yaml"),
        (ROOT / "deploy" / ".env.example", "deploy/.env.example"),
        (ROOT / "deploy" / "scripts" / "import-oci.sh", "deploy/scripts/import-oci.sh"),
        (ROOT / "deploy" / "scripts" / "backup.sh", "deploy/scripts/backup.sh"),
        (ROOT / "deploy" / "scripts" / "upgrade.sh", "deploy/scripts/upgrade.sh"),
        (ROOT / "deploy" / "scripts" / "rollback.sh", "deploy/scripts/rollback.sh"),
        (ROOT / "deploy" / "scripts" / "smoke.sh", "deploy/scripts/smoke.sh"),
    ]
    target = build_bundle(
        release_label=args.release_label,
        source_revision=source_revision,
        dist=DIST,
        worker_oci=args.worker_oci.resolve(),
        bookstack_oci=args.bookstack_oci.resolve(),
        fake_ragflow_oci=args.fake_ragflow_oci.resolve(),
        source_archive=source_archive,
        documentation=documentation,
        supplements=[(args.cleaned_manuals.resolve(), f"extras/{args.cleaned_manuals.name}")],
    )
    print(json.dumps({"bundle": str(target), "sha256": sha256(target)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import stat
import subprocess
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
VERSION = "2.0.3"
SKILLS_VERSION = (ROOT / "components/skills/VERSION").read_text(encoding="utf-8").strip()
DIST = ROOT / "dist"
WHEELHOUSE = ROOT / "wheelhouse"
FORBIDDEN_RELEASE_PARTS = {".git", "__pycache__", "backups", "local-private", "runtime", "secrets"}
FORBIDDEN_RELEASE_NAMES = {"BookStack_RAGFlow_部署经验.txt", "config/site.env"}
REPRODUCIBLE_ZIP_DATE_TIME = (1980, 1, 1, 0, 0, 0)


def is_forbidden_release_file(relative: Path) -> bool:
    normalized = relative.as_posix()
    if normalized in FORBIDDEN_RELEASE_NAMES or any(part in FORBIDDEN_RELEASE_PARTS for part in relative.parts):
        return True
    if relative.name == ".env" or (relative.name.startswith(".env.") and relative.name != ".env.example"):
        return True
    return relative.suffix.lower() in {".key", ".pem", ".pyc"}


def add_tree(archive: zipfile.ZipFile, base: Path, prefix: str, exclude: tuple[str, ...] = ()) -> None:
    for path in sorted(base.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(base)
        normalized = str(relative).replace("\\", "/")
        if is_forbidden_release_file(relative):
            continue
        if any(normalized == item or normalized.startswith(item.rstrip("/") + "/") for item in exclude):
            continue
        archive_name = f"{prefix}/{normalized}"
        info = zipfile.ZipInfo(archive_name, date_time=REPRODUCIBLE_ZIP_DATE_TIME)
        info.create_system = 3
        executable = path.suffix == ".sh"
        if not executable:
            with path.open("rb") as source:
                executable = source.read(2) == b"#!"
        permissions = 0o755 if executable else 0o644
        info.external_attr = (stat.S_IFREG | permissions) << 16
        info.compress_type = archive.compression
        with path.open("rb") as source, archive.open(info, "w") as target:
            shutil.copyfileobj(source, target)


def build_zip(name: str, selections: list[tuple[Path, str, tuple[str, ...]]]) -> Path:
    target = DIST / name
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for base, prefix, exclude in selections:
            add_tree(archive, base, prefix, exclude)
    return target


def write_skills_manifest() -> int:
    component = ROOT / "components/skills"
    files = []
    for path in component.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(component)
        if path.name in {"PACKAGE_MANIFEST.txt", ".env", ".DS_Store"}:
            continue
        if "__pycache__" in relative.parts or path.suffix in {".pyc", ".zip", ".sha256", ".asc"}:
            continue
        if relative.as_posix() == "config/site.env":
            continue
        if relative.parts and relative.parts[0] == "worker":
            continue
        if relative.parts and relative.parts[0] == "manuals" and path.name not in {"README.md", ".gitkeep"}:
            continue
        files.append(path)
    files.sort(key=lambda item: item.relative_to(component).as_posix())
    lines = [
        f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(component).as_posix()}"
        for path in files
    ]
    (component / "PACKAGE_MANIFEST.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return len(files)


def write_governance_manifest() -> int:
    component = ROOT / "components/governance"
    excluded = {"backups", "vendor", ".superpowers", ".git"}
    files = []
    for path in component.rglob("*"):
        if not path.is_file() or path.name == "SHA256SUMS.json":
            continue
        relative = path.relative_to(component)
        if relative.parts and relative.parts[0] in excluded:
            continue
        files.append(path)
    files.sort(key=lambda item: item.relative_to(component).as_posix())
    hashes = {
        path.relative_to(component).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in files
    }
    (component / "SHA256SUMS.json").write_text(json.dumps(hashes, indent=2) + "\n", encoding="utf-8", newline="\n")
    return len(files)


def require_wheelhouse() -> None:
    manifests = list(WHEELHOUSE.rglob("SHA256SUMS.json")) if WHEELHOUSE.is_dir() else []
    if not manifests:
        raise SystemExit(
            "hashed offline wheelhouse is missing; run tools/release/build_wheelhouse.py for each target platform"
        )
    for manifest in manifests:
        try:
            expected = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise SystemExit(f"invalid wheelhouse manifest {manifest}: {exc}") from exc
        if not isinstance(expected, dict) or "WHEELHOUSE.json" not in expected:
            raise SystemExit(f"wheelhouse manifest is incomplete: {manifest}")
        for name, digest in expected.items():
            wheel_file = manifest.parent / name
            if not wheel_file.is_file():
                raise SystemExit(f"wheelhouse file is missing: {wheel_file}")
            actual = hashlib.sha256(wheel_file.read_bytes()).hexdigest()
            if actual != digest:
                raise SystemExit(f"wheelhouse checksum mismatch: {wheel_file}")


def docker_artifact(image: str, dockerfile: Path, context: Path, output_name: str) -> Path | None:
    if shutil.which("docker") is None or shutil.which("zstd") is None:
        return None
    subprocess.run(["docker", "build", "-f", str(dockerfile), "-t", image, str(context)], check=True)
    tar_path = DIST / output_name.removesuffix(".zst")
    with tar_path.open("wb") as stream:
        subprocess.run(["docker", "save", image], stdout=stream, check=True)
    subprocess.run(["zstd", "-19", "--rm", str(tar_path), "-o", str(DIST / output_name)], check=True)
    return DIST / output_name


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-only", action="store_true")
    args = parser.parse_args()
    DIST.mkdir(parents=True, exist_ok=True)
    require_wheelhouse()
    write_skills_manifest()
    write_governance_manifest()
    sbom_path = DIST / f"drv-knowledge-suite-v{VERSION}.spdx.json"
    subprocess.run([sys.executable, str(ROOT / "tools/release/verify_release.py"), "--sbom", str(sbom_path)], check=True)
    source_prefix = f"drv-knowledge-suite-v{VERSION}-source"
    artifacts = [
        build_zip(f"drv-knowledge-skills-v{SKILLS_VERSION}.zip", [
            (ROOT / "components/skills", "drv-knowledge-skills", ("worker",)),
            (WHEELHOUSE, "drv-knowledge-skills/wheelhouse", ()),
        ]),
        build_zip(f"drv-knowledge-governance-v{VERSION}.zip", [(ROOT / "components/governance", "drv-knowledge-governance", ("backups", "vendor"))]),
        build_zip(f"drv-knowledge-contracts-v{VERSION}.zip", [(ROOT / "contracts", "drv-knowledge-contracts", ())]),
        build_zip(f"drv-knowledge-suite-v{VERSION}-source.zip", [
            (ROOT / "components", f"{source_prefix}/components", ("governance/vendor",)),
            (ROOT / "contracts", f"{source_prefix}/contracts", ()),
            (ROOT / "deploy", f"{source_prefix}/deploy", ("vendor",)),
            (ROOT / "docs", f"{source_prefix}/docs", ()),
            (ROOT / "policies", f"{source_prefix}/policies", ()),
            (ROOT / "tools", f"{source_prefix}/tools", ()),
            (ROOT / "tests", f"{source_prefix}/tests", ()),
            (ROOT / "baselines", f"{source_prefix}/baselines", ()),
        ]),
        sbom_path,
    ]
    if not args.source_only:
        for artifact in (
            docker_artifact(f"drvknowledge/worker:{VERSION}", ROOT / "components/skills/worker/Dockerfile", ROOT / "components/skills/worker", f"drv-knowledge-worker-v{VERSION}.oci.tar.zst"),
            docker_artifact(f"drvknowledge/bookstack-governance:{VERSION}", ROOT / "components/governance/docker/bookstack/Dockerfile", ROOT / "components/governance", f"drv-knowledge-bookstack-v{VERSION}.oci.tar.zst"),
        ):
            if artifact is not None:
                artifacts.append(artifact)
    checksums = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in artifacts}
    (DIST / "SHA256SUMS.json").write_text(json.dumps(checksums, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"version": VERSION, "component_versions": {"skills": SKILLS_VERSION, "worker": VERSION, "governance": VERSION, "contracts": VERSION}, "artifacts": [path.name for path in artifacts], "oci_skipped": args.source_only or shutil.which("docker") is None}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

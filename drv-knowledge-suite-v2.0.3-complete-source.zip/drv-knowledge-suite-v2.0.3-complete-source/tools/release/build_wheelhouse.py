#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def main() -> int:
    parser = argparse.ArgumentParser(description="Build and hash the full-profile offline wheelhouse")
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--output", type=Path, default=ROOT / "wheelhouse")
    parser.add_argument("--target-name", help="optional subdirectory name, for example linux-x86_64-cp312")
    parser.add_argument("--platform", action="append", help="repeatable pip target platform tag")
    parser.add_argument("--python-version", help="target Python version without a dot, for example 312")
    parser.add_argument("--implementation", default="cp", help="target Python implementation")
    parser.add_argument("--abi", help="target ABI, for example cp312")
    args = parser.parse_args()
    destination = args.output / args.target_name if args.target_name else args.output
    destination.mkdir(parents=True, exist_ok=True)
    requirements = ROOT / "components/skills/requirements/full.txt"
    command = [
        args.python,
        "-m",
        "pip",
        "download",
        "--only-binary=:all:",
        "--dest",
        str(destination),
        "-r",
        str(requirements),
    ]
    if args.platform:
        if not args.python_version or not args.abi:
            parser.error("--platform requires --python-version and --abi")
        for platform in args.platform:
            command.extend(["--platform", platform])
        command.extend([
            "--python-version", args.python_version,
            "--implementation", args.implementation,
            "--abi", args.abi,
        ])
    subprocess.run(command, check=True)
    metadata = {
        "schema_version": 1,
        "target_name": args.target_name or "native",
        "platforms": args.platform or ["native"],
        "python_version": args.python_version or f"{sys.version_info.major}{sys.version_info.minor}",
        "implementation": args.implementation,
        "abi": args.abi or "native",
        "requirements_sha256": hashlib.sha256(requirements.read_bytes()).hexdigest(),
    }
    (destination / "WHEELHOUSE.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8", newline="\n")
    manifest = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(destination.iterdir()) if path.is_file() and path.name != "SHA256SUMS.json"
    }
    (destination / "SHA256SUMS.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(f"wheelhouse ready: {destination} ({len(manifest)} file(s))")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

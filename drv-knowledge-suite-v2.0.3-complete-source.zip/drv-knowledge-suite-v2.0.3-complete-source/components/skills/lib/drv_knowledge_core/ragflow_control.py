"""Versioned RAGFlow ingestion/chat control plane used by the kb CLI."""
from __future__ import annotations

import hashlib
import json
import os
import urllib.parse
from pathlib import Path
from typing import Any

from .clients.http_json import request_json
from .runtime import dataset_map, load_dotenv


SKILLS_ROOT = Path(__file__).resolve().parents[2]
INGESTION_PROFILES_PATH = SKILLS_ROOT / "config" / "ragflow-ingestion-profiles.v1.json"
CHAT_PROFILE_PATH = SKILLS_ROOT / "config" / "ragflow-chat-assistant.v1.json"


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def ingestion_profiles() -> dict[str, Any]:
    payload = _load(INGESTION_PROFILES_PATH)
    payload["sha256"] = hashlib.sha256(INGESTION_PROFILES_PATH.read_bytes()).hexdigest()
    return payload


def chat_profile() -> dict[str, Any]:
    payload = _load(CHAT_PROFILE_PATH)
    payload["sha256"] = hashlib.sha256(CHAT_PROFILE_PATH.read_bytes()).hexdigest()
    return payload


def _settings() -> tuple[str, str, int]:
    load_dotenv()
    return (
        os.environ.get("RAGFLOW_BASE_URL", "").strip().rstrip("/"),
        os.environ.get("RAGFLOW_API_KEY", "").strip(),
        max(5, min(int(os.environ.get("RAGFLOW_TIMEOUT", "30")), 300)),
    )


def _call(method: str, path: str, body: dict[str, Any]) -> dict[str, Any]:
    base, key, timeout = _settings()
    if not base or not key:
        return {"ok": False, "error": "MissingEnvironment", "message": "RAGFLOW_BASE_URL/RAGFLOW_API_KEY are required"}
    result = request_json(
        base + "/" + path.lstrip("/"),
        headers={"Authorization": "Bearer " + key, "Accept": "application/json"},
        method=method,
        body=body,
        timeout=timeout,
    )
    outer = result.get("data")
    if result.get("ok") and isinstance(outer, dict) and outer.get("code", 0) not in (0, None):
        return {"ok": False, "error": "RagFlowApiError", "status": result.get("status"), "message": str(outer.get("message") or "RAGFlow rejected the request")}
    return {"ok": bool(result.get("ok")), "status": result.get("status"), "data": outer, "error": result.get("error"), "message": result.get("message")}


def apply_document_profile(
    dataset_id: str,
    document_id: str,
    profile_name: str,
    *,
    page_id: str,
    page_url: str,
    module: str = "unknown",
    chip: str = "unknown",
    platform: str = "unknown",
    project: str = "unknown",
    material_type: str = "docs",
) -> dict[str, Any]:
    profiles = ingestion_profiles()
    profile = profiles.get("profiles", {}).get(profile_name)
    if not isinstance(profile, dict):
        return {"ok": False, "error": "UnknownProfile", "profile": profile_name}
    metadata = {
        "page_id": str(page_id),
        "bookstack_page_id": str(page_id),
        "page_url": page_url,
        "source_url": page_url,
        "source_key": f"bookstack_page:{page_id}",
        "content_ref": f"bookstack:page:{page_id}",
        "material_type": material_type,
        "module": module,
        "chip": chip,
        "platform": platform,
        "project": project,
        "rag_enabled": True,
        "ingestion_profile": profile_name,
        "ingestion_profile_sha256": profiles["sha256"],
    }
    path = "/api/v1/datasets/{}/documents/{}".format(urllib.parse.quote(dataset_id, safe=""), urllib.parse.quote(document_id, safe=""))
    result = _call("PATCH", path, {
        "meta_fields": metadata,
        "chunk_method": profile["chunk_method"],
        "parser_config": profile["parser_config"],
    })
    result.update({"dataset_id": dataset_id, "document_id": document_id, "profile": profile_name, "profile_sha256": profiles["sha256"]})
    return result


def start_parsing(dataset_id: str, document_ids: list[str]) -> dict[str, Any]:
    ids = list(dict.fromkeys(str(value).strip() for value in document_ids if str(value).strip()))
    if not dataset_id or not ids:
        return {"ok": False, "error": "MissingDocumentIdentity"}
    path = "/api/v1/datasets/{}/chunks".format(urllib.parse.quote(dataset_id, safe=""))
    result = _call("POST", path, {"document_ids": ids})
    result.update({"dataset_id": dataset_id, "document_ids": ids})
    return result


def sync_chat(dataset_ids: list[str], chat_id: str | None = None) -> dict[str, Any]:
    ids = list(dict.fromkeys(str(value).strip() for value in dataset_ids if str(value).strip()))
    resolved_chat_id = (chat_id or os.environ.get("RAGFLOW_CHAT_ID", "")).strip()
    if not resolved_chat_id:
        return {"ok": False, "error": "MissingChatId", "message": "Set RAGFLOW_CHAT_ID or pass --chat-id"}
    if not ids:
        return {"ok": False, "error": "MissingDatasetIds"}
    profile = chat_profile()
    body = {key: value for key, value in profile.items() if key not in {"schema_version", "sha256", "description"}}
    body["dataset_ids"] = ids
    path = "/api/v1/chats/" + urllib.parse.quote(resolved_chat_id, safe="")
    result = _call("PATCH", path, body)
    result.update({"chat_id": resolved_chat_id, "dataset_ids": ids, "profile_sha256": profile["sha256"]})
    return result


def create_chat(dataset_ids: list[str]) -> dict[str, Any]:
    ids = list(dict.fromkeys(str(value).strip() for value in dataset_ids if str(value).strip()))
    if not ids:
        return {"ok": False, "error": "MissingDatasetIds"}
    profile = chat_profile()
    body = {key: value for key, value in profile.items() if key not in {"schema_version", "sha256", "description"}}
    body["dataset_ids"] = ids
    result = _call("POST", "/api/v1/chats", body)
    response = result.get("data")
    created = response.get("data") if isinstance(response, dict) else None
    chat_id = str(created.get("id") or "").strip() if isinstance(created, dict) else ""
    if result.get("ok") and not chat_id:
        return {"ok": False, "error": "UnsupportedChatCreateResponse", "status": result.get("status")}
    result.update({"chat_id": chat_id, "dataset_ids": ids, "profile_sha256": profile["sha256"]})
    return result


def non_destructive_migration_plan() -> dict[str, Any]:
    mapping = dataset_map()
    return {
        "ok": True,
        "strategy": "parallel-v2-datasets",
        "destructive": False,
        "datasets": [
            {"logical_name": logical, "source_name": name, "target_name": name if name.endswith("_v2") else name + "_v2"}
            for logical, name in mapping.items()
        ],
        "steps": [
            "create_target_datasets",
            "publish_from_bookstack_with_metadata",
            "parse_with_versioned_profiles",
            "run_recall_regression",
            "switch_dataset_ids",
            "retain_source_datasets_for_rollback",
        ],
        "safety_rules": ["do_not_delete_source", "do_not_modify_source_documents", "switch_only_after_validation", "rollback_by_restoring_dataset_ids"],
    }

"""Contracts V2 governance client and durable offline intake outbox."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Iterator

from .clients.http_json import request_json
from .runtime import load_dotenv


Transport = Callable[..., dict[str, Any]]
OUTBOX_STATES = ("pending", "sending", "acknowledged", "retry_wait", "dead_letter")


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def deterministic_submission_id(session_id: str, page_id: int) -> str:
    material = f"drvknowledge:intake:v2:{session_id}:{page_id}".encode("utf-8")
    return f"intake:{hashlib.sha256(material).hexdigest()[:32]}"


def _response_error(response: dict[str, Any]) -> str:
    data = response.get("data")
    if isinstance(data, dict):
        nested = data.get("data")
        for candidate in (data.get("error_code"), nested.get("error_code") if isinstance(nested, dict) else None):
            if candidate:
                return str(candidate)
    return str(response.get("message") or response.get("error") or "delivery failed")


def build_intake_request(
    *,
    session_id: str,
    page_id: int,
    canonical_url: str,
    title: str,
    material_type: str,
    content_hash: str,
    trace_id: str | None = None,
    requested_workflow: str = "drvknowledge_worker",
    client_version: str = "2.0.3",
) -> dict[str, Any]:
    return {
        "schema_version": "drvknowledge.intake-request.v2",
        "trace_id": trace_id or f"trace:{uuid.uuid4().hex}",
        "client_submission_id": deterministic_submission_id(session_id, page_id),
        "page_id": int(page_id),
        "canonical_url": canonical_url,
        "title": title,
        "content_hash": content_hash,
        "material_type": material_type,
        "requested_workflow": requested_workflow,
        "source_key": f"bookstack_page:{int(page_id)}",
        "content_ref": f"bookstack:page:{int(page_id)}",
        "client": {"name": "drv-knowledge-ingestion", "version": client_version},
    }


class GovernanceV2Client:
    def __init__(
        self,
        *,
        base_url: str,
        token_id: str,
        token_secret: str,
        timeout: int = 30,
        transport: Transport = request_json,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token_id = token_id.strip()
        self.token_secret = token_secret.strip()
        self.timeout = timeout
        self.transport = transport

    @classmethod
    def from_environment(cls, *, transport: Transport = request_json) -> "GovernanceV2Client":
        load_dotenv()
        base_url = (os.environ.get("GOVERNANCE_BASE_URL") or os.environ.get("BOOKSTACK_BASE_URL") or "").strip()
        token_id = (os.environ.get("GOVERNANCE_TOKEN_ID") or os.environ.get("BOOKSTACK_TOKEN_ID") or "").strip()
        token_secret = (os.environ.get("GOVERNANCE_TOKEN_SECRET") or os.environ.get("BOOKSTACK_TOKEN_SECRET") or "").strip()
        timeout = int(os.environ.get("GOVERNANCE_TIMEOUT_SECONDS") or os.environ.get("BOOKSTACK_TIMEOUT_SECONDS") or "30")
        return cls(base_url=base_url, token_id=token_id, token_secret=token_secret, timeout=timeout, transport=transport)

    def ready(self) -> bool:
        return bool(self.base_url and self.token_id and self.token_secret)

    def _headers(self, trace_id: str, idempotency_key: str | None = None) -> dict[str, str]:
        headers = {
            "Accept": "application/json",
            "Authorization": f"Token {self.token_id}:{self.token_secret}",
            "X-Trace-ID": trace_id,
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        return headers

    def submit_intake(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.ready():
            return {"ok": False, "status": 0, "error": "MissingConfiguration", "message": "Governance URL or personal token is not configured"}
        return self.transport(
            f"{self.base_url}/api/ai-governance/v2/intakes",
            method="POST",
            headers=self._headers(payload["trace_id"], payload["client_submission_id"]),
            body=payload,
            timeout=self.timeout,
        )

    def get_intake(self, intake_id: str, *, trace_id: str | None = None) -> dict[str, Any]:
        trace = trace_id or f"trace:{uuid.uuid4().hex}"
        return self.transport(
            f"{self.base_url}/api/ai-governance/v2/intakes/{intake_id}",
            headers=self._headers(trace),
            timeout=self.timeout,
        )

    def resolve_status(self, content_refs: list[str], *, trace_id: str | None = None) -> dict[str, Any]:
        trace = trace_id or f"trace:{uuid.uuid4().hex}"
        payload = {"schema_version": "drvknowledge.status-resolve-request.v2", "trace_id": trace, "content_refs": content_refs}
        idempotency_key = f"status:{hashlib.sha256(json.dumps(content_refs, sort_keys=True).encode()).hexdigest()[:32]}"
        return self.transport(
            f"{self.base_url}/api/ai-governance/v2/status/resolve",
            method="POST",
            headers=self._headers(trace, idempotency_key),
            body=payload,
            timeout=self.timeout,
        )


class GovernanceOutbox:
    def __init__(self, path: str | Path, *, max_attempts: int = 10, sending_timeout_seconds: int = 300) -> None:
        self.path = Path(path).expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.max_attempts = max_attempts
        self.sending_timeout_seconds = max(1, sending_timeout_seconds)
        self._initialize()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _initialize(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS governance_outbox (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kind TEXT NOT NULL,
                    submission_id TEXT NOT NULL UNIQUE,
                    payload_json TEXT NOT NULL,
                    state TEXT NOT NULL CHECK(state IN ('pending','sending','acknowledged','retry_wait','dead_letter')),
                    attempts INTEGER NOT NULL DEFAULT 0,
                    next_attempt_at TEXT,
                    last_error TEXT,
                    response_json TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )

    def enqueue_intake(self, payload: dict[str, Any]) -> int:
        submission_id = str(payload["client_submission_id"])
        timestamp = utc_now()
        encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO governance_outbox
                    (kind, submission_id, payload_json, state, attempts, created_at, updated_at)
                VALUES ('intake', ?, ?, 'pending', 0, ?, ?)
                """,
                (submission_id, encoded, timestamp, timestamp),
            )
            row = conn.execute("SELECT id FROM governance_outbox WHERE submission_id = ?", (submission_id,)).fetchone()
        return int(row["id"])

    def get(self, row_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM governance_outbox WHERE id = ?", (row_id,)).fetchone()
        if row is None:
            raise KeyError(row_id)
        return dict(row)

    def replay(self, sender: Callable[[dict[str, Any]], dict[str, Any]], *, limit: int = 50) -> dict[str, int]:
        counts = {"acknowledged": 0, "retry_wait": 0, "dead_letter": 0}
        now = utc_now()
        sending_cutoff = (
            dt.datetime.now(dt.timezone.utc) - dt.timedelta(seconds=self.sending_timeout_seconds)
        ).replace(microsecond=0).isoformat()
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE governance_outbox
                SET state = 'retry_wait', next_attempt_at = ?,
                    last_error = COALESCE(last_error, 'sending lease expired'), updated_at = ?
                WHERE state = 'sending' AND updated_at <= ?
                """,
                (now, now, sending_cutoff),
            )
            rows = conn.execute(
                """
                SELECT * FROM governance_outbox
                WHERE state = 'pending' OR (state = 'retry_wait' AND (next_attempt_at IS NULL OR next_attempt_at <= ?))
                ORDER BY id ASC LIMIT ?
                """,
                (now, limit),
            ).fetchall()
        for row in rows:
            row_id = int(row["id"])
            attempts = int(row["attempts"]) + 1
            with self._connect() as conn:
                changed = conn.execute(
                    "UPDATE governance_outbox SET state = 'sending', attempts = ?, updated_at = ? WHERE id = ? AND state IN ('pending','retry_wait')",
                    (attempts, utc_now(), row_id),
                ).rowcount
            if not changed:
                continue
            payload = json.loads(row["payload_json"])
            try:
                response = sender(payload)
            except Exception as exc:  # keep the request durable even if an adapter raises
                response = {"ok": False, "status": 0, "error": type(exc).__name__, "message": str(exc)}
            failure = _response_error(response)[:1000]
            if response.get("ok"):
                state = "acknowledged"
                last_error = None
                next_attempt_at = None
            elif int(response.get("status") or 0) == 409:
                state = "dead_letter"
                last_error = failure
                next_attempt_at = None
            elif attempts >= self.max_attempts:
                state = "dead_letter"
                last_error = failure
                next_attempt_at = None
            else:
                state = "retry_wait"
                last_error = failure
                delay_seconds = min(3600, 2 ** min(attempts, 10))
                next_attempt_at = (dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=delay_seconds)).replace(microsecond=0).isoformat()
            with self._connect() as conn:
                conn.execute(
                    """
                    UPDATE governance_outbox
                    SET state = ?, next_attempt_at = ?, last_error = ?, response_json = ?, updated_at = ?
                    WHERE id = ? AND state = 'sending'
                    """,
                    (state, next_attempt_at, last_error, json.dumps(response, ensure_ascii=False), utc_now(), row_id),
                )
            counts[state] += 1
        return counts


class GovernanceStatusCache:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path).expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS governance_status_cache (
                    content_ref TEXT PRIMARY KEY,
                    review_status TEXT NOT NULL,
                    snapshot_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def put_many(self, items: list[dict[str, Any]]) -> None:
        with self._connect() as conn:
            for item in items:
                content_ref = str(item.get("content_ref") or "")
                review_status = str(item.get("review_status") or "unknown")
                updated_at = str(item.get("updated_at") or utc_now())
                if not content_ref:
                    continue
                conn.execute(
                    """
                    INSERT INTO governance_status_cache (content_ref, review_status, snapshot_json, updated_at)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(content_ref) DO UPDATE SET
                        review_status = excluded.review_status,
                        snapshot_json = excluded.snapshot_json,
                        updated_at = excluded.updated_at
                    """,
                    (content_ref, review_status, json.dumps(item, ensure_ascii=False, sort_keys=True), updated_at),
                )

    def get_many(self, content_refs: list[str]) -> dict[str, Any]:
        if not content_refs:
            return {"items": [], "as_of": None}
        placeholders = ",".join("?" for _ in content_refs)
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM governance_status_cache WHERE content_ref IN ({placeholders})",  # placeholders only
                tuple(content_refs),
            ).fetchall()
        items = [json.loads(row["snapshot_json"]) for row in rows]
        as_of = max((str(row["updated_at"]) for row in rows), default=None)
        return {"items": items, "as_of": as_of}


def resolve_governance_statuses(
    content_refs: list[str],
    *,
    client: Any | None = None,
    cache: GovernanceStatusCache | None = None,
) -> dict[str, Any]:
    unique_refs = list(dict.fromkeys(ref for ref in content_refs if ref.startswith("bookstack:page:")))
    client = client or GovernanceV2Client.from_environment()
    cache = cache or GovernanceStatusCache(default_status_cache_path())
    live_error = None
    if client.ready() and unique_refs:
        response = client.resolve_status(unique_refs)
        if response.get("ok"):
            payload = response.get("data") or {}
            if isinstance(payload, dict) and isinstance(payload.get("data"), dict):
                payload = payload["data"]
            items = payload.get("items", []) if isinstance(payload, dict) else []
            cache.put_many(items)
            statuses = {
                item["content_ref"]: item.get("review_status", "unknown")
                for item in items
                if item.get("content_ref") in unique_refs
            }
            return {"statuses": statuses, "cache_used": False, "cache_as_of": None, "error": None}
        live_error = response.get("message") or response.get("error") or "status resolve failed"
    cached = cache.get_many(unique_refs)
    statuses = {
        item["content_ref"]: item.get("review_status", "unknown")
        for item in cached["items"]
        if item.get("content_ref") in unique_refs
    }
    return {"statuses": statuses, "cache_used": bool(statuses), "cache_as_of": cached["as_of"], "error": live_error}


def default_outbox_path() -> Path:
    load_dotenv()
    runtime = Path(os.environ.get("DRVKB_RUNTIME_DIR") or "~/.drvknowledge").expanduser()
    return runtime / "governance-outbox.sqlite3"


def default_status_cache_path() -> Path:
    load_dotenv()
    runtime = Path(os.environ.get("DRVKB_RUNTIME_DIR") or "~/.drvknowledge").expanduser()
    return runtime / "governance-status-cache.sqlite3"

"""Drv Knowledge shared core v2.0.3."""
__version__='2.0.3'

"""Shared knowledge contracts used by retrieval and ingestion."""
from __future__ import annotations

MATERIAL_TYPES = ("cases", "manuals", "tech_notes", "project_docs", "docs")
SOURCE_MODES = ("ai_context", "file_import", "existing_markdown", "manual_input")
INGEST_STATES = (
    "LOCAL_DRAFT", "NEEDS_REVISION", "USER_CONFIRMED",
    "BOOKSTACK_PENDING_REVIEW", "BOOKSTACK_APPROVED",
    "RAG_PENDING", "RAG_PARSING", "RAG_READY",
    "RECALL_VERIFIED", "REJECTED", "RAG_FAILED", "RECALL_FAILED"
)
SHELF_BY_MATERIAL = {
    "cases": "【AI】经验案例",
    "manuals": "【AI】手册资料",
    "tech_notes": "【AI】技术资料",
    "project_docs": "【AI】项目资料",
    "docs": "【SYS】工程工具",
}

def shelf_for_material(material: str) -> str:
    return SHELF_BY_MATERIAL.get(material, "")

def pending_metadata_defaults() -> dict:
    return {"source":"bookstack","rag_enabled":False,"status":"draft"}

"""Source metadata helpers shared by retrieval and ingestion.

The performance rule is: a recall result should already carry its canonical BookStack
link in RAGFlow metadata/front matter. Retrieval must not synchronously call BookStack
for every hit merely to resolve a URL.
"""
from __future__ import annotations
import os, re, urllib.parse
from typing import Any
from .runtime import load_dotenv

SOURCE_KEYS=("page_url","source_url","original_url","bookstack_page_id","page_id","source_key")

def parse_embedded_metadata(content:str)->dict[str,str]:
    text=(content or '').strip(); out={}
    if text.startswith('---'):
        for line in text.splitlines()[1:100]:
            if line.strip()=='---': break
            if ':' not in line: continue
            k,v=line.split(':',1); k=k.strip(); v=v.strip().strip('"\'')
            if k: out[k]=v
    # Historical DrvDocs cases used blockquote metadata.
    for line in text.splitlines()[:160]:
        m=re.match(r'^>\s*([A-Za-z_][\w-]*):\s*(.+?)\s*$',line)
        if m: out.setdefault(m.group(1),m.group(2).strip())
    return out

def normalize_bookstack_url(url:str)->str:
    load_dotenv(); value=(url or '').strip()
    if not value: return ''
    canonical=(os.environ.get('BOOKSTACK_PUBLIC_URL') or os.environ.get('BOOKSTACK_CANONICAL_BASE_URL') or os.environ.get('BOOKSTACK_BASE_URL') or '').strip().rstrip('/')
    if not canonical: return value
    aliases=[x.strip().rstrip('/') for x in os.environ.get('BOOKSTACK_URL_ALIASES','').split(',') if x.strip()]
    for old in aliases:
        if value==old or value.startswith(old+'/'): return canonical+value[len(old):]
    rewrite=os.environ.get('BOOKSTACK_REWRITE_ANY_BOOKS_URL','true').strip().lower() not in {'0','false','no','off'}
    if rewrite:
        try:
            src=urllib.parse.urlsplit(value); dst=urllib.parse.urlsplit(canonical)
            if src.scheme in {'http','https'} and '/books/' in src.path and dst.scheme and dst.netloc:
                return urllib.parse.urlunsplit((dst.scheme,dst.netloc,src.path,src.query,src.fragment))
        except Exception: pass
    return value

def extract_chunk_metadata(chunk:dict[str,Any],content:str)->dict[str,Any]:
    meta={}
    for key in ('metadata','document_metadata','meta','meta_fields'):
        value=chunk.get(key)
        if isinstance(value,dict): meta.update(value)
    for k,v in parse_embedded_metadata(content).items(): meta.setdefault(k,v)
    aliases={
      'page_url':['page_url','source_url','original_url','url'],
      'source_url':['source_url','page_url','original_url','url'],
      'page_id':['page_id','bookstack_page_id'],
      'bookstack_page_id':['bookstack_page_id','page_id'],
      'material_type':['material_type','type'],'status':['status'],'module':['module'],'platform':['platform'],
      'chip':['chip'],'project':['project'],'rag_enabled':['rag_enabled'],'source_key':['source_key'],'title':['title']}
    for dst,keys in aliases.items():
        if meta.get(dst) not in (None,''): continue
        for key in keys:
            if chunk.get(key) not in (None,''): meta[dst]=chunk.get(key); break
            if meta.get(key) not in (None,''): meta[dst]=meta.get(key); break
    if meta.get('page_url'): meta['page_url']=normalize_bookstack_url(str(meta['page_url']))
    if meta.get('source_url'): meta['source_url']=normalize_bookstack_url(str(meta['source_url']))
    return meta

def inject_page_identity(markdown:str,*,page_id:int|str,page_url:str)->str:
    """Add canonical BookStack identity to YAML front matter without changing review gates."""
    url=normalize_bookstack_url(page_url) or page_url
    fields={
      'bookstack_page_id':str(page_id),'page_id':str(page_id),'page_url':url,'source_url':url,
      'source_key':f'bookstack_page:{page_id}','content_ref':f'bookstack:page:{page_id}'
    }
    text=markdown
    if not text.startswith('---\n'):
        header='---\n'+''.join(f'{k}: {v}\n' for k,v in fields.items())+'---\n\n'
        return header+text
    end=text.find('\n---',4)
    if end<0: return text
    fm=text[4:end]; body=text[end:]
    lines=fm.splitlines(); existing={}
    for i,line in enumerate(lines):
        if ':' in line: existing[line.split(':',1)[0].strip()]=i
    for k,v in fields.items():
        line=f'{k}: {v}'
        if k in existing: lines[existing[k]]=line
        else: lines.append(line)
    return '---\n'+'\n'.join(lines)+body

"""Read-only BookStack REST adapter with optional full pagination."""
from __future__ import annotations
import os
from typing import Any
from ..runtime import load_dotenv
from .http_json import request_json

def _settings() -> tuple[str,str,str]:
    load_dotenv(); return (os.environ.get('BOOKSTACK_BASE_URL','').rstrip('/'), os.environ.get('BOOKSTACK_TOKEN_ID',''), os.environ.get('BOOKSTACK_TOKEN_SECRET',''))

def ready() -> bool:
    b,i,s=_settings(); return bool(b and i and s)

def get(path: str, params: dict[str,Any] | None=None) -> dict[str,Any]:
    base,tid,secret=_settings()
    if not (base and tid and secret): return {'ok':False,'error':'MissingEnvironment','message':'BOOKSTACK_BASE_URL/BOOKSTACK_TOKEN_ID/BOOKSTACK_TOKEN_SECRET are required'}
    return request_json(base+path,headers={'Authorization':f'Token {tid}:{secret}','Accept':'application/json'},params=params)

def _list(path:str,count:int=100,all_items:bool=False)->dict[str,Any]:
    if not all_items: return get(path,{'count':count})
    page_size=max(1,min(int(count or 100),500)); offset=0; merged=[]; total=None; pages=0
    while True:
        result=get(path,{'count':page_size,'offset':offset})
        if not result.get('ok'): return result
        payload=result.get('data') or {}; rows=payload.get('data',[]) if isinstance(payload,dict) else []
        if not isinstance(rows,list): return {'ok':False,'error':'UnexpectedBookStackResponse','message':f'{path} did not return data[]','raw':result}
        merged.extend(rows); pages+=1
        if isinstance(payload,dict) and isinstance(payload.get('total'),int): total=payload['total']
        if len(rows)<page_size or (total is not None and len(merged)>=total): break
        offset += len(rows)
        if pages>=10000: return {'ok':False,'error':'PaginationGuard','message':'BookStack pagination exceeded guard','data':{'data':merged,'total':total}}
    return {'ok':True,'status':200,'data':{'data':merged,'total':total if total is not None else len(merged),'count':len(merged),'pages':pages},'url':path}

def shelves(count:int=100,all_items:bool=False)->dict[str,Any]: return _list('/api/shelves',count,all_items)
def books(count:int=100,all_items:bool=False)->dict[str,Any]: return _list('/api/books',count,all_items)
def chapters(count:int=100,all_items:bool=False)->dict[str,Any]: return _list('/api/chapters',count,all_items)
def pages(count:int=100,all_items:bool=False)->dict[str,Any]: return _list('/api/pages',count,all_items)
def page(page_id:int)->dict[str,Any]: return get(f'/api/pages/{page_id}')
def search(query:str,count:int=20)->dict[str,Any]: return get('/api/search',{'query':query,'count':count})

"""Tiny stdlib JSON HTTP helper used by drv-knowledge live adapters."""
from __future__ import annotations
import json, urllib.error, urllib.parse, urllib.request
from typing import Any

def request_json(url: str, *, headers: dict[str,str] | None=None, params: dict[str,Any] | None=None, method: str='GET', body: Any=None, timeout: int=30) -> dict[str,Any]:
    if params:
        q=urllib.parse.urlencode({k:v for k,v in params.items() if v is not None})
        url += ('&' if '?' in url else '?') + q
    data=None
    hdrs=dict(headers or {})
    if body is not None:
        data=json.dumps(body,ensure_ascii=False).encode('utf-8'); hdrs.setdefault('Content-Type','application/json')
    req=urllib.request.Request(url,data=data,headers=hdrs,method=method)
    try:
        with urllib.request.urlopen(req,timeout=timeout) as resp:
            raw=resp.read().decode('utf-8',errors='replace')
            return {'ok':True,'status':getattr(resp,'status',200),'data':json.loads(raw) if raw.strip() else None,'url':url}
    except urllib.error.HTTPError as exc:
        raw=exc.read().decode('utf-8',errors='replace')[:2000]
        try: payload=json.loads(raw)
        except Exception: payload={'raw':raw}
        return {'ok':False,'status':exc.code,'error':'HTTPError','message':str(exc),'data':payload,'url':url}
    except Exception as exc:
        return {'ok':False,'status':0,'error':type(exc).__name__,'message':str(exc),'data':None,'url':url}

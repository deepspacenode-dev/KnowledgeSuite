"""Read-only adapter for BookStack AI Governance v1."""
from __future__ import annotations
import os
from typing import Any
from ..runtime import load_dotenv, load_config
from .http_json import request_json

def _base() -> str:
    load_dotenv(); b=os.environ.get('BOOKSTACK_BASE_URL','').rstrip('/'); return b

def ready() -> bool:
    load_dotenv(); return bool(_base() and os.environ.get('GOVERNANCE_COOKIE',''))

def get(kind:str, params:dict[str,Any]|None=None)->dict[str,Any]:
    load_dotenv(); cfg=load_config(); base=_base(); cookie=os.environ.get('GOVERNANCE_COOKIE','').strip()
    if not base: return {'ok':False,'error':'MissingEnvironment','message':'BOOKSTACK_BASE_URL is required'}
    if not cookie: return {'ok':False,'error':'MissingSession','message':'GOVERNANCE_COOKIE is required because current governance GET APIs use BookStack session auth'}
    path=cfg.get('governance_paths',{}).get(kind)
    if not path: return {'ok':False,'error':'UnknownGovernanceResource','message':f'Unsupported governance resource: {kind}'}
    return request_json(base+path,headers={'Cookie':cookie,'Accept':'application/json','X-Requested-With':'XMLHttpRequest'},params=params)

def filter_graph(payload:dict[str,Any], query:str='', limit:int=100)->dict[str,Any]:
    if not payload.get('ok') or not query: return payload
    data=payload.get('data')
    # tolerate wrappers: {data:{nodes,links}}, {nodes,links}, {data:{nodes,edges}}
    graph=data.get('data',data) if isinstance(data,dict) else {}
    nodes=graph.get('nodes',[]) if isinstance(graph,dict) else []
    edges=graph.get('links',graph.get('edges',[])) if isinstance(graph,dict) else []
    q=query.lower(); matched=[]; ids=set()
    for node in nodes:
        blob=' '.join(str(node.get(k,'')) for k in ('id','name','title','label','type','module','platform','chip')).lower()
        if q in blob:
            matched.append(node); ids.add(str(node.get('id','')))
    neighbor_ids=set(ids)
    selected_edges=[]
    for edge in edges:
        s=edge.get('source'); t=edge.get('target')
        s=s.get('id') if isinstance(s,dict) else s; t=t.get('id') if isinstance(t,dict) else t
        if str(s) in ids or str(t) in ids:
            selected_edges.append(edge); neighbor_ids.update([str(s),str(t)])
    selected_nodes=[n for n in nodes if str(n.get('id','')) in neighbor_ids][:limit]
    out=dict(payload); out['data']={'nodes':selected_nodes,'edges':selected_edges[:limit*2],'query':query,'matched':len(matched)}; return out

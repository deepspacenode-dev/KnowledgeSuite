"""Read-only RAGFlow catalog/browse adapter."""
from __future__ import annotations
import os
from typing import Any
from ..runtime import dataset_map, load_dotenv
from .http_json import request_json


def _settings()->tuple[str,str,int]:
    load_dotenv(); return (os.environ.get('RAGFLOW_BASE_URL','').rstrip('/'),os.environ.get('RAGFLOW_API_KEY',''),int(os.environ.get('RAGFLOW_TIMEOUT','30')))

def ready()->bool:
    b,k,_=_settings(); return bool(b and k)

def _get(path:str,params:dict[str,Any]|None=None)->dict[str,Any]:
    base,key,timeout=_settings()
    if not (base and key): return {'ok':False,'error':'MissingEnvironment','message':'RAGFLOW_BASE_URL/RAGFLOW_API_KEY are required'}
    return request_json(base+'/'+path.lstrip('/'),headers={'Authorization':'Bearer '+key,'Accept':'application/json'},params=params,timeout=timeout)

def _payload(result:dict[str,Any])->Any:
    if not result.get('ok'): return None
    outer=result.get('data')
    if isinstance(outer,dict) and 'code' in outer and outer.get('code') not in (0,None): return None
    return outer.get('data',outer) if isinstance(outer,dict) else outer

def _rows(data:Any,keys:tuple[str,...])->tuple[list[dict[str,Any]],int|None]:
    if isinstance(data,list): return [x for x in data if isinstance(x,dict)],len(data)
    if not isinstance(data,dict): return [],None
    for k in keys:
        v=data.get(k)
        if isinstance(v,list):
            total=data.get('total') if isinstance(data.get('total'),int) else data.get('total_count') if isinstance(data.get('total_count'),int) else None
            return [x for x in v if isinstance(x,dict)],total
    nested=data.get('data')
    if isinstance(nested,dict): return _rows(nested,keys)
    if isinstance(nested,list): return [x for x in nested if isinstance(x,dict)],len(nested)
    return [],None

def datasets()->dict[str,Any]:
    path=os.environ.get('RAGFLOW_DATASETS_PATH','/api/v1/datasets')
    r=_get(path,{'page':1,'page_size':1000})
    data=_payload(r); rows,total=_rows(data,('datasets','items','data'))
    return {'ok':r.get('ok',False) and data is not None,'status':r.get('status'),'data':rows,'total':total if total is not None else len(rows),'raw_error':None if r.get('ok') else r}

def dataset_index_state(row:dict[str,Any])->dict[str,Any]:
    def count(*keys):
        for key in keys:
            value=row.get(key)
            if isinstance(value,bool) or value in (None,""): continue
            try:
                number=int(value)
                if number>=0: return number
            except (ValueError,TypeError): pass
        return None
    documents=count('document_count','doc_num','document_num')
    chunks=count('chunk_count','chunk_num')
    if chunks is not None and chunks>0: state='indexed'
    elif documents==0: state='empty'
    elif documents is not None and documents>0 and chunks==0: state='pending_parse'
    else: state='unknown'
    return {'id':str(row.get('id') or row.get('dataset_id') or ''),
            'name':str(row.get('name') or row.get('dataset_name') or ''),
            'document_count':documents,'chunk_count':chunks,'state':state}

def index_status(rows:list[dict[str,Any]])->dict[str,Any]:
    """Summarize dataset counters without claiming a real retrieval succeeded."""
    mapping=dataset_map()
    resolved=[]
    for raw in rows:
        row=dataset_index_state(raw)
        logical=[]
        for domain,name in mapping.items():
            explicit=os.environ.get('RAGFLOW_DATASET_ID_'+domain.upper(),'')
            if (row['id']==explicit if explicit else row['name']==name): logical.append(domain)
        row['default_routes']=logical
        resolved.append(row)
    selected=[row for row in resolved if row['default_routes']]
    indexed=sum(row['state']=='indexed' for row in selected)
    if indexed: state='indexed'
    elif not selected: state='unmapped'
    elif any(row['state']=='unknown' for row in selected): state='unknown'
    elif any(row['state']=='pending_parse' for row in selected): state='pending_parse'
    else: state='empty'
    found={domain for row in selected for domain in row['default_routes']}
    return {'state':state,'has_indexed_content':True if indexed else (None if state=='unknown' else False),
            'indexed_dataset_count':indexed,'default_route_dataset_count':len(selected),
            'missing_default_routes':[domain for domain in mapping if domain not in found],
            'datasets':resolved,'real_query_verified':False,
            'scope':'Dataset counters only; indexed means some chunks exist, not full parse completion or recall quality.'}

def documents(dataset_id:str,*,all_items:bool=True,page_size:int=100)->dict[str,Any]:
    path_tpl=os.environ.get('RAGFLOW_DOCUMENTS_PATH','/api/v1/datasets/{dataset_id}/documents')
    path=path_tpl.format(dataset_id=dataset_id)
    out=[]; page=1; total=None
    while True:
        r=_get(path,{'page':page,'page_size':page_size})
        data=_payload(r); rows,reported=_rows(data,('docs','documents','items','data'))
        if not r.get('ok') or data is None: return {'ok':False,'error':'RagflowDocumentsFailed','detail':r,'data':out}
        out.extend(rows); total=reported if reported is not None else total
        if not all_items or not rows or len(rows)<page_size or (total is not None and len(out)>=total): break
        page+=1
        if page>10000: return {'ok':False,'error':'PaginationGuard','data':out}
    return {'ok':True,'data':out,'total':total if total is not None else len(out),'pages':page}

def chunks(dataset_id:str,document_id:str,*,page_size:int=5)->dict[str,Any]:
    path_tpl=os.environ.get('RAGFLOW_CHUNKS_PATH','/api/v1/datasets/{dataset_id}/documents/{document_id}/chunks')
    path=path_tpl.format(dataset_id=dataset_id,document_id=document_id)
    r=_get(path,{'page':1,'page_size':page_size})
    data=_payload(r); rows,total=_rows(data,('chunks','items','data'))
    if not r.get('ok') or data is None: return {'ok':False,'error':'RagflowChunksFailed','detail':r,'data':[]}
    return {'ok':True,'data':rows,'total':total if total is not None else len(rows)}

"""Controlled BookStack writer used only by ingestion after explicit confirmation."""
from __future__ import annotations
import json, os
from urllib import request, error
from ..runtime import load_dotenv

class BookStackWriteError(RuntimeError): pass

class BookStackWriter:
    def __init__(self):
        load_dotenv()
        self.base=os.environ.get('BOOKSTACK_BASE_URL','').rstrip('/')
        self.tid=os.environ.get('BOOKSTACK_TOKEN_ID','')
        self.sec=os.environ.get('BOOKSTACK_TOKEN_SECRET','')
        self.timeout=float(os.environ.get('BOOKSTACK_TIMEOUT_SECONDS','30'))
        if not all([self.base,self.tid,self.sec]):
            raise BookStackWriteError('BOOKSTACK_BASE_URL/BOOKSTACK_TOKEN_ID/BOOKSTACK_TOKEN_SECRET are required')
    def call(self,method,path,payload=None):
        url=self.base+'/api'+path
        data=None; headers={'Authorization':f'Token {self.tid}:{self.sec}','Accept':'application/json'}
        if payload is not None:
            data=json.dumps(payload,ensure_ascii=False).encode('utf-8'); headers['Content-Type']='application/json'
        req=request.Request(url,data=data,headers=headers,method=method)
        try:
            with request.urlopen(req,timeout=self.timeout) as r:
                raw=r.read().decode('utf-8',errors='replace')
                return json.loads(raw) if raw.strip() else {}
        except error.HTTPError as e:
            raise BookStackWriteError(f'BookStack HTTP {e.code}: {e.read().decode("utf-8",errors="replace")[:500]}')
        except Exception as e:
            raise BookStackWriteError(f'BookStack error: {e}')
    def list_all(self,kind):
        out=[]; offset=0; count=100
        while True:
            obj=self.call('GET',f'/{kind}?count={count}&offset={offset}')
            data=obj.get('data',[]) if isinstance(obj,dict) else []
            out += data
            if len(data)<count: break
            offset += count
        return out
    def find_shelf_books(self,name):
        shelves=[x for x in self.list_all('shelves') if str(x.get('name','')).strip()==name.strip()]
        if len(shelves)!=1: raise BookStackWriteError(f'expected exactly one BookStack shelf named {name!r}; found {len(shelves)}')
        detail=self.call('GET',f"/shelves/{shelves[0]['id']}")
        return shelves[0], detail.get('books',[]) if isinstance(detail,dict) else []
    def find_book(self,name):
        m=[x for x in self.list_all('books') if str(x.get('name','')).strip()==name.strip()]
        if len(m)!=1: raise BookStackWriteError(f'expected exactly one BookStack book named {name!r}; found {len(m)}')
        return m[0]
    def find_chapter(self,name,book_id=None):
        m=[x for x in self.list_all('chapters') if str(x.get('name','')).strip()==name.strip() and (book_id is None or int(x.get('book_id') or 0)==int(book_id))]
        if len(m)!=1: raise BookStackWriteError(f'expected exactly one chapter named {name!r}; found {len(m)}')
        return m[0]
    def create_page(self,title,markdown,book,chapter=None):
        payload={'name':title,'markdown':markdown}
        if chapter: payload['chapter_id']=int(chapter['id'])
        else: payload['book_id']=int(book['id'])
        return self.call('POST','/pages',payload)
    def get_page(self,pid): return self.call('GET',f'/pages/{pid}')
    def update_page(self,pid,title,markdown): return self.call('PUT',f'/pages/{pid}',{'name':title,'markdown':markdown})
    def delete_page(self,pid): return self.call('DELETE',f'/pages/{pid}')

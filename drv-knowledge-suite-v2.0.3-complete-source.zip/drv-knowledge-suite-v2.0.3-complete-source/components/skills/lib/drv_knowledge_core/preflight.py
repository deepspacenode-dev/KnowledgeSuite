"""Runtime preflight helpers for retrieval and optional full installations."""
from __future__ import annotations

import importlib.metadata
import importlib.util
import os
import sys
from pathlib import Path
from typing import Any


DEPENDENCIES = {
    "html": {"import": "bs4", "package": "beautifulsoup4"},
    "docx": {"import": "docx", "package": "python-docx"},
    "pptx": {"import": "pptx", "package": "python-pptx"},
    "pdf": {"import": "fitz", "package": "PyMuPDF"},
    "pdf_tables": {"import": "pdfplumber", "package": "pdfplumber"},
    "images": {"import": "PIL", "package": "Pillow"},
}


def runtime_dir() -> Path:
    raw = os.environ.get("DRVKB_RUNTIME_DIR") or os.environ.get("DRVKNOWLEDGE_RUNTIME_DIR") or "~/.drvknowledge"
    return Path(raw).expanduser()


def env_path() -> Path:
    return runtime_dir() / ".env"


def _profile_from_env_file() -> str:
    path = env_path()
    if not path.is_file():
        return ""
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if line.startswith("DRVKB_INSTALL_PROFILE="):
            return line.split("=", 1)[1].strip().strip("\"'").lower()
    return ""


def install_profile() -> str:
    profile = (os.environ.get("DRVKB_INSTALL_PROFILE") or _profile_from_env_file() or "retrieval").strip().lower()
    return profile if profile in {"retrieval", "full"} else "retrieval"


def check_dependencies(profile: str | None = None) -> dict[str, Any]:
    selected = profile or install_profile()
    if selected not in {"retrieval", "full"}:
        selected = "retrieval"
    rows: dict[str, dict[str, Any]] = {}
    missing: list[str] = []
    for capability, spec in DEPENDENCIES.items():
        required = selected == "full"
        installed = importlib.util.find_spec(spec["import"]) is not None
        version = None
        if installed:
            try:
                version = importlib.metadata.version(spec["package"])
            except importlib.metadata.PackageNotFoundError:
                version = "unknown"
        rows[capability] = {"ok": installed, "required": required, "version": version, **spec}
        if required and not installed:
            missing.append(spec["package"])
    return {
        "ok": not missing,
        "profile": selected,
        "dependencies": rows,
        "missing_packages": sorted(set(missing)),
        "python": sys.executable,
        "python_version": sys.version.split()[0],
        "policy": "retrieval has no format-plugin requirement; full requires all six ingestion plugins; check-only, never pip install",
    }


def install_missing_dependencies(packages: list[str]) -> dict[str, Any]:
    """Runtime commands never mutate Python; only the installer may add dependencies."""
    requested = sorted(set(x for x in packages if x))
    return {
        "ok": not requested,
        "installed": [],
        "requested": requested,
        "error": "UseInstallerDependencyFlow" if requested else None,
        "message": "Prepare the six required ingestion plugins, then run ./install.sh --full. The Suite never installs them automatically.",
    }

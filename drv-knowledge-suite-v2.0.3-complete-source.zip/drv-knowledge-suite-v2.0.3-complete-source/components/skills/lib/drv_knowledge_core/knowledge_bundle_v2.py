"""Compatibility conversion from Recall V3 to Knowledge Bundle Contract V2."""
from __future__ import annotations

import datetime as dt
import hashlib
import re
import uuid
from typing import Any


INTENT_MAP = {
    "diagnosis": "diagnosis",
    "driver_development": "implementation",
    "implementation": "implementation",
    "manual_lookup": "manual_lookup",
    "case_reuse": "case_reuse",
    "concept_explain": "concept_explain",
    "platform_migration": "project_context",
    "review": "implementation",
}
TYPE_MAP = {
    "cases": "case",
    "manuals": "manual",
    "tech_notes": "tech_note",
    "project_docs": "project_doc",
    "docs": "doc",
}


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def _page_id(item: dict[str, Any]) -> int | None:
    raw = str(item.get("page_id") or "").strip()
    if raw.isdigit() and int(raw) > 0:
        return int(raw)
    for value in (item.get("source_key"), item.get("source"), item.get("content_ref")):
        match = re.fullmatch(r"bookstack(?:_page|:page):([1-9][0-9]*)", str(value or "").strip())
        if match:
            return int(match.group(1))
    return None


def bookstack_content_refs(legacy: dict[str, Any]) -> list[str]:
    refs = []
    for item in legacy.get("items", []):
        if not isinstance(item, dict) or item.get("source_kind") == "local_manual":
            continue
        page_id = _page_id(item)
        if page_id is not None:
            refs.append(f"bookstack:page:{page_id}")
    return list(dict.fromkeys(refs))


def _local_identity(item: dict[str, Any]) -> tuple[str, str]:
    raw = str(item.get("source_key") or item.get("relative_path") or item.get("local_path") or item.get("page_url") or item.get("title") or "manual")
    token = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]
    return f"local:manual:{token}", f"local_manual:{token}"


def _evidence(item: dict[str, Any], source_ref: str) -> list[dict[str, Any]]:
    candidates: list[str] = []
    engineering = item.get("engineering_summary")
    if isinstance(engineering, dict):
        candidates.extend(str(engineering.get(key) or "") for key in ("symptom", "root_cause", "solution", "verification", "overview"))
    candidates.extend([str(item.get("summary") or ""), str(item.get("reason") or "")])
    text = next((value.strip() for value in candidates if value.strip()), str(item.get("title") or "知识召回结果"))
    return [{"text": text, "source_ref": source_ref, "section": item.get("section") or None}]


def convert_legacy_bundle(
    legacy: dict[str, Any],
    *,
    knowledge_status: str,
    recall_mode: str,
    governance_statuses: dict[str, str] | None = None,
    trace_id: str | None = None,
    generated_at: str | None = None,
    cache_used: bool = False,
    cache_as_of: str | None = None,
) -> dict[str, Any]:
    """Convert the shipped A 1.x `knowledge-bundle-v3` shape to Contract V2.

    Governance state is never inferred from legacy RAG metadata. BookStack items
    are `unknown` unless B supplied a reviewed/verified status for content_ref.
    """
    governance_statuses = governance_statuses or {}
    items: list[dict[str, Any]] = []
    identity_warnings: list[str] = []
    for legacy_item in legacy.get("items", []):
        if not isinstance(legacy_item, dict):
            continue
        local = legacy_item.get("source_kind") == "local_manual"
        if local:
            content_ref, source_key = _local_identity(legacy_item)
            source_system = "local_manual"
        else:
            page_id = _page_id(legacy_item)
            if page_id is None:
                identity_warnings.append(f"缺少 BookStack page_id，已排除：{legacy_item.get('title', '(untitled)')}")
                continue
            content_ref = f"bookstack:page:{page_id}"
            source_key = f"bookstack_page:{page_id}"
            source_system = "ragflow" if legacy_item.get("source_kind", "ragflow") == "ragflow" else "bookstack"
        governed = governance_statuses.get(content_ref, "unknown")
        status = governed if governed in {"reviewed", "verified"} else "unknown"
        page_url = str(legacy_item.get("page_url") or legacy_item.get("source") or legacy_item.get("local_path") or "").strip()
        if not page_url:
            identity_warnings.append(f"缺少可访问来源，已排除：{legacy_item.get('title', '(untitled)')}")
            continue
        material = str(legacy_item.get("material_type") or legacy_item.get("type") or "docs")
        item_type = TYPE_MAP.get(material, material if material in set(TYPE_MAP.values()) else "doc")
        scope = {
            key: legacy_item.get(key)
            for key in ("platform", "module", "chip", "project")
            if legacy_item.get(key) not in (None, "", "unknown")
        }
        items.append({
            "type": item_type,
            "title": str(legacy_item.get("title") or "Untitled"),
            "content_ref": content_ref,
            "source": {
                "system": source_system,
                "source_key": source_key,
                "path_or_url": page_url,
                "dataset": legacy_item.get("dataset") or None,
                "document_id": str(legacy_item.get("document_id")) if legacy_item.get("document_id") is not None else None,
            },
            "page_url": page_url,
            "summary": str(legacy_item.get("summary") or ""),
            "confidence": min(1.0, max(0.0, float(legacy_item.get("confidence") or 0.0))),
            "status": status,
            "scope": scope,
            "evidence": _evidence(legacy_item, content_ref),
            "reason": str(legacy_item.get("reason") or ""),
        })
    mode = recall_mode if recall_mode in {"live", "local", "hybrid", "fallback"} else "fallback"
    status = knowledge_status if knowledge_status in {"ok", "degraded", "unavailable", "no_match", "no_linked_match"} else "degraded"
    missing = [str(value) for value in legacy.get("missing_info", [])]
    missing.extend(identity_warnings)
    return {
        "schema_version": "drvknowledge.knowledge-bundle.v2",
        "trace_id": trace_id or f"trace:{uuid.uuid4().hex}",
        "bundle_id": str(legacy.get("request_id") or f"bundle:{uuid.uuid4().hex}"),
        "query": str(legacy.get("task_summary") or "知识查询"),
        "intent": INTENT_MAP.get(str(legacy.get("task_type") or "diagnosis"), "diagnosis"),
        "recall_mode": mode,
        "generated_at": generated_at or _utc_now(),
        "knowledge_status": status,
        "cache": {"used": bool(cache_used), "as_of": cache_as_of},
        "items": items,
        "conflicts": [str(value) for value in legacy.get("conflicts", [])],
        "missing_info": missing,
        "suggested_next_actions": [str(value) for value in legacy.get("suggested_next_action", legacy.get("suggested_next_actions", []))],
    }

"""Shared runtime/config helpers for drv-knowledge."""
from __future__ import annotations
import hashlib, json, os
from pathlib import Path
from typing import Any

CORE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = CORE_DIR / "config" / "knowledge.json"

def load_dotenv() -> list[str]:
    loaded=[]
    candidates=[]
    override=os.environ.get("DRVKB_ENV_FILE","").strip()
    if override: candidates.append(Path(override).expanduser())
    runtime_root = os.environ.get("DRVKB_RUNTIME_DIR") or os.environ.get("DRVKNOWLEDGE_RUNTIME_DIR") or "~/.drvknowledge"
    candidates.extend([Path.cwd()/".env", Path(runtime_root).expanduser()/".env", CORE_DIR/".env"])
    seen=set()
    for path in candidates:
        try: path=path.resolve()
        except OSError: continue
        if path in seen or not path.is_file(): continue
        seen.add(path)
        for raw in path.read_text(encoding="utf-8",errors="ignore").splitlines():
            line=raw.strip()
            if not line or line.startswith("#") or "=" not in line: continue
            key,value=line.split("=",1); key=key.strip(); value=value.strip()
            if value[:1] in {'"',"'"} and value[-1:]==value[:1]: value=value[1:-1]
            if key and key not in os.environ: os.environ[key]=value
        loaded.append(str(path))
    return loaded

def load_config() -> dict[str,Any]:
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

def dataset_profile_name() -> str:
    cfg=load_config(); name=os.environ.get("DRVKB_DATASET_PROFILE",cfg.get("default_dataset_profile","drvdocs")).strip()
    return name if name in cfg.get("dataset_profiles",{}) else cfg.get("default_dataset_profile","drvdocs")

def remote_cache_signature() -> str:
    """Fingerprint remote service, account, routing and source-link policy."""
    load_dotenv()
    values={key:value for key,value in os.environ.items()
            if key.startswith(("RAGFLOW_", "BOOKSTACK_")) and value}
    values["DRVKB_DATASET_PROFILE"]=dataset_profile_name()
    raw=json.dumps(values,sort_keys=True,separators=(",",":"),ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()

def dataset_map() -> dict[str,str]:
    cfg=load_config(); return dict(cfg["dataset_profiles"][dataset_profile_name()])

def canonical_dataset(value: str) -> str:
    value=(value or "").strip(); maps=load_config().get("dataset_profiles",{})
    if value in dataset_map(): return dataset_map()[value]
    for profile in maps.values():
        for logical,name in profile.items():
            if value==name: return dataset_map().get(logical,name)
    return value

def logical_dataset(value: str) -> str:
    value=(value or "").strip(); cfg=load_config()
    if value in dataset_map(): return value
    for profile in cfg.get("dataset_profiles",{}).values():
        for logical,name in profile.items():
            if value==name: return logical
    return value

def route_for(task_type: str) -> list[str]:
    cfg=load_config(); logical=cfg.get("routing",{}).get(task_type) or cfg.get("routing",{}).get("diagnosis",[])
    mapping=dataset_map(); return [mapping.get(x,x) for x in logical]

def ragflow_credentials_ready() -> bool:
    load_dotenv()
    return bool(os.environ.get("RAGFLOW_BASE_URL") and os.environ.get("RAGFLOW_API_KEY"))

def ragflow_dataset_mapping_present() -> bool:
    load_dotenv()
    per=["CASES","MANUALS","TECH_NOTES","PROJECT_DOCS","DOCS"]
    if any(os.environ.get(f"RAGFLOW_DATASET_ID_{k}") for k in per): return True
    return bool(os.environ.get("RAGFLOW_DATASET_NAMES_JSON") or os.environ.get("RAGFLOW_DATASET_IDS"))

def env_ready_for_ragflow() -> bool:
    """Live recall can start with credentials only; dataset IDs may be auto-discovered."""
    return ragflow_credentials_ready()

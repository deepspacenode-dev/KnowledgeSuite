---
name: kb:doctor
description: 环境与服务健康检查
---

执行 `kb doctor --live`，并说明异常组件。

---
name: kb:recall
description: 工程问题知识召回分析
---

执行 `kb recall -q "$ARGUMENTS"`。优先返回不同知识页面的高相关结果，并保留可点击原文链接和工程化摘要。

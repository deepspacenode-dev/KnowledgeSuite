---
name: kb:manuals
description: 浏览芯片/平台技术手册
---

执行 `kb manuals $ARGUMENTS`。手册域同时查询 RAGFlow 与本地 Markdown；需要刷新本地目录时追加 `--refresh`。

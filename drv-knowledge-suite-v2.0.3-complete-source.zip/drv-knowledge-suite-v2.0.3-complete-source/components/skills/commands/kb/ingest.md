---
name: kb:ingest
description: 知识入库与异构文档转换入口
---

本命令仅在 full 模式且 6 个必需插件均已满足时注册。根据参数执行对应子操作：

- `kb ingest analyze <file>`
- `kb ingest import <file>`
- `kb ingest preview <SESSION>`
- `kb ingest submit <SESSION> --confirm`
- `kb ingest status <SESSION> --refresh`
- `kb ingest experience`
- `kb ingest manual <PDF>`
- `kb ingest sanitize-manual <MARKDOWN> <OUTPUT_DIR>`

提交前必须向用户确认，不得绕过 BookStack / Governance 审核链路。
超过 2 MiB、表格或图片密集的 Markdown 技术手册不得直接上传 RAGFlow；先运行
`sanitize-manual`，再上传输出目录中的 `ragflow/part-*.md`。

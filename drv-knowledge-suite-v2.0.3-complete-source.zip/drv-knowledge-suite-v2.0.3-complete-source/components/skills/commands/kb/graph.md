---
name: kb:graph
description: 查询知识图谱
---

执行 `kb graph $ARGUMENTS`。

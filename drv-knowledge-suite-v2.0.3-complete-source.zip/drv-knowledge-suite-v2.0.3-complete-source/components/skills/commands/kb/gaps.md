---
name: kb:gaps
description: 查看知识缺口
---

执行 `kb gaps $ARGUMENTS`。

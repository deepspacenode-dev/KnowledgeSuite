---
name: kb:bootstrap
description: 初始化或重建知识目录
---

执行 `kb bootstrap`。

---
name: kb:where
description: 定位知识所在位置
---

执行 `kb where $ARGUMENTS`。

---
name: kb:search
description: 搜索知识库内容
---

执行 `kb search -q "$ARGUMENTS"`。普通语义查询与关键词搜索统一使用此入口。

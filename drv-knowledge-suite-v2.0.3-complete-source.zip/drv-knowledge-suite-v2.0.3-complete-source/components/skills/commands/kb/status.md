---
name: kb:status
description: 查看知识系统状态
---

执行 `kb status $ARGUMENTS`。

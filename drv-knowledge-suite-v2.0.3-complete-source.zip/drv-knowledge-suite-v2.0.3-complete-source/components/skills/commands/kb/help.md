---
name: kb:help
description: Drv Knowledge Suite 使用帮助
---

执行 `kb help`，只展示当前 `/kb:*` 用户命令。

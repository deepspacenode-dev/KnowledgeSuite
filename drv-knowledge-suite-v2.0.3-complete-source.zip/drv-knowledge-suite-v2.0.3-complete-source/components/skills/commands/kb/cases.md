---
name: kb:cases
description: 浏览知识库案例
---

执行 `kb cases $ARGUMENTS`。空参数表示全部案例，不要用 Top-K recall 代替全量浏览。

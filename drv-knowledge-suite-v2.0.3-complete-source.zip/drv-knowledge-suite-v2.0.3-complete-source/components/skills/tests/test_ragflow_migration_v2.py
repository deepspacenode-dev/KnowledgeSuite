#!/usr/bin/env python3
"""RAGFlow migration regressions for the V2 Skills component."""
from __future__ import annotations

import contextlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "skills/drv-knowledge-retrieval"
CONFIG_MIGRATE = ROOT / "tools/install/config_migrate.py"
TEMPLATE = ROOT / "config/env.example"
KB = ROOT / "tools/cli/kb.py"
WRITE_CLI = ROOT / "tools/install/write_cli.py"
INSTALL = ROOT / "install.py"
for directory in (ROOT, ROOT / "lib", SKILL):
    sys.path.insert(0, str(directory))

from drv_knowledge_core.clients import ragflow_admin
from navigator import browse_engine, catalog


@contextlib.contextmanager
def mock_ragflow(chunks: int = 0):
    calls: list[str] = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            return

        def do_GET(self):
            calls.append(self.path)
            rows = [
                {"id": "new-cases", "name": "drvdocs_ai_cases", "document_count": 40, "chunk_count": chunks},
                {"id": "new-docs", "name": "drvdocs_ai_docs", "document_count": 18, "chunk_count": 0},
                *[
                    {"id": "new-" + domain, "name": "drvdocs_ai_" + domain, "document_count": 0, "chunk_count": 0}
                    for domain in ("project_docs", "tech_notes", "manuals")
                ],
            ]
            body = json.dumps({"code": 0, "data": rows}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_address[1]}", calls
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def parse_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def clean_env() -> dict[str, str]:
    return {
        key: value
        for key, value in os.environ.items()
        if not key.startswith(("RAGFLOW_", "BOOKSTACK_", "GOVERNANCE_", "DRVKB_", "DRVKNOWLEDGE_"))
    }


def run_kb(runtime: Path, *arguments: str, extra_env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    env = clean_env()
    env.update(
        {
            "HOME": str(runtime),
            "USERPROFILE": str(runtime),
            "DRVKB_RUNTIME_DIR": str(runtime),
            "DRVKB_ENV_FILE": str(runtime / ".env"),
            "DRVKB_LOCAL_MANUALS_ENABLED": "false",
        }
    )
    if extra_env:
        env.update(extra_env)
    return subprocess.run(
        [sys.executable, str(KB), *arguments],
        cwd=ROOT,
        env=env,
        text=True,
        encoding="utf-8",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


class RagflowConfigurationMigrationTests(unittest.TestCase):
    def configure(self, root: Path, runtime: Path, site: Path, *flags: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [
                sys.executable,
                str(CONFIG_MIGRATE),
                "--runtime",
                str(runtime),
                "--target",
                str(root / "target"),
                "--template",
                str(TEMPLATE),
                "--site-config",
                str(site),
                "--profile",
                "full",
                "--json",
                "--show-redacted",
                *flags,
            ],
            cwd=ROOT,
            env=clean_env(),
            text=True,
            encoding="utf-8",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def prepare_existing_install(self, root: Path) -> tuple[Path, Path, str]:
        runtime = root / "runtime"
        runtime.mkdir()
        old = (
            "DRVKB_INSTALL_PROFILE=full\n"
            "DRVKB_DATASET_PROFILE=bookstack\n"
            "RAGFLOW_BASE_URL=http://old-ragflow.example\n"
            "RAGFLOW_API_KEY=old-ragflow-key\n"
            "RAGFLOW_DATASET_ID_CASES=old-cases\n"
            "RAGFLOW_DATASET_IDS=old-cases,old-docs\n"
            "RAGFLOW_DATASET_NAMES_JSON={\"old-cases\":\"bookstack_ai_cases\"}\n"
            "RAGFLOW_RETRIEVAL_PATH=/legacy/retrieval\n"
            "RAGFLOW_TIMEOUT=45\n"
            "BOOKSTACK_BASE_URL=http://bookstack.example\n"
            "BOOKSTACK_TOKEN_ID=book-id\n"
            "BOOKSTACK_TOKEN_SECRET=book-secret\n"
            "GOVERNANCE_BASE_URL=http://governance.example\n"
            "GOVERNANCE_TOKEN_ID=governance-id\n"
            "GOVERNANCE_TOKEN_SECRET=governance-secret\n"
            "OWNER=operator\n"
        )
        (runtime / ".env").write_text(old, encoding="utf-8")
        site = root / "ragflow-site.env"
        site.write_text(
            "DRVKB_DATASET_PROFILE=drvdocs\n"
            "RAGFLOW_BASE_URL=http://new-ragflow.example/api/v1/\n"
            "RAGFLOW_API_KEY=new-ragflow-key\n",
            encoding="utf-8",
        )
        return runtime, site, old

    def test_explicit_migration_replaces_only_ragflow_and_preserves_v2_state(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runtime, site, old = self.prepare_existing_install(root)
            preserved = (
                "manuals/keep.md",
                "local_manuals_index.json.gz",
                "ingestion/sessions/keep.json",
                "outbox/pending.sqlite3",
            )
            for relative in ("knowledge_catalog.json", "cache/browse/cases.json", *preserved):
                path = runtime / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("keep", encoding="utf-8")

            result = self.configure(root, runtime, site, "--migrate-ragflow", "--write")

            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            report = json.loads(result.stdout)
            values = parse_env(runtime / ".env")
            self.assertEqual(values["RAGFLOW_BASE_URL"], "http://new-ragflow.example")
            self.assertEqual(values["RAGFLOW_API_KEY"], "new-ragflow-key")
            self.assertEqual(values["DRVKB_DATASET_PROFILE"], "drvdocs")
            self.assertEqual(values["RAGFLOW_RETRIEVAL_PATH"], "/api/v1/retrieval")
            self.assertEqual(values["RAGFLOW_TIMEOUT"], "45")
            self.assertEqual(values["RAGFLOW_DATASET_ID_CASES"], "")
            self.assertEqual(values["RAGFLOW_DATASET_IDS"], "")
            self.assertEqual(values["RAGFLOW_DATASET_NAMES_JSON"], "")
            self.assertEqual(values["BOOKSTACK_TOKEN_SECRET"], "book-secret")
            self.assertEqual(values["GOVERNANCE_TOKEN_SECRET"], "governance-secret")
            self.assertEqual(values["OWNER"], "operator")
            self.assertFalse((runtime / "knowledge_catalog.json").exists())
            self.assertFalse((runtime / "cache/browse").exists())
            for relative in preserved:
                self.assertEqual((runtime / relative).read_text(encoding="utf-8"), "keep")
            backup = Path(report["backup_path"])
            self.assertEqual(backup.read_text(encoding="utf-8"), old)
            self.assertNotIn("new-ragflow-key", result.stdout)
            self.assertNotIn("book-secret", result.stdout)
            self.assertNotIn("governance-secret", result.stdout)

    def test_invalid_migration_writes_nothing_and_keeps_cache(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runtime, site, old = self.prepare_existing_install(root)
            catalog = runtime / "knowledge_catalog.json"
            catalog.write_text("old-cache", encoding="utf-8")
            site.write_text("RAGFLOW_BASE_URL=not-a-url\n", encoding="utf-8")

            result = self.configure(root, runtime, site, "--migrate-ragflow", "--write")

            self.assertEqual(result.returncode, 30, result.stdout + result.stderr)
            self.assertEqual((runtime / ".env").read_text(encoding="utf-8"), old)
            self.assertEqual(catalog.read_text(encoding="utf-8"), "old-cache")
            self.assertFalse((runtime / "backups").exists())

    def test_plain_upgrade_does_not_replace_existing_ragflow(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runtime, site, _ = self.prepare_existing_install(root)

            result = self.configure(root, runtime, site, "--write")

            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            values = parse_env(runtime / ".env")
            self.assertEqual(values["RAGFLOW_BASE_URL"], "http://old-ragflow.example")
            self.assertEqual(values["RAGFLOW_API_KEY"], "old-ragflow-key")
            self.assertEqual(values["RAGFLOW_DATASET_ID_CASES"], "old-cases")


class RagflowRuntimeMigrationTests(unittest.TestCase):
    @staticmethod
    def migrated_rows(chunks: int = 0) -> list[dict[str, object]]:
        return [
            {"id": "new-cases", "name": "drvdocs_ai_cases", "document_count": 40, "chunk_count": chunks},
            {"id": "new-docs", "name": "drvdocs_ai_docs", "document_count": 18, "chunk_count": 0},
            {"id": "analysis", "name": "aiproblemtools_analysis_all", "document_count": 39, "chunk_count": 200},
            *[
                {"id": "new-" + domain, "name": "drvdocs_ai_" + domain, "document_count": 0, "chunk_count": 0}
                for domain in ("project_docs", "tech_notes", "manuals")
            ],
        ]

    def test_catalog_and_browse_caches_follow_server_account_and_legacy_runtime_name(self):
        with tempfile.TemporaryDirectory() as directory:
            runtime = Path(directory)
            env = {
                "DRVKNOWLEDGE_RUNTIME_DIR": str(runtime),
                "HOME": str(runtime),
                "USERPROFILE": str(runtime),
                "RAGFLOW_BASE_URL": "http://old-ragflow.example",
                "RAGFLOW_API_KEY": "account-one",
                "DRVKB_DATASET_PROFILE": "drvdocs",
            }
            with patch.dict(os.environ, env, clear=True), patch.object(catalog.ragflow_admin, "ready", return_value=True), patch.object(
                catalog.ragflow_admin,
                "datasets",
                return_value={"ok": True, "data": self.migrated_rows(4)},
            ):
                built = catalog.build_catalog(include_bookstack=False)
                self.assertEqual(Path(built["catalog_path"]).parent, runtime)
                self.assertTrue(catalog.load_catalog(refresh_if_missing=False))
                browse_engine._write_cache("same-id", [{"title": "old content"}], [], 1)
                self.assertTrue(browse_engine._load_cache("same-id"))

                os.environ["RAGFLOW_BASE_URL"] = "http://new-ragflow.example"
                self.assertEqual(catalog.load_catalog(refresh_if_missing=False), {})
                self.assertIsNone(browse_engine._load_cache("same-id"))

                catalog.build_catalog(include_bookstack=False)
                self.assertTrue(catalog.load_catalog(refresh_if_missing=False))
                os.environ["RAGFLOW_API_KEY"] = "account-two"
                self.assertEqual(catalog.load_catalog(refresh_if_missing=False), {})

    def test_dataset_index_status_does_not_confuse_documents_with_parsed_chunks(self):
        self.assertTrue(hasattr(ragflow_admin, "index_status"), "RAGFlow adapter must expose index_status")

        pending = ragflow_admin.index_status(self.migrated_rows())
        self.assertEqual(pending["state"], "pending_parse")
        self.assertFalse(pending["has_indexed_content"])
        self.assertEqual(pending["datasets"][2]["default_routes"], [])

        unknown_rows = self.migrated_rows()
        unknown_rows[0].pop("chunk_count")
        self.assertEqual(ragflow_admin.index_status(unknown_rows)["state"], "unknown")

        indexed = ragflow_admin.index_status(self.migrated_rows(3))
        self.assertEqual(indexed["state"], "indexed")
        self.assertFalse(indexed["real_query_verified"])

    def test_doctor_separates_configuration_api_connectivity_and_parse_state(self):
        with tempfile.TemporaryDirectory() as directory, mock_ragflow() as (base, calls):
            runtime = Path(directory)
            (runtime / ".env").write_text(
                f"DRVKB_DATASET_PROFILE=drvdocs\nRAGFLOW_BASE_URL={base}\nRAGFLOW_API_KEY=test-key\n",
                encoding="utf-8",
            )

            local = run_kb(runtime, "doctor", "--json")
            self.assertEqual(local.returncode, 0, local.stdout + local.stderr)
            local_payload = json.loads(local.stdout)
            self.assertIn("services_checked", local_payload)
            self.assertTrue(local_payload["configured"]["ragflow"])
            self.assertFalse(local_payload["services_checked"])
            self.assertEqual(local_payload["ragflow_index"]["state"], "not_checked")
            self.assertEqual(calls, [])

            for arguments in (("doctor", "--live", "--json"), ("command", "/kb:doctor --live --json")):
                result = run_kb(runtime, *arguments)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                payload = json.loads(result.stdout)
                self.assertTrue(payload["services_checked"])
                self.assertTrue(payload["services"]["ragflow"])
                self.assertEqual(payload["ragflow_index"]["state"], "pending_parse")
                self.assertFalse(payload["ragflow_index"]["has_indexed_content"])
                self.assertFalse(payload["ragflow_index"]["real_query_verified"])
                self.assertEqual(payload["ready_scope"], "retrieval_api_connectivity")
            self.assertEqual(len(calls), 2)


class RagflowInstallerMigrationTests(unittest.TestCase):
    def test_generated_launcher_keeps_selected_python_and_runtime_in_fresh_shell(self):
        self.assertTrue(WRITE_CLI.is_file(), "installer must use a shared launcher generator")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / "target with spaces"
            runtime = root / "runtime with spaces"
            bin_dir = root / "bin with spaces"
            entry = target / "skills/drv-knowledge-router/scripts/router_cli.py"
            entry.parent.mkdir(parents=True)
            entry.write_text(
                "import json,os,sys\n"
                "print(json.dumps({'executable':sys.executable,'runtime':os.environ.get('DRVKB_RUNTIME_DIR'),"
                "'env_file':os.environ.get('DRVKB_ENV_FILE')}))\n",
                encoding="utf-8",
            )

            generated = subprocess.run(
                [
                    sys.executable,
                    str(WRITE_CLI),
                    "--target",
                    str(target),
                    "--runtime",
                    str(runtime),
                    "--bin-dir",
                    str(bin_dir),
                    "--profile",
                    "retrieval",
                ],
                cwd=ROOT,
                env=clean_env(),
                text=True,
                encoding="utf-8",
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )
            self.assertEqual(generated.returncode, 0, generated.stdout + generated.stderr)

            env = clean_env()
            if os.name == "nt":
                command = [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", str(bin_dir / "kb.cmd")]
            else:
                command = [str(bin_dir / "kb")]
            launched = subprocess.run(
                command,
                cwd=root,
                env=env,
                text=True,
                encoding="utf-8",
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )
            self.assertEqual(launched.returncode, 0, launched.stdout + launched.stderr)
            payload = json.loads(launched.stdout)
            self.assertEqual(Path(payload["executable"]).resolve(), Path(sys.executable).resolve())
            self.assertEqual(Path(payload["runtime"]), runtime)
            self.assertEqual(Path(payload["env_file"]), runtime / ".env")

    def test_python_installer_applies_explicit_migration_and_generated_cli_reads_it(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runtime = root / "runtime"
            target = root / "target"
            bin_dir = root / "bin"
            runtime.mkdir()
            (runtime / ".env").write_text(
                "DRVKB_INSTALL_PROFILE=retrieval\n"
                "DRVKB_DATASET_PROFILE=bookstack\n"
                "RAGFLOW_BASE_URL=http://old-ragflow.example\n"
                "RAGFLOW_API_KEY=old-key\n"
                "RAGFLOW_DATASET_ID_CASES=old-cases\n",
                encoding="utf-8",
            )
            site = root / "ragflow-site.env"
            site.write_text(
                "DRVKB_DATASET_PROFILE=drvdocs\n"
                "RAGFLOW_BASE_URL=http://new-ragflow.example\n"
                "RAGFLOW_API_KEY=new-key\n",
                encoding="utf-8",
            )
            env = clean_env()
            env.update({"HOME": str(root), "USERPROFILE": str(root)})

            installed = subprocess.run(
                [
                    sys.executable,
                    str(INSTALL),
                    "--no-verify",
                    "--no-bootstrap",
                    "--migrate-ragflow",
                    "--site-config",
                    str(site),
                    "--target",
                    str(target),
                    "--runtime-dir",
                    str(runtime),
                    "--bin-dir",
                    str(bin_dir),
                ],
                cwd=ROOT,
                env=env,
                text=True,
                encoding="utf-8",
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )
            self.assertEqual(installed.returncode, 0, installed.stdout + installed.stderr)
            values = parse_env(runtime / ".env")
            self.assertEqual(values["RAGFLOW_BASE_URL"], "http://new-ragflow.example")
            self.assertEqual(values["RAGFLOW_DATASET_ID_CASES"], "")
            launcher = bin_dir / ("kb.cmd" if os.name == "nt" else "kb")
            self.assertTrue(launcher.is_file())
            text = launcher.read_text(encoding="utf-8")
            self.assertIn(str(runtime), text)
            self.assertIn(str(Path(sys.executable).absolute()), text)


if __name__ == "__main__":
    unittest.main(verbosity=2)

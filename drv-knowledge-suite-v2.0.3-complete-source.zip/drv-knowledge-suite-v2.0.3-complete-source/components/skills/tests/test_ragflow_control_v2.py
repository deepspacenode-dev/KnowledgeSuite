from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ENTRY = ROOT / "skills" / "drv-knowledge-retrieval" / "scripts" / "drvkb_entry.py"
KB_ENTRY = ROOT / "tools" / "cli" / "kb.py"


class RagFlowControlTests(unittest.TestCase):
    def run_cli(self, *args: str, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
        merged = os.environ.copy()
        if env:
            merged.update(env)
        return subprocess.run(
            [sys.executable, "-B", "-X", "utf8", str(ENTRY), *args],
            cwd=ROOT,
            env=merged,
            text=True,
            encoding="utf-8",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )

    def test_profiles_are_versioned_and_explicit(self) -> None:
        result = self.run_cli("rag", "profiles", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["schema_version"], "drvknowledge.ragflow-ingestion-profiles.v1")
        markdown = payload["profiles"]["bookstack-markdown-v1"]
        self.assertEqual(markdown["chunk_method"], "naive")
        self.assertEqual(markdown["parser_config"]["chunk_token_num"], 512)
        self.assertFalse(markdown["parser_config"]["raptor"]["use_raptor"])
        self.assertFalse(markdown["parser_config"]["graphrag"]["use_graphrag"])
        self.assertEqual(payload["profiles"]["technical-manual-pdf-v1"]["parser_config"]["task_page_size"], 6)
        sanitized = payload["profiles"]["sanitized-chip-manual-v1"]
        self.assertEqual(sanitized["chunk_method"], "naive")
        self.assertEqual(sanitized["parser_config"]["chunk_token_num"], 256)
        self.assertEqual(sanitized["parser_config"]["delimiter"], "\n")
        self.assertEqual(sanitized["parser_config"]["auto_keywords"], 0)
        self.assertEqual(sanitized["parser_config"]["auto_questions"], 0)

        routed = subprocess.run(
            [sys.executable, "-B", "-X", "utf8", str(KB_ENTRY), "rag", "profiles", "--json"],
            cwd=ROOT,
            text=True,
            encoding="utf-8",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        self.assertEqual(routed.returncode, 0, routed.stderr)
        self.assertEqual(json.loads(routed.stdout)["schema_version"], "drvknowledge.ragflow-ingestion-profiles.v1")

    def test_write_actions_require_confirm_and_use_v027_endpoints(self) -> None:
        calls: list[tuple[str, str, dict]] = []

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                return

            def _handle(self):
                length = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(length) or b"{}")
                calls.append((self.command, self.path, payload))
                data = {"id": "chat-created"} if self.command == "POST" and self.path == "/api/v1/chats" else True
                body = json.dumps({"code": 0, "data": data}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            do_PATCH = _handle
            do_POST = _handle

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        try:
            env = {
                "RAGFLOW_BASE_URL": f"http://127.0.0.1:{server.server_port}",
                "RAGFLOW_API_KEY": "test-key",
                "RAGFLOW_CHAT_ID": "chat-1",
            }
            refused = self.run_cli("rag", "parse", "--dataset-id", "manuals-v2", "--document-id", "doc-1", "--json", env=env)
            self.assertNotEqual(refused.returncode, 0)
            self.assertEqual(calls, [])

            applied = self.run_cli(
                "rag", "document", "apply", "--dataset-id", "manuals-v2", "--document-id", "doc-1",
                "--profile", "bookstack-markdown-v1", "--page-id", "231",
                "--page-url", "http://book/books/network/page/rtl8367s", "--module", "network",
                "--confirm", "--json", env=env,
            )
            self.assertEqual(applied.returncode, 0, applied.stderr)
            parsed = self.run_cli("rag", "parse", "--dataset-id", "manuals-v2", "--document-id", "doc-1", "--confirm", "--json", env=env)
            self.assertEqual(parsed.returncode, 0, parsed.stderr)
            created = self.run_cli("rag", "chat", "create", "--dataset-id", "manuals-v2", "--confirm", "--json", env=env)
            self.assertEqual(created.returncode, 0, created.stderr)
            self.assertEqual(json.loads(created.stdout)["chat_id"], "chat-created")
            synced = self.run_cli("rag", "chat", "sync", "--dataset-id", "manuals-v2", "--confirm", "--json", env=env)
            self.assertEqual(synced.returncode, 0, synced.stderr)

            self.assertEqual([call[0] for call in calls], ["PATCH", "POST", "POST", "PATCH"])
            self.assertEqual(calls[0][1], "/api/v1/datasets/manuals-v2/documents/doc-1")
            self.assertEqual(calls[0][2]["meta_fields"]["page_id"], "231")
            self.assertEqual(calls[0][2]["parser_config"]["chunk_token_num"], 512)
            self.assertEqual(calls[1][1], "/api/v1/datasets/manuals-v2/chunks")
            self.assertEqual(calls[1][2]["document_ids"], ["doc-1"])
            self.assertEqual(calls[2][1], "/api/v1/chats")
            self.assertEqual(calls[2][2]["dataset_ids"], ["manuals-v2"])
            self.assertIn("{knowledge}", calls[2][2]["prompt_config"]["system"])
            self.assertEqual(calls[3][1], "/api/v1/chats/chat-1")
            self.assertEqual(calls[3][2]["dataset_ids"], ["manuals-v2"])
            self.assertNotIn("test-key", synced.stdout)
        finally:
            server.shutdown()
            server.server_close()

    def test_migration_plan_is_non_destructive(self) -> None:
        result = self.run_cli("rag", "migration-plan", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertFalse(payload["destructive"])
        self.assertEqual(payload["strategy"], "parallel-v2-datasets")
        self.assertTrue(all(item["target_name"].endswith("_v2") for item in payload["datasets"]))
        self.assertIn("do_not_delete_source", payload["safety_rules"])


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = (
    ROOT
    / "skills"
    / "drv-knowledge-ingestion"
    / "resources"
    / "technical-manual-engine"
    / "scripts"
    / "ragflow_sanitize.py"
)
INGEST_CLI = ROOT / "skills" / "drv-knowledge-ingestion" / "scripts" / "ingest_cli.py"


def load_module():
    spec = importlib.util.spec_from_file_location("drv_ragflow_sanitize", SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load sanitizer: {SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RagflowSanitizerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module = load_module() if SCRIPT.exists() else None

    def require_module(self):
        if self.module is None:
            self.skipTest("sanitizer implementation is not present")
        return self.module

    def test_sanitizer_script_exists(self):
        self.assertTrue(SCRIPT.is_file(), f"missing sanitizer implementation: {SCRIPT}")

    def test_pseudo_html_tag_is_escaped_but_real_table_is_preserved(self):
        module = self.require_module()
        source = (
            "escaped = 1<<table\\_out\\_norm\n"
            "literal = 1<<table_out_norm\n"
            "single = 1<table_out_norm\n"
            "hyphen = 1<<table-out\n"
            "dot = 1<<table.field\n"
            "colon = 1<<table:value\n"
            "<table><tr><td>REG_A</td></tr></table>"
        )
        cleaned, changes = module.clean_for_bookstack(source)
        self.assertIn("1&lt;&lt;table\\_out\\_norm", cleaned)
        self.assertIn("1&lt;&lt;table_out_norm", cleaned)
        self.assertIn("1&lt;table_out_norm", cleaned)
        self.assertIn("1&lt;&lt;table-out", cleaned)
        self.assertIn("1&lt;&lt;table.field", cleaned)
        self.assertIn("1&lt;&lt;table:value", cleaned)
        self.assertIn("<table>", cleaned)
        self.assertEqual(changes["pseudo_html_tags"], 6)

    def test_xxx_placeholders_are_never_globally_removed(self):
        module = self.require_module()
        source = "/dev/xxx 0x0XXX19f5 Vx.x.x"
        cleaned, _changes = module.clean_for_bookstack(source)
        self.assertEqual(cleaned, source)

    def test_word_private_bullet_becomes_visible_bullet(self):
        module = self.require_module()
        cleaned, changes = module.clean_for_bookstack("前文 \uf06c 注意事项")
        self.assertEqual(cleaned, "前文 • 注意事项")
        self.assertEqual(changes["private_bullets"], 1)

    def test_only_high_confidence_tripled_ocr_span_is_collapsed(self):
        module = self.require_module()
        source = "wwwuuubbbiiissshhheeennnggg@@@aaaxxxeeerrraaa---ttteeeccchhh...cccooommm /dev/xxx"
        cleaned, changes = module.clean_for_bookstack(source)
        self.assertIn("wubisheng@axera-tech.com", cleaned)
        self.assertIn("/dev/xxx", cleaned)
        self.assertEqual(changes["ocr_triplet_spans"], 1)

    def test_private_and_relative_images_become_ragflow_captions(self):
        module = self.require_module()
        source = '![](http://10.0.0.8/a.png "Pin Map")\n![Clock](./img/clock.png)'
        safe, images = module.clean_for_ragflow(source)
        self.assertNotIn("![", safe)
        self.assertIn("[图示：Pin Map]", safe)
        self.assertIn("[图示：Clock]", safe)
        self.assertEqual([item["kind"] for item in images], ["private_url", "relative"])

    def test_common_markdown_and_html_image_forms_are_parsed_without_tail_corruption(self):
        module = self.require_module()
        source = (
            "![pin](./img/pin_(revA).png)\n"
            "![clock][clock-map]\n"
            "[clock-map]: ./img/clock.png \"Clock map\"\n"
            "<img src=./img/bare.png alt=BarePin>\n"
            "<img src=\"./img/compare.png\" alt=\"A > B\">\n"
        )
        safe, images = module.clean_for_ragflow(source)
        self.assertNotIn(".png)", safe)
        self.assertNotIn("![", safe)
        self.assertIn("[图示：pin]", safe)
        self.assertIn("[图示：clock]", safe)
        self.assertIn("[图示：BarePin]", safe)
        self.assertIn("[图示：A > B]", safe)
        self.assertNotIn(' B">', safe)
        self.assertEqual(
            [item["url"] for item in images],
            ["./img/pin_(revA).png", "./img/clock.png", "./img/bare.png", "./img/compare.png"],
        )

    def test_code_examples_are_not_cleaned_as_live_markdown_or_html(self):
        module = self.require_module()
        source = (
            "```markdown\n"
            "![example](http://10.0.0.8/a.png)\n"
            "<table><tr><td>EXAMPLE</td></tr></table>\n"
            "<a name=\"same\"></a><a name=\"same\"></a>\n"
            "```\n\n"
            "![real](./real.png)\n"
        )
        result = module.build_ragflow_body(source, soft_limit=1800, hard_limit=2200)
        self.assertIn("![example](http://10.0.0.8/a.png)", result["body"])
        self.assertIn("<table><tr><td>EXAMPLE</td></tr></table>", result["body"])
        self.assertEqual(result["body"].count('<a name="same"></a>'), 2)
        self.assertNotIn("![real](./real.png)", result["body"])
        self.assertEqual(len(result["images"]), 1)

    def test_html_attribute_greater_than_does_not_leak_attribute_tail(self):
        module = self.require_module()
        source = '<span title="A > B">REG</span>\n<p style="x > y">TEXT</p>'
        result = module.build_ragflow_body(source, soft_limit=1800, hard_limit=2200)
        self.assertIn("<span>REG</span>", result["body"])
        self.assertIn("<p>TEXT</p>", result["body"])
        self.assertNotIn(' B">', result["body"])
        self.assertNotIn(' y">', result["body"])

    def test_html_table_is_row_oriented_and_atoms_stay_under_limit(self):
        module = self.require_module()
        source = "<table>" + "".join(
            f"<tr><td>REG_{index}</td><td>{'数值' * 80}</td></tr>" for index in range(40)
        ) + "</table>"
        result = module.build_ragflow_body(source, soft_limit=1800, hard_limit=2200)
        self.assertLessEqual(max(map(len, result["atoms"])), 2200)
        self.assertIn("REG_39", result["body"])
        self.assertNotIn("<table", result["body"].lower())

    def test_markdown_table_does_not_split_pipe_inside_inline_code(self):
        module = self.require_module()
        source = "| Register | Expression |\n| --- | --- |\n| CTRL | `REG[3:0] = A|B` |"
        result = module.build_ragflow_body(source, soft_limit=1800, hard_limit=2200)
        self.assertIn("`REG[3:0] = A|B`", result["body"])
        self.assertNotIn("`REG[3:0] = A | B`", result["body"])

    def test_html_table_preserves_caption_and_mixed_header_row(self):
        module = self.require_module()
        source = (
            "<table title=\"A > B\"><caption>Clock source selection</caption>"
            "<tr><th>Bit</th><td>Description</td></tr>"
            "<tr><td>7:4</td><td>CLK_SEL</td></tr></table>"
        )
        result = module.build_ragflow_body(source, soft_limit=1800, hard_limit=2200)
        self.assertIn("表题：Clock source selection", result["body"])
        self.assertIn("- 表头：Bit | Description", result["body"])
        self.assertIn("- 行 2：7:4 | CLK_SEL", result["body"])

    def test_nested_html_table_preserves_outer_and_inner_visible_text(self):
        module = self.require_module()
        source = (
            "<table><tr><td>OUTER_BEFORE"
            "<table><tr><td>INNER</td></tr></table>"
            "OUTER_AFTER</td></tr></table>"
        )
        result = module.build_ragflow_body(source, soft_limit=1800, hard_limit=2200)
        self.assertIn("OUTER_BEFORE", result["body"])
        self.assertIn("INNER", result["body"])
        self.assertIn("OUTER_AFTER", result["body"])

    def test_hard_limit_cannot_be_raised_above_safe_ceiling(self):
        module = self.require_module()
        with self.assertRaises(module.SanitizeError):
            module.build_ragflow_body("X" * 3000, soft_limit=3000, hard_limit=5000)

    def test_preflight_detects_multiline_protected_atoms_and_reference_images(self):
        module = self.require_module()
        source_text = (
            "```text\n" + ("F" * 100 + "\n") * 30 + "```\n\n"
            "<table>\n" + ("<tr><td>" + "T" * 100 + "</td></tr>\n") * 30 + "</table>\n\n"
            "![pin][map]\n[map]: ./pin.png\n"
        )
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "manual.md"
            source.write_text(source_text, encoding="utf-8")
            audit = module.audit_source(source)
            self.assertTrue(audit["requires_sanitization"])
            self.assertIn("protected_atom_over_hard_limit", audit["risks"])
            self.assertIn("non_public_images", audit["risks"])
            self.assertGreater(audit["protected_atoms"]["max_chars"], 2200)

    def test_oversized_single_code_line_is_rejected_without_truncation(self):
        module = self.require_module()
        with self.assertRaises(module.SanitizeError):
            module.build_ragflow_body("```c\n" + "A" * 2300 + "\n```", 1800, 2200)

    def test_plain_text_split_never_creates_an_accidental_fence(self):
        module = self.require_module()
        source = ("A" * 1800) + "``` literal marker " + ("后续说明 " * 500)
        result = module.build_ragflow_body(source, soft_limit=1800, hard_limit=2200)
        atoms = module._structural_atoms_from_output(result["body"], "synthetic")
        self.assertLessEqual(max(map(len, atoms)), 2200)
        self.assertIn("&#96;&#96;&#96; literal marker", result["body"])

    def test_clean_document_is_non_destructive_and_gate_reconstructs_body(self):
        module = self.require_module()
        source_text = (
            "# Manual\n\n"
            "value = 1<<table\\_out\\_norm\n\n"
            "![](http://10.0.0.8/a.png \"Pin Map\")\n\n"
            + "说明。" * 1500
        )
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "manual.md"
            output = root / "out"
            source.write_text(source_text, encoding="utf-8")
            source_hash = hashlib.sha256(source.read_bytes()).hexdigest()

            audit = module.clean_document(source, output, shard_limit=8192)
            gate = module.gate_output(output)

            self.assertEqual(audit["result"], "PASS")
            self.assertEqual(gate["result"], "PASS")
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), source_hash)
            self.assertTrue((output / "document.cleaned.md").is_file())
            self.assertTrue((output / "images.jsonl").is_file())
            self.assertGreater(len(list((output / "ragflow").glob("part-*.md"))), 1)
            self.assertTrue(all(path.stat().st_size <= 8192 for path in (output / "ragflow").glob("part-*.md")))
            saved_audit = json.loads((output / "audit.json").read_text(encoding="utf-8"))
            self.assertEqual(saved_audit["result"], "PASS")
            self.assertEqual(
                saved_audit["artifacts"]["document_cleaned"]["sha256"],
                hashlib.sha256((output / "document.cleaned.md").read_bytes()).hexdigest(),
            )
            self.assertEqual(
                saved_audit["artifacts"]["images_jsonl"]["sha256"],
                hashlib.sha256((output / "images.jsonl").read_bytes()).hexdigest(),
            )

            (output / "document.cleaned.md").write_text("tampered\n", encoding="utf-8")
            with self.assertRaises(module.SanitizeError):
                module.gate_output(output)

    def test_ocr_transform_ledger_has_line_and_before_after_hashes(self):
        module = self.require_module()
        source_text = "# E2\n\nwwwuuubbbiiissshhheeennnggg@@@aaaxxxeeerrraaa---ttteeeccchhh...cccooommm"
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "e2.md"
            output = root / "out"
            source.write_text(source_text, encoding="utf-8")
            audit = module.clean_document(source, output, shard_limit=8192)
            entries = audit["transform_ledger"]["ocr_triplet_spans"]
            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0]["line"], 3)
            self.assertEqual(len(entries[0]["before_sha256"]), 64)
            self.assertEqual(len(entries[0]["after_sha256"]), 64)
            self.assertGreater(entries[0]["before_chars"], entries[0]["after_chars"])

    def test_clean_document_applies_ocr_collapse_exactly_once(self):
        module = self.require_module()
        source_text = "".join(char * 9 for char in "abcdefghijkl")
        expected_once = "".join(char * 3 for char in "abcdefghijkl")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "manual.md"
            output = root / "out"
            source.write_text(source_text, encoding="utf-8")
            audit = module.clean_document(source, output, shard_limit=8192)
            part = next((output / "ragflow").glob("part-*.md")).read_text(encoding="utf-8")
            body = module.FRONT_MATTER_RE.sub("", part, count=1).strip()
            self.assertEqual(body, expected_once)
            self.assertEqual(len(audit["transform_ledger"]["ocr_triplet_spans"]), 1)

    def test_ingest_cli_sanitize_manual_runs_offline(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "manual.md"
            output = root / "sanitized"
            source.write_text("# Manual\n\n" + "寄存器说明。" * 600, encoding="utf-8")
            result = subprocess.run(
                [
                    sys.executable,
                    str(INGEST_CLI),
                    "sanitize-manual",
                    str(source),
                    str(output),
                    "--shard-limit",
                    "8192",
                ],
                cwd=ROOT,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
            )
            self.assertEqual(result.returncode, 0, result.stderr or result.stdout)
            payload = json.loads(result.stdout)
            self.assertEqual(payload["result"], "PASS")
            self.assertTrue((output / "audit.json").is_file())

    def test_batch_writes_complete_sha256_manifest(self):
        module = self.require_module()
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source_dir = root / "source"
            output_dir = root / "output"
            source_dir.mkdir()
            (source_dir / "manual.md").write_text(
                "# Manual\n\n" + "寄存器说明。" * 600,
                encoding="utf-8",
            )

            module.clean_batch(
                source_dir,
                output_dir,
                ["manual.md"],
                soft_limit=1800,
                hard_limit=2200,
                shard_limit=8192,
            )

            manifest_path = output_dir / "SHA256SUMS.json"
            self.assertTrue(manifest_path.is_file())
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            files = manifest["files"]
            self.assertIn("manual/audit.json", files)
            self.assertIn("manual/ragflow/part-0001.md", files)
            self.assertEqual(
                files["manual/audit.json"],
                hashlib.sha256((output_dir / "manual" / "audit.json").read_bytes()).hexdigest(),
            )

    def test_batch_rejects_duplicate_selected_basenames(self):
        module = self.require_module()
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source_dir = root / "source"
            for branch, body in (("a", "FROM_A"), ("b", "FROM_B")):
                folder = source_dir / branch
                folder.mkdir(parents=True)
                (folder / "manual.md").write_text(body, encoding="utf-8")
            with self.assertRaises(module.SanitizeError):
                module.clean_batch(
                    source_dir,
                    root / "output",
                    ["manual.md"],
                    soft_limit=1800,
                    hard_limit=2200,
                    shard_limit=8192,
                )

    def test_gate_recomputes_projection_instead_of_trusting_self_hashed_parts(self):
        module = self.require_module()
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source = root / "manual.md"
            output = root / "out"
            source.write_text("# Manual\n\nREGISTER_A description", encoding="utf-8")
            module.clean_document(source, output, shard_limit=8192)

            part_path = next((output / "ragflow").glob("part-*.md"))
            part_text = part_path.read_text(encoding="utf-8").replace("REGISTER_A", "REGISTER_B")
            part_path.write_text(part_text, encoding="utf-8", newline="\n")
            audit_path = output / "audit.json"
            audit = json.loads(audit_path.read_text(encoding="utf-8"))
            audit["ragflow"]["parts"][0]["sha256"] = hashlib.sha256(part_path.read_bytes()).hexdigest()
            audit["ragflow"]["parts"][0]["bytes"] = part_path.stat().st_size
            body = module.FRONT_MATTER_RE.sub("", part_text, count=1).strip() + "\n"
            audit["ragflow"]["body_sha256"] = hashlib.sha256(body.encode("utf-8")).hexdigest()
            audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

            with self.assertRaises(module.SanitizeError):
                module.gate_output(output)


if __name__ == "__main__":
    unittest.main(verbosity=2)

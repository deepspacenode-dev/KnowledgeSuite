#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULES = ("bs4", "docx", "pptx", "fitz", "pdfplumber", "PIL")


def bash_executable() -> str | None:
    if os.name != "nt":
        return None
    candidates = (
        shutil.which("bash"),
        str(Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Git" / "bin" / "bash.exe"),
    )
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return candidate
    raise RuntimeError("Git Bash is required to test install.sh on Windows")


def shell_command(script: Path, *args: object) -> list[str]:
    command = [str(script), *map(str, args)]
    bash = bash_executable()
    return [bash, *command] if bash else command


def shell(*args, env=None):
    env = (env or os.environ).copy()
    env.setdefault("PYTHON", sys.executable.replace("\\", "/"))
    return subprocess.run(
        shell_command(ROOT / "install.sh", *args),
        cwd=ROOT,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def fake_full_env(base: Path, missing: set[str] | None = None) -> dict[str, str]:
    missing = missing or set()
    site = base / "fake-site"
    for module in MODULES:
        if module in missing:
            continue
        package = site / module
        package.mkdir(parents=True, exist_ok=True)
        (package / "__init__.py").write_text("", encoding="utf-8")
    pip_package = site / "pip"
    pip_package.mkdir(parents=True, exist_ok=True)
    (pip_package / "__init__.py").write_text("", encoding="utf-8")
    (pip_package / "__main__.py").write_text("raise SystemExit(99)\n", encoding="utf-8")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(site) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    return env


def finish(checks: list[str]) -> int:
    validator=subprocess.run([sys.executable,str(ROOT/"tools/install/validate_commands.py"),str(ROOT/"commands/kb"),"--expected","12"],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert validator.returncode == 0, validator.stderr+validator.stdout
    checks.append("command_validation_12")

    installer=(ROOT/"install.sh").read_text(encoding="utf-8")
    assert "-m pip" not in installer and "--offline" not in installer and "--deps" not in installer and "--wheel-dir" not in installer
    assert not (ROOT/"offline").exists() and not (ROOT/"requirements/offline.lock.txt").exists()
    checks.append("release_contains_no_dependency_bundle_or_pip_install_path")

    print(json.dumps({"result":"PASS","total":len(checks),"checks":checks},ensure_ascii=False,indent=2))
    return 0


def main() -> int:
    checks = []

    with tempfile.TemporaryDirectory() as td:
        base = Path(td); target, runtime, bindir = base/"cb", base/"runtime", base/"bin"
        r = shell("--plan", "--target", target, "--runtime-dir", runtime, "--bin-dir", bindir)
        assert r.returncode == 0 and "Profile            retrieval" in r.stdout and "/kb:* (11 expected)" in r.stdout
        assert "never pip install" in r.stdout and not target.exists() and not runtime.exists() and not bindir.exists()
        r = shell("--plan", "--full", "--target", target, "--runtime-dir", runtime, "--bin-dir", bindir)
        assert r.returncode == 0 and "Profile            full" in r.stdout and "/kb:* (12 expected)" in r.stdout
        checks.append("plans_are_read_only_and_use_kb_namespace")

    if os.name == "nt":
        checks.append("linux_install_mutations_skipped_on_windows")
        return finish(checks)

    with tempfile.TemporaryDirectory() as td:
        base=Path(td); target, runtime, bindir=base/"cb", base/"runtime", base/"bin"
        # Simulate V1.0.7 legacy commands plus a user custom command that must survive migration.
        legacy=target/"commands/knowledge"; legacy.mkdir(parents=True)
        (legacy/"cases.md").write_text("suite-old",encoding="utf-8")
        (legacy/"my-custom.md").write_text("user-custom",encoding="utf-8")
        r=shell("--no-verify","--no-bootstrap","--target",target,"--runtime-dir",runtime,"--bin-dir",bindir)
        assert r.returncode == 10, r.stderr+"\n"+r.stdout
        assert (bindir/"kb").is_file() and not (bindir/"drvkr").exists() and not (bindir/"drvki").exists()
        assert not (target/"skills/drv-knowledge-ingestion").exists()
        assert len(list((target/"commands/kb").glob("*.md"))) == 11
        assert not (legacy/"cases.md").exists() and (legacy/"my-custom.md").read_text(encoding="utf-8") == "user-custom"
        assert "DRVKB_INSTALL_PROFILE=retrieval" in (runtime/".env").read_text(encoding="utf-8")
        env=os.environ.copy(); env["DRVKB_RUNTIME_DIR"]=str(runtime)
        doctor=subprocess.run(shell_command(bindir/"kb","doctor","--json"),env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert doctor.returncode == 0 and json.loads(doctor.stdout)["profile"] == "retrieval"
        checks.append("fresh_retrieval_install_migrates_known_legacy_commands_only")

        uninstall=shell("--uninstall","--target",target,"--runtime-dir",runtime,"--bin-dir",bindir)
        assert uninstall.returncode == 0 and (runtime/".env").is_file() and not (bindir/"kb").exists()
        assert (legacy/"my-custom.md").is_file()
        checks.append("uninstall_preserves_config_and_custom_commands")

    with tempfile.TemporaryDirectory() as td:
        base=Path(td); target, runtime, bindir=base/"cb", base/"runtime", base/"bin"
        env=fake_full_env(base)
        r=shell("--no-verify","--full","--no-bootstrap","--target",target,"--runtime-dir",runtime,"--bin-dir",bindir,env=env)
        assert r.returncode == 10, r.stderr+"\n"+r.stdout
        assert (target/"skills/drv-knowledge-ingestion").is_dir()
        assert len(list((target/"commands/kb").glob("*.md"))) == 12
        assert "DRVKB_INSTALL_PROFILE=full" in (runtime/".env").read_text(encoding="utf-8")
        assert "6 / 6 required ingestion plugins PASS" in r.stdout
        env["DRVKB_RUNTIME_DIR"]=str(runtime)
        doctor=subprocess.run(shell_command(bindir/"kb","doctor","--json"),env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        payload=json.loads(doctor.stdout)
        assert doctor.returncode == 0 and payload["profile"] == "full" and "ingestion" in payload["components"]
        checks.append("full_install_requires_preexisting_plugins_and_registers_12")

        r=shell("--no-verify","--no-bootstrap","--target",target,"--runtime-dir",runtime,"--bin-dir",bindir,env=env)
        assert r.returncode == 10, r.stderr+"\n"+r.stdout
        assert not (target/"skills/drv-knowledge-ingestion").exists()
        assert len(list((target/"commands/kb").glob("*.md"))) == 11
        checks.append("profile_switch_full_to_retrieval")

    # Upgrade regression: old installed core must not shadow staged core.
    with tempfile.TemporaryDirectory() as td:
        base=Path(td); home=base/"home"; target=home/".codebuddy"; runtime=base/"runtime"; bindir=base/"bin"
        old_core=target/"lib/drv_knowledge_core"; old_core.mkdir(parents=True)
        (old_core/"__init__.py").write_text("",encoding="utf-8")
        (old_core/"runtime.py").write_text("CONFIG_PATH=None\ndef load_dotenv(*a,**k): return None\ndef dataset_map(*a,**k): return {}\ndef getenv(*a,**k): return None\ndef get_bool(*a,**k): return False\ndef get_int(*a,**k): return 0\n",encoding="utf-8")
        env=os.environ.copy(); env["HOME"]=str(home)
        r=shell("--no-verify","--no-bootstrap","--target",target,"--runtime-dir",runtime,"--bin-dir",bindir,env=env)
        assert r.returncode == 10, r.stderr+"\n"+r.stdout
        assert (target/"lib/drv_knowledge_core/source_metadata.py").is_file()
        checks.append("upgrade_old_core_does_not_shadow_stage")

    return finish(checks)


if __name__=="__main__": raise SystemExit(main())

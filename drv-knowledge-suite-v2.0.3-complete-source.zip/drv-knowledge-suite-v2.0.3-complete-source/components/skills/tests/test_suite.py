#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULES = ("bs4", "docx", "pptx", "fitz", "pdfplumber", "PIL")


def run(*args, env=None):
    merged = os.environ.copy()
    if env:
        merged.update(env)
    merged["PYTHONUTF8"] = "1"
    merged["PYTHONIOENCODING"] = "utf-8"
    return subprocess.run([sys.executable,*map(str,args)],cwd=ROOT,env=merged,text=True,encoding="utf-8",stdout=subprocess.PIPE,stderr=subprocess.PIPE)


def fake_full_environment(root: Path) -> dict[str,str]:
    site=root/"fake-site"
    for module in MODULES:
        package=site/module; package.mkdir(parents=True,exist_ok=True); (package/"__init__.py").write_text("",encoding="utf-8")
    pip_package=site/"pip"; pip_package.mkdir(parents=True,exist_ok=True)
    (pip_package/"__init__.py").write_text("",encoding="utf-8")
    (pip_package/"__main__.py").write_text("raise SystemExit(99)\n",encoding="utf-8")
    env=os.environ.copy(); env["PYTHONPATH"]=str(site)+(os.pathsep+env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    return env


def main()->int:
    checks=[]
    for relative in ["skills/drv-knowledge-router/VERSION","skills/drv-knowledge-retrieval/VERSION","skills/drv-knowledge-ingestion/VERSION","VERSION"]:
        assert (ROOT/relative).read_text(encoding="utf-8").strip()=="2.0.3"
        checks.append("version:"+relative)

    with tempfile.TemporaryDirectory() as td:
        runtime=Path(td)/"runtime"
        retrieval_env={"DRVKB_RUNTIME_DIR":str(runtime),"DRVKB_INSTALL_PROFILE":"retrieval"}
        full_env=fake_full_environment(Path(td)); full_env.update({"DRVKB_RUNTIME_DIR":str(runtime),"DRVKB_INSTALL_PROFILE":"full"})

        r=run(ROOT/"tools/cli/kb.py","command","/kb:cases","--resolve-only",env=retrieval_env)
        p=json.loads(r.stdout); assert r.returncode==0 and p["target"]=="retrieval" and not p.get("deprecated")
        checks.append("route_kb_colon_retrieval")

        r=run(ROOT/"tools/cli/kb.py","command","/kb cases","--resolve-only",env=retrieval_env)
        assert r.returncode==0 and json.loads(r.stdout)["target"]=="retrieval"
        checks.append("route_kb_space_retrieval")

        r=run(ROOT/"tools/cli/kb.py","command","/knowledge:cases","--resolve-only",env=retrieval_env)
        p=json.loads(r.stdout); assert p["target"]=="retrieval" and p["deprecated"] is True and "/kb:cases" in p["deprecation"]
        checks.append("legacy_knowledge_cases_deprecated")

        r=run(ROOT/"tools/cli/kb.py","command","/knowledge:query PHY","--resolve-only",env=retrieval_env)
        p=json.loads(r.stdout); assert p["command"]=="search PHY" and "/kb:search" in p["deprecation"]
        checks.append("legacy_query_aliases_search")

        r=run(ROOT/"tools/cli/kb.py","command","/kb:ingest experience","--resolve-only",env=retrieval_env)
        assert r.returncode==0 and json.loads(r.stdout)["target"]=="unsupported"
        checks.append("retrieval_rejects_ingestion")

        r=run(ROOT/"tools/cli/kb.py","command","/kb:ingest experience","--resolve-only",env=full_env)
        assert r.returncode==0 and json.loads(r.stdout)["target"]=="ingestion"
        checks.append("full_routes_ingestion")

        r=run(ROOT/"tools/cli/kb.py","command","/knowledge:ingest-preview S1","--resolve-only",env=full_env)
        p=json.loads(r.stdout); assert p["target"]=="ingestion" and p["command"]=="preview S1" and "/kb:ingest preview" in p["deprecation"]
        checks.append("legacy_ingest_flat_alias")

        r=run(ROOT/"tools/cli/kb.py","ask","-q","帮我找到目前库上所有案例内容","--resolve-only",env=retrieval_env)
        assert json.loads(r.stdout)["target"]=="retrieval"
        checks.append("intent_cases")

    r=run(ROOT/"tools/cli/drvkr.py","selftest","--json")
    assert r.returncode==0, r.stderr; checks.append("retrieval_selftest")

    with tempfile.TemporaryDirectory() as td:
        r=run(ROOT/"tools/cli/drvki.py","selftest",env={"DRVKI_WORKSPACE":td})
        assert r.returncode==0, r.stderr; checks.append("ingestion_selftest")

    with tempfile.TemporaryDirectory() as td:
        base=Path(td); target,runtime,bindir=base/"codebuddy",base/"runtime",base/"bin"
        # Seed a custom old namespace file; Python compatibility installer must preserve it.
        legacy=target/"commands/knowledge"; legacy.mkdir(parents=True)
        (legacy/"cases.md").write_text("old-suite",encoding="utf-8")
        (legacy/"custom.md").write_text("custom",encoding="utf-8")
        r=run(ROOT/"install.py","--no-verify","--profile","retrieval","--target",target,"--runtime-dir",runtime,"--bin-dir",bindir,"--no-bootstrap","--strict")
        assert r.returncode==0, r.stderr+"\n"+r.stdout
        assert (runtime/".env").is_file() and (bindir/"kb").is_file() and (target/"lib/drv_knowledge_core").is_dir()
        assert not (target/"skills/drv-knowledge-ingestion").exists()
        assert len(list((target/"commands/kb").glob("*.md")))==11
        assert (legacy/"custom.md").is_file() and not (legacy/"cases.md").exists()
        checks.append("fresh_python_install_retrieval_kb_namespace")

    with tempfile.TemporaryDirectory() as td:
        base=Path(td); target,runtime,bindir=base/"codebuddy",base/"runtime",base/"bin"; env=fake_full_environment(base)
        env["PYTHONUTF8"]="1"; env["PYTHONIOENCODING"]="utf-8"
        r=subprocess.run([sys.executable,str(ROOT/"install.py"),"--no-verify","--full","--target",str(target),"--runtime-dir",str(runtime),"--bin-dir",str(bindir),"--no-bootstrap","--strict"],cwd=ROOT,env=env,text=True,encoding="utf-8",stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert r.returncode==0, r.stderr+"\n"+r.stdout
        assert (target/"skills/drv-knowledge-ingestion").is_dir() and len(list((target/"commands/kb").glob("*.md")))==12
        assert "6 / 6 required ingestion plugins ready" in r.stdout
        checks.append("fresh_python_install_full_check_only")

    print(json.dumps({"result":"PASS","total":len(checks),"checks":checks},ensure_ascii=False,indent=2))
    return 0


if __name__=='__main__': raise SystemExit(main())

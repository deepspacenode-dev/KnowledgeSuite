from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "lib"))

from drv_knowledge_core.source_metadata import inject_page_identity


class SourceMetadataContractV2Tests(unittest.TestCase):
    def test_front_matter_keeps_source_key_and_content_ref_distinct(self) -> None:
        markdown = inject_page_identity(
            "---\nstatus: draft\n---\n\n# Demo\n",
            page_id=42,
            page_url="http://bookstack.internal/books/net/page/demo",
        )
        self.assertIn("source_key: bookstack_page:42", markdown)
        self.assertIn("content_ref: bookstack:page:42", markdown)


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parents[1]
sys.path.insert(0, str(ROOT / "lib"))
sys.path.insert(0, str(REPO_ROOT))

from contracts.tools.validate import validate_contract  # noqa: E402
from drv_knowledge_core.knowledge_bundle_v2 import convert_legacy_bundle  # noqa: E402


class KnowledgeBundleV2Tests(unittest.TestCase):
    def test_recall_pipeline_exposes_v2_and_legacy_warning(self) -> None:
        entry = ROOT / "skills" / "drv-knowledge-retrieval" / "scripts" / "drvkb_entry.py"
        with tempfile.TemporaryDirectory() as tmp:
            env = os.environ.copy()
            env.update({"DRVKB_RUNTIME_DIR": tmp, "RAGFLOW_BASE_URL": "", "RAGFLOW_API_KEY": ""})
            result = subprocess.run(
                [sys.executable, "-B", "-X", "utf8", str(entry), "recall", "-q", "PHY link up 无流量", "--mode", "fixture", "--json"],
                cwd=ROOT,
                env=env,
                text=True,
                encoding="utf-8",
                errors="strict",
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        validate_contract(payload["knowledge_bundle_v2"])
        self.assertTrue(payload["knowledge_bundle_v2"]["items"])
        self.assertIn("deprecated", payload["compatibility_warnings"][0])

    def test_converts_bookstack_result_and_uses_governance_status(self) -> None:
        legacy = {
            "contract_version": "knowledge-bundle-v3",
            "request_id": "KB-123",
            "task_summary": "PHY link up 无流量",
            "task_type": "diagnosis",
            "items": [{
                "type": "case",
                "title": "RGMII 时序案例",
                "page_id": "42",
                "page_url": "http://bookstack.local/books/cases/page/rgmii",
                "source_key": "bookstack:page:42",
                "source_kind": "ragflow",
                "dataset": "cases",
                "document_id": "doc-42",
                "summary": "RGMII delay 配置错误。",
                "confidence": 0.91,
                "status": "verified",
                "module": "network",
                "reason": "症状匹配",
                "engineering_summary": {"overview": "检查 RGMII delay。"},
            }],
            "conflicts": [],
            "missing_info": [],
            "suggested_next_action": ["检查 delay"],
        }
        bundle = convert_legacy_bundle(
            legacy,
            knowledge_status="ok",
            recall_mode="live",
            trace_id="trace-recall-001",
            generated_at="2026-08-30T08:00:00Z",
            governance_statuses={"bookstack:page:42": "reviewed"},
        )
        validate_contract(bundle)
        item = bundle["items"][0]
        self.assertEqual(item["content_ref"], "bookstack:page:42")
        self.assertEqual(item["source"]["source_key"], "bookstack_page:42")
        self.assertEqual(item["status"], "reviewed")

    def test_local_manual_remains_available_offline(self) -> None:
        legacy = {
            "contract_version": "knowledge-bundle-v3",
            "request_id": "KB-local",
            "task_summary": "查询寄存器",
            "task_type": "manual_lookup",
            "items": [{
                "type": "manual",
                "title": "本地芯片手册",
                "page_url": "file:///opt/manuals/chip.md",
                "source_key": "local_manual:chip.md",
                "source_kind": "local_manual",
                "local_path": "/opt/manuals/chip.md",
                "summary": "寄存器定义。",
                "confidence": 0.7,
                "reason": "本地匹配",
            }],
            "conflicts": [],
            "missing_info": [],
            "suggested_next_action": [],
        }
        bundle = convert_legacy_bundle(
            legacy,
            knowledge_status="degraded",
            recall_mode="local",
            trace_id="trace-local-0001",
            generated_at="2026-08-30T08:00:00Z",
        )
        validate_contract(bundle)
        self.assertEqual(bundle["items"][0]["source"]["system"], "local_manual")
        self.assertEqual(bundle["items"][0]["status"], "unknown")


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
from pathlib import Path
import importlib.util, traceback
P=Path(__file__).resolve().parent/'test_retrieval.py'
spec=importlib.util.spec_from_file_location('test_retrieval',P); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
tests=[]
for n in dir(m):
    if n.startswith('test_') and callable(getattr(m,n)) and not n.startswith('test_manual_'):
        tests.append((n,getattr(m,n)))
failed=0
for n,f in tests:
    try:
        f(); print('PASS',n)
    except Exception:
        failed+=1; print('FAIL',n); traceback.print_exc()
print(f'RETRIEVAL_SUMMARY total={len(tests)} failed={failed}')
raise SystemExit(1 if failed else 0)

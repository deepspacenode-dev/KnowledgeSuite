from __future__ import annotations

import contextlib
import importlib.util
import io
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "lib"))
SCRIPT = ROOT / "skills" / "drv-knowledge-ingestion" / "scripts" / "ingest_cli.py"


def load_ingest_module():
    spec = importlib.util.spec_from_file_location("drv_ingest_v2_test", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


class FakeBookStack:
    base = "http://bookstack.local"

    def find_book(self, name):
        return {"id": 5, "name": name, "slug": "ai-cases"}

    def find_chapter(self, name, book_id):
        return {"id": 6, "name": name}

    def create_page(self, title, content, book, chapter):
        return {"id": 42, "url": "http://bookstack.local/books/ai-cases/page/example", "slug": "example"}

    def update_page(self, page_id, title, content):
        self.updated = (page_id, title, content)

    def delete_page(self, page_id):
        raise AssertionError("rollback is not expected")


class IngestionV2FlowTests(unittest.TestCase):
    def make_session(self, root: Path) -> Path:
        session = root / "session-001"
        session.mkdir()
        (session / "content.md").write_text(
            "---\nstatus: draft\nrag_enabled: false\n---\n\n# 诊断案例\n",
            encoding="utf-8",
        )
        (session / "state.json").write_text(json.dumps({
            "schema_version": 1,
            "session_id": "session-001",
            "version": "2.0.0",
            "state": "LOCAL_DRAFT",
            "title": "诊断案例",
            "material_type": "cases",
            "bookstack": {},
            "approval": {},
            "rag": {},
            "history": [],
        }, ensure_ascii=False), encoding="utf-8")
        return session

    def test_submit_queues_intake_when_governance_is_offline(self) -> None:
        ingest = load_ingest_module()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            session = self.make_session(root)
            outbox_path = root / "outbox.sqlite3"
            ingest.BookStack = FakeBookStack
            ingest.default_outbox_path = lambda: outbox_path

            class OfflineClient:
                @classmethod
                def from_environment(cls):
                    return cls()

                def submit_intake(self, payload):
                    return {"ok": False, "status": 0, "message": "offline"}

            ingest.GovernanceV2Client = OfflineClient
            args = types.SimpleNamespace(session=str(session), confirm=True, book="案例", chapter=None)
            stream = io.StringIO()
            with contextlib.redirect_stdout(stream):
                ingest.cmd_submit(args)

            output = json.loads(stream.getvalue())
            state = json.loads((session / "state.json").read_text(encoding="utf-8"))
            self.assertEqual(output["governance_sync"], "pending")
            self.assertEqual(state["governance"]["outbox_state"], "retry_wait")
            self.assertEqual(state["governance"]["content_ref"], "bookstack:page:42")
            self.assertTrue(outbox_path.exists())

    def test_refresh_uses_governance_status_as_authority(self) -> None:
        ingest = load_ingest_module()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            session = self.make_session(root)
            state_path = session / "state.json"
            state = json.loads(state_path.read_text(encoding="utf-8"))
            state["state"] = "BOOKSTACK_PENDING_REVIEW"
            state["bookstack"] = {"page_id": 42, "page_url": "http://bookstack.local/books/ai-cases/page/example"}
            state["governance"] = {"content_ref": "bookstack:page:42", "source_key": "bookstack_page:42"}
            state_path.write_text(json.dumps(state), encoding="utf-8")
            ingest.default_outbox_path = lambda: root / "outbox.sqlite3"

            class StatusClient:
                @classmethod
                def from_environment(cls):
                    return cls()

                def ready(self):
                    return True

                def submit_intake(self, payload):
                    raise AssertionError("no queued intake should be present")

                def resolve_status(self, content_refs):
                    self.requested = content_refs
                    return {"ok": True, "status": 200, "data": {
                        "schema_version": "drvknowledge.governance-status.v2",
                        "trace_id": "trace-status-001",
                        "generated_at": "2026-08-30T08:03:00Z",
                        "items": [{
                            "content_ref": "bookstack:page:42",
                            "source_key": "bookstack_page:42",
                            "asset_id": 7,
                            "compile_status": "succeeded",
                            "review_status": "verified",
                            "rag_status": "ready",
                            "quality_score": 92,
                            "updated_at": "2026-08-30T08:03:00Z",
                        }],
                        "unresolved": [],
                    }}

            ingest.GovernanceV2Client = StatusClient
            args = types.SimpleNamespace(session=str(session), refresh=True)
            stream = io.StringIO()
            with contextlib.redirect_stdout(stream):
                ingest.cmd_status(args)
            output = json.loads(stream.getvalue())
            saved = json.loads(state_path.read_text(encoding="utf-8"))
            self.assertEqual(output["state"], "RAG_READY")
            self.assertEqual(output["governance_status"]["review_status"], "verified")
            self.assertEqual(saved["approval"]["status"], "verified")
            self.assertEqual(saved["rag"]["status"], "ready")


if __name__ == "__main__":
    unittest.main()

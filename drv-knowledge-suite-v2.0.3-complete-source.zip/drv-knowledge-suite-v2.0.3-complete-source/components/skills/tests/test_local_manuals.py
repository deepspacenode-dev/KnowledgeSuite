#!/usr/bin/env python3
from __future__ import annotations
import json, os, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SKILL=ROOT/'skills/drv-knowledge-retrieval'

def main():
    checks=[]
    with tempfile.TemporaryDirectory() as td:
        base=Path(td); runtime=base/'runtime'; manuals=runtime/'manuals/02_网络与通信芯片'; manuals.mkdir(parents=True)
        manual=manuals/'RTL8367S_本地手册.md'
        manual.write_text('''---\ntitle: RTL8367S 本地手册\nchip: rtl8367s\nmodule: network\n---\n# RTL8367S 本地手册\n\n## PHY Register 0\nBCR bit 12 controls Auto-Negotiation enable.\n\n## RGMII Delay\nRGMII RX/TX delay 用于 MAC 与 PHY 时序调整。PHY Link Up 但无流量时应核对 RGMII delay 配置。\n''',encoding='utf-8')
        env=os.environ.copy(); env['DRVKB_RUNTIME_DIR']=str(runtime); env['DRVKNOWLEDGE_RUNTIME_DIR']=str(runtime)
        entry=SKILL/'scripts/drvkb_entry.py'
        # Local browse works with no RAGFlow credentials.
        p=subprocess.run([sys.executable,str(entry),'manuals','RTL8367S','--refresh','--json'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert p.returncode==0, p.stderr+'\n'+p.stdout
        b=json.loads(p.stdout); assert b['ok'] and b['local_manuals']['documents']==1 and any(x.get('source_kind')=='local_manual' for x in b['items'])
        checks.append('local_manual_browse_without_ragflow')
        # Recall falls back to local manual even when RAGFlow is not configured.
        p=subprocess.run([sys.executable,str(entry),'recall','-q','RTL8367S PHY link up 无流量 RGMII delay 怎么配置','--json'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert p.returncode==0, p.stderr+'\n'+p.stdout
        r=json.loads(p.stdout); items=r['knowledge_bundle']['items']; assert items and items[0]['source_kind']=='local_manual'
        assert items[0]['page_url'].startswith('file://') and 'RTL8367S' in items[0]['title']
        assert r['trace']['local_manuals']['candidate_count']>0
        checks.append('local_manual_recall_without_ragflow')
        # Index is reusable and refreshable.
        assert (runtime/'cache/local_manuals_index.json.gz').is_file(); checks.append('local_manual_index_created')
        # Source contract remains clickable.
        assert r['knowledge_bundle']['source_integrity']['source_url_rate']==1.0; checks.append('local_manual_clickable_source_contract')
    print(json.dumps({'result':'PASS','total':len(checks),'checks':checks},ensure_ascii=False,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())

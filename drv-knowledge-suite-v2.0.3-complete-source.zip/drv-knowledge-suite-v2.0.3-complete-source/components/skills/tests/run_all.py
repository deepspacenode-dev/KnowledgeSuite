#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
cmds=[
    [sys.executable,str(ROOT/'tests/test_suite.py')],
    [sys.executable,str(ROOT/'tests/test_installer_shell.py')],
    [sys.executable,str(ROOT/'tests/test_dependency_check.py')],
    [sys.executable,str(ROOT/'tests/test_ragflow_migration_v2.py')],
    [sys.executable,str(ROOT/'tests/test_ragflow_control_v2.py')],
    [sys.executable,str(ROOT/'tests/test_ragflow_sanitize.py')],
    [sys.executable,str(ROOT/'tests/test_source_metadata_contract_v2.py')],
    [sys.executable,str(ROOT/'tests/test_ingestion.py')],
    [sys.executable,str(ROOT/'tests/test_local_manuals.py')],
    [sys.executable,str(ROOT/'tests/run_retrieval.py')],
]
failed=0
for c in cmds:
    p=subprocess.run(c,cwd=ROOT)
    if p.returncode: failed+=1
print(f'SUITE_TEST_SUMMARY total={len(cmds)} failed={failed}')
raise SystemExit(1 if failed else 0)

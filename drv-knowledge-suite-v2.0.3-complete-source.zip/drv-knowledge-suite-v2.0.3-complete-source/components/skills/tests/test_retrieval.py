"""Regression tests for drv-knowledge-retrieval v2.0.3."""
from __future__ import annotations
import json, os, re, subprocess, sys, tempfile, threading, urllib.parse
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "skills" / "drv-knowledge-retrieval"
ENTRY = SKILL / "scripts" / "drvkb_entry.py"
PYTHON = sys.executable
SECRET_TOKEN_RE = re.compile(r"ragflow-[A-Za-z0-9]{24,}", re.I)
sys.path.insert(0,str(SKILL/"resources"/"drvkb"))


def run(*args: str, env: dict[str,str] | None=None) -> subprocess.CompletedProcess[str]:
    e=os.environ.copy()
    if env: e.update(env)
    return subprocess.run([PYTHON,"-B","-X","utf8",str(ENTRY),*args],cwd=str(ROOT),env=e,text=True,encoding="utf-8",stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)


def frontmatter(text: str) -> dict[str,str]:
    assert text.startswith("---\n")
    end=text.find("\n---",4); assert end>0
    out={}
    for line in text[4:end].splitlines():
        if ":" in line:
            k,v=line.split(":",1); out[k.strip()]=v.strip()
    return out


def test_skill_metadata_and_single_entrypoint():
    text=(SKILL/"SKILL.md").read_text(encoding="utf-8"); meta=frontmatter(text)
    assert meta["name"]=="drv-knowledge-retrieval" and "知识获取" in meta["description"]
    for k in ("Browse","Search","Recall","Governance","Knowledge Gap","Evaluate"):
        assert k in text


def test_version_and_shared_config_exist():
    assert (SKILL/"VERSION").read_text().strip()=="2.0.3"
    cfg=json.loads((ROOT/"lib/drv_knowledge_core/config/knowledge.json").read_text(encoding="utf-8"))
    assert set(cfg["dataset_profiles"]) >= {"bookstack","drvdocs"}
    assert cfg["dataset_profiles"]["bookstack"]["manuals"]=="bookstack_ai_manuals"
    assert cfg["dataset_profiles"]["drvdocs"]["manuals"]=="drvdocs_ai_manuals"


def test_help_exposes_full_core_commands():
    r=run("--help"); assert r.returncode==0, r.stderr
    for cmd in ("init","doctor","recall","search","feedback","evaluate","browse","cases","manuals","bootstrap","refresh","catalog","status","where","graph","gaps","ask","command","bookstack","governance","gap","selftest"):
        assert cmd in r.stdout


def test_zero_config_doctor_is_ready_locally():
    r=run("doctor","--json",env={"RAGFLOW_BASE_URL":"","RAGFLOW_API_KEY":"","BOOKSTACK_BASE_URL":"","BOOKSTACK_TOKEN_ID":"","BOOKSTACK_TOKEN_SECRET":"","GOVERNANCE_COOKIE":""})
    p=json.loads(r.stdout); assert p["version"]=="2.0.3" and p["readiness"]["local_fixture"] is True
    assert p["release_safety"]["plaintext_ragflow_tokens"]==0


def test_zero_config_selftest_passes():
    r=run("selftest","--json",env={"RAGFLOW_BASE_URL":"","RAGFLOW_API_KEY":""}); assert r.returncode==0, r.stderr
    p=json.loads(r.stdout); assert p["ok"] is True
    assert p["checks"][1]["metrics"]["top3_hit_rate"]>=0.8


def test_auto_recall_requires_live_configuration():
    r=run("recall","-q","PHY up 但是无流量","--mode","auto","--json",env={"RAGFLOW_BASE_URL":"","RAGFLOW_API_KEY":""})
    assert r.returncode==6, r.stderr
    p=json.loads(r.stdout); assert p["resolved_mode"]=="live" and p["error"]=="LiveNotConfigured" and p["knowledge_status"]=="unavailable"

def test_fixture_recall_must_be_explicit_and_still_works():
    r=run("recall","-q","PHY up 但是无流量","--mode","fixture","--json",env={"RAGFLOW_BASE_URL":"","RAGFLOW_API_KEY":""})
    assert r.returncode==0, r.stderr
    p=json.loads(r.stdout); assert p["resolved_mode"]=="fixture" and p["knowledge_bundle"]["items"]


def test_recall_extracts_chip_and_bundle_contract():
    r=run("recall","-q","RTL8367S PHY link up 但是无流量","--mode","fixture","--json"); p=json.loads(r.stdout)
    b=p["knowledge_bundle"]
    assert b["chip"]=="rtl8367s" and b["module"]=="network"
    for key in ("request_id","project","graph_neighbors","conflicts","missing_info","suggested_next_action"):
        assert key in b


def test_fixture_filters_deprecated_and_rag_disabled():
    r=run("recall","-q","PHY network","--mode","fixture","--json"); p=json.loads(r.stdout)
    titles=[x["title"] for x in p["knowledge_bundle"]["items"]]
    assert not any("过期" in x or "禁用" in x for x in titles)


def test_evaluate_fixture_metrics():
    r=run("evaluate","--mode","fixture","--json"); assert r.returncode==0, r.stderr
    p=json.loads(r.stdout); assert p["total"]>=5 and p["metrics"]["top3_hit_rate"]>=0.8 and p["metrics"]["source_uri_rate"]==1.0 and "page_url_rate" in p["metrics"] and "citation_ready_rate" in p["metrics"]


def test_dataset_profile_bookstack_is_consistent():
    r=run("recall","-q","PHY 无流量","--mode","fixture","--json",env={"DRVKB_DATASET_PROFILE":"bookstack"}); p=json.loads(r.stdout)
    assert all(x.startswith("bookstack_ai_") for x in p["dataset_route"])


def test_dataset_profile_drvdocs_is_consistent():
    r=run("recall","-q","PHY 无流量","--mode","fixture","--json",env={"DRVKB_DATASET_PROFILE":"drvdocs"}); p=json.loads(r.stdout)
    assert all(x.startswith("drvdocs_ai_") for x in p["dataset_route"])
    assert p["knowledge_bundle"]["items"] and all(x["dataset"].startswith("drvdocs_ai_") for x in p["knowledge_bundle"]["items"])


def test_gap_uses_same_dataset_profile():
    with tempfile.TemporaryDirectory() as d:
        r=run("gap","--data-dir",d,"collect","--question","缺少 PHY 手册","--module","network","--background","调试网络","--gap","缺少 PHY 手册","--impact","无法定位","--priority","high",env={"DRVKB_DATASET_PROFILE":"bookstack"})
        assert r.returncode==0, r.stderr
        p=json.loads(r.stdout); assert all(x.startswith("bookstack_ai_") for x in p["suggested_dataset"])


def test_gap_type_separates_trigger_from_category():
    with tempfile.TemporaryDirectory() as d:
        run("gap","--data-dir",d,"collect","--question","缺少 PHY 手册","--module","network","--background","调试网络","--gap","缺少 PHY 手册","--impact","无法定位","--priority","high")
        assert run("gap","--data-dir",d,"analyze").returncode==0
        items=json.loads((Path(d)/"gap_items.yaml").read_text(encoding="utf-8"))
        assert items and "missing_document" in items[0]["gap_type"]


def test_bookstack_missing_env_fails_clearly():
    r=run("bookstack","shelves",env={"BOOKSTACK_BASE_URL":"","BOOKSTACK_TOKEN_ID":"","BOOKSTACK_TOKEN_SECRET":""}); assert r.returncode==4
    p=json.loads(r.stdout); assert p["error"]=="MissingEnvironment"


def test_governance_missing_session_fails_clearly():
    r=run("governance","summary",env={"BOOKSTACK_BASE_URL":"http://127.0.0.1:1","GOVERNANCE_COOKIE":""}); assert r.returncode==4
    p=json.loads(r.stdout); assert p["error"]=="MissingSession"







def test_no_plaintext_secrets_in_deliverable_sources():
    hits=[]
    for base in (SKILL, ROOT/"lib/drv_knowledge_core"):
        for path in base.rglob("*"):
            if path.is_dir() or "__pycache__" in path.parts or path.suffix.lower() in {".pyc",".png",".jpg",".jpeg",".gif",".webp",".zip"}: continue
            if SECRET_TOKEN_RE.search(path.read_text(encoding="utf-8",errors="ignore")): hits.append(str(path))
    assert not hits, hits


def test_launchers_exist():
    for name in ("drvkr.py","drvkr.sh","drvkr.cmd"):
        assert (ROOT/"tools/cli"/name).is_file()


def test_doctor_live_missing_core_config_returns_nonzero():
    r=run("doctor","--live","--json",env={"RAGFLOW_BASE_URL":"","RAGFLOW_API_KEY":"","BOOKSTACK_BASE_URL":"","BOOKSTACK_TOKEN_ID":"","BOOKSTACK_TOKEN_SECRET":"","GOVERNANCE_COOKIE":""})
    assert r.returncode==6
    p=json.loads(r.stdout); assert p["live_ok"] is False and p["live_probes"]["ragflow"]["ok"] is False


def test_live_transport_error_returns_nonzero():
    r=run("recall","-q","PHY 无流量","--mode","live","--json",env={
        "RAGFLOW_BASE_URL":"http://127.0.0.1:9","RAGFLOW_API_KEY":"x","RAGFLOW_DATASET_ID_CASES":"case-id",
        "RAGFLOW_TIMEOUT":"1","RAGFLOW_DATASET_ID_MANUALS":"","RAGFLOW_DATASET_ID_TECH_NOTES":"","RAGFLOW_DATASET_ID_PROJECT_DOCS":"","RAGFLOW_DATASET_ID_DOCS":""
    })
    assert r.returncode==6
    p=json.loads(r.stdout); assert p["knowledge_status"]=="unavailable" and p["trace"]["external_dependency_errors"]


def test_gap_default_builds_one_primary_todo():
    with tempfile.TemporaryDirectory() as d:
        assert run("gap","--data-dir",d,"collect","--question","缺少 PHY 手册","--module","network","--background","调试网络","--gap","缺少 PHY 手册","--impact","无法定位","--priority","high",env={"DRVKB_GAP_TODO_MODE":"primary"}).returncode==0
        assert run("gap","--data-dir",d,"analyze",env={"DRVKB_GAP_TODO_MODE":"primary"}).returncode==0
        assert run("gap","--data-dir",d,"build-todos",env={"DRVKB_GAP_TODO_MODE":"primary"}).returncode==0
        todos=json.loads((Path(d)/"gap_todos.yaml").read_text(encoding="utf-8"))
        assert len(todos)==1


def test_bookstack_all_follows_offset_pagination():
    rows=[{"id":i,"name":f"P{i}"} for i in range(5)]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_GET(self):
            parsed=urllib.parse.urlparse(self.path); q=urllib.parse.parse_qs(parsed.query)
            count=int(q.get("count",[2])[0]); offset=int(q.get("offset",[0])[0]); data=rows[offset:offset+count]
            body=json.dumps({"data":data,"total":len(rows)}).encode()
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"
        r=run("bookstack","pages","--count","2","--all",env={"BOOKSTACK_BASE_URL":base,"BOOKSTACK_TOKEN_ID":"id","BOOKSTACK_TOKEN_SECRET":"sec"})
        assert r.returncode==0, r.stderr
        p=json.loads(r.stdout); assert len(p["data"]["data"])==5 and p["data"]["pages"]==3
    finally:
        server.shutdown(); server.server_close()


def test_live_dataset_discovery_and_metadata_project_are_preserved():
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_GET(self):
            body=json.dumps({"code":0,"data":[{"id":"case-id","name":"bookstack_ai_cases"},{"id":"manual-id","name":"bookstack_ai_manuals"},{"id":"tech-id","name":"bookstack_ai_tech_notes"},{"id":"proj-id","name":"bookstack_ai_project_docs"},{"id":"docs-id","name":"bookstack_ai_docs"}]}).encode()
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
        def do_POST(self):
            n=int(self.headers.get("Content-Length","0")); self.rfile.read(n)
            chunk={"dataset_id":"case-id","document_id":"d1","chunk_id":"c1","document_keyword":"A3 PHY Case","content":"---\nstatus: verified\nmodule: network\nplatform: atlas\nchip: rtl8367s\nproject: a3\npage_url: http://bookstack/pages/1\n---\nPHY no traffic","similarity":0.91}
            body=json.dumps({"code":0,"data":{"chunks":[chunk]}}).encode()
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"
        env={"RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x","RAGFLOW_TIMEOUT":"2",
             "RAGFLOW_DATASET_ID_CASES":"","RAGFLOW_DATASET_ID_MANUALS":"","RAGFLOW_DATASET_ID_TECH_NOTES":"","RAGFLOW_DATASET_ID_PROJECT_DOCS":"","RAGFLOW_DATASET_ID_DOCS":"","RAGFLOW_DATASET_NAMES_JSON":"","RAGFLOW_DATASET_IDS":""}
        r=run("recall","-q","A3 RTL8367S PHY 无流量","--mode","live","--json",env=env)
        assert r.returncode==0, r.stderr
        p=json.loads(r.stdout); item=p["knowledge_bundle"]["items"][0]
        assert item["project"]=="a3" and item["chip"]=="rtl8367s" and item["page_url"]=="http://bookstack/pages/1" and item["status"]=="verified"
    finally:
        server.shutdown(); server.server_close()


def test_natural_language_resolves_all_cases_without_source_question():
    r=run("ask","-q","帮我找到目前库上所有案例内容","--resolve-only")
    assert r.returncode==0, r.stderr
    p=json.loads(r.stdout); x=p["resolved"]
    assert x["operation"]=="browse" and x["domain"]=="cases" and x["query"]==""


def test_natural_language_sensor_manuals_resolves_browse_filter():
    r=run("ask","-q","Sensor 手册现在有哪些？","--resolve-only")
    assert r.returncode==0, r.stderr
    p=json.loads(r.stdout); x=p["resolved"]
    assert x["operation"]=="browse" and x["domain"]=="manuals" and x["query"]=="sensor"


def test_slash_command_parser_is_deterministic():
    r=run("command","/kb cases network","--resolve-only")
    assert r.returncode==0, r.stderr
    p=json.loads(r.stdout); x=p["resolved"]
    assert x["operation"]=="browse" and x["domain"]=="cases" and x["query"]=="network" and x["all"] is False and x["refresh"] is False


def test_slash_command_refresh_is_preserved():
    r=run("command","/kb cases --refresh","--resolve-only")
    assert r.returncode==0, r.stderr
    p=json.loads(r.stdout); x=p["resolved"]
    assert x["operation"]=="browse" and x["domain"]=="cases" and x["refresh"] is True


def test_slash_command_help_is_available():
    r=run("kb-help")
    assert r.returncode==0 and "/kb cases" in r.stdout and "/kb bootstrap" in r.stdout


def test_catalog_bootstrap_discovers_dataset_and_counts_documents():
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_GET(self):
            parsed=urllib.parse.urlparse(self.path)
            if parsed.path=="/api/v1/datasets":
                body=json.dumps({"code":0,"data":[{"id":"case-id","name":"bookstack_ai_cases"},{"id":"manual-id","name":"bookstack_ai_manuals"},{"id":"tech-id","name":"bookstack_ai_tech_notes"},{"id":"proj-id","name":"bookstack_ai_project_docs"},{"id":"docs-id","name":"bookstack_ai_docs"}]}).encode()
            elif parsed.path.endswith('/documents'):
                body=json.dumps({"code":0,"data":{"docs":[{"id":"d1","name":"x"}],"total":7}}).encode()
            else:
                self.send_response(404); self.end_headers(); return
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"
        with tempfile.TemporaryDirectory() as d:
            r=run("bootstrap","--no-bookstack","--json",env={"RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x","DRVKB_RUNTIME_DIR":d,"DRVKB_DATASET_PROFILE":"bookstack"})
            assert r.returncode==0, r.stderr
            p=json.loads(r.stdout); assert p["domains"]["cases"]["dataset_id"]=="case-id" and p["domains"]["cases"]["ragflow_document_count"]==7
            assert (Path(d)/"knowledge_catalog.json").is_file()
    finally:
        server.shutdown(); server.server_close()


def test_cases_browse_enumerates_case_pages_counts_picture_attachments_and_rewrites_old_url():
    docs=[
        {"id":"c1","name":"case1.md","chunk_method":"naive","chunk_count":1},
        {"id":"pic1","name":"shot.png","chunk_method":"picture","chunk_count":1},
    ]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_GET(self):
            parsed=urllib.parse.urlparse(self.path)
            if parsed.path=="/api/v1/datasets":
                data=[{"id":"case-id","name":"bookstack_ai_cases"},{"id":"manual-id","name":"bookstack_ai_manuals"},{"id":"tech-id","name":"bookstack_ai_tech_notes"},{"id":"proj-id","name":"bookstack_ai_project_docs"},{"id":"docs-id","name":"bookstack_ai_docs"}]
                body=json.dumps({"code":0,"data":data}).encode()
            elif parsed.path=="/api/v1/datasets/case-id/documents":
                body=json.dumps({"code":0,"data":{"docs":docs,"total":2}}).encode()
            elif parsed.path=="/api/v1/datasets/case-id/documents/c1/chunks":
                content="# 【AC001】问题\n> original_url: http://10.222.118.40:8080/books/03/page/ac001\n> bookstack_page_id: 231\n> chapter: 【5月】版本问题分析\n\n问题描述：PHY link up 但是无流量"
                body=json.dumps({"code":0,"data":{"chunks":[{"id":"ch1","content":content}],"total":1}}).encode()
            elif parsed.path.endswith('/documents'):
                body=json.dumps({"code":0,"data":{"docs":[],"total":0}}).encode()
            else:
                self.send_response(404); self.end_headers(); return
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"
        with tempfile.TemporaryDirectory() as d:
            env={"RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x","DRVKB_RUNTIME_DIR":d,"DRVKB_DATASET_PROFILE":"bookstack","BOOKSTACK_BASE_URL":"http://10.222.120.25:8080","BOOKSTACK_TOKEN_ID":"","BOOKSTACK_TOKEN_SECRET":""}
            assert run("bootstrap","--no-bookstack","--json",env=env).returncode==0
            r=run("cases","--json",env=env); assert r.returncode==0, r.stderr
            p=json.loads(r.stdout); assert p["matched"]==1 and p["attachments_count"]==1
            assert p["items"][0]["page_url"].startswith("http://10.222.120.25:8080/books/")
            assert "PHY link up" in p["items"][0]["summary"]
    finally:
        server.shutdown(); server.server_close()


def test_catalog_auto_resolves_alternate_known_dataset_profile():
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_GET(self):
            parsed=urllib.parse.urlparse(self.path)
            if parsed.path=="/api/v1/datasets":
                data=[{"id":"case-id","name":"drvdocs_ai_cases"},{"id":"manual-id","name":"drvdocs_ai_manuals"},{"id":"tech-id","name":"drvdocs_ai_tech_notes"},{"id":"proj-id","name":"drvdocs_ai_project_docs"},{"id":"docs-id","name":"drvdocs_ai_docs"}]
                body=json.dumps({"code":0,"data":data}).encode()
            elif parsed.path.endswith('/documents'):
                body=json.dumps({"code":0,"data":{"docs":[],"total":0}}).encode()
            else:
                self.send_response(404); self.end_headers(); return
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"
        with tempfile.TemporaryDirectory() as d:
            r=run("bootstrap","--no-bookstack","--json",env={"RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x","DRVKB_RUNTIME_DIR":d,"DRVKB_DATASET_PROFILE":"bookstack"})
            assert r.returncode==0, r.stderr
            p=json.loads(r.stdout); assert p["domains"]["cases"]["dataset_name"]=="drvdocs_ai_cases" and p["domains"]["cases"]["resolved_profile"]=="drvdocs"
    finally:
        server.shutdown(); server.server_close()


def test_live_recall_uses_ragflow_embedded_bookstack_url_without_bookstack_lookup():
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_GET(self):
            body=json.dumps({"code":0,"data":[{"id":"case-id","name":"bookstack_ai_cases"}]}).encode()
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
        def do_POST(self):
            n=int(self.headers.get("Content-Length","0")); self.rfile.read(n)
            content="# Case\n> original_url: http://old-bookstack:8080/books/x/page/y\n> bookstack_page_id: 231\n> material_type: cases\n> status: verified\n> module: network\n\n问题现象：无流量"
            chunk={"dataset_id":"case-id","document_id":"d1","chunk_id":"c1","document_keyword":"Case","content":content,"similarity":0.95}
            body=json.dumps({"code":0,"data":{"chunks":[chunk]}}).encode()
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"
        env={"RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x","RAGFLOW_DATASET_ID_CASES":"case-id","RAGFLOW_DATASET_ID_MANUALS":"","RAGFLOW_DATASET_ID_TECH_NOTES":"","BOOKSTACK_BASE_URL":"http://new-bookstack:8080","BOOKSTACK_URL_ALIASES":"http://old-bookstack:8080"}
        r=run("recall","-q","网络无流量","--mode","live","--json",env=env); assert r.returncode==0, r.stderr
        item=json.loads(r.stdout)["knowledge_bundle"]["items"][0]
        assert item["page_url"]=="http://new-bookstack:8080/books/x/page/y"
    finally:
        server.shutdown(); server.server_close()


def test_recall_v3_executes_expanded_queries_across_dataset_lanes():
    requests=[]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_POST(self):
            n=int(self.headers.get("Content-Length","0")); payload=json.loads(self.rfile.read(n).decode()); requests.append(payload)
            did=payload["dataset_ids"][0]; q=payload["question"]; suffix=str(abs(hash(q))%100000)
            content=f"---\npage_url: http://book/books/net/page/{suffix}\nmaterial_type: cases\nstatus: verified\nmodule: network\n---\n# RGMII Case {suffix}\n## 问题现象\nPHY link up 但是无流量\n## 根因\nRGMII delay 不匹配\n## 解决方案\n修正 RGMII delay"
            chunk={"dataset_id":did,"document_id":"d"+suffix,"chunk_id":"c"+suffix,"document_keyword":"RGMII Case "+suffix,"content":content,"similarity":0.82}
            body=json.dumps({"code":0,"data":{"chunks":[chunk]}}).encode()
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"
        env={"RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x","RAGFLOW_DATASET_ID_CASES":"case-id","RAGFLOW_DATASET_ID_MANUALS":"manual-id","RAGFLOW_DATASET_ID_TECH_NOTES":"tech-id","RAGFLOW_DATASET_ID_PROJECT_DOCS":"proj-id","RAGFLOW_DATASET_ID_DOCS":"docs-id"}
        r=run("recall","-q","RTL8367S PHY link up 但是没有流量","--mode","live","--json",env=env); assert r.returncode==0, r.stderr
        p=json.loads(r.stdout); assert p["trace"]["version"]=="recall-v4"
        questions={x["question"] for x in requests}; assert len(questions)>=3, questions
        assert any(x["dataset_ids"]==["case-id"] for x in requests)
        assert any("tech-id" in x["dataset_ids"] and "manual-id" in x["dataset_ids"] for x in requests)
        assert p["knowledge_bundle"]["items"] and p["knowledge_bundle"]["source_integrity"]["source_url_rate"]==1.0
    finally:
        server.shutdown(); server.server_close()


def test_live_recall_uses_v027_parameters_reference_metadata_and_domain_filter():
    requests=[]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_POST(self):
            n=int(self.headers.get("Content-Length","0")); payload=json.loads(self.rfile.read(n).decode()); requests.append(payload)
            did=payload["dataset_ids"][0]
            chunk={
                "dataset_id":did,"document_id":"network-doc","chunk_id":"network-chunk",
                "document_keyword":"网络调试案例","content":"PHY link up 但是没有流量，检查 RGMII 时序。","similarity":0.91,
                "document_metadata":{
                    "page_id":"231","page_url":"http://old-bookstack:8080/books/network/page/rgmii",
                    "source_key":"bookstack_page:231","content_ref":"bookstack:page:231",
                    "material_type":"cases","status":"verified","module":"network","chip":"rtl8367s"
                }
            }
            body=json.dumps({"code":0,"data":{"chunks":[chunk]}}).encode()
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"
        env={
            "RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x",
            "RAGFLOW_DATASET_ID_CASES":"case-id","RAGFLOW_DATASET_ID_MANUALS":"manual-id",
            "RAGFLOW_DATASET_ID_TECH_NOTES":"tech-id","RAGFLOW_DATASET_ID_PROJECT_DOCS":"proj-id","RAGFLOW_DATASET_ID_DOCS":"docs-id",
            "BOOKSTACK_PUBLIC_URL":"http://new-bookstack:8080","BOOKSTACK_URL_ALIASES":"http://old-bookstack:8080",
            "DRVKB_RAGFLOW_PAGE_SIZE":"12","DRVKB_RAGFLOW_KNN_TOP_K":"256",
            "DRVKB_RAGFLOW_KNN_NUM_CANDIDATES":"1024","DRVKB_RAGFLOW_RERANK_CANDIDATES":"64",
            "DRVKB_RAGFLOW_SIMILARITY_THRESHOLD":"0.25","DRVKB_RAGFLOW_VECTOR_WEIGHT":"0.35"
        }
        r=run("recall","-q","RTL8367S 网络无流量","--mode","live","--json",env=env); assert r.returncode==0, r.stderr
        item=json.loads(r.stdout)["knowledge_bundle"]["items"][0]
        assert item["page_url"]=="http://new-bookstack:8080/books/network/page/rgmii"
        assert requests
        for payload in requests:
            assert "top_k" not in payload
            assert payload["page"]==1 and payload["page_size"]==12
            assert payload["knn_top_k"]==256 and payload["knn_num_candidates"]==1024
            assert payload["rerank_candidates_count"]==64
            assert payload["similarity_threshold"]==0.25 and payload["vector_similarity_weight"]==0.35
            assert payload["keyword"] is True
            assert payload["reference_metadata"]["include"] is True
            assert "page_url" in payload["reference_metadata"]["fields"]
            conditions=payload["metadata_condition"]["conditions"]
            assert {c["name"]:c["value"] for c in conditions}=={"module":"network","chip":"rtl8367s"}
    finally:
        server.shutdown(); server.server_close()


def test_live_recall_discards_explicit_cross_domain_candidates_even_if_server_returns_them():
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_POST(self):
            n=int(self.headers.get("Content-Length","0")); payload=json.loads(self.rfile.read(n).decode()); did=payload["dataset_ids"][0]
            wrong={"dataset_id":did,"document_id":"soc-doc","chunk_id":"soc","document_keyword":"SoC 启动手册","document_metadata":{"page_url":"http://book/books/soc/page/boot","material_type":"manuals","status":"verified","module":"boot","chip":"rk3568"},"content":"SoC 启动网络配置寄存器说明","similarity":0.99}
            right={"dataset_id":did,"document_id":"network-doc","chunk_id":"net","document_keyword":"RTL8367S 网络案例","document_metadata":{"page_url":"http://book/books/network/page/rtl8367s","material_type":"cases","status":"verified","module":"network","chip":"rtl8367s"},"content":"RTL8367S PHY link up 但是没有流量","similarity":0.75}
            body=json.dumps({"code":0,"data":{"chunks":[wrong,right]}}).encode()
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"; env={"RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x","RAGFLOW_DATASET_ID_CASES":"case-id","RAGFLOW_DATASET_ID_MANUALS":"manual-id","RAGFLOW_DATASET_ID_TECH_NOTES":"tech-id","RAGFLOW_DATASET_ID_PROJECT_DOCS":"proj-id","RAGFLOW_DATASET_ID_DOCS":"docs-id"}
        r=run("recall","-q","RTL8367S 网络无流量","--mode","live","--json",env=env); assert r.returncode==0, r.stderr
        items=json.loads(r.stdout)["knowledge_bundle"]["items"]
        assert items and items[0]["page_url"].endswith("/rtl8367s")
        assert all(item["module"]=="network" for item in items)
        assert not any(item["title"]=="SoC 启动手册" for item in items)
    finally:
        server.shutdown(); server.server_close()


def test_recall_v3_deduplicates_chunks_at_document_level():
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_POST(self):
            n=int(self.headers.get("Content-Length","0")); payload=json.loads(self.rfile.read(n).decode()); did=payload["dataset_ids"][0]
            c1={"dataset_id":did,"document_id":"same-doc","chunk_id":"a","document_keyword":"重复案例","metadata":{"page_url":"http://book/books/x/page/same","material_type":"cases","status":"verified","module":"network","source_key":"bookstack:page:100"},"content":"## 问题现象\nPHY link up 无流量","similarity":0.92}
            c2={"dataset_id":did,"document_id":"same-doc","chunk_id":"b","document_keyword":"重复案例","metadata":{"page_url":"http://book/books/x/page/same","material_type":"cases","status":"verified","module":"network","source_key":"bookstack:page:100"},"content":"## 根因\nRGMII RX delay 不匹配\n## 解决方案\n调整 delay","similarity":0.88}
            c3={"dataset_id":did,"document_id":"other-doc","chunk_id":"c","document_keyword":"另一个案例","metadata":{"page_url":"http://book/books/x/page/other","material_type":"cases","status":"verified","module":"network","source_key":"bookstack:page:101"},"content":"PHY link up 但 VLAN 配置错误","similarity":0.75}
            body=json.dumps({"code":0,"data":{"chunks":[c1,c2,c3]}}).encode(); self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"; env={"RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x","RAGFLOW_DATASET_ID_CASES":"case-id","RAGFLOW_DATASET_ID_MANUALS":"manual-id","RAGFLOW_DATASET_ID_TECH_NOTES":"tech-id","RAGFLOW_DATASET_ID_PROJECT_DOCS":"proj-id","RAGFLOW_DATASET_ID_DOCS":"docs-id"}
        r=run("recall","-q","PHY link up 无流量","--mode","live","--json",env=env); assert r.returncode==0, r.stderr
        p=json.loads(r.stdout); items=p["knowledge_bundle"]["items"]; urls=[x["page_url"] for x in items]
        assert len(urls)==len(set(urls)), urls
        same=next(x for x in items if x["page_url"].endswith('/same')); assert same["supporting_chunk_count"]>=2
    finally:
        server.shutdown(); server.server_close()


def test_recall_v3_returns_structured_engineering_description_and_original_link():
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_POST(self):
            n=int(self.headers.get("Content-Length","0")); payload=json.loads(self.rfile.read(n).decode()); did=payload["dataset_ids"][0]
            content="""---
page_url: http://book/books/network/page/rgmii-no-traffic
source_key: bookstack:page:231
material_type: cases
status: verified
module: network
chip: rtl8367s
---
# RTL8367S PHY Link 正常但无流量
## 问题现象
PHY Link Up，但 MAC 层没有有效流量。
## 根因
RGMII RX Delay 参数与 PHY 时序不匹配。
## 解决方案
修正 MAC/PHY RX Delay 配置并重新验证。
## 验证
Ping 和业务流量恢复正常。"""
            chunk={"dataset_id":did,"document_id":"d1","chunk_id":"c1","document_keyword":"RTL8367S PHY Link 正常但无流量","content":content,"similarity":0.95}
            body=json.dumps({"code":0,"data":{"chunks":[chunk]}}).encode(); self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"; env={"RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x","RAGFLOW_DATASET_ID_CASES":"case-id","RAGFLOW_DATASET_ID_MANUALS":"manual-id","RAGFLOW_DATASET_ID_TECH_NOTES":"tech-id","RAGFLOW_DATASET_ID_PROJECT_DOCS":"proj-id","RAGFLOW_DATASET_ID_DOCS":"docs-id"}
        r=run("recall","-q","RTL8367S PHY link up 但是无流量","--mode","live","--json",env=env); assert r.returncode==0, r.stderr
        item=json.loads(r.stdout)["knowledge_bundle"]["items"][0]; es=item["engineering_summary"]
        assert "RGMII RX Delay" in es["root_cause"] and "修正" in es["solution"] and "Ping" in es["verification"]
        assert item["page_url"]=="http://book/books/network/page/rgmii-no-traffic" and item["source"]==item["page_url"]
        assert item["reason"] and "来源类型" in item["reason"]
        text=run("recall","-q","RTL8367S PHY link up 但是无流量","--mode","live",env=env).stdout
        assert "查看原文:" in text and "http://book/books/network/page/rgmii-no-traffic" in text
    finally:
        server.shutdown(); server.server_close()


def test_recall_v3_never_exposes_linkless_result_in_public_bundle():
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_POST(self):
            n=int(self.headers.get("Content-Length","0")); payload=json.loads(self.rfile.read(n).decode()); did=payload["dataset_ids"][0]
            linked={"dataset_id":did,"document_id":"good","chunk_id":"1","document_keyword":"有链接案例","metadata":{"page_url":"http://book/books/x/page/good","material_type":"cases","status":"verified","module":"network"},"content":"PHY link up 无流量","similarity":0.8}
            bad={"dataset_id":did,"document_id":"bad","chunk_id":"2","document_keyword":"无链接案例","metadata":{"material_type":"cases","status":"verified","module":"network"},"content":"PHY link up 无流量 RGMII","similarity":0.99}
            body=json.dumps({"code":0,"data":{"chunks":[bad,linked]}}).encode(); self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler); threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        base=f"http://127.0.0.1:{server.server_address[1]}"; env={"RAGFLOW_BASE_URL":base,"RAGFLOW_API_KEY":"x","RAGFLOW_DATASET_ID_CASES":"case-id","RAGFLOW_DATASET_ID_MANUALS":"manual-id","RAGFLOW_DATASET_ID_TECH_NOTES":"tech-id","RAGFLOW_DATASET_ID_PROJECT_DOCS":"proj-id","RAGFLOW_DATASET_ID_DOCS":"docs-id","BOOKSTACK_BASE_URL":""}
        r=run("recall","-q","PHY link up 无流量","--mode","live","--json",env=env); assert r.returncode==0, r.stderr
        b=json.loads(r.stdout)["knowledge_bundle"]; assert b["items"] and all(x["page_url"].startswith(("http://","https://")) for x in b["items"])
        assert not any(x["title"]=="无链接案例" for x in b["items"]); assert b["source_integrity"]["excluded_unlinked"]>=1 and b["source_integrity"]["source_url_rate"]==1.0
    finally:
        server.shutdown(); server.server_close()


def test_recall_v3_evaluator_reports_mrr_latency_and_duplicate_rate():
    r=run("evaluate","--mode","fixture","--json"); assert r.returncode==0, r.stderr
    payload=json.loads(r.stdout); m=payload["metrics"]
    for key in ("recall_at_1","mrr_at_5","document_duplicate_rate","latency_p50_s","latency_p95_s"):
        assert key in m
    assert m["document_duplicate_rate"]==0.0 and m["page_url_rate"]==1.0
    assert payload["total"]>=12 and m["forbidden_module_violation_rate"]==0.0 and m["expected_answer_status_rate"]==1.0


def _gate_query(**overrides):
    base={"raw_query":"RTL8367S 网络无流量","task_type":"diagnosis","module":"network","chip":"rtl8367s","platform":"unknown","project":"unknown"}
    base.update(overrides); return base


def _gate_candidate(title,score,**overrides):
    base={"title":title,"content":"PHY link up 但是没有流量","final_score":score,"module":"network","chip":"rtl8367s","status":"verified","material_type":"cases","page_url":"http://book/books/network/page/case","query_hits":["raw"],"lane_hits":["case_first"]}
    base.update(overrides); return base


def test_recall_v4_rejects_explicit_domain_and_chip_conflicts_with_trace_reasons():
    from recall.relevance_gate import apply_relevance_gate
    candidates=[
        _gate_candidate("Sensor ISP Pipeline",99,module="unknown",chip="unknown",content="Sensor ISP MIPI VI 图像处理"),
        _gate_candidate("RK3568 网络手册",97,chip="rk3568"),
        _gate_candidate("RTL8367S 无流量案例",88),
    ]
    result=apply_relevance_gate(_gate_query(),candidates)
    assert [x["title"] for x in result["accepted"]]==["RTL8367S 无流量案例"]
    assert {x["reason"] for x in result["rejected"]} >= {"explicit_domain_conflict","explicit_chip_conflict"}
    assert all("content" not in x for x in result["rejected"])


def test_recall_v4_only_uses_missing_metadata_as_low_result_fallback():
    from recall.relevance_gate import apply_relevance_gate
    incomplete=_gate_candidate("旧文档无元数据",86,module="unknown",status="unknown",material_type="unknown")
    scarce=apply_relevance_gate(_gate_query(),[_gate_candidate("严格结果",90),incomplete])
    assert any(x["title"]=="旧文档无元数据" and x["gate_mode"]=="fallback_metadata" for x in scarce["accepted"])
    enough=apply_relevance_gate(_gate_query(),[
        _gate_candidate("严格结果 1",91),_gate_candidate("严格结果 2",89),_gate_candidate("严格结果 3",87),incomplete,
    ])
    assert not any(x["title"]=="旧文档无元数据" for x in enough["accepted"])
    assert any(x["title"]=="旧文档无元数据" and x["reason"]=="metadata_missing_strict" for x in enough["rejected"])


def test_recall_v4_answer_gate_distinguishes_no_match_ambiguous_and_consensus():
    from recall.relevance_gate import apply_relevance_gate
    assert apply_relevance_gate(_gate_query(),[_gate_candidate("低分",10)])["answer_status"]=="no_match"
    close=[_gate_candidate("候选 A",82),_gate_candidate("候选 B",79)]
    assert apply_relevance_gate(_gate_query(),close)["answer_status"]=="ambiguous_match"
    close[0]["query_hits"]=["raw","engineering"]
    assert apply_relevance_gate(_gate_query(),close)["answer_status"]=="ok"


def test_recall_pipeline_emits_v4_trace_and_answer_status_without_chunk_text():
    r=run("recall","-q","RTL8367S PHY link up 但是无流量","--mode","fixture","--json"); assert r.returncode==0, r.stderr
    p=json.loads(r.stdout)
    assert p["trace"]["version"]=="recall-v4" and p["answer_status"] in {"ok","no_match","ambiguous_match"}
    serialized=json.dumps(p["trace"],ensure_ascii=False)
    assert '"content"' not in serialized and p["trace"]["trace_id"].startswith("recall-")


def test_recall_feedback_is_explicit_sanitized_and_creates_gap_for_missing_answer():
    with tempfile.TemporaryDirectory() as d:
        env={"DRVKB_RUNTIME_DIR":d,"RAGFLOW_BASE_URL":"","RAGFLOW_API_KEY":""}
        recalled=run("recall","-q","RTL8367S 网络无流量","--mode","fixture","--json",env=env); assert recalled.returncode==0, recalled.stderr
        payload=json.loads(recalled.stdout); trace_id=payload["trace"]["trace_id"]
        feedback_path=Path(d)/"recall"/"feedback.jsonl"
        assert not feedback_path.exists(), "normal recall must not fabricate user feedback"
        saved=run("feedback","--trace-id",trace_id,"--label","missing_answer","--reason","缺少当前板卡的 RGMII 时序案例","--json",env=env)
        assert saved.returncode==0, saved.stderr
        result=json.loads(saved.stdout); assert result["ok"] is True and result["gap_event_created"] is True
        rows=[json.loads(line) for line in feedback_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        assert len(rows)==1 and rows[0]["label"]=="missing_answer" and rows[0]["trace_id"]==trace_id
        serialized=json.dumps(rows[0],ensure_ascii=False).lower()
        assert '"content"' not in serialized and "api_key" not in serialized and "authorization" not in serialized
        assert (Path(d)/"knowledge_gap"/"gap_events.jsonl").is_file()


def test_relevant_feedback_does_not_create_gap_and_unknown_trace_is_rejected():
    with tempfile.TemporaryDirectory() as d:
        env={"DRVKB_RUNTIME_DIR":d,"RAGFLOW_BASE_URL":"","RAGFLOW_API_KEY":""}
        recalled=run("recall","-q","PHY link up 无流量","--mode","fixture","--json",env=env); trace_id=json.loads(recalled.stdout)["trace"]["trace_id"]
        saved=run("feedback","--trace-id",trace_id,"--label","relevant","--json",env=env); assert saved.returncode==0, saved.stderr
        assert json.loads(saved.stdout)["gap_event_created"] is False and not (Path(d)/"knowledge_gap"/"gap_events.jsonl").exists()
        missing=run("feedback","--trace-id","recall-does-not-exist","--label","irrelevant","--json",env=env)
        assert missing.returncode!=0 and json.loads(missing.stdout)["error"]=="TraceNotFound"

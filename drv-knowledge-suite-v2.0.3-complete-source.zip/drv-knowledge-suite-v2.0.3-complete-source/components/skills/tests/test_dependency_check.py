#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / "tools/install/dependency_check.py"


def load_checker():
    spec = importlib.util.spec_from_file_location("drvks_dependency_check_test", CHECKER)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def main() -> int:
    checks=[]
    checker=load_checker()

    # retrieval never requires the format plugins.
    rows, missing=checker.probe("retrieval")
    assert missing == [] and all(not row["required"] for row in rows.values())
    checks.append("retrieval_requires_no_format_plugins")

    # Simulate a full environment with all six import names available.
    original=checker.importlib.util.find_spec
    checker.importlib.util.find_spec=lambda name: object()
    rows, missing=checker.probe("full")
    assert missing == [] and len([x for x in rows.values() if x["required"]]) == 6
    checks.append("full_six_dependencies_ready")

    # Simulate two missing imports and verify they are reported, never installed.
    hidden={"bs4","fitz"}
    checker.importlib.util.find_spec=lambda name: None if name in hidden else object()
    rows, missing=checker.probe("full")
    assert set(missing)=={"beautifulsoup4","PyMuPDF"}
    assert rows["beautifulsoup4"]["action"]=="missing" and rows["PyMuPDF"]["action"]=="missing"
    checks.append("full_missing_dependencies_detected")
    checker.importlib.util.find_spec=original

    # Removed mutating option must be rejected by CLI.
    proc=subprocess.run([sys.executable,str(CHECKER),"--profile","full","--install","--json"],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert proc.returncode != 0 and "unrecognized arguments" in proc.stderr
    checks.append("dependency_checker_has_no_install_mode")

    source=CHECKER.read_text(encoding="utf-8")
    assert "subprocess" not in source and "pip install" not in source and "--offline" not in source
    checks.append("checker_is_check_only")

    print(json.dumps({"result":"PASS","total":len(checks),"checks":checks},ensure_ascii=False,indent=2))
    return 0


if __name__=="__main__": raise SystemExit(main())

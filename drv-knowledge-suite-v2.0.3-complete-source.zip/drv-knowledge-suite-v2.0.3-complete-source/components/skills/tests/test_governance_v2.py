from __future__ import annotations

import json
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "lib"))

from drv_knowledge_core.governance_v2 import (  # noqa: E402
    GovernanceOutbox,
    GovernanceStatusCache,
    GovernanceV2Client,
    build_intake_request,
    deterministic_submission_id,
    resolve_governance_statuses,
)


class GovernanceV2Tests(unittest.TestCase):
    def test_submission_id_is_deterministic_and_page_specific(self) -> None:
        first = deterministic_submission_id("session-001", 42)
        self.assertEqual(first, deterministic_submission_id("session-001", 42))
        self.assertNotEqual(first, deterministic_submission_id("session-001", 43))
        self.assertTrue(first.startswith("intake:"))

    def test_intake_payload_contains_contract_identity(self) -> None:
        payload = build_intake_request(
            session_id="session-001",
            page_id=42,
            canonical_url="http://bookstack.local/books/ai/page/example",
            title="诊断案例",
            material_type="cases",
            content_hash="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
            trace_id="trace-intake-001",
        )
        self.assertEqual(payload["schema_version"], "drvknowledge.intake-request.v2")
        self.assertEqual(payload["source_key"], "bookstack_page:42")
        self.assertEqual(payload["content_ref"], "bookstack:page:42")
        self.assertEqual(payload["client_submission_id"], deterministic_submission_id("session-001", 42))
        self.assertEqual(payload["client"]["version"], "2.0.3")

    def test_client_sends_personal_token_and_idempotency_key(self) -> None:
        calls = []

        def transport(url, **kwargs):
            calls.append((url, kwargs))
            return {"ok": True, "status": 202, "data": {"intake_id": "17"}}

        client = GovernanceV2Client(
            base_url="http://bookstack.local",
            token_id="user-token",
            token_secret="secret",
            transport=transport,
        )
        payload = build_intake_request(
            session_id="session-001",
            page_id=42,
            canonical_url="http://bookstack.local/books/ai/page/example",
            title="诊断案例",
            material_type="cases",
            content_hash="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
            trace_id="trace-intake-001",
        )
        client.submit_intake(payload)
        _, request = calls[0]
        self.assertEqual(request["method"], "POST")
        self.assertEqual(request["headers"]["Authorization"], "Token user-token:secret")
        self.assertEqual(request["headers"]["Idempotency-Key"], payload["client_submission_id"])
        self.assertEqual(request["headers"]["X-Trace-ID"], payload["trace_id"])

    def test_outbox_replays_once_and_acknowledges(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            outbox = GovernanceOutbox(Path(tmp) / "outbox.sqlite3")
            payload = {"schema_version": "drvknowledge.intake-request.v2", "client_submission_id": "intake:one"}
            first_id = outbox.enqueue_intake(payload)
            self.assertEqual(first_id, outbox.enqueue_intake(payload))
            sent = []

            def sender(body):
                sent.append(body)
                return {"ok": True, "status": 202, "data": {"intake_id": "17"}}

            result = outbox.replay(sender)
            self.assertEqual(result, {"acknowledged": 1, "retry_wait": 0, "dead_letter": 0})
            self.assertEqual(len(sent), 1)
            self.assertEqual(outbox.get(first_id)["state"], "acknowledged")
            self.assertEqual(outbox.replay(sender)["acknowledged"], 0)

    def test_outbox_preserves_request_during_outage(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            outbox = GovernanceOutbox(Path(tmp) / "outbox.sqlite3")
            row_id = outbox.enqueue_intake({
                "schema_version": "drvknowledge.intake-request.v2",
                "client_submission_id": "intake:offline",
            })
            result = outbox.replay(lambda _: {"ok": False, "status": 0, "message": "offline"})
            row = outbox.get(row_id)
            self.assertEqual(result["retry_wait"], 1)
            self.assertEqual(row["state"], "retry_wait")
            self.assertEqual(row["attempts"], 1)
            self.assertEqual(json.loads(row["payload_json"])["client_submission_id"], "intake:offline")

    def test_outbox_sends_idempotency_conflict_to_dead_letter(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            outbox = GovernanceOutbox(Path(tmp) / "outbox.sqlite3")
            row_id = outbox.enqueue_intake({
                "schema_version": "drvknowledge.intake-request.v2",
                "client_submission_id": "intake:conflict",
            })
            result = outbox.replay(lambda _: {
                "ok": False,
                "status": 409,
                "data": {"error_code": "IDEMPOTENCY_CONFLICT"},
            })
            row = outbox.get(row_id)
            self.assertEqual(result, {"acknowledged": 0, "retry_wait": 0, "dead_letter": 1})
            self.assertEqual(row["state"], "dead_letter")
            self.assertIn("IDEMPOTENCY_CONFLICT", row["last_error"])

    def test_outbox_recovers_a_stale_sending_lease_after_process_exit(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "outbox.sqlite3"
            outbox = GovernanceOutbox(path, sending_timeout_seconds=30)
            row_id = outbox.enqueue_intake({
                "schema_version": "drvknowledge.intake-request.v2",
                "client_submission_id": "intake:stale-sending",
            })
            connection = sqlite3.connect(path)
            try:
                connection.execute(
                    "UPDATE governance_outbox SET state = 'sending', updated_at = ? WHERE id = ?",
                    ("2000-01-01T00:00:00+00:00", row_id),
                )
                connection.commit()
            finally:
                connection.close()
            result = outbox.replay(lambda _: {"ok": True, "status": 202})
            self.assertEqual(result["acknowledged"], 1)
            self.assertEqual(outbox.get(row_id)["state"], "acknowledged")

    def test_status_resolver_batches_live_and_falls_back_to_cache(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cache = GovernanceStatusCache(Path(tmp) / "status.sqlite3")

            class LiveClient:
                def ready(self):
                    return True

                def resolve_status(self, content_refs):
                    self.refs = content_refs
                    return {"ok": True, "data": {
                        "schema_version": "drvknowledge.governance-status.v2",
                        "trace_id": "trace-status-live",
                        "generated_at": "2026-08-30T08:00:00Z",
                        "items": [{
                            "content_ref": "bookstack:page:42",
                            "source_key": "bookstack_page:42",
                            "asset_id": 7,
                            "compile_status": "succeeded",
                            "review_status": "verified",
                            "rag_status": "ready",
                            "quality_score": 95,
                            "updated_at": "2026-08-30T08:00:00Z",
                        }],
                        "unresolved": [],
                    }}

            live = resolve_governance_statuses(["bookstack:page:42"], client=LiveClient(), cache=cache)
            self.assertEqual(live["statuses"], {"bookstack:page:42": "verified"})
            self.assertFalse(live["cache_used"])

            class OfflineClient:
                def ready(self):
                    return False

            offline = resolve_governance_statuses(["bookstack:page:42"], client=OfflineClient(), cache=cache)
            self.assertEqual(offline["statuses"], {"bookstack:page:42": "verified"})
            self.assertTrue(offline["cache_used"])
            self.assertEqual(offline["cache_as_of"], "2026-08-30T08:00:00Z")


if __name__ == "__main__":
    unittest.main()

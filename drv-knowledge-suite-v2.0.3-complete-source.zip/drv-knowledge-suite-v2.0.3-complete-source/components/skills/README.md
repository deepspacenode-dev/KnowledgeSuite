# Drv Knowledge Suite Skills/CLI V2.0.3

V2.0.3 在 V2.0.1 迁移能力上增加 RAGFlow v0.27.1 参数固化、BookStack 来源链接、领域防漂移、版本化解析 Profile，以及 BookStack 悬浮助手的 RAGFlow Chat 后端配置。

RAGFlow 迁移请使用 `--migrate-ragflow --site-config FILE`，不要把内网地址或 Token 写入源码模板。参见 [迁移说明](docs/RAGFLOW_MIGRATION_V2.0.1.md)。

## 统一用户入口

普通用户只需要记住 `kb`：

| 场景 | 形式 | 示例 |
|---|---|---|
| CodeBuddy | `/kb:动作` | `/kb:cases` |
| 终端 | `kb 动作` | `kb cases` |
| 自然语言 | 不要求记命令 | “查一下网络相关案例” |
| 产品名 | Drv Knowledge Suite | 保留 |
| 内部 Skill | `drv-knowledge-*` | 不面向普通用户 |
| 开发者 CLI | `drvkr` / `drvki` | 仅 `--developer` 安装 |

`/knowledge:*` 从 V1.0.8 起仅作为兼容格式保留，执行时给出弃用提醒；README 不再把它作为正式入口。

## CodeBuddy 命令

默认 retrieval 安装注册 11 个：

```text
/kb:cases
/kb:manuals
/kb:search
/kb:recall
/kb:status
/kb:where
/kb:gaps
/kb:graph
/kb:bootstrap
/kb:doctor
/kb:help
```

full 模式额外注册：

```text
/kb:ingest
```

入库子操作统一通过参数表达：

```text
/kb:ingest analyze file.docx
/kb:ingest import file.docx
/kb:ingest preview SESSION
/kb:ingest submit SESSION
/kb:ingest status SESSION
/kb:ingest experience
/kb:ingest manual chip.pdf
/kb:ingest sanitize-manual chip.md output/chip
```

不再单独注册 `query`、`manual`、`ingest-preview`、`ingest-submit` 等扁平命令。

## 安装

默认检索安装：

```bash
chmod +x install.sh
./install.sh
```

启用知识入库：

```bash
./install.sh --full
```

### full 模式依赖

项目包**不携带依赖 Wheel，也不会自动 pip 安装**。full 模式要求服务器已经具备：

```text
beautifulsoup4==4.14.3
python-docx==1.2.0
python-pptx==1.0.2
PyMuPDF==1.26.7
pdfplumber==0.11.7
Pillow==11.3.0
```

安装器只做检查。缺任意一项时退出 20，并且不会切换 Suite 组件。

## 本地手册

Markdown/TXT 手册可放入发行包 `manuals/` 或运行目录 `~/.drvknowledge/manuals/`。

```bash
kb manuals --refresh
kb manuals RTL8367S
kb recall -q "RTL8367S PHY link up 但没有流量"
```

本地手册可以在 RAGFlow manuals 数据集为空时参与 Recall V3。

### 超长芯片手册清洗

表格、图片密集的大型 Markdown 手册先执行：

```bash
drvki sanitize-manual chip.md output/chip
```

该命令完全离线运行，不覆盖原文，并生成 BookStack 阅读版、RAGFlow 文字分片、
图片清单、审计报告和 SHA-256 证据。RAGFlow 只上传 `ragflow/part-*.md`，每个
part 使用 `sanitized-chip-manual-v1` 文档级配置。

## 升级兼容

V2.0.1 保留 V1.0.8 的命令迁移规则，并新增显式 RAGFlow 站点迁移：

1. 安装 `commands/kb/` 到 `~/.codebuddy/commands/kb/`；
2. 对旧 `~/.codebuddy/commands/knowledge/` **只删除 Suite 已知旧命令文件**；
3. 未知/用户自定义命令文件原样保留；
4. Router 暂时兼容 `/knowledge:*` 并输出弃用提醒；
5. `/knowledge:query` 映射到 `/kb:search`；旧 flat ingest 命令映射到 `/kb:ingest ...`。

## 目录

```text
drv-knowledge-skills-v2.0.3/
├── README.md
├── VERSION
├── install.sh / install.py / install.cmd
├── PACKAGE_MANIFEST.txt
├── commands/kb/                # full 12 个；retrieval 安装时去掉 ingest.md
├── manuals/                    # 本地手册内容注入区
├── requirements/full.txt       # 仅声明 6 个 full 必需插件，不含 Wheel
├── skills/
│   ├── drv-knowledge-router/
│   ├── drv-knowledge-retrieval/
│   └── drv-knowledge-ingestion/
├── lib/drv_knowledge_core/
├── tools/
├── docs/
└── tests/
```

## 重点文档

- `docs/QUICKSTART.md`
- `docs/MIGRATION.md`
- `docs/INGESTION_DEPENDENCIES_V1.0.8.md`
- `docs/DETAILED_DESIGN.md`
- `docs/TEST_REPORT.md`

#!/usr/bin/env python3
from __future__ import annotations
import argparse, datetime, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
from tools.install.write_cli import write_cli

VERSION='2.0.3'
ROOT=Path(__file__).resolve().parent
ALL_SKILLS=['drv-knowledge-router','drv-knowledge-retrieval','drv-knowledge-ingestion']
OLD_NAMES=['drv-knowledge','drv-knowledge-ingest','drv-knowledge-retrieval','drv-knowledge-ingestion','drv-knowledge-router','rag-search','bookstack-fetch']


def verify_manifest()->dict:
    manifest=ROOT/'PACKAGE_MANIFEST.txt'
    if not manifest.is_file(): return {'ok':False,'error':'ManifestMissing','checked':0}
    bad=[]; checked=0
    for raw in manifest.read_text(encoding='utf-8').splitlines():
        line=raw.strip()
        if not line: continue
        try: expected,rel=line.split(None,1)
        except ValueError: bad.append({'path':line,'reason':'invalid manifest line'}); continue
        path=ROOT/rel.strip()
        if not path.is_file(): bad.append({'path':rel,'reason':'missing'}); continue
        actual=hashlib.sha256(path.read_bytes()).hexdigest(); checked+=1
        if actual!=expected: bad.append({'path':rel,'reason':'sha256 mismatch'})
    return {'ok':not bad,'checked':checked,'bad':bad}


def check_environment(profile:str)->tuple[int,dict]:
    args=[sys.executable,str(ROOT/'tools/install/dependency_check.py'),'--profile',profile,'--json']
    proc=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    try: payload=json.loads(proc.stdout)
    except Exception: payload={'ok':False,'raw':proc.stdout,'stderr':proc.stderr}
    return proc.returncode,payload

def parse_env(path:Path)->dict[str,str]:
    out={}
    if not path.is_file(): return out
    for raw in path.read_text(encoding='utf-8',errors='ignore').splitlines():
        line=raw.strip()
        if not line or line.startswith('#') or '=' not in line: continue
        k,v=line.split('=',1); k=k.strip(); v=v.strip().strip('"\'')
        if k: out[k]=v
    return out


KB_COMMAND_FILES={'bootstrap.md','cases.md','doctor.md','gaps.md','graph.md','help.md','ingest.md','manuals.md','recall.md','search.md','status.md','where.md'}
LEGACY_KNOWLEDGE_FILES={'bootstrap.md','cases.md','doctor.md','gaps.md','graph.md','help.md','ingest-experience.md','ingest-preview.md','ingest-status.md','ingest-submit.md','ingest.md','manual.md','manuals.md','query.md','recall.md','search.md','status.md','where.md'}

def _remove_known_commands(directory:Path,names:set[str]):
    if not directory.is_dir(): return
    for name in names:
        p=directory/name
        if p.is_file(): p.unlink()
    try: directory.rmdir()
    except OSError: pass

def install_commands(target:Path,profile:str)->list[str]:
    src=ROOT/'commands'/'kb'; dst=target/'commands'/'kb'
    if not src.is_dir(): return []
    dst.mkdir(parents=True,exist_ok=True); installed=[]
    _remove_known_commands(dst,KB_COMMAND_FILES)
    dst.mkdir(parents=True,exist_ok=True)
    allowed=set(KB_COMMAND_FILES) if profile=='full' else set(KB_COMMAND_FILES)-{'ingest.md'}
    for f in sorted(src.glob('*.md')):
        if f.name not in allowed: continue
        shutil.copy2(f,dst/f.name); installed.append(str(dst/f.name))
    # Remove only Suite-owned legacy /knowledge:* files; preserve user custom files.
    _remove_known_commands(target/'commands'/'knowledge',LEGACY_KNOWLEDGE_FILES)
    return installed

def credentials_present(envfile:Path)->dict[str,bool]:
    env=parse_env(envfile)
    return {
        'ragflow':bool(env.get('RAGFLOW_BASE_URL') and env.get('RAGFLOW_API_KEY')),
        'bookstack':bool(env.get('BOOKSTACK_BASE_URL') and env.get('BOOKSTACK_TOKEN_ID') and env.get('BOOKSTACK_TOKEN_SECRET')),
        'governance':bool(env.get('GOVERNANCE_COOKIE')),
    }


def run_installed(target:Path,runtime:Path,args:list[str])->subprocess.CompletedProcess[str]:
    env=os.environ.copy(); env['DRVKB_RUNTIME_DIR']=str(runtime); env['DRVKNOWLEDGE_RUNTIME_DIR']=str(runtime)
    env['DRVKB_ENV_FILE']=str(runtime/'.env')
    entry=target/'skills/drv-knowledge-router/scripts/router_cli.py'
    return subprocess.run([sys.executable,str(entry),*args],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)


def main():
    p=argparse.ArgumentParser(description=f'Install Drv Knowledge Suite v{VERSION}')
    p.add_argument('--target',default=str(Path.home()/'.codebuddy'))
    p.add_argument('--runtime-dir',default=str(Path.home()/'.drvknowledge'))
    p.add_argument('--bin-dir',default=str((Path.home()/'.local/bin') if os.name!='nt' else (Path.home()/'.drvknowledge/bin')))
    p.add_argument('--no-backup',action='store_true')
    p.add_argument('--profile',choices=['retrieval','full'],default='retrieval')
    p.add_argument('--full',action='store_true',help='shortcut for --profile full')
    p.add_argument('--developer',action='store_true',help='install drvkr and full-only drvki developer CLIs')
    p.add_argument('--site-config',help='optional private env file for internal one-step deployment; defaults to config/site.env when present')
    p.add_argument('--migrate-ragflow',action='store_true',help='replace RAGFlow using site config; reset old dataset IDs and remote caches')
    p.add_argument('--no-verify',action='store_true',help='skip PACKAGE_MANIFEST integrity verification')
    p.add_argument('--no-bootstrap',action='store_true',help='do not auto-build Knowledge Catalog even when live credentials are present')
    p.add_argument('--strict',action='store_true',help='return non-zero when local/live validation is not ready')
    a=p.parse_args()

    if sys.version_info < (3,10):
        print('ERROR: Python 3.10+ is required.',file=sys.stderr); return 2
    profile='full' if a.full else a.profile
    if not a.no_verify:
        integrity=verify_manifest()
        if not integrity.get('ok'):
            print('ERROR: release integrity verification failed. Re-download/re-extract the package, or use --no-verify only for development.',file=sys.stderr)
            for item in integrity.get('bad',[])[:10]: print(f"  - {item.get('path')}: {item.get('reason')}",file=sys.stderr)
            return 3
        print(f"Package integrity: PASS ({integrity.get('checked')} files)")

    dep_rc,dep_result=check_environment(profile)
    print('Environment preflight:')
    print(json.dumps(dep_result,ensure_ascii=False,indent=2))
    if dep_rc!=0:
        print('ERROR: mandatory ingestion dependencies are missing; no Suite component was installed. The Suite never runs pip automatically.',file=sys.stderr)
        return 20

    target=Path(a.target).expanduser().resolve(); runtime=Path(a.runtime_dir).expanduser().resolve(); bin_dir=Path(a.bin_dir).expanduser().resolve()
    skills=target/'skills'; lib=target/'lib'; skills.mkdir(parents=True,exist_ok=True); lib.mkdir(parents=True,exist_ok=True); runtime.mkdir(parents=True,exist_ok=True)
    manual_dst=runtime/'manuals'; manual_dst.mkdir(parents=True,exist_ok=True)
    manual_src=ROOT/'manuals'
    if manual_src.is_dir():
        for src in manual_src.rglob('*'):
            rel=src.relative_to(manual_src); dst=manual_dst/rel
            if src.is_dir(): dst.mkdir(parents=True,exist_ok=True)
            elif src.is_file(): dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S'); backup=target/'skills_backup'/f'pre_drv_knowledge_suite_v{VERSION}_{stamp}'

    # Preserve old installation before cleanup.
    if not a.no_backup:
        for n in OLD_NAMES:
            src=skills/n
            if src.exists(): backup.mkdir(parents=True,exist_ok=True); shutil.copytree(src,backup/n,dirs_exist_ok=True)
        dot_backup=skills/'.backup'
        if dot_backup.exists(): backup.mkdir(parents=True,exist_ok=True); shutil.copytree(dot_backup,backup/'legacy_dot_backup',dirs_exist_ok=True)

    # Both entry points share the same validation, precedence and migration semantics.
    shared_env=runtime/'.env'; template=ROOT/'config/env.example'
    site_cfg=Path(a.site_config).expanduser().resolve() if a.site_config else (ROOT/'config/site.env')
    config_args=[sys.executable,str(ROOT/'tools/install/config_migrate.py'),'--runtime',str(runtime),
                 '--target',str(target),'--template',str(template),'--profile',profile,'--write','--show-redacted','--json']
    if a.site_config or site_cfg.is_file(): config_args.extend(['--site-config',str(site_cfg)])
    if a.migrate_ragflow: config_args.append('--migrate-ragflow')
    configuration=subprocess.run(config_args,text=True,encoding='utf-8',stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    print(configuration.stdout)
    if configuration.returncode:
        print('ERROR: shared configuration validation failed; Suite components were not replaced.',file=sys.stderr)
        if configuration.stderr: print(configuration.stderr,file=sys.stderr)
        return 30
    if a.migrate_ragflow:
        for key in list(os.environ):
            if key.startswith('RAGFLOW_') or key=='DRVKB_DATASET_PROFILE': os.environ.pop(key,None)
    os.environ['DRVKB_ENV_FILE']=str(shared_env)
    os.environ['DRVKB_INSTALL_PROFILE']=profile

    # Remove legacy triggerable Skills and scan-visible backups.
    for n in ['drv-knowledge','drv-knowledge-ingest','drv-knowledge-ingestion','rag-search','bookstack-fetch','rag-search.bak','bookstack-fetch.bak']:
        legacy=skills/n
        if legacy.exists(): shutil.rmtree(legacy) if legacy.is_dir() else legacy.unlink()
    dot_backup=skills/'.backup'
    if dot_backup.exists(): shutil.rmtree(dot_backup)

    # Install components.
    skills_to_install=ALL_SKILLS if profile=='full' else ALL_SKILLS[:2]
    for n in skills_to_install:
        dst=skills/n
        if dst.exists(): shutil.rmtree(dst)
        shutil.copytree(ROOT/'skills'/n,dst)
    dst_core=lib/'drv_knowledge_core'
    if dst_core.exists(): shutil.rmtree(dst_core)
    shutil.copytree(ROOT/'lib/drv_knowledge_core',dst_core)


    cli_files=write_cli(bin_dir,target,runtime,profile,a.developer)
    command_files=install_commands(target,profile)

    # Always run local suite doctor from the installed copy.
    local=run_installed(target,runtime,['doctor','--json'])
    try: local_payload=json.loads(local.stdout)
    except Exception: local_payload={'ready':False,'raw':local.stdout,'stderr':local.stderr}

    creds=credentials_present(shared_env); bootstrap=None
    if creds['ragflow'] and not a.no_bootstrap:
        env=os.environ.copy(); env['DRVKB_RUNTIME_DIR']=str(runtime); env['DRVKNOWLEDGE_RUNTIME_DIR']=str(runtime)
        entry=target/'skills/drv-knowledge-retrieval/scripts/drvkb_entry.py'
        args=[sys.executable,str(entry),'bootstrap','--json']
        if not creds['bookstack']: args.append('--no-bookstack')
        proc=subprocess.run(args,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
        try: payload=json.loads(proc.stdout)
        except Exception: payload={'raw':proc.stdout,'stderr':proc.stderr}
        bootstrap={'returncode':proc.returncode,'payload':payload}

    print(f'\nDrv Knowledge Suite v{VERSION} installation complete')
    print(f'- Profile: {profile}')
    print(f'- Skills: {", ".join(skills_to_install)}')
    print(f'- Shared core: {dst_core}')
    print(f'- Shared config: {shared_env}')
    print(f'- CLI: {bin_dir}/kb')
    print(f"- CodeBuddy commands: {len(command_files)} files -> {target / 'commands' / 'kb'}")
    manual_count=sum(1 for x in manual_dst.rglob('*') if x.is_file() and x.suffix.lower() in {'.md','.markdown','.txt'} and x.name.lower()!='readme.md')
    if profile=='full':
        print('- Dependencies: 6 / 6 required ingestion plugins ready (check-only; pip never invoked)')
    else:
        print('- Dependencies: format plugins not required for retrieval')
    print(f'- Local manuals: {manual_count} file(s) -> {manual_dst}')
    print(f"- Local self-check: {'PASS' if local.returncode==0 and local_payload.get('local_ok',local_payload.get('ready')) else 'FAIL'}")
    if bootstrap is None:
        print('- Knowledge Catalog: not auto-built (configure RAGFlow in shared .env, then run `kb bootstrap`)')
    else:
        print(f"- Knowledge Catalog: {'READY' if bootstrap['returncode']==0 else 'FAILED - run `kb bootstrap` after checking network/config'}")
    if os.name!='nt' and str(bin_dir) not in os.environ.get('PATH','').split(':'):
        print(f'- PATH note: add {bin_dir} to PATH, or invoke {bin_dir}/kb directly')
    print('\nNext recommended commands:')
    print('  kb doctor')
    print('  kb doctor --live')
    print('  kb manuals')
    print('  kb cases')
    if profile=='full': print('  kb ingest analyze <file>')

    warnings=[]
    if local.returncode!=0: warnings.append('local doctor failed')
    if bootstrap and bootstrap['returncode']!=0: warnings.append('live catalog bootstrap failed')
    if a.strict and warnings:
        print('STRICT install not ready: '+', '.join(warnings),file=sys.stderr); return 4
    return 0

if __name__=='__main__': raise SystemExit(main())

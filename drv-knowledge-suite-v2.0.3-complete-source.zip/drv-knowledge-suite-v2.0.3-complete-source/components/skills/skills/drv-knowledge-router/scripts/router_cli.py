#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path


VERSION = "2.0.3"
SKILL_DIR = Path(__file__).resolve().parents[1]
SUITE_HOME = SKILL_DIR.parents[1]
CORE_PARENT = SUITE_HOME / "lib"
if CORE_PARENT.is_dir() and str(CORE_PARENT) not in sys.path:
    sys.path.insert(0, str(CORE_PARENT))

RETRIEVAL_DIRECT = {
    "init", "recall", "search", "evaluate", "browse", "cases", "manuals", "bootstrap", "refresh", "catalog",
    "status", "where", "graph", "gaps", "ask", "command", "bookstack", "governance", "gap", "rag", "selftest", "kb-help",
}
INGEST_AI_ASSISTED = {"experience", "tech-note", "tech_note"}


def _runtime_dir() -> Path:
    return Path(os.environ.get("DRVKB_RUNTIME_DIR") or os.environ.get("DRVKNOWLEDGE_RUNTIME_DIR") or "~/.drvknowledge").expanduser()


def _active_profile() -> str:
    profile = (os.environ.get("DRVKB_INSTALL_PROFILE") or "").strip().lower()
    if not profile:
        envfile = _runtime_dir() / ".env"
        if envfile.is_file():
            for raw in envfile.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = raw.strip()
                if line.startswith("DRVKB_INSTALL_PROFILE="):
                    profile = line.split("=", 1)[1].strip().strip("\"'").lower()
                    break
    return profile if profile in {"retrieval", "full"} else "retrieval"


def _find_skill(name: str) -> Path | None:
    for path in (SKILL_DIR.parent / name, Path.home() / ".codebuddy" / "skills" / name):
        if path.is_dir():
            return path
    return None


def _ingestion_available() -> bool:
    return _active_profile() == "full" and _find_skill("drv-knowledge-ingestion") is not None


def _skill_root(name: str) -> Path:
    path = _find_skill(name)
    if path is not None:
        return path
    hint = "run ./install.sh --full" if name == "drv-knowledge-ingestion" else "reinstall drv-knowledge-suite"
    raise RuntimeError(f"{name} not found; {hint}")


def _entry(target: str) -> Path:
    if target == "retrieval":
        return _skill_root("drv-knowledge-retrieval") / "scripts" / "drvkb_entry.py"
    if target == "ingestion" and _ingestion_available():
        return _skill_root("drv-knowledge-ingestion") / "scripts" / "ingest_cli.py"
    raise RuntimeError("Knowledge ingestion is not enabled; prepare the six required plugins, then run ./install.sh --full")


def _unsupported_ingestion(query: str) -> dict:
    return {
        "target": "unsupported",
        "operation": "ingestion_not_installed",
        "query": query,
        "message": "当前未启用知识入库；请先由管理员准备 6 个必需插件，再执行 ./install.sh --full。",
    }


LEGACY_COMMAND_ALIASES = {
    "query": "search",
    "manual": "ingest manual",
    "ingest-preview": "ingest preview",
    "ingest-submit": "ingest submit",
    "ingest-status": "ingest status",
    "ingest-experience": "ingest experience",
}


def _split_user_command(command: str) -> tuple[str, str, bool]:
    """Return namespace, normalized tail and legacy flag.

    Supported during V1.0.8 migration:
      /kb:cases
      /kb cases
      /knowledge:cases
      /knowledge cases
    """
    raw = command.strip()
    m = re.match(r"^/(kb|knowledge)(?::|\s+)?(.*)$", raw, re.I)
    if not m:
        raise ValueError("command must start with /kb: or /kb")
    namespace = m.group(1).lower()
    tail = (m.group(2) or "").strip()
    legacy = namespace == "knowledge"
    return namespace, tail, legacy


def resolve_command(text: str) -> dict:
    command = text.strip()
    namespace, tail, legacy = _split_user_command(command)
    if not tail:
        tail = "help"

    # Compatibility aliases from the old /knowledge:* flat namespace.
    first, *rest = tail.split(None, 1)
    alias = LEGACY_COMMAND_ALIASES.get(first.lower())
    if alias:
        tail = alias + ((" " + rest[0]) if rest else "")

    result: dict
    if re.match(r"^ingest(?:\s|$)", tail, re.I):
        if not _ingestion_available():
            result = _unsupported_ingestion(command)
        else:
            result = {"target": "ingestion", "command": tail[len("ingest"):].strip() or "help", "original": command}
    else:
        result = {"target": "retrieval", "command": tail or "help", "original": command}

    result["namespace"] = namespace
    if legacy:
        result["deprecated"] = True
        legacy_name = first.lower()
        replacement = {
            "query": "/kb:search",
            "manual": "/kb:ingest manual",
            "ingest-preview": "/kb:ingest preview",
            "ingest-submit": "/kb:ingest submit",
            "ingest-status": "/kb:ingest status",
            "ingest-experience": "/kb:ingest experience",
        }.get(legacy_name, f"/kb:{legacy_name}")
        result["deprecation"] = f"/knowledge:{legacy_name} 已更名为 {replacement}；旧 /knowledge:* 格式将在后续版本移除。"
    return result


def resolve_natural(query: str) -> dict:
    low = query.strip().lower()
    ingest_terms = ["入库", "沉淀", "导入", "上传知识库", "提交知识库", "提交审批", "整理成案例", "形成案例", "生成案例", "整理成经验", "形成经验", "生成经验", "知识生产"]
    if any(term in low for term in ingest_terms):
        if not _ingestion_available():
            return _unsupported_ingestion(query)
        if any(term in low for term in ["案例", "经验", "刚才这个问题", "当前问题"]):
            operation = "experience"
        elif any(term in low for term in ["技术专题", "技术笔记", "专题"]):
            operation = "tech-note"
        elif any(term in low for term in ["文件", "pdf", "docx", "pptx", "markdown", "md", "html", "txt"]):
            operation = "analyze/import"
        else:
            operation = "help"
        return {"target": "ingestion", "operation": operation, "query": query}
    if any(term in low for term in ["所有案例", "全部案例", "案例有哪些"]):
        operation = "cases"
    elif "手册" in low and any(term in low for term in ["哪些", "所有", "全部", "有多少"]):
        operation = "manuals"
    elif any(term in low for term in ["为什么", "怎么排查", "分析", "之前有没有", "手册", "寄存器", "datasheet"]):
        operation = "recall"
    elif any(term in low for term in ["缺口", "缺什么"]):
        operation = "gaps"
    elif any(term in low for term in ["状态", "没入库", "未入库", "解析失败", "审核"]):
        operation = "status"
    else:
        operation = "search"
    return {"target": "retrieval", "operation": operation, "query": query}


def run_target(target: str, argv: list[str]) -> int:
    child_env = os.environ.copy()
    child_env.setdefault("PYTHONUTF8", "1")
    return subprocess.call([sys.executable, str(_entry(target)), *argv], env=child_env)


def _capture_target(target: str, argv: list[str]) -> tuple[int, object, str]:
    proc = subprocess.run([sys.executable, str(_entry(target)), *argv], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    try:
        payload = json.loads(proc.stdout) if proc.stdout.strip() else {}
    except Exception:
        payload = {"raw_stdout": proc.stdout.strip()}
    if proc.stderr.strip() and isinstance(payload, dict):
        payload.setdefault("stderr", proc.stderr.strip())
    return proc.returncode, payload, proc.stderr


def command_to_argv(spec: dict) -> list[str]:
    if spec.get("target") == "unsupported":
        raise RuntimeError(spec.get("message") or "unsupported operation")
    command = spec["command"].strip()
    if spec["target"] == "ingestion":
        if not command or command == "help":
            return ["--help"]
        parts = shlex.split(command)
        operation, rest = parts[0].lower(), parts[1:]
        if operation in {"analyze", "import", "preview", "route", "submit", "status", "manual", "doctor", "selftest"}:
            return [operation, *rest]
        return ["command", "/kb ingest " + command]
    if not command or command == "help":
        return ["kb-help"]
    return ["command", "/kb " + command]


def _core_preflight():
    try:
        from drv_knowledge_core.preflight import check_dependencies, env_path
        return check_dependencies(), env_path()
    except Exception as exc:
        return {"ok": False, "error": "CorePreflightUnavailable", "message": str(exc), "missing_packages": []}, _runtime_dir() / ".env"


def _parse_env_file(path: Path) -> dict[str, str]:
    values = {}
    if not path.is_file():
        return values
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip()
        if len(value) >= 2 and value[0] in "\"'" and value[-1] == value[0]:
            value = value[1:-1]
        if key:
            values[key] = value
    return values


def _redact_value(key: str, value: str) -> str:
    if not value:
        return "<empty>"
    if any(hint in key.upper() for hint in ("KEY", "TOKEN", "SECRET", "COOKIE", "PASSWORD")):
        return "configured:" + ("****" + value[-4:] if len(value) > 4 else "****")
    return value


def command_config(args) -> int:
    _, envfile = _core_preflight()
    values = _parse_env_file(envfile)
    problems, warnings = [], []
    if values.get("RAGFLOW_API_KEY") and not values.get("RAGFLOW_BASE_URL"):
        problems.append("RAGFLOW_API_KEY requires RAGFLOW_BASE_URL")
    if values.get("RAGFLOW_BASE_URL") and not values.get("RAGFLOW_API_KEY"):
        warnings.append("RAGFlow endpoint is staged; live retrieval remains disabled until RAGFLOW_API_KEY is configured")
    bookstack = [values.get("BOOKSTACK_BASE_URL"), values.get("BOOKSTACK_TOKEN_ID"), values.get("BOOKSTACK_TOKEN_SECRET")]
    if any(bookstack) and not all(bookstack):
        problems.append("BookStack URL/token id/token secret must be configured together")
    if not values.get("RAGFLOW_BASE_URL"):
        warnings.append("RAGFlow live retrieval not configured")
    if not all(bookstack):
        warnings.append("BookStack live browse/submit not fully configured")
    profile = values.get("DRVKB_INSTALL_PROFILE", "retrieval") or "retrieval"
    if profile not in {"retrieval", "full"}:
        problems.append("DRVKB_INSTALL_PROFILE must be retrieval|full")
    payload = {"ok": not problems, "path": str(envfile), "exists": envfile.is_file(), "profile": profile, "problems": problems, "warnings": warnings}
    if args.config_action == "show":
        payload["values"] = {key: _redact_value(key, value) for key, value in sorted(values.items())}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload["ok"] else 30


def doctor_payload(live: bool = False) -> tuple[int, dict]:
    deps, envfile = _core_preflight()
    profile = deps.get("profile", _active_profile())
    full = profile == "full"
    retrieval_rc, retrieval, _ = _capture_target("retrieval", ["doctor", *(["--live"] if live else []), "--json"])
    retrieval_test_rc, retrieval_test, _ = _capture_target("retrieval", ["selftest", "--json"])
    components = {
        "retrieval": {
            "doctor_returncode": retrieval_rc,
            "selftest_returncode": retrieval_test_rc,
            "doctor": retrieval,
            "selftest": retrieval_test,
        }
    }
    ingestion_doctor_rc = 0
    ingestion_test_rc = 0
    if full:
        if _ingestion_available():
            ingestion_doctor_rc, ingestion, _ = _capture_target("ingestion", ["doctor", *(["--live"] if live else [])])
            ingestion_test_rc, ingestion_test, _ = _capture_target("ingestion", ["selftest"])
        else:
            ingestion_doctor_rc = ingestion_test_rc = 2
            ingestion = ingestion_test = {"error": "IngestionSkillMissing", "message": "prepare the six required plugins, then run ./install.sh --full"}
        components["ingestion"] = {
            "doctor_returncode": ingestion_doctor_rc,
            "selftest_returncode": ingestion_test_rc,
            "doctor": ingestion,
            "selftest": ingestion_test,
        }

    readiness = (retrieval.get("readiness") or {}) if isinstance(retrieval, dict) else {}
    bookstack_ready = bool(readiness.get("bookstack_live"))
    ragflow_ready = bool(readiness.get("ragflow_live"))
    governance_ready = bool(readiness.get("governance_live"))
    local_ok = retrieval_test_rc == 0 and bool(deps.get("ok")) and (not full or ingestion_test_rc == 0)
    retrieval_live_ok = retrieval_rc == 0 and bool(retrieval.get("live_ok")) if live else True
    full_live_ok = retrieval_live_ok and bookstack_ready and ingestion_doctor_rc == 0 if full and live else retrieval_live_ok
    payload = {
        "suite": "drv-knowledge-suite",
        "version": VERSION,
        "profile": profile,
        "local_ok": local_ok,
        "live_requested": live,
        "ready_scope": "full_api_connectivity" if live and full else ("retrieval_api_connectivity" if live else "local_install"),
        "ready": local_ok and (full_live_ok if live else True),
        "config": {"path": str(envfile), "exists": envfile.is_file()},
        "dependencies": deps,
        "components": components,
        "services": {"ragflow": ragflow_ready, "bookstack": bookstack_ready, "governance": governance_ready, "governance_optional": True},
        "services_checked": live,
        "configured": retrieval.get("configured", {}),
        "ragflow_index": retrieval.get("ragflow_index", {"state": "not_checked", "real_query_verified": False}),
        "readiness": {
            "local": local_ok,
            "retrieval_live": bool(live and local_ok and retrieval_live_ok),
            "ingestion_submit": bool(live and full and local_ok and bookstack_ready and ingestion_doctor_rc == 0),
            "governance": governance_ready,
        },
        "catalog_cached": bool(readiness.get("catalog_cached")),
        "local_manuals": retrieval.get("local_manuals", {}) if isinstance(retrieval, dict) else {},
    }
    return (0 if payload["ready"] else (6 if live else 5)), payload


def print_doctor(payload: dict):
    deps = payload.get("dependencies", {})
    print(f"Drv Knowledge Suite v{payload['version']} ({payload.get('profile', 'retrieval')})")
    print(f"- Shared config: {'OK' if payload['config']['exists'] else 'MISSING'}  {payload['config']['path']}")
    print(f"- Runtime dependencies: {'OK' if deps.get('ok') else 'MISSING: ' + ', '.join(deps.get('missing_packages', []))}")
    print(f"- Retrieval selftest: {'PASS' if payload['components']['retrieval']['selftest_returncode'] == 0 else 'FAIL'}")
    if "ingestion" in payload["components"]:
        print(f"- Ingestion selftest: {'PASS' if payload['components']['ingestion']['selftest_returncode'] == 0 else 'FAIL'}")
    for service in ("ragflow", "bookstack", "governance"):
        state=("API REACHABLE" if payload['services'][service] else "NOT REACHABLE / NOT CONFIGURED") if payload['live_requested'] else ("CONFIGURED, NOT PROBED" if payload.get('configured',{}).get(service) else "NOT CONFIGURED")
        print(f"- {service}: {state}")
    print(f"- RAGFlow index: {payload['ragflow_index']['state']} (real query not verified)")
    if payload['ragflow_index']['state'] == 'pending_parse':
        print("- Action: parse the migrated documents in RAGFlow, then run kb recall with a known question.")
    print(f"- Knowledge Catalog: {'READY' if payload['catalog_cached'] else 'NOT BUILT'}")
    local_manuals = payload.get("local_manuals", {})
    print(f"- Local manuals: {local_manuals.get('document_count', 0)} file(s) / {local_manuals.get('root', '~/.drvknowledge/manuals')}")
    print(f"- Overall: {('LIVE API READY' if payload['live_requested'] else 'LOCAL READY') if payload['ready'] else 'ACTION REQUIRED'}")
    if not payload["live_requested"]:
        print("- Next: run kb doctor --live to validate real RAGFlow + BookStack.")


def show_help() -> int:
    print("""Drv Knowledge Suite / kb

Public naming:
  CodeBuddy: /kb:cases, /kb:recall, /kb:search ...
  Terminal:  kb cases, kb recall -q "..."
  Legacy /knowledge:* is accepted temporarily with a deprecation warning.

Common retrieval:
  kb cases [filter]
  kb manuals [filter]
  kb search -q <keywords>
  kb recall -q <question>
  kb status
  kb gaps
  kb where <keyword>

Local chip manuals:
  Put Markdown manuals under ~/.drvknowledge/manuals/.
  kb manuals --refresh rebuilds the local index.
""")
    if _ingestion_available():
        print("""Knowledge ingestion (full profile):
  kb ingest analyze <file>
  kb ingest import <file>
  kb ingest preview <session>
  kb ingest submit <session> --book <book> --confirm
  kb ingest status <session> --refresh
  kb ingest experience
  kb ingest manual <pdf>
  kb ingest sanitize-manual <markdown> <output-dir>
""")
    else:
        print("Knowledge ingestion: disabled. Prepare the six required plugins, then run ./install.sh --full.\n")
    print("""Setup & diagnostics:
  kb init
  kb bootstrap
  kb doctor
  kb doctor --live
  kb config validate
  kb config show --redacted
""")
    return 0


def _direct_dispatch(argv: list[str]) -> int | None:
    if not argv:
        return None
    operation = argv[0].lower()
    if operation == "ingest":
        if not _ingestion_available():
            print("ERROR: knowledge ingestion is disabled. Prepare the six required plugins, then run ./install.sh --full.", file=sys.stderr)
            return 2
        rest = argv[1:]
        if not rest:
            return run_target("ingestion", ["--help"])
        if rest[0].lower() in INGEST_AI_ASSISTED:
            return run_target("ingestion", ["command", "/kb ingest " + " ".join(shlex.quote(x) for x in rest)])
        return run_target("ingestion", rest)
    if operation in RETRIEVAL_DIRECT:
        return run_target("retrieval", argv)
    return None


def main() -> int:
    if len(sys.argv) > 1:
        first = sys.argv[1].lower()
        if first not in {"doctor", "help", "--help", "-h", "--version", "version", "setup", "command", "ask", "config"}:
            direct = _direct_dispatch(sys.argv[1:])
            if direct is not None:
                return direct

    parser = argparse.ArgumentParser(description=f"Drv Knowledge Suite router v{VERSION}", add_help=True)
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="op")
    command = sub.add_parser("command")
    command.add_argument("text")
    command.add_argument("--resolve-only", action="store_true")
    ask = sub.add_parser("ask")
    ask.add_argument("-q", "--query", required=True)
    ask.add_argument("--resolve-only", action="store_true")
    sub.add_parser("help")
    doctor = sub.add_parser("doctor")
    doctor.add_argument("--live", action="store_true")
    doctor.add_argument("--json", action="store_true")
    setup = sub.add_parser("setup")
    setup.add_argument("--force", action="store_true")
    setup.add_argument("--bootstrap", action="store_true")
    config = sub.add_parser("config")
    config_actions = config.add_subparsers(dest="config_action", required=True)
    config_actions.add_parser("validate")
    show = config_actions.add_parser("show")
    show.add_argument("--redacted", action="store_true", default=True)
    args = parser.parse_args()

    if not args.op or args.op == "help":
        return show_help()
    if args.op == "command":
        spec = resolve_command(args.text)
        if args.resolve_only:
            print(json.dumps(spec, ensure_ascii=False, indent=2))
            return 0
        if spec.get("deprecated"):
            print("DEPRECATED: " + spec.get("deprecation", "/knowledge:* 已更名为 /kb:*"), file=sys.stderr)
        if spec.get("target") == "unsupported":
            print(spec["message"], file=sys.stderr)
            return 2
        parts=shlex.split(spec.get("command", ""))
        if spec["target"] == "retrieval" and parts and parts[0].lower() == "doctor":
            options=doctor.parse_args(parts[1:])
            rc,payload=doctor_payload(options.live)
            if options.json: print(json.dumps(payload,ensure_ascii=False,indent=2))
            else: print_doctor(payload)
            return rc
        return run_target(spec["target"], command_to_argv(spec))
    if args.op == "ask":
        spec = resolve_natural(args.query)
        if args.resolve_only or spec.get("target") != "retrieval":
            print(json.dumps(spec, ensure_ascii=False, indent=2))
            return 0 if args.resolve_only or spec.get("target") == "ingestion" else 2
        return run_target("retrieval", ["ask", "-q", args.query])
    if args.op == "doctor":
        rc, payload = doctor_payload(args.live)
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print_doctor(payload)
        return rc
    if args.op == "config":
        return command_config(args)
    if args.op == "setup":
        init_args = ["init"] + (["--force"] if args.force else [])
        rc = run_target("retrieval", init_args)
        if rc not in (0, 2):
            return rc
        return run_target("retrieval", ["bootstrap"]) if args.bootstrap else 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

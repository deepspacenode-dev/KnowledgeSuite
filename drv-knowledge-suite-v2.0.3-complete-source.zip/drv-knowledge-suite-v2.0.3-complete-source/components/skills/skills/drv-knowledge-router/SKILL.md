---
name: drv-knowledge-router
description: Drv Knowledge Suite 统一知识路由 Skill。负责把自然语言和 /kb 命令路由到知识获取 drv-knowledge-retrieval 或知识入库 drv-knowledge-ingestion。用户不需要知道底层 Skill、RAGFlow、BookStack、Dataset 或文件处理引擎。
---

# drv-knowledge-router v2.0.3

## 唯一用户入口

对外统一使用 `/kb:*` CodeBuddy 命令、`kb ...` 终端命令或自然语言。`knowledge` 只保留为内部概念，不再作为正式用户命令命名空间。

### 路由规则

- 查、找、搜索、所有案例、有哪些手册、Recall、状态、图谱、Gap → `drv-knowledge-retrieval`。
- full Profile 下，入库、沉淀、导入、上传知识库、整理成案例、提交审批、预览草稿 → `drv-knowledge-ingestion`。
- retrieval Profile 下，同类意图明确返回 `ingestion_not_installed`；管理员准备 6 个入库转换必需插件后才能执行 `./install.sh --full`。
- `/kb:ingest ...` / `kb ingest ...` 仅在 full Profile、Ingestion Skill 已安装且 6 个必需插件均满足时路由。
- 其它 `/kb:*` / `kb ...` 默认路由到 Retrieval。
- V1.0.8 暂时兼容 `/knowledge:*`，执行时输出弃用提醒；正式文档只展示 `/kb:*`。

### 安全边界

路由到 Ingestion 也不等于允许写入。BookStack Submit 仍必须经过 Preview 与用户明确确认。运行时命令不得自行调用 pip。

### 自然语言示例

- “帮我找到目前库上所有案例内容” → retrieval / browse cases all。
- “Sensor 手册有哪些” → retrieval / browse manuals sensor。
- “把刚才这个问题整理成案例” → ingestion / experience。
- “把这个老 DOCX 放知识库” → ingestion / analyze + import。

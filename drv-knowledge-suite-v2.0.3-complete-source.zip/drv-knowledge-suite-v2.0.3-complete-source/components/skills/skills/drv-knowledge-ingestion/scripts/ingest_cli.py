#!/usr/bin/env python3
from __future__ import annotations
import argparse, datetime as dt, hashlib, html, json, os, re, shutil, subprocess, sys, uuid
from pathlib import Path
from urllib import request, parse, error

# Shared core bootstrap.
# Prefer the core shipped with the current suite/staging tree and stop after
# the first valid candidate. Loading every candidate with insert(0) reverses
# priority and can accidentally load an older installed core during upgrades.
for _p in [Path(__file__).resolve().parents[3]/'lib', Path.home()/'.codebuddy'/'lib']:
    if (_p/'drv_knowledge_core').is_dir():
        if str(_p) not in sys.path:
            sys.path.insert(0,str(_p))
        break
from drv_knowledge_core.runtime import load_dotenv
from drv_knowledge_core.contracts import MATERIAL_TYPES, shelf_for_material, pending_metadata_defaults
from drv_knowledge_core.clients.bookstack_writer import BookStackWriter, BookStackWriteError
from drv_knowledge_core.governance_v2 import GovernanceOutbox, GovernanceV2Client, build_intake_request, default_outbox_path
from drv_knowledge_core.source_metadata import inject_page_identity, normalize_bookstack_url
load_dotenv()

VERSION='2.0.3'
SKILL_DIR=Path(__file__).resolve().parents[1]
DEFAULT_WS=Path(os.environ.get('DRVKI_WORKSPACE','~/.drvknowledge/ingest_sessions')).expanduser()
SUPPORTED={'.md','.markdown','.txt','.html','.htm','.docx','.pdf','.pptx'}

class IngestError(RuntimeError): pass

def now(): return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
def sha256_file(p:Path):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def slug(s):
    s=re.sub(r'\s+','-',s.strip())
    s=re.sub(r'[^\w\-\u4e00-\u9fff]+','-',s)
    return s.strip('-')[:60] or 'knowledge'
def write_json(p,obj): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def read_json(p): return json.loads(p.read_text(encoding='utf-8'))

def yaml_scalar(v):
    if v is None: return 'null'
    if isinstance(v,bool): return 'true' if v else 'false'
    if isinstance(v,(int,float)): return str(v)
    s=str(v)
    if not s: return '""'
    if re.search(r'[:#\[\]{},&*!?|>\'"%@`\n]|^[-?:]|\s$',s): return json.dumps(s,ensure_ascii=False)
    return s

def dump_yaml(d,indent=0):
    lines=[]; pad=' '*indent
    for k,v in d.items():
        if isinstance(v,dict): lines.append(f'{pad}{k}:'); lines += dump_yaml(v,indent+2)
        elif isinstance(v,list):
            if not v: lines.append(f'{pad}{k}: []')
            else:
                lines.append(f'{pad}{k}:')
                for x in v: lines.append(f'{pad}  - {yaml_scalar(x)}')
        else: lines.append(f'{pad}{k}: {yaml_scalar(v)}')
    return lines

def strip_frontmatter(text):
    if text.startswith('---\n'):
        m=re.search(r'\n---\s*\n',text[4:])
        if m: return text[4+m.end():]
    return text

def extract_text(path:Path):
    ext=path.suffix.lower()
    if ext in {'.md','.markdown','.txt'}:
        return path.read_text(encoding='utf-8',errors='replace'), {'adapter':'text'}
    if ext in {'.html','.htm'}:
        raw=path.read_text(encoding='utf-8',errors='replace')
        try:
            from bs4 import BeautifulSoup
            soup=BeautifulSoup(raw,'html.parser')
            title=soup.title.get_text(' ',strip=True) if soup.title else ''
            text='\n'.join(x.strip() for x in soup.stripped_strings)
            return (f'# {title}\n\n' if title else '')+text, {'adapter':'html','title':title}
        except Exception:
            return re.sub(r'<[^>]+>',' ',raw), {'adapter':'html-fallback'}
    if ext=='.docx':
        from docx import Document
        doc=Document(str(path)); out=[]; tables=0
        for p in doc.paragraphs:
            t=p.text.strip()
            if not t: continue
            style=(p.style.name or '').lower() if p.style else ''
            if style.startswith('heading'):
                n=re.search(r'(\d+)',style); level=int(n.group(1)) if n else 2
                out.append('#'*min(max(level,1),6)+' '+t)
            else: out.append(t)
        for table in doc.tables:
            rows=[[c.text.strip().replace('\n',' ') for c in r.cells] for r in table.rows]
            if not rows: continue
            tables+=1; out.append('')
            out.append('| '+' | '.join(rows[0])+' |')
            out.append('| '+' | '.join(['---']*len(rows[0]))+' |')
            for r in rows[1:]: out.append('| '+' | '.join(r)+' |')
        return '\n\n'.join(out), {'adapter':'docx','tables':tables,'paragraphs':len(doc.paragraphs)}
    if ext=='.pdf':
        import fitz
        doc=fitz.open(str(path)); out=[]
        for i,page in enumerate(doc):
            text=page.get_text('text').strip()
            out.append(f'<!-- SOURCE_PAGE:{i+1:04d} -->\n\n{text}')
        return '\n\n'.join(out), {'adapter':'pdf-generic','pages':len(doc)}
    if ext=='.pptx':
        from pptx import Presentation
        prs=Presentation(str(path)); out=[]
        for i,slide in enumerate(prs.slides,1):
            texts=[]
            for shape in slide.shapes:
                if hasattr(shape,'text') and shape.text.strip(): texts.append(shape.text.strip())
            out.append(f'## Slide {i}\n\n'+'\n\n'.join(texts))
        return '\n\n'.join(out), {'adapter':'pptx','slides':len(prs.slides)}
    raise IngestError(f'unsupported format: {ext}')

def classify(title,text,forced=None):
    if forced:
        mp={'case':'cases','experience':'cases','manual':'manuals','tech-note':'tech_notes','tech_note':'tech_notes','project':'project_docs','project-doc':'project_docs','docs':'docs'}
        return mp.get(forced,forced), 1.0, ['user-forced']
    s=(title+'\n'+text[:12000]).lower(); scores={k:0 for k in MATERIAL_TYPES}; reasons=[]
    def hit(kind,words,weight=1):
        nonlocal reasons
        for w in words:
            if w.lower() in s: scores[kind]+=weight; reasons.append(f'{kind}:{w}')
    hit('cases',['问题现象','根因','故障','问题分析','解决方案','验证结果','产线问题','网上问题','版本问题','case'],2)
    hit('manuals',['datasheet','reference manual','user manual','register map','sdk api','programming guide','芯片手册','数据手册','寄存器','reference'],2)
    hit('tech_notes',['技术专题','原理','调试指南','最佳实践','技术说明','机制','教程'],2)
    hit('project_docs',['项目','需求','详细设计','设计方案','特性','版本规划','项目总结','方案设计','project','design proposal','project summary','requirement'],2)
    hit('docs',['规范','流程','策略','标准','工具','操作说明','使用说明'],1)
    kind=max(scores,key=scores.get)
    if scores[kind]==0: kind='docs'
    total=sum(scores.values()) or 1
    return kind, min(0.95,0.55+scores[kind]/total*0.4), reasons[:12]

def detect_manual_fidelity(path,title,text,material):
    if path.suffix.lower()!='.pdf' or material!='manuals': return False,[]
    s=(title+' '+text[:8000]).lower(); keys=['datasheet','reference manual','register','sdk','api','programming guide','user manual','数据手册','寄存器','参考手册','芯片手册']
    hit=[k for k in keys if k in s]
    return bool(hit), hit

def title_from(path,text,override=None):
    if override: return override.strip()
    m=re.search(r'^#\s+(.+)$',text,re.M)
    if m: return m.group(1).strip()[:120]
    for ln in text.splitlines():
        t=ln.strip().strip('#').strip()
        if 4<=len(t)<=120: return t
    return path.stem

def new_session(title, source_mode, source_format, material, source_path=None):
    sid=dt.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+slug(title)[:30]+'_'+uuid.uuid4().hex[:6]
    d=DEFAULT_WS/sid; d.mkdir(parents=True,exist_ok=False); (d/'source').mkdir(); (d/'assets').mkdir()
    state={'schema_version':1,'session_id':sid,'version':VERSION,'created_utc':now(),'updated_utc':now(),'state':'LOCAL_DRAFT','title':title,'source_mode':source_mode,'source_format':source_format,'material_type':material,'bookstack':{},'approval':{},'rag':{},'history':[{'utc':now(),'state':'LOCAL_DRAFT','event':'session_created'}]}
    write_json(d/'state.json',state)
    return d,state

def make_metadata(title,material,source_mode,source_format,source_file=None,extra=None):
    md={'title':title,**pending_metadata_defaults(),'material_type':material,'module':'','platform':'','kernel':'','owner':'','last_verified':'','tags':[],'ingest':{'source_mode':source_mode,'source_format':source_format}}
    if source_file: md['ingest']['source_file']=source_file
    if extra:
        for k,v in extra.items():
            if v not in (None,''): md[k]=v
    return md

def canonicalize(content,metadata):
    body=strip_frontmatter(content).strip()
    fm='---\n'+'\n'.join(dump_yaml(metadata))+'\n---\n\n'
    return fm+body+'\n'

def route_suggestion(material):
    return shelf_for_material(material)

def build_preview(session):
    state=read_json(session/'state.json'); meta=(session/'metadata.yaml').read_text(encoding='utf-8'); content=(session/'content.md').read_text(encoding='utf-8')
    preview=f"# Ingest Preview\n\n- Session: `{state['session_id']}`\n- State: `{state['state']}`\n- Material: `{state['material_type']}`\n- Source: `{state['source_mode']} / {state['source_format']}`\n- Recommended shelf: `{route_suggestion(state['material_type'])}`\n\n## Metadata\n\n```yaml\n{meta}```\n\n## Content\n\n{strip_frontmatter(content)}"
    (session/'preview.md').write_text(preview,encoding='utf-8'); return preview

def cmd_analyze(a):
    p=Path(a.file).expanduser().resolve()
    if not p.exists(): raise IngestError(f'file not found: {p}')
    if p.suffix.lower() not in SUPPORTED: raise IngestError(f'unsupported format {p.suffix}; supported: {sorted(SUPPORTED)}')
    text,info=extract_text(p); title=title_from(p,text,a.title); material,conf,reasons=classify(title,text,a.as_type); fidelity,hits=detect_manual_fidelity(p,title,text,material)
    out={'file':str(p),'sha256':sha256_file(p),'size':p.stat().st_size,'source_format':p.suffix.lower().lstrip('.'),'title':title,'material_type':material,'classification_confidence':round(conf,3),'classification_reasons':reasons,'recommended_workflow':'technical_manual_fidelity' if fidelity else 'heterogeneous_import','manual_fidelity_signals':hits,'recommended_shelf':route_suggestion(material),'extraction':info,'text_chars':len(text)}
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0

def stage_from_file(p:Path,a):
    text,info=extract_text(p); title=title_from(p,text,a.title); material,conf,reasons=classify(title,text,a.as_type); fidelity,hits=detect_manual_fidelity(p,title,text,material)
    d,state=new_session(title,'existing_markdown' if p.suffix.lower() in {'.md','.markdown'} else 'file_import',p.suffix.lower().lstrip('.'),material,p)
    copied=d/'source'/p.name; shutil.copy2(p,copied)
    meta=make_metadata(title,material,state['source_mode'],state['source_format'],p.name,{'module':a.module or '','platform':a.platform or '','owner':a.owner or ''})
    (d/'metadata.yaml').write_text('\n'.join(dump_yaml(meta))+'\n',encoding='utf-8')
    content=canonicalize(text,meta); (d/'content.md').write_text(content,encoding='utf-8')
    manifest={'schema_version':1,'created_utc':now(),'source':{'path':str(p),'copied':str(copied),'sha256':sha256_file(p),'bytes':p.stat().st_size,'format':state['source_format']},'extraction':info,'classification':{'material_type':material,'confidence':conf,'reasons':reasons},'recommended_workflow':'technical_manual_fidelity' if fidelity else 'heterogeneous_import','manual_fidelity_signals':hits,'canonical':{'content_sha256':hashlib.sha256(content.encode()).hexdigest()}}
    write_json(d/'source_manifest.json',manifest)
    if fidelity:
        state['specialized_engine']={'required':True,'engine':'resources/technical-manual-engine','reason':'technical manual PDF detected'}
    state['updated_utc']=now(); write_json(d/'state.json',state); build_preview(d)
    return d,state

def cmd_import(a):
    p=Path(a.file).expanduser().resolve(); d,state=stage_from_file(p,a)
    print(json.dumps({'result':'STAGED','session':state['session_id'],'dir':str(d),'state':state['state'],'material_type':state['material_type'],'recommended_shelf':route_suggestion(state['material_type']),'specialized_engine':state.get('specialized_engine'),'preview':str(d/'preview.md')},ensure_ascii=False,indent=2)); return 0

def cmd_draft(a):
    if a.file:
        text=Path(a.file).expanduser().read_text(encoding='utf-8',errors='replace')
        source_format=Path(a.file).suffix.lower().lstrip('.') or 'text'
    elif a.stdin:
        text=sys.stdin.read(); source_format='conversation'
    else: raise IngestError('draft requires --file or --stdin')
    title=a.title or (re.search(r'^#\s+(.+)$',text,re.M).group(1).strip() if re.search(r'^#\s+(.+)$',text,re.M) else 'AI 生成知识')
    material,_,_=classify(title,text,a.as_type or ('case' if a.experience else None))
    d,state=new_session(title,'ai_context' if a.experience else 'manual_input',source_format,material)
    meta=make_metadata(title,material,state['source_mode'],source_format,None,{'module':a.module or '','platform':a.platform or '','owner':a.owner or ''})
    if a.experience:
        meta['evidence']={'root_cause_status':a.root_cause_status,'confirmed':[],'inferred':[],'unresolved':[]}
    (d/'metadata.yaml').write_text('\n'.join(dump_yaml(meta))+'\n',encoding='utf-8')
    content=canonicalize(text,meta); (d/'content.md').write_text(content,encoding='utf-8')
    write_json(d/'source_manifest.json',{'schema_version':1,'created_utc':now(),'source':{'mode':state['source_mode'],'format':source_format},'canonical':{'content_sha256':hashlib.sha256(content.encode()).hexdigest()}})
    build_preview(d)
    print(json.dumps({'result':'STAGED','session':state['session_id'],'dir':str(d),'preview':str(d/'preview.md'),'next':'review preview, then submit only after explicit user confirmation'},ensure_ascii=False,indent=2)); return 0

def resolve_session(s):
    p=Path(s).expanduser()
    if p.exists(): return p.resolve()
    p=DEFAULT_WS/s
    if p.exists(): return p
    raise IngestError(f'session not found: {s}')

def cmd_preview(a):
    d=resolve_session(a.session); print(build_preview(d)); return 0

class BookStack(BookStackWriter):
    """Compatibility alias for the shared controlled writer."""
    pass

def cmd_doctor(a):
    result={'version':VERSION,'workspace':str(DEFAULT_WS),'adapters':{},'bookstack':{'configured':all(os.environ.get(k) for k in ['BOOKSTACK_BASE_URL','BOOKSTACK_TOKEN_ID','BOOKSTACK_TOKEN_SECRET'])},'manual_engine':(SKILL_DIR/'resources/technical-manual-engine/scripts/manual_pipeline.py').exists()}
    for ext in sorted(SUPPORTED):
        result['adapters'][ext]='supported'
    if a.live and result['bookstack']['configured']:
        try:
            bs=BookStack(); result['bookstack']['books']=len(bs.list_all('books')); result['bookstack']['live']='ok'
        except Exception as e: result['bookstack']['live']='fail'; result['bookstack']['error']=str(e)
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0 if result.get('bookstack',{}).get('live')!='fail' else 2

def route_candidates(state, bs):
    shelf_name=route_suggestion(state['material_type'])
    shelf, books=bs.find_shelf_books(shelf_name)
    return {'shelf':{'id':shelf.get('id'),'name':shelf.get('name')},'books':[{'id':b.get('id'),'name':b.get('name'),'slug':b.get('slug')} for b in books]}

def cmd_route(a):
    d=resolve_session(a.session); state=read_json(d/'state.json'); bs=BookStack(); out=route_candidates(state,bs); out['session']=state['session_id']; out['material_type']=state['material_type']; out['auto_selectable']=len(out['books'])==1
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0

def cmd_submit(a):
    d=resolve_session(a.session); state=read_json(d/'state.json')
    if not a.confirm: raise IngestError('submit requires --confirm after the user explicitly approves the preview')
    if state['state'] not in {'LOCAL_DRAFT','NEEDS_REVISION'}: raise IngestError(f"session state {state['state']} cannot be submitted")
    bs=BookStack()
    book_name=a.book
    if not book_name:
        route=route_candidates(state,bs)
        if len(route['books'])==1:
            book_name=route['books'][0]['name']
        else:
            names=', '.join(str(x['name']) for x in route['books']) or '(none)'
            raise IngestError(f"BookStack route is ambiguous under shelf {route['shelf']['name']!r}; candidates: {names}. Re-run submit with --book.")
    content=(d/'content.md').read_text(encoding='utf-8')
    # Safety: force pending-review front matter semantics.
    if not re.search(r'^status:\s*draft\s*$',content,re.M) or not re.search(r'^rag_enabled:\s*false\s*$',content,re.M):
        raise IngestError('content.md must contain status:draft and rag_enabled:false before submit')
    book=bs.find_book(book_name); chapter=bs.find_chapter(a.chapter,book.get('id')) if a.chapter else None
    page=bs.create_page(state['title'],content,book,chapter)
    pid=page.get('id'); url=normalize_bookstack_url(page.get('url') or (f"{bs.base}/books/{book.get('slug','')}/page/{page.get('slug','')}" if page.get('slug') else ''))
    if not pid or not url:
        raise IngestError('BookStack created the page but did not return a stable page id/url; refusing to continue because RAG source identity would be incomplete')
    # Performance contract: persist canonical source identity in the BookStack Markdown itself.
    # When Governance later upserts this page to RAGFlow, every chunk can carry the URL directly;
    # retrieval no longer needs a second BookStack request just to resolve the link.
    patched=inject_page_identity(content,page_id=pid,page_url=url)
    try:
        bs.update_page(pid,state['title'],patched)
    except Exception as exc:
        try: bs.delete_page(pid)
        except Exception: pass
        raise IngestError(f'failed to persist BookStack source metadata; rolled back draft page: {exc}')
    (d/'content.md').write_text(patched,encoding='utf-8')
    intake=build_intake_request(session_id=state['session_id'],page_id=int(pid),canonical_url=url,title=state['title'],material_type=state['material_type'],content_hash=hashlib.sha256(patched.encode('utf-8')).hexdigest(),client_version=VERSION)
    outbox=GovernanceOutbox(default_outbox_path()); outbox_id=outbox.enqueue_intake(intake)
    governance=GovernanceV2Client.from_environment(); delivery=outbox.replay(governance.submit_intake,limit=1)
    outbox_row=outbox.get(outbox_id); sync_state='acknowledged' if outbox_row['state']=='acknowledged' else 'pending'
    response=json.loads(outbox_row['response_json']) if outbox_row.get('response_json') else None
    response_data=response.get('data') if isinstance(response,dict) else None
    if isinstance(response_data,dict) and isinstance(response_data.get('data'),dict): response_data=response_data['data']
    state['state']='BOOKSTACK_PENDING_REVIEW'; state['updated_utc']=now(); state['bookstack']={'page_id':pid,'page_url':url,'book_id':book.get('id'),'book_name':book.get('name'),'chapter_id':chapter.get('id') if chapter else None,'chapter_name':chapter.get('name') if chapter else None,'submitted_utc':now()}
    state['governance']={'content_ref':intake['content_ref'],'source_key':intake['source_key'],'client_submission_id':intake['client_submission_id'],'trace_id':intake['trace_id'],'outbox_id':outbox_id,'outbox_state':outbox_row['state'],'intake_id':response_data.get('intake_id') if isinstance(response_data,dict) else None}
    state['history'].append({'utc':now(),'state':state['state'],'event':'submitted_to_bookstack'})
    state['history'].append({'utc':now(),'state':state['state'],'event':'governance_intake_'+sync_state,'outbox_id':outbox_id})
    write_json(d/'state.json',state)
    print(json.dumps({'result':'SUBMITTED','session':state['session_id'],'state':state['state'],'page_id':pid,'page_url':url,'content_ref':intake['content_ref'],'governance_sync':sync_state,'outbox_state':outbox_row['state'],'delivery':delivery,'note':'BookStack submission is pending website governance; RAGFlow publication remains controlled by B.'},ensure_ascii=False,indent=2)); return 0

def cmd_status(a):
    d=resolve_session(a.session); state=read_json(d/'state.json')
    out={'session':state['session_id'],'state':state['state'],'bookstack':state.get('bookstack',{}),'approval':state.get('approval',{}),'rag':state.get('rag',{}),'governance':state.get('governance',{})}
    if a.refresh and state.get('bookstack',{}).get('page_id'):
        try:
            governance=GovernanceV2Client.from_environment(); outbox=GovernanceOutbox(default_outbox_path())
            out['outbox_replay']=outbox.replay(governance.submit_intake) if governance.ready() else {'acknowledged':0,'retry_wait':0,'dead_letter':0}
            content_ref=state.get('governance',{}).get('content_ref') or f"bookstack:page:{int(state['bookstack']['page_id'])}"
            response=governance.resolve_status([content_ref])
            if not response.get('ok'): raise IngestError(response.get('message') or response.get('error') or 'governance status request failed')
            payload=response.get('data') or {}
            if isinstance(payload,dict) and isinstance(payload.get('data'),dict): payload=payload['data']
            items=payload.get('items',[]) if isinstance(payload,dict) else []
            current=next((item for item in items if item.get('content_ref')==content_ref),None)
            if current is None: raise IngestError(f'governance returned no status for {content_ref}')
            review_status=current.get('review_status'); rag_status=current.get('rag_status'); compile_status=current.get('compile_status')
            if rag_status=='ready': state['state']='RAG_READY'
            elif rag_status=='parsing': state['state']='RAG_PARSING'
            elif rag_status=='queued': state['state']='RAG_PENDING'
            elif review_status in {'reviewed','verified'}: state['state']='BOOKSTACK_APPROVED'
            elif review_status in {'need_fix','need_recheck'}: state['state']='NEEDS_REVISION'
            state['approval']={'detected_utc':now(),'status':review_status,'quality_score':current.get('quality_score')}
            state['rag']={'detected_utc':now(),'status':rag_status}
            state.setdefault('governance',{}).update({'content_ref':content_ref,'source_key':current.get('source_key'),'asset_id':current.get('asset_id'),'compile_status':compile_status,'review_status':review_status,'rag_status':rag_status,'updated_at':current.get('updated_at')})
            state['updated_utc']=now(); state['history'].append({'utc':now(),'state':state['state'],'event':'governance_status_refreshed','compile_status':compile_status,'review_status':review_status,'rag_status':rag_status}); write_json(d/'state.json',state)
            out.update({'state':state['state'],'approval':state['approval'],'rag':state['rag'],'governance':state['governance'],'governance_status':current})
        except Exception as e: out['refresh_error']=str(e)
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0

def cmd_command(a):
    s=a.command.strip(); m=re.match(r'^/kb\s+ingest\s+(.+)$',s,re.I)
    if not m: raise IngestError('command must start with /kb ingest')
    tail=m.group(1).strip(); parts=tail.split(); op=parts[0].lower() if parts else 'help'; rest=parts[1:]
    mapping={'experience':'draft --stdin --experience','tech-note':'draft --stdin --as-type tech-note','tech_note':'draft --stdin --as-type tech-note','import':'import','analyze':'analyze','preview':'preview','route':'route','submit':'submit','status':'status','doctor':'doctor','manual':'manual','sanitize-manual':'sanitize-manual'}
    print(json.dumps({'normalized_command':s,'operation':op,'argv_hint':mapping.get(op,'help')+((' '+' '.join(rest)) if rest else ''),'note':'Chat Skill should execute the corresponding drvki command; experience uses AI-generated current-context Markdown as stdin.'},ensure_ascii=False,indent=2)); return 0

def cmd_selftest(a):
    import tempfile
    passed=[]
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/'case.md'; p.write_text('# PHY link up 无流量问题分析\n\n## 问题现象\n链路已 up 但无流量。\n\n## 根因分析\nRGMII delay 配置不匹配。\n\n## 解决方案\n修正时序。',encoding='utf-8')
        text,info=extract_text(p); mat,_,_=classify('PHY link up 无流量问题分析',text); assert mat=='cases'; passed.append('classify_case')
        assert not detect_manual_fidelity(p,'x',text,mat)[0]; passed.append('manual_route')
        meta=make_metadata('x','cases','existing_markdown','md'); c=canonicalize(text,meta); assert 'rag_enabled: false' in c and 'status: draft' in c; passed.append('pending_gate')
        assert '/kb ingest' in '/kb ingest experience'; passed.append('command_protocol')
    engine=SKILL_DIR/'resources/technical-manual-engine/scripts/manual_pipeline.py'; assert engine.exists(); passed.append('manual_engine_present')
    print(json.dumps({'result':'PASS','version':VERSION,'tests':passed,'count':len(passed)},ensure_ascii=False,indent=2)); return 0

def cmd_manual(a):
    engine=SKILL_DIR/'resources/technical-manual-engine/scripts/manual_pipeline.py'
    if not engine.exists():
        raise IngestError('technical manual engine is missing')
    if not a.file:
        print(json.dumps({'engine':str(engine),'available':True,'usage':'kb ingest manual INPUT.pdf [--work-dir DIR] [--dpi 240] [--document-kind datasheet] [--profiles general]'},ensure_ascii=False,indent=2)); return 0
    src=Path(a.file).expanduser().resolve()
    if not src.is_file(): raise IngestError(f'manual source not found: {src}')
    if src.suffix.lower()!='.pdf': raise IngestError('high-fidelity manual engine currently accepts PDF; use `kb ingest import FILE` for other formats')
    work=Path(a.work_dir).expanduser().resolve() if a.work_dir else (DEFAULT_WS/f'manual-{src.stem}-{uuid.uuid4().hex[:8]}')
    cmd=[sys.executable,str(engine),'prepare',str(src),str(work),'--dpi',str(a.dpi),'--document-kind',a.document_kind,'--profiles',a.profiles]
    proc=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    out={'engine':str(engine),'source':str(src),'work_dir':str(work),'returncode':proc.returncode,'stdout':proc.stdout[-4000:],'stderr':proc.stderr[-4000:]}
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if proc.returncode==0 else 2

def cmd_sanitize_manual(a):
    engine=SKILL_DIR/'resources/technical-manual-engine/scripts/ragflow_sanitize.py'
    if not engine.exists():
        raise IngestError('RAGFlow manual sanitizer is missing')
    src=Path(a.file).expanduser().resolve()
    if not src.is_file(): raise IngestError(f'manual source not found: {src}')
    output=Path(a.output).expanduser().resolve()
    cmd=[sys.executable,str(engine),'clean',str(src),str(output),'--soft-limit',str(a.soft_limit),'--hard-limit',str(a.hard_limit),'--shard-limit',str(a.shard_limit)]
    proc=subprocess.run(cmd,text=True,encoding='utf-8',errors='replace',stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    if proc.stdout: print(proc.stdout,end='')
    if proc.stderr: print(proc.stderr,end='',file=sys.stderr)
    return proc.returncode

def parser():
    p=argparse.ArgumentParser(description='Drv Knowledge Ingest Navigator'); p.add_argument('--version',action='version',version=VERSION); sp=p.add_subparsers(dest='cmd',required=True)
    q=sp.add_parser('doctor'); q.add_argument('--live',action='store_true'); q.set_defaults(func=cmd_doctor)
    q=sp.add_parser('analyze'); q.add_argument('file'); q.add_argument('--as',dest='as_type'); q.add_argument('--title'); q.set_defaults(func=cmd_analyze)
    q=sp.add_parser('import'); q.add_argument('file'); q.add_argument('--as',dest='as_type'); q.add_argument('--title'); q.add_argument('--module'); q.add_argument('--platform'); q.add_argument('--owner'); q.set_defaults(func=cmd_import)
    q=sp.add_parser('draft'); q.add_argument('--file'); q.add_argument('--stdin',action='store_true'); q.add_argument('--experience',action='store_true'); q.add_argument('--as',dest='as_type'); q.add_argument('--title'); q.add_argument('--module'); q.add_argument('--platform'); q.add_argument('--owner'); q.add_argument('--root-cause-status',choices=['confirmed','probable','hypothesis','unresolved'],default='unresolved'); q.set_defaults(func=cmd_draft)
    q=sp.add_parser('preview'); q.add_argument('session'); q.set_defaults(func=cmd_preview)
    q=sp.add_parser('route'); q.add_argument('session'); q.set_defaults(func=cmd_route)
    q=sp.add_parser('submit'); q.add_argument('session'); q.add_argument('--book'); q.add_argument('--chapter'); q.add_argument('--confirm',action='store_true'); q.set_defaults(func=cmd_submit)
    q=sp.add_parser('status'); q.add_argument('session'); q.add_argument('--refresh',action='store_true'); q.set_defaults(func=cmd_status)
    q=sp.add_parser('command'); q.add_argument('command'); q.set_defaults(func=cmd_command)
    q=sp.add_parser('manual'); q.add_argument('file',nargs='?'); q.add_argument('--work-dir'); q.add_argument('--dpi',type=int,default=240); q.add_argument('--document-kind',default='datasheet'); q.add_argument('--profiles',default='general'); q.set_defaults(func=cmd_manual)
    q=sp.add_parser('sanitize-manual'); q.add_argument('file'); q.add_argument('output'); q.add_argument('--soft-limit',type=int,default=1800); q.add_argument('--hard-limit',type=int,default=2200); q.add_argument('--shard-limit',type=int,default=1024*1024); q.set_defaults(func=cmd_sanitize_manual)
    q=sp.add_parser('selftest'); q.set_defaults(func=cmd_selftest)
    return p

def main():
    a=parser().parse_args()
    try: return a.func(a)
    except IngestError as e: print(f'ERROR: {e}',file=sys.stderr); return 2

if __name__=='__main__': raise SystemExit(main())

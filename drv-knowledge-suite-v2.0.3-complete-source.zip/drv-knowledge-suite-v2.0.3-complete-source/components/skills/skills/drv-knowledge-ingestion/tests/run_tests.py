#!/usr/bin/env python3
from pathlib import Path
import json, os, subprocess, sys, tempfile
from docx import Document
from pptx import Presentation
import fitz

ROOT=Path(__file__).resolve().parents[3]
CLI=ROOT/'drvki.py'

def run(args,input_text=None,env=None,expect=0):
    e=os.environ.copy(); e.update(env or {})
    p=subprocess.run([sys.executable,str(CLI),*args],input=input_text,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=e)
    if p.returncode!=expect:
        raise AssertionError(f"{args} rc={p.returncode} expected={expect}\nOUT={p.stdout}\nERR={p.stderr}")
    return p

def main():
    tests=[]
    def ok(name): tests.append(name)
    with tempfile.TemporaryDirectory() as td:
        td=Path(td); ws=td/'sessions'; env={'DRVKI_WORKSPACE':str(ws)}
        # md case
        md=td/'case.md'; md.write_text('# PHY link up 无流量问题分析\n\n## 问题现象\n链路已 up 但无流量。\n\n## 根因分析\nRGMII delay 配置异常。\n\n## 解决方案\n修正 delay。',encoding='utf-8')
        d=json.loads(run(['analyze',str(md)],env=env).stdout); assert d['material_type']=='cases'; ok('analyze_md_case')
        # docx project
        doc=Document(); doc.add_heading('网络 VLAN/ACL 优化策略',0); doc.add_paragraph('项目设计方案与需求。'); doc.save(td/'strategy.docx')
        d=json.loads(run(['analyze',str(td/'strategy.docx')],env=env).stdout); assert d['material_type']=='project_docs' and d['recommended_workflow']=='heterogeneous_import'; ok('analyze_docx_project')
        # pdf manual
        pdf=fitz.open(); page=pdf.new_page(); page.insert_text((72,72),'RTL8367S Reference Manual\nRegister Map\nSDK API'); pdf.save(td/'manual.pdf')
        d=json.loads(run(['analyze',str(td/'manual.pdf')],env=env).stdout); assert d['material_type']=='manuals' and d['recommended_workflow']=='technical_manual_fidelity'; ok('route_pdf_manual')
        # pdf generic project
        pdf=fitz.open(); page=pdf.new_page(); page.insert_text((72,72),'Project Network Optimization Plan\nDesign proposal and verification.'); pdf.save(td/'plan.pdf')
        d=json.loads(run(['analyze',str(td/'plan.pdf')],env=env).stdout); assert d['material_type']=='project_docs' and d['recommended_workflow']=='heterogeneous_import'; ok('route_pdf_generic')
        # html tech
        html=td/'note.html'; html.write_text('<html><head><title>PHY 调试指南</title></head><body><h1>PHY 调试指南</h1><p>技术专题：链路问题排查。</p></body></html>',encoding='utf-8')
        d=json.loads(run(['analyze',str(html)],env=env).stdout); assert d['material_type']=='tech_notes'; ok('analyze_html')
        # pptx
        prs=Presentation(); s=prs.slides.add_slide(prs.slide_layouts[1]); s.shapes.title.text='项目总结'; s.placeholders[1].text='项目需求与方案'; prs.save(td/'project.pptx')
        d=json.loads(run(['analyze',str(td/'project.pptx')],env=env).stdout); assert d['material_type']=='project_docs'; ok('analyze_pptx')
        # import creates canonical draft
        d=json.loads(run(['import',str(td/'strategy.docx'),'--owner','tester'],env=env).stdout); session=d['session']; sd=ws/session; assert (sd/'content.md').exists() and (sd/'preview.md').exists(); text=(sd/'content.md').read_text(encoding='utf-8'); assert 'status: draft' in text and 'rag_enabled: false' in text; ok('import_canonical')
        # AI experience draft
        d=json.loads(run(['draft','--stdin','--experience','--title','PHY link up 无流量问题分析','--root-cause-status','probable'],input_text=md.read_text(encoding='utf-8'),env=env).stdout); assert d['result']=='STAGED'; ok('ai_experience_draft')
        # submit must require explicit confirmation
        run(['submit',session,'--book','dummy'],env=env,expect=2); ok('submit_confirmation_gate')
        # command protocol
        d=json.loads(run(['command','/kb ingest experience'],env=env).stdout); assert d['operation']=='experience'; ok('command_router')
        # manual engine present
        d=json.loads(run(['manual'],env=env).stdout); assert d['available'] is True; ok('manual_engine')
        # selftest
        d=json.loads(run(['selftest'],env=env).stdout); assert d['result']=='PASS'; ok('selftest')
    print(json.dumps({'result':'PASS','total':len(tests),'tests':tests},ensure_ascii=False,indent=2))
    return 0

if __name__=='__main__': raise SystemExit(main())

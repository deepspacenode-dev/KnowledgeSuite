# drv-knowledge-ingestion v2.0.3

Drv Knowledge Suite 的知识入库 Skill。

两条主流程：

1. AI 原生知识生产：从当前项目/对话生成案例、技术专题等标准 Markdown。
2. 异构格式知识导入：MD/TXT/HTML/DOCX/PDF/PPTX → Canonical Markdown。

技术手册 PDF 的高保真流程保留为内部 `technical-manual-engine`。所有提交先进入 BookStack 待审核，RAGFlow 正式入库继续复用现有治理链路。

对于已经转换为 Markdown 的超长芯片手册，使用：

```bash
python scripts/ingest_cli.py sanitize-manual INPUT.md OUTPUT_DIR
```

该操作不覆盖源文件。RAGFlow 只接收 `OUTPUT_DIR/ragflow/part-*.md`，并使用
`sanitized-chip-manual-v1` 文档级解析 Profile。

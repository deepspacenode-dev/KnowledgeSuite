---
name: drv-knowledge-ingestion
description: DrvDocs 统一知识生产与异构格式知识导入 Skill。用于把当前项目/对话中形成的工程经验由 AI 编写成标准 Markdown，或把已有 PDF、DOCX、Markdown、HTML、TXT、PPTX 等资料转换为标准知识；完成知识类型识别、元数据、预览、查重提示、用户确认和 BookStack 待审核提交。技术手册 PDF 自动转入高保真 technical-manual engine。BookStack 审批后仍复用现有 Governance/RAGFlow upsert 链路，本 Skill 不创建第二套 RAG 入库机制。
---

# drv-knowledge-ingestion v2.0.3

## 核心定位

这是**知识生产 Skill**，不是查询 Skill。

## 入库运行依赖

本 Skill 的异构格式转换要求服务器预先具备 6 个插件：`beautifulsoup4`、`python-docx`、`python-pptx`、`PyMuPDF`、`pdfplumber`、`Pillow`。V1.0.8 发布包不携带这些插件，安装器也不会执行 pip；full 安装只做强制环境检查。


- `drv-knowledge-retrieval`：知识获取——Search / Recall / Browse / Gap / Graph / Status。
- `drv-knowledge-ingestion`：知识入库——AI 编写 / 异构导入 / 标准化 / Preview / Submit / 审批状态跟踪。

不要把 PDF 当作知识类型。文件格式与最终知识类型是两个不同维度。

## 用户无需知道底层流程

收到自然语言请求后，先做意图分析，再转换成确定性命令。除非目标分类或 BookStack 位置确实存在多个不可判定候选，否则不要要求用户决定 PDF pipeline、Dataset、RAGFlow 或 BookStack API。

### 一级意图

1. **AI 原生知识生产**
   - “把刚才的问题整理成案例”
   - “把这次开发经验沉淀一下”
   - “把当前 VLAN/ACL 开发整理成技术专题”

2. **异构格式知识导入**
   - “这个老 DOCX 很有价值，放知识库”
   - “把这个 PDF/MD/PPTX 入库”
   - “先分析一下这个文件适合归哪里”

3. **生命周期操作**
   - 预览草稿
   - 提交 BookStack 审批
   - 查询审批状态

## 标准命令协议

聊天侧统一识别：

```text
/kb:ingest help
/kb:ingest experience
/kb:ingest tech-note
/kb:ingest analyze <file>
/kb:ingest import <file>
/kb:ingest preview <session>
/kb:ingest route <session>
/kb:ingest submit <session>
/kb:ingest status <session>
/kb:ingest manual <pdf>
```

底层 CLI：

```bash
kb ingest analyze FILE
kb ingest import FILE
drvki draft --stdin --experience
kb ingest preview SESSION
kb ingest route SESSION
kb ingest submit SESSION --book "TARGET_BOOK" --confirm
kb ingest status SESSION --refresh
kb ingest sanitize-manual MANUAL.md OUTPUT_DIR
kb doctor --live
```

## 意图到命令

### 当前项目经验

用户说“把刚才这个问题沉淀成经验/案例”时：

1. 不要求用户准备文件。
2. 读取当前对话和当前项目已提供的日志、代码、命令结果、验证结论。
3. 按 `references/experience-writing.md` 生成可独立阅读的正式 Markdown。
4. 明确区分 confirmed / inferred / unresolved，不得把 AI 假设改写成事实。
5. 将生成结果通过 `drvki.py draft --stdin --experience ...` 创建 LOCAL_DRAFT。
6. 展示 `preview.md`。
7. **询问用户是否提交 BookStack 审批。** 未获明确确认不得提交。

### 技术专题/策略知识

当前上下文已经形成系统方案但不是单一故障案例时，生成 `tech_notes` 或 `project_docs`，不要强行套案例模板。

### 文件导入

用户给出文件时先执行分析：

```bash
kb ingest analyze FILE
```

根据分析结果选择：

- `heterogeneous_import`：通用异构导入，支持 MD/TXT/HTML/DOCX/PDF/PPTX。
- `technical_manual_fidelity`：技术手册 PDF，转入 `resources/technical-manual-engine/`。

用户说“直接入库”也必须先创建 Draft 和 Preview，不能跳过确认。

## Source 与 Material 分离

`source_mode`：

- `ai_context`
- `file_import`
- `existing_markdown`
- `manual_input`

`material_type`：

- `cases`
- `manuals`
- `tech_notes`
- `project_docs`
- `docs`

格式只能决定 Adapter，不能决定 material_type。

## Canonical Markdown

所有入口统一收敛为 Session：

```text
~/.drvknowledge/ingest_sessions/<session>/
├── source/
├── assets/
├── content.md
├── metadata.yaml
├── source_manifest.json
├── state.json
└── preview.md
```

提交前 `content.md` 强制：

```yaml
status: draft
rag_enabled: false
```

BookStack 提交仅表示 `BOOKSTACK_PENDING_REVIEW`，不代表正式知识，更不得直接进入 RAGFlow。

## BookStack 提交规则

- 用户明确说“提交/上传到网站审核”后才执行。
- 先执行 `drvki.py route SESSION` 自动发现推荐 Shelf 下的 Book。仅有 1 个候选时可自动选择；多个候选时展示给用户选择，不要猜。
- 不自动创建/删除 Shelf 或 Book。
- 不绕过网站审核。
- 不在本 Skill 中另建 RAGFlow upsert/index。

## 审批后

使用 `status --refresh` 可通过 BookStack 页面 front matter 检查 `status` / `rag_enabled`。如现场审批状态由 Governance 独立数据库维护，应由后续 Governance Adapter 查询真实状态；不要自行伪造 APPROVED。

审批后 RAGFlow 入库继续复用现有 BookStack/Governance/PHP upsert 流程。最终召回验证交给 `drv-knowledge-retrieval`。

## 技术手册 PDF

识别为 Datasheet / Reference Manual / Register / SDK/API / Programming Guide 等高保真资料时，不走普通 PDF 文本抽取作为最终版本。调用：

```text
resources/technical-manual-engine/
```

保留其 source fingerprint、exact Markdown、表格审计、rewrite audit、test upload、read-back 和 rollback 能力。

若技术手册已经是 Markdown，且文件超过 2 MiB、图片超过 100 个、包含内网或
相对图片、超长表格或超过 2,200 字符的单行，禁止原文件直接上传 RAGFlow。
先执行 `sanitize-manual`，只上传生成的 `ragflow/part-*.md`，并为每个 part
应用 `sanitized-chip-manual-v1` 文档级 Profile。不得使用静默截断来规避
embedding 报错；`xxx` 也不得全局删除。

## 禁止行为

- 不把“PDF”当成 material_type。
- 不把当前聊天直接原样入库。
- 不把 AI 推测写成已确认根因。
- 不在用户确认前执行 BookStack 写入。
- 不把 `status:draft` / `rag_enabled:false` 的内容推入 RAGFlow。
- 不为通用 DOCX/PDF 重复实现一套新的 RAGFlow 入库链路。
- 不把命中超长手册门禁的原始 Markdown 直接上传 RAGFlow。


## Shared Core

Material Contract、Dataset 映射、BookStack/RAGFlow/Governance 基础配置统一由 `drv-knowledge-core` 提供，禁止本 Skill 自建第二份 Dataset 或 metadata 标准。

#!/usr/bin/env python3
"""Prepare and audit high-fidelity technical-manual PDF-to-Markdown conversions."""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import html
import json
import re
import shutil
import subprocess
import sys
import unicodedata
from collections import Counter
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import unquote

try:
    import fitz  # PyMuPDF
except ImportError as exc:  # pragma: no cover
    raise SystemExit("PyMuPDF is required. Ask the administrator to prepare the V1.0.8 ingestion runtime dependencies.") from exc

try:
    import pdfplumber
except ImportError as exc:  # pragma: no cover
    raise SystemExit("pdfplumber is required. Ask the administrator to prepare the V1.0.8 ingestion runtime dependencies.") from exc

try:
    from PIL import Image, ImageDraw, ImageOps
except ImportError as exc:  # pragma: no cover
    raise SystemExit("Pillow is required. Ask the administrator to prepare the V1.0.8 ingestion runtime dependencies.") from exc


VERSION = "1.0.8"
PAGE_MARKER_RE = re.compile(r"<!--\s*PDF_PAGE:(\d{4})\s*-->")
MD_IMAGE_RE = re.compile(r"!\[[^\]]*\]\(([^)]+)\)")
HTML_IMAGE_RE = re.compile(r"<img\b[^>]*\bsrc=[\"']([^\"']+)[\"'][^>]*>", re.I)
ALLOWED_CONTENT_PROFILES = {
    "general",
    "soc-mcu-cpu",
    "sensor-media",
    "memory-storage",
    "interface-protocol",
    "power-analog",
    "connectivity",
    "sdk-software",
    "hardware-layout",
    "security-boot",
}
DOCUMENT_KINDS = (
    "datasheet",
    "reference-manual",
    "programming-guide",
    "sdk-api",
    "hardware-design-guide",
    "protocol-specification",
    "errata",
    "application-note",
    "schematic-drawing",
    "mechanical-drawing",
    "mixed",
    "other-technical",
)
ALLOWED_IMAGE_STATUS = {
    "verified-embedded",
    "verified-crop",
    "covered-by-page-image",
    "decorative",
    "duplicate",
    "not-meaningful",
}
ALLOWED_TABLE_STATUS = {
    "verified-html",
    "verified-markdown",
    "verified-image",
    "false-detection",
}
NUMBER_LITERAL = r"[+-]?(?:(?:\d{1,3}(?:,\d{3})+|\d+(?:_\d+)*)(?:\.\d+)?|\.\d+)(?:[eE][+-]?\d+)?"
UNIT_PATTERN = re.compile(
    rf"(?<![\w.]){NUMBER_LITERAL}\s*"
    r"(?:°C/W|K/W|m/s\^?2|mm\^?[23]|cm\^?[23]|m\^?[23]|GT/s|MT/s|GS/s|MS/s|kS/s|"
    r"samples/s|frames/s|Mbaud|kbaud|baud|Tbps|Gbps|Mbps|kbps|bps|TiB|GiB|MiB|KiB|"
    r"TB|GB|MB|KB|bytes|byte|bits|bit|THz|GHz|MHz|kHz|Hz|rpm|fps|ps|ns|μs|µs|us|ms|s|"
    r"Vp-p|Vpp|Vrms|mV|μV|µV|uV|V|mA|μA|µA|uA|A|mW|μW|µW|uW|W|mΩ|μΩ|µΩ|uΩ|"
    r"kΩ|MΩ|Ω|mohm|kohm|Mohm|ohm|pF|nF|μF|µF|uF|mF|F|pH|nH|μH|µH|uH|mH|H|"
    r"nm|μm|µm|um|mm|cm|km|mil|inches|inch|in|m|°C|K|Pa|kPa|MPa|bar|mN|N|mg|kg|g|"
    r"mJ|μJ|µJ|uJ|J|mC|μC|µC|uC|C|mAh|Ah|dBFS|dBV|dBm|dB|lux|lm|cd|ppm|ppb|%|°)"
    r"(?![\w])"
)
RADIX_LITERAL_PATTERN = re.compile(
    r"(?<!\w)(?:0[xX][0-9A-Fa-f](?:_?[0-9A-Fa-f])*|0[bB][01](?:_?[01])*)[uUlL]*(?!\w)"
)
VERILOG_LITERAL_PATTERN = re.compile(r"\b\d+'[hHbBoOdD][0-9A-Fa-f_xXzZ]+\b")
BIT_RANGE_PATTERN = re.compile(r"(?:\[|<)\d+(?::\d+)?(?:\]|>)")
ENGINEERING_SYMBOL_PATTERN = re.compile(r"[±≤≥≈≠×÷√∞∑∫∆ΔΩμµ°]+")
GREEK_TOKEN_PATTERN = re.compile(r"[\u0370-\u03ff]+")
ACTIVE_LOW_PATTERN = re.compile(
    r"(?:\b[nN][A-Z][A-Za-z0-9_]*\b|\b[A-Za-z_][A-Za-z0-9_./:+-]*_(?:N|B)\b|"
    r"\b[A-Za-z_][A-Za-z0-9_./:+-]*#(?!\w)|(?<!\w)/[A-Za-z_][A-Za-z0-9_./:+-]*)"
)


def parse_profiles(value: str) -> list[str]:
    profiles = list(dict.fromkeys(item.strip() for item in value.split(",") if item.strip()))
    invalid = sorted(set(profiles) - ALLOWED_CONTENT_PROFILES)
    if not profiles or invalid:
        allowed = ", ".join(sorted(ALLOWED_CONTENT_PROFILES))
        detail = f"; invalid: {', '.join(invalid)}" if invalid else ""
        raise argparse.ArgumentTypeError(f"profiles must be a comma-separated subset of: {allowed}{detail}")
    return profiles


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")


def write_csv(path: Path, fieldnames: list[str], rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def ensure_new_work_dir(path: Path) -> None:
    if path.exists():
        if not path.is_dir():
            raise SystemExit(f"Work path exists and is not a directory: {path}")
        if any(path.iterdir()):
            raise SystemExit(f"Refusing to overwrite non-empty work directory: {path}")
    path.mkdir(parents=True, exist_ok=True)


def json_safe(value: Any) -> Any:
    if isinstance(value, bytes):
        return {"byte_length": len(value), "sha256": sha256_bytes(value)}
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def block_text(block: dict[str, Any]) -> str:
    lines: list[str] = []
    for line in block.get("lines", []):
        lines.append("".join(span.get("text", "") for span in line.get("spans", [])))
    return "\n".join(lines)


def bbox_distance(a: Iterable[float], b: Iterable[float]) -> float:
    return sum(abs(float(x) - float(y)) for x, y in zip(a, b))


def safe_extension(value: str) -> str:
    ext = re.sub(r"[^A-Za-z0-9]", "", (value or "bin").lower())
    return ext if ext in {"png", "jpg", "jpeg", "jpx", "jp2", "tif", "tiff", "bmp"} else "bin"


def run_ocr(image_path: Path, language: str, psm: int) -> tuple[str, str]:
    executable = shutil.which("tesseract")
    if not executable:
        return "", "tesseract-not-found"
    result = subprocess.run(
        [executable, str(image_path), "stdout", "-l", language, "--psm", str(psm)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    if result.returncode:
        return "", f"tesseract-error:{result.stderr.strip()[:240]}"
    return result.stdout, ""


def command_version(executable: str, *arguments: str) -> str | None:
    path = shutil.which(executable)
    if not path:
        return None
    result = subprocess.run(
        [path, *arguments],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    line = result.stdout.strip().splitlines()
    return line[0] if line else None


def make_contact_sheets(page_paths: list[Path], output_dir: Path) -> list[str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    generated: list[str] = []
    per_sheet, columns, thumb_width = 20, 4, 340
    margin, label_height = 18, 30
    for sheet_index, start in enumerate(range(0, len(page_paths), per_sheet), start=1):
        batch = page_paths[start : start + per_sheet]
        thumbs: list[Image.Image] = []
        for page_number, page_path in enumerate(batch, start=start + 1):
            with Image.open(page_path) as source:
                image = source.convert("RGB")
                height = max(1, round(image.height * thumb_width / image.width))
                thumb = image.resize((thumb_width, height), Image.Resampling.LANCZOS)
            framed = ImageOps.expand(thumb, border=1, fill="black")
            canvas = Image.new("RGB", (framed.width, framed.height + label_height), "white")
            canvas.paste(framed, (0, label_height))
            ImageDraw.Draw(canvas).text((8, 7), f"PDF page {page_number}", fill="black")
            thumbs.append(canvas)
        rows = (len(thumbs) + columns - 1) // columns
        cell_width = max(image.width for image in thumbs)
        cell_height = max(image.height for image in thumbs)
        sheet = Image.new(
            "RGB",
            (columns * cell_width + (columns + 1) * margin, rows * cell_height + (rows + 1) * margin),
            "#d9dde3",
        )
        for index, thumb in enumerate(thumbs):
            x = margin + (index % columns) * (cell_width + margin)
            y = margin + (index // columns) * (cell_height + margin)
            sheet.paste(thumb, (x, y))
        name = f"contact_{sheet_index:03d}.jpg"
        sheet.save(output_dir / name, "JPEG", quality=90, optimize=True)
        generated.append(name)
    return generated


def extract_page_images(
    doc: fitz.Document,
    page: fitz.Page,
    page_number: int,
    page_dict: dict[str, Any],
    asset_dir: Path,
) -> tuple[list[dict[str, Any]], dict[int, str], list[str]]:
    rows: list[dict[str, Any]] = []
    block_to_asset: dict[int, str] = {}
    risks: list[str] = []
    image_blocks = [(index, block) for index, block in enumerate(page_dict.get("blocks", [])) if block.get("type") == 1]
    used_blocks: set[int] = set()
    try:
        soft_masks = {int(item[0]): int(item[1]) for item in page.get_images(full=True) if int(item[1]) > 0}
    except Exception:
        soft_masks = {}
    try:
        infos = page.get_image_info(hashes=True, xrefs=True)
    except Exception as exc:  # pragma: no cover - malformed PDFs vary
        infos = []
        risks.append(f"image-info-error:{type(exc).__name__}")

    def save_occurrence(raw: bytes, ext: str, occurrence: int, bbox: Any, method: str, xref: int, block_index: int | None) -> None:
        digest = sha256_bytes(raw)
        suffix = safe_extension(ext)
        asset_name = f"image_{digest[:16]}.{suffix}"
        asset_path = asset_dir / asset_name
        if not asset_path.exists():
            asset_path.write_bytes(raw)
        relative = f"assets/images/{asset_name}"
        if block_index is not None:
            block_to_asset[block_index] = relative
        rows.append(
            {
                "image_id": f"p{page_number:04d}-img{occurrence:03d}",
                "page": page_number,
                "bbox": json.dumps([round(float(v), 3) for v in bbox], separators=(",", ":")),
                "xref": xref,
                "extraction_method": method,
                "format": suffix,
                "byte_size": len(raw),
                "sha256": digest,
                "asset": relative,
                "review_status": "",
                "md_reference": "",
                "notes": "",
            }
        )

    occurrence = 0
    for info in infos:
        occurrence += 1
        bbox = info.get("bbox", (0, 0, 0, 0))
        xref = int(info.get("xref") or 0)
        raw = b""
        ext = "bin"
        method = ""
        if xref > 0:
            try:
                extracted = doc.extract_image(xref)
                raw = extracted.get("image", b"")
                ext = extracted.get("ext", "bin")
                method = "xref-stream"
            except Exception:
                pass
        nearest: tuple[int, dict[str, Any]] | None = None
        if image_blocks:
            nearest = min(image_blocks, key=lambda item: bbox_distance(item[1].get("bbox", (0, 0, 0, 0)), bbox))
            if bbox_distance(nearest[1].get("bbox", (0, 0, 0, 0)), bbox) > 3.0:
                nearest = None
        block_index = nearest[0] if nearest else None
        if not raw and nearest:
            raw = nearest[1].get("image", b"")
            ext = nearest[1].get("ext", "bin")
            method = "display-block"
        if raw:
            if block_index is not None:
                used_blocks.add(block_index)
            save_occurrence(raw, ext, occurrence, bbox, method, xref, block_index)
            if xref in soft_masks:
                risks.append(f"image-soft-mask-review-{occurrence}")
        else:
            risks.append(f"unextractable-image-{occurrence}")

    for block_index, block in image_blocks:
        if block_index in used_blocks:
            continue
        raw = block.get("image", b"")
        if not raw:
            continue
        occurrence += 1
        save_occurrence(raw, block.get("ext", "bin"), occurrence, block.get("bbox", (0, 0, 0, 0)), "display-block", 0, block_index)

    return rows, block_to_asset, risks


def prepare(args: argparse.Namespace) -> int:
    source = Path(args.pdf).expanduser().resolve()
    work = Path(args.work_dir).expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"PDF not found: {source}")
    ensure_new_work_dir(work)
    dirs = {
        "assets": work / "assets/images",
        "blocks": work / "evidence/blocks",
        "tables": work / "evidence/tables",
        "text": work / "evidence/text",
        "pages": work / "reference/pages",
        "contacts": work / "reference/contact_sheets",
        "qa": work / "qa",
        "verified_text": work / "qa/verified_text",
    }
    for directory in dirs.values():
        directory.mkdir(parents=True, exist_ok=True)

    source_hash = sha256_file(source)
    doc = fitz.open(source)
    if doc.needs_pass:
        raise SystemExit("Encrypted PDF requires a password; decrypt an authorized copy before conversion.")
    plumber = pdfplumber.open(source)
    pdf_metadata = dict(doc.metadata or {})
    pdf_toc = doc.get_toc(simple=True)
    pdf_permissions = int(doc.permissions)
    title = str(pdf_metadata.get("title") or "").strip()
    if not title or title.lower() in {"(anonymous)", "anonymous", "untitled"}:
        title = source.stem
    title = re.sub(r"\s+", " ", title)
    page_rows: list[dict[str, Any]] = []
    image_rows: list[dict[str, Any]] = []
    table_rows: list[dict[str, Any]] = []
    page_records: list[dict[str, Any]] = []
    page_paths: list[Path] = []
    draft: list[str] = [
        "---",
        f"source_file: {json.dumps(source.name, ensure_ascii=False)}",
        f'source_sha256: "{source_hash}"',
        f"source_pages: {doc.page_count}",
        f"document_kind: {json.dumps(args.document_kind, ensure_ascii=False)}",
        f"content_profiles: {json.dumps(args.profiles, ensure_ascii=False)}",
        'conversion_state: "unverified-draft"',
        "---",
        "",
        f"# {title}",
        "",
        "> Machine-prepared draft. Verify every page against the rendered source before delivery.",
        "",
    ]
    visual: list[str] = [
        f"# {title} - Visual Archive",
        "",
        f"- Source: `{source.name}`",
        f"- SHA-256: `{source_hash}`",
        f"- Pages: {doc.page_count}",
        f"- Document kind: `{args.document_kind}`",
        f"- Initial content profiles: `{', '.join(args.profiles)}`",
        f"- Render DPI: {args.dpi}",
        "",
        "> This preserves each page visually at the stated render resolution; it is not a byte-identical copy of PDF drawing instructions.",
        "",
    ]

    try:
        for index in range(doc.page_count):
            page_number = index + 1
            page = doc[index]
            page_dict = page.get_text("dict", sort=True)
            embedded_text = page.get_text("text", sort=True)
            embedded_path = dirs["text"] / f"page_{page_number:04d}_embedded.txt"
            write_text(embedded_path, embedded_text)

            scale = args.dpi / 72.0
            pixmap = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False, colorspace=fitz.csRGB)
            page_path = dirs["pages"] / f"page_{page_number:04d}.png"
            pixmap.save(page_path)
            page_paths.append(page_path)

            selected_text = embedded_text
            text_source = "embedded"
            risks: list[str] = []
            if len(embedded_text.strip()) < args.text_threshold:
                risks.append("text-sparse")
                if args.ocr_lang:
                    ocr_text, ocr_error = run_ocr(page_path, args.ocr_lang, args.ocr_psm)
                    write_text(dirs["text"] / f"page_{page_number:04d}_ocr.txt", ocr_text)
                    if ocr_text.strip():
                        selected_text = ocr_text
                        text_source = "ocr"
                        risks.append("ocr-manual-verification-required")
                    if ocr_error:
                        risks.append(ocr_error)
            selected_path = dirs["text"] / f"page_{page_number:04d}.txt"
            write_text(selected_path, selected_text)

            page_image_rows, block_assets, image_risks = extract_page_images(
                doc, page, page_number, page_dict, dirs["assets"]
            )
            image_rows.extend(page_image_rows)
            risks.extend(image_risks)

            drawing_count = 0
            try:
                drawing_count = len(page.get_drawings())
            except Exception as exc:
                risks.append(f"drawing-scan-error:{type(exc).__name__}")
            if drawing_count:
                risks.append("vector-content-review")

            detected_tables: list[Any] = []
            try:
                detected_tables = plumber.pages[index].find_tables()
            except Exception as exc:
                risks.append(f"table-detection-error:{type(exc).__name__}")
            for table_index, table in enumerate(detected_tables, start=1):
                table_id = f"p{page_number:04d}-table{table_index:03d}"
                data = table.extract()
                table_path = dirs["tables"] / f"{table_id}.json"
                table_payload = {
                    "table_id": table_id,
                    "page": page_number,
                    "bbox": [round(float(v), 3) for v in table.bbox],
                    "rows": data,
                }
                write_text(table_path, json.dumps(table_payload, ensure_ascii=False, indent=2) + "\n")
                table_rows.append(
                    {
                        "table_id": table_id,
                        "page": page_number,
                        "bbox": json.dumps(table_payload["bbox"], separators=(",", ":")),
                        "row_count": len(data),
                        "column_count": max((len(row or []) for row in data), default=0),
                        "evidence": str(table_path.relative_to(work)),
                        "review_status": "",
                        "md_reference": "",
                        "notes": "",
                    }
                )
            if detected_tables:
                risks.append("table-review-required")

            text_blocks = [block for block in page_dict.get("blocks", []) if block.get("type") == 0]
            if len(text_blocks) > 1:
                x_positions = {round(float(block.get("bbox", (0, 0, 0, 0))[0]) / 20) for block in text_blocks}
                if len(x_positions) >= 3:
                    risks.append("reading-order-review")
            classification = "born-digital"
            if text_source == "ocr":
                classification = "scanned-or-textless"
            elif len(embedded_text.strip()) < args.text_threshold:
                classification = "sparse"
            elif page_image_rows:
                classification = "mixed"

            clean_risks = sorted(set(risks))
            page_rows.append(
                {
                    "page": page_number,
                    "content_profiles": ";".join(args.profiles),
                    "classification": classification,
                    "text_source": text_source,
                    "text_chars": len(selected_text),
                    "image_occurrences": len(page_image_rows),
                    "tables_detected": len(detected_tables),
                    "vector_objects": drawing_count,
                    "risk_flags": ";".join(clean_risks),
                    "text_review_status": "",
                    "visual_review_status": "",
                    "critical_review_status": "",
                    "risk_resolution": "",
                    "notes": "",
                }
            )
            blocks_path = dirs["blocks"] / f"page_{page_number:04d}.json"
            write_text(blocks_path, json.dumps(json_safe(page_dict), ensure_ascii=False, indent=2) + "\n")

            marker = f"<!-- PDF_PAGE:{page_number:04d} -->"
            draft.extend([marker, f'<a id="pdf-page-{page_number:04d}"></a>', "", f"## PDF page {page_number}", ""])
            ordered_blocks = sorted(
                enumerate(page_dict.get("blocks", [])),
                key=lambda item: (float(item[1].get("bbox", (0, 0, 0, 0))[1]), float(item[1].get("bbox", (0, 0, 0, 0))[0])),
            )
            for block_index, block in ordered_blocks:
                if block.get("type") == 0:
                    value = block_text(block).strip("\n")
                    if value:
                        draft.extend([value, ""])
                elif block.get("type") == 1 and block_index in block_assets:
                    draft.extend([f"![Source image on PDF page {page_number}]({block_assets[block_index]})", ""])
            if text_source == "ocr" and selected_text.strip():
                draft.extend(
                    [
                        "<!-- OCR_TRANSCRIPTION: manually verify every character against this PDF page -->",
                        selected_text.rstrip(),
                        "",
                    ]
                )
            if not selected_text.strip() and not page_image_rows:
                draft.extend(["*[Blank or extraction-empty source page; verify visually.]*", ""])

            visual.extend(
                [
                    marker,
                    f'<a id="pdf-page-{page_number:04d}"></a>',
                    "",
                    f"## PDF page {page_number}",
                    "",
                    f"![PDF page {page_number}](reference/pages/page_{page_number:04d}.png)",
                    "",
                ]
            )
            page_records.append(
                {
                    "page": page_number,
                    "width_points": round(page.rect.width, 3),
                    "height_points": round(page.rect.height, 3),
                    "rotation": page.rotation,
                    "selected_text": str(selected_path.relative_to(work)),
                    "page_render": str(page_path.relative_to(work)),
                    "page_render_sha256": sha256_file(page_path),
                    "classification": classification,
                    "risk_flags": clean_risks,
                }
            )
            print(f"Prepared page {page_number}/{doc.page_count}", file=sys.stderr)
    finally:
        plumber.close()
        doc.close()

    contact_names = make_contact_sheets(page_paths, dirs["contacts"])
    write_text(work / "draft.md", "\n".join(draft).rstrip() + "\n")
    write_text(work / "visual_archive.md", "\n".join(visual).rstrip() + "\n")
    write_csv(
        dirs["qa"] / "page_inventory.csv",
        [
            "page", "content_profiles", "classification", "text_source", "text_chars",
            "image_occurrences", "tables_detected", "vector_objects", "risk_flags",
            "text_review_status", "visual_review_status", "critical_review_status",
            "risk_resolution", "notes",
        ],
        page_rows,
    )
    write_csv(
        dirs["qa"] / "image_inventory.csv",
        [
            "image_id", "page", "bbox", "xref", "extraction_method", "format", "byte_size",
            "sha256", "asset", "review_status", "md_reference", "notes",
        ],
        image_rows,
    )
    write_csv(
        dirs["qa"] / "table_inventory.csv",
        [
            "table_id", "page", "bbox", "row_count", "column_count", "evidence",
            "review_status", "md_reference", "notes",
        ],
        table_rows,
    )
    manifest = {
        "schema_version": 2,
        "pipeline_version": VERSION,
        "created_utc": utc_now(),
        "source": {
            "filename": source.name,
            "absolute_path": str(source),
            "size_bytes": source.stat().st_size,
            "sha256": source_hash,
            "page_count": len(page_records),
            "metadata": pdf_metadata,
            "outline": pdf_toc,
            "permissions": pdf_permissions,
        },
        "conversion": {
            "document_kind": args.document_kind,
            "content_profiles": args.profiles,
            "render_dpi": args.dpi,
            "ocr_language": args.ocr_lang or None,
            "ocr_psm": args.ocr_psm if args.ocr_lang else None,
            "text_sparse_threshold": args.text_threshold,
            "contact_sheets": [f"reference/contact_sheets/{name}" for name in contact_names],
        },
        "inventories": {
            "image_occurrence_ids": [row["image_id"] for row in image_rows],
            "table_candidate_ids": [row["table_id"] for row in table_rows],
        },
        "environment": {
            "python": sys.version.split()[0],
            "pymupdf": getattr(fitz, "VersionBind", None),
            "mupdf": getattr(fitz, "VersionFitz", None),
            "pdfplumber": getattr(pdfplumber, "__version__", None),
            "tesseract": command_version("tesseract", "--version") if args.ocr_lang else None,
        },
        "pages": page_records,
    }
    write_text(work / "manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    ocr_pages = sum(1 for row in page_rows if row["text_source"] == "ocr")
    risk_pages = sum(1 for row in page_rows if row["risk_flags"])
    report = [
        "# Preparation Report",
        "",
        f"- Source: `{source.name}`",
        f"- SHA-256: `{source_hash}`",
        f"- Pages: {len(page_rows)}",
        f"- Document kind: `{args.document_kind}`",
        f"- Initial content profiles: `{', '.join(args.profiles)}`",
        f"- Render DPI: {args.dpi}",
        f"- OCR-selected pages: {ocr_pages}",
        f"- Pages with review flags: {risk_pages}",
        f"- Extracted image occurrences: {len(image_rows)}",
        f"- Detected table candidates: {len(table_rows)}",
        "",
        "Status: **UNVERIFIED DRAFT**. Confirm page profiles, complete text/visual/critical review fields, and run the audit after reconstructing `manual_exact.md`.",
    ]
    write_text(dirs["qa"] / "prepare_report.md", "\n".join(report) + "\n")
    print(f"Prepared conversion workspace: {work}")
    return 0


def normalize_text(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).replace("\u00ad", "")
    # NFKC maps full-width Chinese punctuation to ASCII. Keep punctuation
    # attached to the Latin token, but separate it from following CJK text so
    # tokenization does not turn ``WARNING：在`` into the false token
    # ``WARNING:``. This also preserves active-low spellings such as ``IRQ#``.
    value = re.sub(
        r"(?<=[A-Za-z0-9_])([./:+#-])(?=[\u3400-\u9fff])",
        r"\1 ",
        value,
    )
    return re.sub(r"\s+", " ", value).strip()


def markdown_to_plain(value: str) -> str:
    value = re.sub(r"(?im)^\s{0,3}#{1,6}\s+PDF page \d+\s*$", " ", value)
    value = value.replace("*[Blank or extraction-empty source page; verify visually.]*", " ")
    value = re.sub(r"<!--.*?-->", " ", value, flags=re.S)
    value = MD_IMAGE_RE.sub(" ", value)
    value = HTML_IMAGE_RE.sub(" ", value)
    value = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", value)
    value = re.sub(r"</?[A-Za-z][^>]*>", " ", value)
    value = re.sub(r"```[^\n]*\n", "", value)
    value = value.replace("```", "")
    # Remove Markdown syntax only where it is syntax. Literal ``#`` and ``>``
    # can be part of engineering tokens (IRQ#, <31:16>) and must survive.
    value = re.sub(r"(?m)^\s{0,3}#{1,6}(?=\s)", " ", value)
    value = re.sub(r"(?m)^\s{0,3}>\s?", " ", value)
    value = re.sub(r"[`*|~]", " ", value)
    return html.unescape(value)


def text_tokens(value: str) -> list[str]:
    normalized = normalize_text(value)
    return re.findall(
        rf"0[xX][0-9A-Fa-f](?:_?[0-9A-Fa-f])*[uUlL]*|"
        rf"0[bB][01](?:_?[01])*[uUlL]*|"
        rf"\d+'[hHbBoOdD][0-9A-Fa-f_xXzZ]+|{NUMBER_LITERAL}|"
        r"[A-Za-z_][A-Za-z0-9_./:+-]*#?|[\u3400-\u9fff]|[\u0370-\u03ff]+|"
        r"[±≤≥≈≠×÷√∞∑∫∆ΔΩμµ°]",
        normalized,
    )


def critical_tokens(value: str) -> list[str]:
    normalized = normalize_text(value)
    found: list[str] = []
    found.extend(RADIX_LITERAL_PATTERN.findall(normalized))
    found.extend(VERILOG_LITERAL_PATTERN.findall(normalized))
    found.extend(BIT_RANGE_PATTERN.findall(normalized))
    found.extend(UNIT_PATTERN.findall(normalized))
    found.extend(re.findall(rf"(?<![\w.]){NUMBER_LITERAL}(?!\w)", normalized))
    found.extend(ENGINEERING_SYMBOL_PATTERN.findall(normalized))
    found.extend(GREEK_TOKEN_PATTERN.findall(normalized))
    found.extend(ACTIVE_LOW_PATTERN.findall(normalized))
    for token in re.findall(r"\b[A-Za-z_][A-Za-z0-9_./:+-]{1,}\b", normalized):
        if "_" in token or any(char.isdigit() for char in token) or (token.isupper() and len(token) > 1):
            found.append(token)
    return found


def multiset_recall(source: list[str], target: list[str]) -> tuple[float, Counter[str]]:
    expected, actual = Counter(source), Counter(target)
    missing = expected - actual
    total = sum(expected.values())
    matched = total - sum(missing.values())
    return (1.0 if total == 0 else matched / total), missing


def multiset_precision(source: list[str], target: list[str]) -> tuple[float, Counter[str]]:
    expected, actual = Counter(source), Counter(target)
    unexpected = actual - expected
    total = sum(actual.values())
    matched = total - sum(unexpected.values())
    return (1.0 if total == 0 else matched / total), unexpected


def split_pages(markdown: str) -> tuple[list[int], dict[int, str]]:
    matches = list(PAGE_MARKER_RE.finditer(markdown))
    markers = [int(match.group(1)) for match in matches]
    sections: dict[int, str] = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(markdown)
        page_number = int(match.group(1))
        sections.setdefault(page_number, markdown[match.end() : end])
    return markers, sections


def image_references(markdown: str) -> list[str]:
    references = MD_IMAGE_RE.findall(markdown) + HTML_IMAGE_RE.findall(markdown)
    return [unquote(raw.strip().split()[0].strip("<>\"'")) for raw in references]


def local_image_references(markdown: str, markdown_path: Path) -> tuple[list[str], list[str]]:
    local: list[str] = []
    broken: list[str] = []
    for ref in image_references(markdown):
        if re.match(r"^(?:https?:|data:)", ref, re.I):
            continue
        local.append(ref)
        target = (markdown_path.parent / ref).resolve()
        if not target.is_file():
            broken.append(ref)
    return local, broken


def load_exceptions(path: Path) -> dict[tuple[int, str], Counter[str]]:
    allowed: dict[tuple[int, str], Counter[str]] = {}
    for row in read_csv(path):
        if not row.get("reason", "").strip() or not row.get("reviewer", "").strip():
            continue
        try:
            page = int(row.get("page", ""))
            count = int(row.get("count", "1") or "1")
        except ValueError:
            continue
        category = row.get("category", "").strip()
        token = row.get("token", "")
        if category and token and count > 0:
            allowed.setdefault((page, category), Counter())[token] += count
    return allowed


def audit(args: argparse.Namespace) -> int:
    source = Path(args.pdf).expanduser().resolve()
    markdown_path = Path(args.markdown).expanduser().resolve()
    work = Path(args.work_dir).expanduser().resolve()
    manifest_path = work / "manifest.json"
    if not source.is_file() or not markdown_path.is_file() or not manifest_path.is_file():
        raise SystemExit("Audit requires the source PDF, final Markdown, and WORK_DIR/manifest.json.")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    expected_hash = manifest["source"]["sha256"]
    expected_pages = int(manifest["source"]["page_count"])
    conversion = manifest.get("conversion", {})
    document_kind = str(conversion.get("document_kind") or "")
    manifest_profiles = list(conversion.get("content_profiles") or [])
    inventory_manifest = manifest.get("inventories", {})
    expected_image_ids = list(inventory_manifest.get("image_occurrence_ids") or [])
    expected_table_ids = list(inventory_manifest.get("table_candidate_ids") or [])
    actual_hash = sha256_file(source)
    with fitz.open(source) as doc:
        actual_pages = doc.page_count
    markdown = markdown_path.read_text(encoding="utf-8")
    markers, sections = split_pages(markdown)
    _, broken_refs = local_image_references(markdown, markdown_path)
    section_image_basenames = {
        page: {
            Path(ref).name
            for ref in image_references(section)
            if not re.match(r"^(?:https?:|data:)", ref, re.I)
        }
        for page, section in sections.items()
    }
    exceptions = load_exceptions(work / "qa/exceptions.csv")

    failures: list[str] = []
    if document_kind not in DOCUMENT_KINDS:
        failures.append("Manifest document kind is missing or invalid")
    if not manifest_profiles or set(manifest_profiles) - ALLOWED_CONTENT_PROFILES:
        failures.append("Manifest content profiles are missing or invalid")
    if "image_occurrence_ids" not in inventory_manifest or "table_candidate_ids" not in inventory_manifest:
        failures.append("Manifest inventory identities are missing")
    if actual_hash != expected_hash:
        failures.append("Source SHA-256 does not match manifest")
    if actual_pages != expected_pages:
        failures.append("Source page count does not match manifest")
    expected_marker_sequence = list(range(1, expected_pages + 1))
    if markers != expected_marker_sequence:
        failures.append("Page markers are missing, duplicated, or out of order")
    if broken_refs:
        failures.append(f"Broken local image references: {len(broken_refs)}")

    page_metrics: list[dict[str, Any]] = []
    verified_text_overrides: list[int] = []
    global_source_tokens: list[str] = []
    global_target_tokens: list[str] = []
    global_source_critical: list[str] = []
    global_target_critical: list[str] = []
    for page_number in range(1, expected_pages + 1):
        verified_text_path = work / f"qa/verified_text/page_{page_number:04d}.txt"
        source_text_path = (
            verified_text_path
            if verified_text_path.is_file()
            else work / f"evidence/text/page_{page_number:04d}.txt"
        )
        if source_text_path == verified_text_path:
            verified_text_overrides.append(page_number)
        source_text = source_text_path.read_text(encoding="utf-8") if source_text_path.exists() else ""
        target_text = markdown_to_plain(sections.get(page_number, ""))
        source_tokens = text_tokens(source_text)
        target_tokens = text_tokens(target_text)
        token_recall, missing_tokens = multiset_recall(source_tokens, target_tokens)
        token_precision, unexpected_tokens = multiset_precision(source_tokens, target_tokens)
        source_critical = critical_tokens(source_text)
        target_critical = critical_tokens(target_text)
        critical_recall_raw, missing_critical = multiset_recall(source_critical, target_critical)
        critical_precision, unexpected_critical = multiset_precision(source_critical, target_critical)
        allowed = exceptions.get((page_number, "critical-token"), Counter())
        unresolved_critical = missing_critical - allowed
        resolved_count = sum(missing_critical.values()) - sum(unresolved_critical.values())
        critical_total = len(source_critical)
        critical_recall = 1.0 if critical_total == 0 else (critical_total - sum(unresolved_critical.values())) / critical_total
        status = "PASS"
        if (
            page_number not in sections
            or token_recall < args.min_token_recall
            or token_precision < args.min_token_precision
            or critical_recall < args.min_critical_recall
            or critical_precision < args.min_critical_precision
        ):
            status = "FAIL"
            failures.append(f"Page {page_number} failed semantic fidelity gate")
        page_metrics.append(
            {
                "page": page_number,
                "source_tokens": len(source_tokens),
                "token_recall": token_recall,
                "token_precision": token_precision,
                "critical_tokens": critical_total,
                "critical_recall": critical_recall,
                "critical_precision": critical_precision,
                "critical_recall_before_exceptions": critical_recall_raw,
                "documented_critical_exceptions": resolved_count,
                "missing_tokens": missing_tokens,
                "unexpected_tokens": unexpected_tokens,
                "missing_critical": unresolved_critical,
                "unexpected_critical": unexpected_critical,
                "status": status,
            }
        )
        global_source_tokens.extend(source_tokens)
        global_target_tokens.extend(target_tokens)
        global_source_critical.extend(source_critical)
        global_target_critical.extend(target_critical)

    page_inventory = read_csv(work / "qa/page_inventory.csv")
    if len(page_inventory) != expected_pages:
        failures.append("Page inventory row count does not match source pages")
    unresolved_pages: list[str] = []
    inventory_page_numbers: list[int] = []
    reviewed_profiles: set[str] = set()
    for row in page_inventory:
        page = row.get("page", "?")
        if row.get("text_review_status", "").strip() != "verified":
            unresolved_pages.append(f"page {page}: text not verified")
        if row.get("visual_review_status", "").strip() != "verified":
            unresolved_pages.append(f"page {page}: visual not verified")
        if row.get("critical_review_status", "").strip() != "verified":
            unresolved_pages.append(f"page {page}: profile-specific critical elements not verified")
        profiles = {
            value.strip()
            for value in row.get("content_profiles", "").split(";")
            if value.strip()
        }
        invalid_profiles = sorted(profiles - ALLOWED_CONTENT_PROFILES)
        if not profiles:
            unresolved_pages.append(f"page {page}: content profile is blank")
        elif invalid_profiles:
            unresolved_pages.append(f"page {page}: invalid content profiles: {', '.join(invalid_profiles)}")
        reviewed_profiles.update(profiles & ALLOWED_CONTENT_PROFILES)
        if row.get("risk_flags", "").strip() and not row.get("risk_resolution", "").strip():
            unresolved_pages.append(f"page {page}: risk flags lack resolution")
        try:
            page_number = int(page)
        except ValueError:
            page_number = -1
        inventory_page_numbers.append(page_number)
        if page_number in verified_text_overrides and not row.get("notes", "").strip():
            unresolved_pages.append(f"page {page}: verified text override lacks an explanation")
    if inventory_page_numbers != expected_marker_sequence:
        failures.append("Page inventory pages are missing, duplicated, or out of order")
    if unresolved_pages:
        failures.append(f"Unresolved page review items: {len(unresolved_pages)}")

    image_inventory = read_csv(work / "qa/image_inventory.csv")
    unresolved_images: list[str] = []
    actual_image_ids = [row.get("image_id", "").strip() for row in image_inventory]
    image_inventory_ids_match = (
        len(actual_image_ids) == len(expected_image_ids)
        and len(actual_image_ids) == len(set(actual_image_ids))
        and len(expected_image_ids) == len(set(expected_image_ids))
        and set(actual_image_ids) == set(expected_image_ids)
    )
    if not image_inventory_ids_match:
        failures.append("Image inventory ID set does not match preparation manifest")
    for row in image_inventory:
        image_id = row.get("image_id", "?")
        status = row.get("review_status", "").strip()
        notes = row.get("notes", "").strip()
        asset_name = Path(row.get("asset", "")).name
        if status not in ALLOWED_IMAGE_STATUS:
            unresolved_images.append(f"{image_id}: invalid or blank status")
            continue
        if status in {"verified-embedded", "verified-crop"}:
            md_reference = row.get("md_reference", "").strip()
            expected_reference = asset_name if status == "verified-embedded" else Path(md_reference).name
            try:
                image_page = int(row.get("page", ""))
            except ValueError:
                image_page = -1
            if not md_reference:
                unresolved_images.append(f"{image_id}: missing Markdown image reference")
            elif status == "verified-embedded" and Path(md_reference).name != asset_name:
                unresolved_images.append(f"{image_id}: Markdown reference does not match extracted asset")
            elif expected_reference not in section_image_basenames.get(image_page, set()):
                unresolved_images.append(f"{image_id}: referenced asset is not present on its source page")
        elif not notes:
            unresolved_images.append(f"{image_id}: disposition requires notes")
    if unresolved_images:
        failures.append(f"Unresolved image inventory items: {len(unresolved_images)}")

    table_inventory = read_csv(work / "qa/table_inventory.csv")
    unresolved_tables: list[str] = []
    actual_table_ids = [row.get("table_id", "").strip() for row in table_inventory]
    table_inventory_ids_match = (
        len(actual_table_ids) == len(expected_table_ids)
        and len(actual_table_ids) == len(set(actual_table_ids))
        and len(expected_table_ids) == len(set(expected_table_ids))
        and set(actual_table_ids) == set(expected_table_ids)
    )
    if not table_inventory_ids_match:
        failures.append("Table inventory ID set does not match preparation manifest")
    for row in table_inventory:
        table_id = row.get("table_id", "?")
        status = row.get("review_status", "").strip()
        if status not in ALLOWED_TABLE_STATUS:
            unresolved_tables.append(f"{table_id}: invalid or blank status")
            continue
        md_reference = row.get("md_reference", "").strip()
        try:
            table_page = int(row.get("page", ""))
        except ValueError:
            table_page = -1
        reference_key = md_reference.lstrip("#")
        if not md_reference:
            unresolved_tables.append(f"{table_id}: missing Markdown reference")
        elif reference_key not in sections.get(table_page, ""):
            unresolved_tables.append(f"{table_id}: Markdown reference is not present on its source page")
        if status in {"verified-image", "false-detection"} and not row.get("notes", "").strip():
            unresolved_tables.append(f"{table_id}: disposition requires notes")
    if unresolved_tables:
        failures.append(f"Unresolved table inventory items: {len(unresolved_tables)}")

    visual_path = work / "visual_archive.md"
    visual_failures: list[str] = []
    if not visual_path.is_file():
        visual_failures.append("visual_archive.md is missing")
    else:
        visual_markdown = visual_path.read_text(encoding="utf-8")
        visual_markers, visual_sections = split_pages(visual_markdown)
        _, visual_broken = local_image_references(visual_markdown, visual_path)
        if visual_markers != expected_marker_sequence:
            visual_failures.append("visual archive page markers are incomplete or out of order")
        if visual_broken:
            visual_failures.append(f"visual archive has {len(visual_broken)} broken page images")
        for page_number in expected_marker_sequence:
            expected_render = f"reference/pages/page_{page_number:04d}.png"
            page_refs = image_references(visual_sections.get(page_number, ""))
            if page_refs.count(expected_render) != 1:
                visual_failures.append(
                    f"visual archive page {page_number} does not reference its render exactly once"
                )
    failures.extend(visual_failures)

    global_token_recall, _ = multiset_recall(global_source_tokens, global_target_tokens)
    global_token_precision, _ = multiset_precision(global_source_tokens, global_target_tokens)
    global_critical_recall, _ = multiset_recall(global_source_critical, global_target_critical)
    global_critical_precision, _ = multiset_precision(global_source_critical, global_target_critical)
    unresolved_critical_total = sum(sum(metric["missing_critical"].values()) for metric in page_metrics)
    global_critical_after_exceptions = (
        1.0
        if not global_source_critical
        else (len(global_source_critical) - unresolved_critical_total) / len(global_source_critical)
    )
    overall = "PASS" if not failures else "FAIL"
    report_lines = [
        "# PDF-to-Markdown Fidelity Audit",
        "",
        f"**Result: {overall}**",
        "",
        f"- Source: `{source.name}`",
        f"- Document kind: `{document_kind or 'INVALID'}`",
        f"- Initial content profiles: `{', '.join(manifest_profiles) or 'INVALID'}`",
        f"- Reviewed page profiles: `{', '.join(sorted(reviewed_profiles)) or 'NONE'}`",
        f"- Source SHA-256 match: {'PASS' if actual_hash == expected_hash else 'FAIL'}",
        f"- PDF pages: {actual_pages}",
        f"- Markdown page markers: {len(markers)}",
        f"- Visual archive pages: {expected_pages if not visual_failures else 'FAIL'}",
        f"- Broken asset references: {len(broken_refs)}",
        f"- Image inventory identity: {'PASS' if image_inventory_ids_match else 'FAIL'}",
        f"- Table inventory identity: {'PASS' if table_inventory_ids_match else 'FAIL'}",
        f"- Global token recall: {global_token_recall:.6f}",
        f"- Global token precision: {global_token_precision:.6f}",
        f"- Global critical-token recall before exceptions: {global_critical_recall:.6f}",
        f"- Global critical-token recall after exceptions: {global_critical_after_exceptions:.6f}",
        f"- Global critical-token precision: {global_critical_precision:.6f}",
        f"- Global unresolved critical tokens: {unresolved_critical_total}",
        f"- Visually verified text overrides: {len(verified_text_overrides)}",
        f"- Unresolved page review items: {len(unresolved_pages)}",
        f"- Unresolved image inventory items: {len(unresolved_images)}",
        f"- Unresolved table inventory items: {len(unresolved_tables)}",
        "",
        "## Per-page semantic fidelity",
        "",
        "| Page | Tokens | Token recall | Token precision | Critical tokens | Critical recall | Critical precision | Status |",
        "| ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |",
    ]
    for metric in page_metrics:
        report_lines.append(
            f"| {metric['page']} | {metric['source_tokens']} | {metric['token_recall']:.6f} | "
            f"{metric['token_precision']:.6f} | {metric['critical_tokens']} | "
            f"{metric['critical_recall']:.6f} | {metric['critical_precision']:.6f} | {metric['status']} |"
        )
    if failures:
        report_lines.extend(["", "## Hard-gate failures", ""])
        report_lines.extend(f"- {item}" for item in dict.fromkeys(failures))
    details = unresolved_pages + unresolved_images + unresolved_tables + [f"broken asset: {item}" for item in broken_refs]
    for metric in page_metrics:
        if metric["status"] == "FAIL":
            missing_semantic = ", ".join(
                f"{token} x{count}" for token, count in metric["missing_tokens"].most_common(12)
            )
            unexpected_semantic = ", ".join(
                f"{token} x{count}" for token, count in metric["unexpected_tokens"].most_common(12)
            )
            missing = ", ".join(f"{token} x{count}" for token, count in metric["missing_critical"].most_common(12))
            unexpected = ", ".join(
                f"{token} x{count}" for token, count in metric["unexpected_critical"].most_common(12)
            )
            if missing_semantic:
                details.append(f"page {metric['page']} missing semantic tokens: {missing_semantic}")
            if unexpected_semantic:
                details.append(f"page {metric['page']} unexpected semantic tokens: {unexpected_semantic}")
            details.append(
                f"page {metric['page']} missing critical tokens: "
                f"{missing or 'none; another semantic gate failed'}"
            )
            if unexpected:
                details.append(f"page {metric['page']} unexpected critical tokens: {unexpected}")
    if details:
        report_lines.extend(["", "## Review details", ""])
        report_lines.extend(f"- {item}" for item in details[:500])
    report_lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "PASS proves only the measured source identity, page coverage, asset integrity, review-state, and extraction-relative recall/precision gates. It does not make semantic Markdown visually or byte-for-byte identical to arbitrary PDF drawing instructions.",
        ]
    )
    report_path = Path(args.report).resolve() if args.report else work / "qa/audit_report.md"
    write_text(report_path, "\n".join(report_lines) + "\n")
    json_report = {
        "result": overall,
        "audited_utc": utc_now(),
        "pipeline_version": VERSION,
        "markdown_name": markdown_path.name,
        "markdown_sha256": sha256_file(markdown_path),
        "normalized_markdown_sha256": sha256_bytes(
            (markdown.replace("\r\n", "\n").replace("\r", "\n").rstrip() + "\n").encode("utf-8")
        ),
        "source_sha256_match": actual_hash == expected_hash,
        "source_pages": actual_pages,
        "document_kind": document_kind,
        "initial_content_profiles": manifest_profiles,
        "reviewed_page_profiles": sorted(reviewed_profiles),
        "markdown_page_markers": len(markers),
        "image_inventory_identity_match": image_inventory_ids_match,
        "table_inventory_identity_match": table_inventory_ids_match,
        "global_token_recall": global_token_recall,
        "global_token_precision": global_token_precision,
        "global_critical_token_recall_before_exceptions": global_critical_recall,
        "global_critical_token_recall_after_exceptions": global_critical_after_exceptions,
        "global_critical_token_precision": global_critical_precision,
        "failure_count": len(failures),
        "failures": list(dict.fromkeys(failures)),
    }
    write_text(work / "qa/audit_report.json", json.dumps(json_report, ensure_ascii=False, indent=2) + "\n")
    print(f"Audit result: {overall}; report: {report_path}")
    return 0 if overall == "PASS" else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=VERSION)
    subparsers = parser.add_subparsers(dest="command", required=True)

    prepare_parser = subparsers.add_parser("prepare", help="Extract immutable evidence and create conversion drafts")
    prepare_parser.add_argument("pdf", help="Source PDF")
    prepare_parser.add_argument("work_dir", help="New or empty output directory")
    prepare_parser.add_argument("--dpi", type=int, default=240, choices=range(120, 601), metavar="120..600")
    prepare_parser.add_argument(
        "--document-kind",
        choices=DOCUMENT_KINDS,
        default="other-technical",
        help="Source publication kind used in the conversion manifest",
    )
    prepare_parser.add_argument(
        "--profiles",
        type=parse_profiles,
        default=["general"],
        help="Comma-separated embedded content profiles; revise per page after visual inspection",
    )
    prepare_parser.add_argument("--ocr-lang", help="Tesseract language expression, for example eng+chi_sim")
    prepare_parser.add_argument("--ocr-psm", type=int, default=3, choices=range(0, 14), metavar="0..13")
    prepare_parser.add_argument("--text-threshold", type=int, default=40, help="OCR-candidate character threshold")
    prepare_parser.set_defaults(func=prepare)

    audit_parser = subparsers.add_parser("audit", help="Audit a reconstructed Markdown file against prepared evidence")
    audit_parser.add_argument("pdf", help="Original source PDF")
    audit_parser.add_argument("markdown", help="Final source-faithful Markdown")
    audit_parser.add_argument("work_dir", help="Preparation workspace")
    audit_parser.add_argument("--min-token-recall", type=float, default=0.999)
    audit_parser.add_argument("--min-token-precision", type=float, default=0.999)
    audit_parser.add_argument("--min-critical-recall", type=float, default=1.0)
    audit_parser.add_argument("--min-critical-precision", type=float, default=1.0)
    audit_parser.add_argument("--report", help="Optional audit report path")
    audit_parser.set_defaults(func=audit)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    for option in (
        "min_token_recall",
        "min_token_precision",
        "min_critical_recall",
        "min_critical_precision",
    ):
        value = getattr(args, option, 1.0)
        if value < 0 or value > 1:
            parser.error(f"--{option.replace('_', '-')} must be between 0 and 1")
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

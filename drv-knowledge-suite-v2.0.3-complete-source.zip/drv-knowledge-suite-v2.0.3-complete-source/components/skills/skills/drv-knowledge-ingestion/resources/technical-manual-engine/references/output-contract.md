# End-to-End Output Contract

## Conversion workspace

```text
WORK_DIR/
├── draft.md
├── visual_archive.md
├── manual_exact.md
├── manual_bookstack.md               # only after exact gates; AI-authored derivative
├── manual_rag_clean.md               # only when separately requested
├── manifest.json
├── assets/images/
├── evidence/{blocks,tables,text}/
├── reference/{contact_sheets,pages}/
└── qa/
    ├── prepare_report.md
    ├── page_inventory.csv
    ├── image_inventory.csv
    ├── table_inventory.csv
    ├── table_census.csv
    ├── table_census_meta.json
    ├── verified_tables/
    ├── table_audit.json
    ├── bookstack_rewrite_review.json
    ├── bookstack_rewrite_exceptions.csv
    ├── bookstack_table_audit.json
    ├── bookstack_rewrite_audit.json
    ├── audit_report.md
    └── audit_report.json
```

Keep raw evidence and source fingerprints immutable. Store visually corrected
page ground truth only under `qa/verified_text/`.

Keep `manual_exact.md` and `manual_bookstack.md` separately hash-bound. The
BookStack derivative may translate and reorganize prose only after the exact
audits pass. Its review, exception ledger, translated table audit, and rewrite
audit are mandatory when that derivative is selected for ingestion.

## Frozen BookStack bundle

```text
BUNDLE_DIR/
├── plan.json
├── plan_report.md
├── assets/
├── pages/
│   ├── 0001.md
│   └── ...
└── runs/
    ├── test-*.json
    └── formal-*.json
```

`plan.json` contains the source/audit hashes, routing names, page names,
priorities, content hashes, asset hashes, exact-audit hashes, the rewrite-audit
hash when applicable, and its own deterministic plan hash. Any content,
classification, rewrite, asset, or routing change requires a new plan and a new
test.

## Complete-delivery gates

Require all of the following:

| Gate | Required result |
| --- | --- |
| Source SHA-256 and page count | PASS |
| Ordered page markers | complete |
| Page text/visual/profile review | all verified |
| Bidirectional semantic token gates | PASS |
| Critical-token recall and precision | 1.000000, except documented source-only recall exceptions |
| Table census | all pages reviewed |
| Structured table cell matrices | exact match |
| BookStack rewrite review | all full-read attestations complete |
| Translated tables | geometry and per-cell engineering tokens match |
| Rewrite critical-token recall and precision | 1.000000 after narrow valid exceptions |
| Rewrite code and meaningful-image preservation | exact code; all required images retained |
| Exact/derivative/audit SHA-256 binding | PASS |
| Markdown and asset gate | PASS |
| Test upload read-back | VERIFIED |
| User test review | explicitly confirmed |
| Formal upload read-back | VERIFIED |
| Rollback journal | complete and credential-free |

Keep claims dimension-specific. A formal run is complete only while its run
manifest and a fresh read-back verification report both show `VERIFIED`.

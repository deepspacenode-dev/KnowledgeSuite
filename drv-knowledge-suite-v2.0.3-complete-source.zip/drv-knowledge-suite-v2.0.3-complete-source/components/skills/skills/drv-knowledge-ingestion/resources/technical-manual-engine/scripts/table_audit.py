#!/usr/bin/env python3
"""Create and audit a page-complete, cell-exact table census for technical manuals."""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import html
import json
import re
import sys
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
from typing import Any


VERSION = "1.0.8"
PAGE_MARKER_RE = re.compile(r"<!--\s*PDF_PAGE:(\d{4})\s*-->")
TABLE_MARKER_RE = re.compile(r"<!--\s*SOURCE_TABLE:([A-Za-z0-9_-]+)\s*-->")
STRUCTURED_STATUS = {"verified-markdown", "verified-html"}
ALLOWED_STATUS = STRUCTURED_STATUS | {"verified-image", "false-detection"}
CENSUS_FIELDS = [
    "table_id",
    "page",
    "candidate_id",
    "title",
    "representation",
    "review_status",
    "continuation_of",
    "md_reference",
    "verified_table",
    "notes",
]


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=CENSUS_FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def split_pages(markdown: str) -> tuple[list[int], dict[int, str]]:
    matches = list(PAGE_MARKER_RE.finditer(markdown))
    markers = [int(match.group(1)) for match in matches]
    sections: dict[int, str] = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(markdown)
        sections[int(match.group(1))] = markdown[match.end() : end]
    return markers, sections


def rectangular(rows: list[list[Any]]) -> list[list[str]]:
    converted = [["" if cell is None else str(cell).strip() for cell in (row or [])] for row in rows]
    width = max((len(row) for row in converted), default=0)
    return [row + [""] * (width - len(row)) for row in converted]


def normalize_cell(value: str) -> str:
    value = html.unescape(value).replace("\r\n", "\n").replace("\r", "\n")
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r" *\n *", "\n", value)
    return value.strip()


def split_pipe_row(line: str) -> list[str]:
    value = line.strip()
    if value.startswith("|"):
        value = value[1:]
    if value.endswith("|") and not value.endswith("\\|"):
        value = value[:-1]
    cells: list[str] = []
    current: list[str] = []
    escaped = False
    for char in value:
        if escaped:
            current.append(char)
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == "|":
            cells.append("".join(current))
            current = []
        else:
            current.append(char)
    if escaped:
        current.append("\\")
    cells.append("".join(current))
    return [normalize_cell(re.sub(r"<br\s*/?>", "\n", cell, flags=re.I)) for cell in cells]


def is_pipe_separator(row: list[str]) -> bool:
    return bool(row) and all(re.fullmatch(r":?-{3,}:?", cell.replace(" ", "")) for cell in row)


def parse_pipe_table(fragment: str) -> list[list[str]]:
    lines = fragment.splitlines()
    start = next((index for index, line in enumerate(lines) if line.lstrip().startswith("|")), None)
    if start is None:
        raise ValueError("no GFM pipe table follows the source marker")
    table_lines: list[str] = []
    for line in lines[start:]:
        if not line.strip():
            if table_lines:
                break
            continue
        if not line.lstrip().startswith("|"):
            break
        table_lines.append(line)
    rows = [split_pipe_row(line) for line in table_lines]
    if len(rows) >= 2 and is_pipe_separator(rows[1]):
        rows.pop(1)
    rows = rectangular(rows)
    if not rows or not rows[0]:
        raise ValueError("empty GFM table")
    return rows


class TableHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.in_table = False
        self.table_depth = 0
        self.row_index = -1
        self.grid: dict[tuple[int, int], str] = {}
        self.in_cell = False
        self.cell_parts: list[str] = []
        self.cell_rowspan = 1
        self.cell_colspan = 1
        self.finished = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag == "table":
            if not self.in_table:
                self.in_table = True
                self.table_depth = 1
            else:
                self.table_depth += 1
            return
        if not self.in_table or self.finished:
            return
        if tag == "tr":
            self.row_index += 1
        elif tag in {"td", "th"}:
            if self.row_index < 0:
                self.row_index = 0
            values = {key.lower(): value for key, value in attrs}
            self.in_cell = True
            self.cell_parts = []
            try:
                self.cell_rowspan = max(1, int(values.get("rowspan") or "1"))
                self.cell_colspan = max(1, int(values.get("colspan") or "1"))
            except ValueError as exc:
                raise ValueError("invalid HTML rowspan or colspan") from exc
        elif tag == "br" and self.in_cell:
            self.cell_parts.append("\n")
        elif tag in {"sub", "sup"} and self.in_cell:
            self.cell_parts.append(f"<{tag}>")

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag == "table" and self.in_table:
            self.table_depth -= 1
            if self.table_depth == 0:
                self.in_table = False
                self.finished = True
            return
        if not self.in_table or self.finished:
            return
        if tag in {"td", "th"} and self.in_cell:
            column = 0
            while (self.row_index, column) in self.grid:
                column += 1
            value = normalize_cell("".join(self.cell_parts))
            for row_offset in range(self.cell_rowspan):
                for column_offset in range(self.cell_colspan):
                    key = (self.row_index + row_offset, column + column_offset)
                    if key in self.grid:
                        raise ValueError("overlapping HTML table spans")
                    self.grid[key] = value
            self.in_cell = False
        elif tag in {"sub", "sup"} and self.in_cell:
            self.cell_parts.append(f"</{tag}>")

    def handle_data(self, data: str) -> None:
        if self.in_table and self.in_cell and not self.finished:
            self.cell_parts.append(data)

    def matrix(self) -> list[list[str]]:
        if not self.finished or not self.grid:
            raise ValueError("incomplete or empty HTML table")
        max_row = max(row for row, _ in self.grid)
        max_column = max(column for _, column in self.grid)
        return [
            [self.grid.get((row, column), "") for column in range(max_column + 1)]
            for row in range(max_row + 1)
        ]


def parse_html_table(fragment: str) -> list[list[str]]:
    match = re.search(r"<table\b", fragment, re.I)
    if not match:
        raise ValueError("no HTML table follows the source marker")
    parser = TableHTMLParser()
    parser.feed(fragment[match.start() :])
    return rectangular(parser.matrix())


def compare_rows(expected: list[list[str]], actual: list[list[str]]) -> list[str]:
    expected = [[normalize_cell(cell) for cell in row] for row in rectangular(expected)]
    actual = [[normalize_cell(cell) for cell in row] for row in rectangular(actual)]
    problems: list[str] = []
    if len(expected) != len(actual):
        problems.append(f"row count differs: expected {len(expected)}, actual {len(actual)}")
    expected_width = len(expected[0]) if expected else 0
    actual_width = len(actual[0]) if actual else 0
    if expected_width != actual_width:
        problems.append(f"column count differs: expected {expected_width}, actual {actual_width}")
    for row in range(min(len(expected), len(actual))):
        for column in range(min(len(expected[row]), len(actual[row]))):
            if expected[row][column] != actual[row][column]:
                problems.append(
                    f"cell R{row + 1}C{column + 1} differs: "
                    f"expected {expected[row][column]!r}, actual {actual[row][column]!r}"
                )
                if len(problems) >= 25:
                    return problems
    return problems


def compare_translated_rows(expected: list[list[str]], actual: list[list[str]]) -> list[str]:
    """Allow prose translation while preserving geometry and engineering tokens per cell."""
    from manual_pipeline import critical_tokens

    expected = [[normalize_cell(cell) for cell in row] for row in rectangular(expected)]
    actual = [[normalize_cell(cell) for cell in row] for row in rectangular(actual)]
    problems: list[str] = []
    if len(expected) != len(actual):
        problems.append(f"row count differs: expected {len(expected)}, actual {len(actual)}")
    expected_width = len(expected[0]) if expected else 0
    actual_width = len(actual[0]) if actual else 0
    if expected_width != actual_width:
        problems.append(f"column count differs: expected {expected_width}, actual {actual_width}")
    for row in range(min(len(expected), len(actual))):
        for column in range(min(len(expected[row]), len(actual[row]))):
            source_cell = expected[row][column]
            target_cell = actual[row][column]
            if bool(source_cell) != bool(target_cell):
                problems.append(
                    f"cell R{row + 1}C{column + 1} blank/nonblank state differs: "
                    f"expected {source_cell!r}, actual {target_cell!r}"
                )
            source_tokens = Counter(critical_tokens(source_cell))
            target_tokens = Counter(critical_tokens(target_cell))
            if source_tokens != target_tokens:
                missing = source_tokens - target_tokens
                unexpected = target_tokens - source_tokens
                problems.append(
                    f"cell R{row + 1}C{column + 1} engineering tokens differ: "
                    f"missing {dict(missing)}, unexpected {dict(unexpected)}"
                )
            if len(problems) >= 25:
                return problems
    return problems


def command_init(args: argparse.Namespace) -> int:
    work = Path(args.work_dir).expanduser().resolve()
    manifest_path = work / "manifest.json"
    inventory_path = work / "qa/table_inventory.csv"
    census_path = work / "qa/table_census.csv"
    meta_path = work / "qa/table_census_meta.json"
    if not manifest_path.is_file() or not inventory_path.is_file():
        raise SystemExit("init requires WORK_DIR/manifest.json and qa/table_inventory.csv")
    if census_path.exists() or meta_path.exists():
        raise SystemExit("Refusing to overwrite an existing table census")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    source = manifest["source"]
    rows: list[dict[str, Any]] = []
    verified_dir = work / "qa/verified_tables"
    verified_dir.mkdir(parents=True, exist_ok=True)
    for item in read_csv(inventory_path):
        table_id = item["table_id"].strip()
        page = int(item["page"])
        verified_relative = f"qa/verified_tables/{table_id}.json"
        rows.append(
            {
                "table_id": table_id,
                "page": page,
                "candidate_id": table_id,
                "title": "",
                "representation": "",
                "review_status": "unreviewed",
                "continuation_of": "",
                "md_reference": f"SOURCE_TABLE:{table_id}",
                "verified_table": verified_relative,
                "notes": "",
            }
        )
        evidence_path = work / item.get("evidence", "")
        evidence = json.loads(evidence_path.read_text(encoding="utf-8")) if evidence_path.is_file() else {}
        template = {
            "table_id": table_id,
            "page": page,
            "title": "",
            "representation": "",
            "verified_against_pdf": False,
            "reviewer": "",
            "continuation_of": "",
            "rows": rectangular(evidence.get("rows") or []),
            "notes": "Unverified extractor seed; correct every cell against the PDF render.",
        }
        write_json(work / verified_relative, template)
    write_csv(census_path, rows)
    write_json(
        meta_path,
        {
            "schema_version": 1,
            "source_sha256": source["sha256"],
            "source_pages": int(source["page_count"]),
            "all_pages_reviewed_against_pdf": False,
            "reviewer": "",
            "reviewed_utc": "",
            "notes": "",
        },
    )
    print(f"Initialized {len(rows)} table candidates. Review all pages and add missed tables before audit.")
    return 0


def command_sync(args: argparse.Namespace) -> int:
    work = Path(args.work_dir).expanduser().resolve()
    census = read_csv(work / "qa/table_census.csv")
    inventory_path = work / "qa/table_inventory.csv"
    with inventory_path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        inventory = list(reader)
        fields = list(reader.fieldnames or [])
    by_candidate: dict[str, dict[str, str]] = {}
    for row in census:
        candidate = row.get("candidate_id", "").strip()
        if candidate:
            if candidate in by_candidate:
                raise SystemExit(f"Duplicate candidate_id in census: {candidate}")
            by_candidate[candidate] = row
    missing = [row["table_id"] for row in inventory if row["table_id"] not in by_candidate]
    if missing:
        raise SystemExit(f"Census is missing detected candidates: {', '.join(missing)}")
    for row in inventory:
        linked = by_candidate[row["table_id"]]
        status = linked.get("review_status", "").strip()
        if status not in ALLOWED_STATUS:
            raise SystemExit(f"{row['table_id']} has invalid or unreviewed census status")
        row["review_status"] = status
        if status == "false-detection":
            row["md_reference"] = f"pdf-page-{int(row['page']):04d}"
        else:
            row["md_reference"] = f"SOURCE_TABLE:{linked['table_id']}"
        row["notes"] = linked.get("notes", "")
    with inventory_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(inventory)
    print(f"Synchronized {len(inventory)} detected candidates into table_inventory.csv")
    return 0


def command_audit(args: argparse.Namespace) -> int:
    markdown_path = Path(args.markdown).expanduser().resolve()
    work = Path(args.work_dir).expanduser().resolve()
    manifest_path = work / "manifest.json"
    census_path = work / "qa/table_census.csv"
    meta_path = work / "qa/table_census_meta.json"
    if not all(path.is_file() for path in (markdown_path, manifest_path, census_path, meta_path)):
        raise SystemExit("audit requires Markdown, manifest.json, table_census.csv, and table_census_meta.json")
    markdown = markdown_path.read_text(encoding="utf-8")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    census = read_csv(census_path)
    markers, sections = split_pages(markdown)
    failures: list[str] = []
    details: list[dict[str, Any]] = []
    expected_pages = int(manifest["source"]["page_count"])
    expected_candidates = set(manifest.get("inventories", {}).get("table_candidate_ids") or [])

    if markers != list(range(1, expected_pages + 1)):
        failures.append("PDF page markers are incomplete or out of order")
    if meta.get("source_sha256") != manifest["source"]["sha256"]:
        failures.append("Table census source SHA-256 does not match conversion manifest")
    if int(meta.get("source_pages") or 0) != expected_pages:
        failures.append("Table census page count does not match conversion manifest")
    if meta.get("all_pages_reviewed_against_pdf") is not True:
        failures.append("Whole-manual table census has not been visually verified")
    if not str(meta.get("reviewer") or "").strip():
        failures.append("Table census reviewer is blank")

    ids = [row.get("table_id", "").strip() for row in census]
    if len(ids) != len(set(ids)) or any(not value for value in ids):
        failures.append("Table census IDs are blank or duplicated")
    candidate_ids = [row.get("candidate_id", "").strip() for row in census if row.get("candidate_id", "").strip()]
    if len(candidate_ids) != len(set(candidate_ids)) or set(candidate_ids) != expected_candidates:
        failures.append("Detected table candidate coverage does not match the conversion manifest")

    marker_counts: dict[str, int] = {}
    marker_pages: dict[str, list[int]] = {}
    for page, section in sections.items():
        for table_id in TABLE_MARKER_RE.findall(section):
            marker_counts[table_id] = marker_counts.get(table_id, 0) + 1
            marker_pages.setdefault(table_id, []).append(page)

    for row in census:
        table_id = row.get("table_id", "").strip()
        status = row.get("review_status", "").strip()
        try:
            page = int(row.get("page", ""))
        except ValueError:
            page = -1
        item: dict[str, Any] = {"table_id": table_id, "page": page, "status": status, "result": "PASS"}
        item_failures: list[str] = []
        if page < 1 or page > expected_pages:
            item_failures.append("invalid page")
        if status not in ALLOWED_STATUS:
            item_failures.append("invalid or unreviewed status")
        if status == "false-detection":
            if not row.get("notes", "").strip():
                item_failures.append("false detection lacks notes")
            if marker_counts.get(table_id, 0):
                item_failures.append("false detection unexpectedly has a Markdown table marker")
        elif status == "verified-image":
            if not args.allow_image_only:
                item_failures.append("image-only table is blocked for semantic ingestion")
            if not row.get("notes", "").strip():
                item_failures.append("image-only table lacks limitation notes")
        elif status in STRUCTURED_STATUS:
            source_representation = "markdown" if status == "verified-markdown" else "html"
            actual_representation = (
                source_representation if args.representation == "source" else args.representation
            )
            if row.get("representation", "").strip() != source_representation:
                item_failures.append("census representation does not match review status")
            if row.get("md_reference", "").strip() != f"SOURCE_TABLE:{table_id}":
                item_failures.append("census Markdown reference does not match table ID")
            if marker_counts.get(table_id, 0) != 1:
                item_failures.append("source table marker is missing or duplicated")
            elif marker_pages.get(table_id) != [page]:
                item_failures.append("source table marker is on the wrong PDF page")
            verified_path = work / row.get("verified_table", "")
            if not verified_path.is_file():
                item_failures.append("verified table matrix file is missing")
            else:
                verified = json.loads(verified_path.read_text(encoding="utf-8"))
                if verified.get("table_id") != table_id or int(verified.get("page") or 0) != page:
                    item_failures.append("verified matrix identity does not match census")
                if verified.get("representation") != source_representation:
                    item_failures.append("verified matrix representation does not match census")
                if str(verified.get("continuation_of") or "") != row.get("continuation_of", "").strip():
                    item_failures.append("verified matrix continuation does not match census")
                if verified.get("verified_against_pdf") is not True:
                    item_failures.append("verified matrix lacks PDF review attestation")
                if not str(verified.get("reviewer") or "").strip():
                    item_failures.append("verified matrix reviewer is blank")
                expected_rows = rectangular(verified.get("rows") or [])
                if not expected_rows or not expected_rows[0]:
                    item_failures.append("verified matrix is empty")
                if not item_failures:
                    section = sections[page]
                    marker_match = re.search(
                        rf"<!--\s*SOURCE_TABLE:{re.escape(table_id)}\s*-->",
                        section,
                    )
                    fragment = section[marker_match.end() :] if marker_match else ""
                    try:
                        actual_rows = (
                            parse_pipe_table(fragment)
                            if actual_representation == "markdown"
                            else parse_html_table(fragment)
                        )
                        matrix_failures = (
                            compare_rows(expected_rows, actual_rows)
                            if args.mode == "exact"
                            else compare_translated_rows(expected_rows, actual_rows)
                        )
                        item_failures.extend(matrix_failures)
                        item["source_representation"] = source_representation
                        item["actual_representation"] = actual_representation
                        item["comparison_mode"] = args.mode
                        item["expected_rows"] = len(expected_rows)
                        item["expected_columns"] = len(expected_rows[0])
                        item["actual_rows"] = len(actual_rows)
                        item["actual_columns"] = len(actual_rows[0]) if actual_rows else 0
                    except (ValueError, TypeError) as exc:
                        item_failures.append(str(exc))
        if item_failures:
            item["result"] = "FAIL"
            item["failures"] = item_failures
            failures.extend(f"{table_id}: {problem}" for problem in item_failures)
        details.append(item)

    real_ids = {row["table_id"].strip() for row in census if row.get("review_status", "").strip() != "false-detection"}
    unknown_markers = sorted(set(marker_counts) - real_ids)
    missing_markers = sorted(
        table_id
        for table_id in real_ids
        if next((row for row in census if row["table_id"].strip() == table_id), {}).get("review_status")
        in STRUCTURED_STATUS
        and marker_counts.get(table_id, 0) != 1
    )
    if unknown_markers:
        failures.append(f"Unknown SOURCE_TABLE markers: {', '.join(unknown_markers)}")
    if missing_markers:
        failures.append(f"Structured tables missing unique markers: {', '.join(missing_markers)}")

    result = "PASS" if not failures else "FAIL"
    report = {
        "schema_version": 1,
        "result": result,
        "audited_utc": utc_now(),
        "table_audit_version": VERSION,
        "markdown_name": markdown_path.name,
        "markdown_sha256": sha256_file(markdown_path),
        "representation_mode": args.representation,
        "comparison_mode": args.mode,
        "source_sha256": manifest["source"]["sha256"],
        "source_pages": expected_pages,
        "census_rows": len(census),
        "real_tables": sum(1 for row in census if row.get("review_status", "").strip() != "false-detection"),
        "false_detections": sum(1 for row in census if row.get("review_status", "").strip() == "false-detection"),
        "allow_image_only": bool(args.allow_image_only),
        "failure_count": len(failures),
        "failures": failures,
        "tables": details,
    }
    output_path = Path(args.output).expanduser().resolve() if args.output else work / "qa/table_audit.json"
    write_json(output_path, report)
    lines = [
        "# Table Fidelity Audit",
        "",
        f"**Result: {result}**",
        "",
        f"- Source pages: {expected_pages}",
        f"- Census rows: {len(census)}",
        f"- Real tables: {report['real_tables']}",
        f"- False detections: {report['false_detections']}",
        f"- Representation mode: {args.representation}",
        f"- Comparison mode: {args.mode}",
        f"- Image-only tables allowed: {bool(args.allow_image_only)}",
    ]
    if failures:
        lines.extend(["", "## Failures", ""])
        lines.extend(f"- {failure}" for failure in failures[:500])
    report_md_path = (
        Path(args.report_md).expanduser().resolve()
        if args.report_md
        else output_path.with_suffix(".md")
    )
    report_md_path.parent.mkdir(parents=True, exist_ok=True)
    report_md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Table audit result: {result}; report: {output_path}")
    return 0 if result == "PASS" else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=VERSION)
    subparsers = parser.add_subparsers(dest="command", required=True)
    init_parser = subparsers.add_parser("init", help="Create an unverified table census and matrix templates")
    init_parser.add_argument("work_dir")
    init_parser.set_defaults(func=command_init)
    sync_parser = subparsers.add_parser("sync", help="Copy reviewed candidate dispositions into table_inventory.csv")
    sync_parser.add_argument("work_dir")
    sync_parser.set_defaults(func=command_sync)
    audit_parser = subparsers.add_parser("audit", help="Audit table census and Markdown cell matrices")
    audit_parser.add_argument("markdown")
    audit_parser.add_argument("work_dir")
    audit_parser.add_argument("--allow-image-only", action="store_true")
    audit_parser.add_argument(
        "--representation",
        choices=("source", "markdown", "html"),
        default="source",
        help="Parse tables using the source representation or a derivative override",
    )
    audit_parser.add_argument(
        "--mode",
        choices=("exact", "translated"),
        default="exact",
        help="Require exact cells or allow translated prose with cell-level engineering-token equality",
    )
    audit_parser.add_argument("--output", help="Optional JSON report path")
    audit_parser.add_argument("--report-md", help="Optional Markdown report path")
    audit_parser.set_defaults(func=command_audit)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

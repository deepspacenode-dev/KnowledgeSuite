# Embedded Manual Content Profiles

## Contents

1. Profile rules
2. Document kinds
3. Content profiles
4. Cross-profile review
5. Cleaning safeguards

## 1. Profile rules

Use profiles to add domain-specific review checks to the universal fidelity standard. Do not use them to select, summarize, or discard source content.

- Assign every page at least one profile. Use multiple profiles for mixed pages.
- Keep `general` for covers, revision history, legal text, glossary, index, and genuinely cross-domain pages.
- Replace `general` with a more specific profile when the page contains subsystem-specific facts.
- Review profile assignment after inspecting page renders; title and filename alone are insufficient.
- Apply the same source identity, page coverage, image, table, OCR, and visual gates to every profile.
- Treat an unlisted embedded topic as `general`, record the topic in page notes, and add source-specific checks without weakening the common gates.

Allowed profile values:

```text
general
soc-mcu-cpu
sensor-media
memory-storage
interface-protocol
power-analog
connectivity
sdk-software
hardware-layout
security-boot
```

## 2. Document kinds

Record the source's actual kind because fidelity risks differ by publication type.

| Kind | Typical content | Primary risk |
| --- | --- | --- |
| `datasheet` | Features, pins, limits, timing, package | Dense tables, plots, suffix-specific values |
| `reference-manual` | Architecture, blocks, registers, sequences | Long memory maps, cross-references, repeated headers |
| `programming-guide` | Required configuration and call order | Procedural order, prerequisites, code fragments |
| `sdk-api` | Functions, types, enums, errors, examples | Signature punctuation, identifiers, return conditions |
| `hardware-design-guide` | Power, reset, clocks, routing, layout | Schematics, dimensions, conditional recommendations |
| `protocol-specification` | Frames, states, commands, timing | Bit order, state transitions, normative wording |
| `errata` | Affected revisions, symptoms, workarounds | Scope qualifiers, exceptions, revision applicability |
| `application-note` | Worked design or integration guidance | Equations, assumptions, example-versus-limit confusion |
| `schematic-drawing` | Nets, components, connectors, hierarchy | Geometry and tiny labels; visual evidence dominates |
| `mechanical-drawing` | Package, footprint, tolerances, keepouts | Dimension arrows, units, views, tolerance notation |
| `mixed` | Several kinds in one PDF | Per-section rules and changing page layouts |
| `other-technical` | Embedded document outside this list | Source-specific inventory and explicit review notes |

Do not merge an errata, datasheet, and reference manual into one page namespace. Preserve each source hash and revision independently even when packaging them together.

## 3. Content profiles

### `general`

Verify:

- exact title, product/family name, document number, revision, date, language, publication status, and confidentiality marking;
- revision history, applicability matrix, terminology, normative words, warnings, legal notices, contents, appendices, indexes, and cross-references;
- product suffixes, packages, grades, board revisions, silicon steppings, and software versions without collapsing variants;
- page labels printed by the document separately from physical PDF page numbers.

### `soc-mcu-cpu`

Verify:

- core architecture and revision, privilege or exception levels, endianness, cache/MMU/MPU/IOMMU attributes, and coherency rules;
- complete address and memory maps, base/end addresses, offsets, aliases, access widths, reset values, and reserved regions;
- interrupt/vector/event IDs, priorities, trigger types, routing, wake sources, DMA request/channel IDs, and affinity constraints;
- clock sources, muxes, dividers, frequencies, reset domains, power domains, dependencies, and sequencing;
- boot modes, straps, option bytes, OTP/eFuse fields, pinmux alternatives, debug ports, and low-power state transitions;
- register access types, bit ranges, enumerations, side effects, write-one semantics, and required ordering.

Common traps: address underscores dropped from `0x4000_0000`, `IRQ 0` confused with no IRQ, active-low bars lost, and reserved bits omitted from tables.

### `sensor-media`

Apply this profile to image sensors, radar, ToF, IMU, display, camera, video, audio, codec, and similar acquisition/output devices.

Verify:

- model, optical/acoustic/radar mode, resolution, sample rate, frame rate, pixel or sample format, bit depth, color order, and packing;
- lane count and mapping, virtual channel, clock mode, link rate, line/frame timing, blanking, synchronization, polarity, and trigger behavior;
- exposure, gain, integration time, frame length, region/crop, calibration, OTP contents, temperature compensation, and valid ranges;
- register initialization order, page/bank selection, delays, streaming transitions, group hold, reset, and standby sequences;
- timing charts, waveforms, calibration diagrams, coordinate systems, axes, legends, and test conditions.

Common traps: `RAW10` rewritten as a generic number, lane order reversed, units lost from exposure tables, and initialization tables reordered.

### `memory-storage`

Apply this profile to DDR/LPDDR, SRAM, NOR/NAND, eMMC, SD, UFS, EEPROM, and storage-controller documentation.

Verify:

- density, geometry, ranks, channels, dies, banks, rows, columns, bus width, address cycles, page/block/erase-unit sizes, and capacity units;
- supply and I/O voltage, speed bin, data rate, clocking, timing parameters, derating, training, calibration, and topology constraints;
- command/opcode, mode-register and EXT_CSD fields, state transitions, initialization order, busy timing, and error/status bits;
- ECC strength, OOB/spare layout, bad-block rules, wear/endurance, retention, cache/queue behavior, and atomicity requirements;
- boot partition, RPMB, user area, logical/physical block, alignment, partition, and firmware-version applicability.

Common traps: `MB` confused with `Mb`, decimal capacity substituted for binary capacity, timing minima/maximums swapped, and reserved command values removed.

### `interface-protocol`

Apply this profile to I2C/I3C, SPI/QSPI, UART, CAN/LIN, USB, PCIe, MIPI, GPIO, PWM, ADC/DAC, JTAG, proprietary buses, and protocol specifications.

Verify:

- standard/version, roles, topology, addressing, bus width, clock mode, polarity, phase, bit/byte order, lane mapping, and electrical level;
- frame, packet, descriptor, transaction, and register layouts including every bit range, length, checksum/CRC, opcode, and reserved value;
- state machines, handshakes, arbitration, retries, timeout, error recovery, reset, hot-plug, and low-power transitions;
- setup/hold, rise/fall, skew, duty cycle, latency, throughput, termination, impedance, and test conditions;
- normative `must/shall/may` behavior separately from examples and implementation suggestions.

Common traps: MSB/LSB order reversed, `CPOL` and `CPHA` swapped, timing labels detached from waveforms, and protocol examples mistaken for limits.

### `power-analog`

Apply this profile to PMICs, regulators, clocks, amplifiers, ADC/DAC analog sections, battery/charger devices, thermal control, and mixed-signal design.

Verify:

- absolute maximum, recommended operating, and characterized/tested conditions as separate categories;
- rail names, nominal/minimum/typical/maximum voltage and current, tolerance, ripple, noise, efficiency, dropout, and load/transient conditions;
- power-up/down order, ramp rate, delays, enable/reset thresholds, discharge, sequencing diagrams, and fault behavior;
- resistance, capacitance, inductance, compensation networks, stability regions, thermal resistance, package dissipation, and derating;
- plots with axes, scale type, units, legends, corners, load, temperature, and other test conditions.

Common traps: `µ` read as `u` or omitted, minus signs lost from temperature, typical values presented as guaranteed, and graph conditions detached from the graph.

### `connectivity`

Apply this profile to Ethernet switches/PHYs/MACs, Wi-Fi, Bluetooth, cellular, GNSS, RF transceivers, and related connectivity components.

Verify:

- interface/port/radio capabilities, rates, duplex or channel modes, clocking, addressing, frame/packet fields, queues, tables, and counters;
- PHY/MAC/RF register fields, link or association states, autonegotiation, calibration, channel/frequency, modulation, power, sensitivity, and coexistence constraints;
- filtering, forwarding, VLAN/QoS/security policies, CPU/host interfaces, interrupts, statistics, and initialization order when present;
- antenna, matching, RF layout, regulatory-domain, conducted/radiated test, and temperature/voltage conditions.

Apply this profile only to pages that actually contain connectivity-specific content.

### `sdk-software`

Verify:

- function prototypes character for character, including return type, qualifiers, pointer level, arrays, parameters, calling convention, and termination punctuation;
- structures, unions, enums, typedefs, macros, constants, ioctl/command IDs, error codes, defaults, ownership, and lifetime;
- prerequisites, initialization/deinitialization order, state constraints, thread/ISR context, locking, blocking behavior, timeout, DMA/cache rules, and callbacks;
- build options, configuration keys, source/header names, device-tree properties, shell/AT commands, paths, version compatibility, and sample output;
- sample code order and literals without silently “fixing” deprecated or suspicious source code.

Common traps: pointer stars stripped by Markdown, underscores changed, line wraps inserted into identifiers, sample code reordered, and parameter direction or units omitted.

### `hardware-layout`

Apply this profile to schematics, reference designs, board manuals, pinouts, BOMs, PCB/layout guides, package drawings, and mechanical specifications.

Verify:

- reference designators, values, tolerances, manufacturer part numbers, DNP/NC status, net labels, connectors, pin numbers, sheet hierarchy, and variant stuffing;
- power, ground, reset, clock, strap, differential-pair, shield, test-point, and domain-crossing connections;
- layer stack, impedance, length/skew, via, trace, spacing, clearance, creepage, return path, keepout, placement, and decoupling constraints;
- package/footprint dimensions, datum, view direction, pin-1 marker, pitch, tolerances, land pattern, mounting hole, and enclosure limits;
- every geometry-dependent sheet as a page image or verified high-resolution crop even when a text transcription is also supplied.

Common traps: tiny net labels missed, top/bottom views mirrored, decimal points lost from dimensions, and DNP components treated as populated.

### `security-boot`

Apply this profile to secure boot, trusted execution, lifecycle, access control, crypto-engine, key storage, firmware update, and debug-authentication manuals.

Verify:

- boot chain and verification order, image/header formats, hashes/signature algorithms, modes, key-slot and certificate identifiers, and version compatibility;
- lifecycle states, access permissions, privilege levels, debug states, irreversible transitions, rollback counters, and failure behavior;
- OTP/eFuse addresses and bit meanings, lock/write-once behavior, provisioning order, warnings, and recovery limitations;
- update slots, anti-rollback, atomicity, power-failure behavior, and authenticated error/status codes.

Never infer a security value or procedure from another device revision. Preserve irreversible-action warnings prominently.

## 4. Cross-profile review

For every page:

1. Confirm the page profile against the render.
2. Verify all names, numbers, signs, ranges, units, suffixes, and qualifiers.
3. Verify the order of procedures, initialization tables, transactions, and state transitions.
4. Verify every table header, cell, note, footnote, and continuation across pages.
5. Preserve geometry-dependent meaning through original images, lossless assets, or high-resolution crops.
6. Compare equations, plots, waveforms, schematics, pinouts, and mechanical drawings visually.
7. Mark profile-specific critical review `verified` only after completing the applicable checks above.

Do not claim a profile is covered merely because its keywords were extracted. The profile review is source-page review, not keyword detection.

## 5. Cleaning safeguards

Create a clean derivative only after the exact version passes.

- Remove repeated furniture only after confirming it does not encode revision, section, safety, variant, or continuation context.
- Preserve all source identities, applicability statements, errata, prerequisites, warnings, reserved entries, sequence steps, notes, and test conditions.
- Preserve diagrams and tables needed to interpret nearby text even when they appear repetitive.
- Keep exact and clean files separate. Log each clean-file removal or rewrite by source page and source-text hash.
- Never apply a cleanup rule globally until sampling every layout family in the PDF; manuals often change headers, columns, and table structure between sections.

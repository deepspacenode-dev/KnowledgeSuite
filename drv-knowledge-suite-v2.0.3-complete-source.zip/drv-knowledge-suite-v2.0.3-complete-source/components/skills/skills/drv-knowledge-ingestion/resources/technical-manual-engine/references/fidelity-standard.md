# Technical Manual Fidelity Standard

## Contents

1. Fidelity model
2. Source and revision identity
3. Page and reading order
4. Text and technical tokens
5. Tables
6. Images and vector content
7. Equations and notation
8. OCR
9. Cleaning
10. Review gates

## 1. Fidelity model

Evaluate fidelity by independent dimensions. Never collapse them into an unsupported single percentage.

| Dimension | Required evidence | Hard-pass condition |
| --- | --- | --- |
| Source identity | SHA-256, size, metadata, revision | Exact source matches manifest |
| Page coverage | PDF page count and ordered page markers | Every page represented once |
| Visual coverage | Per-page renders and visual archive | Every render exists and is referenced |
| Semantic text | Per-page source text and bidirectional token comparison | Recall and precision thresholds met on every applicable page |
| Critical values | Multiset comparison of critical tokens | Recall 1.0 or documented exception; precision 1.0 |
| Tables | Table inventory plus cell-by-cell review | Every table verified or rejected as false detection |
| Images | Image inventory plus disposition | Every occurrence verified or explained |
| Reading order | Positioned blocks plus page image | Every ambiguous page visually verified |
| OCR | OCR text plus page image | Every OCR page manually verified |

The page-image archive preserves appearance at the chosen render resolution. It is not a byte-identical reproduction of PDF drawing instructions. The semantic file preserves searchable structure; it is not a promise of identical pagination.

## 2. Source and revision identity

- Match the complete device, component, board, protocol, SDK, or document name. Preserve package, density, speed-bin, temperature-grade, silicon-stepping, board-revision, and software-version suffixes.
- Record document title, revision, date, language, and publication status exactly as printed.
- Treat a preliminary/final datasheet, reference manual, errata, application note, hardware guide, protocol specification, programming guide, schematic, and SDK API document as distinct sources.
- Do not merge documents without separate hashes and page namespaces.
- Preserve confidentiality, copyright, safety, and redistribution notices. Confirm the user is authorized to reproduce restricted material before packaging full original content.

## 3. Page and reading order

- Use `<!-- PDF_PAGE:NNNN -->` as the canonical page boundary.
- Preserve cover pages, blank pages, divider pages, appendices, indexes, and back covers.
- Determine reading order from layout, not just extraction order. Check multi-column pages, sidebars, floating callouts, rotated text, and footnotes.
- Keep captions adjacent to their figures and notes adjacent to their tables.
- For pages whose semantic order cannot be established confidently, embed the page or relevant crop and flag it until reviewed.

## 4. Text and technical tokens

Preserve the following exactly, including case and punctuation:

- part numbers, package/speed/grade suffixes, board and silicon revisions, document IDs, software versions, API and function signatures;
- register, memory-map, bit-field, interrupt, vector, DMA, event, clock, reset, power-domain, command, opcode, mode, and status identifiers;
- offsets, addresses, hexadecimal/binary/decimal literals, masks, reset values, ranges, enumerations, array indexes, and address widths;
- pin, connector, rail, net, lane, channel, reference-designator, and signal names, including polarity, active-low notation, bus membership, and differential pairing;
- protocol frame/packet fields, checksums, state names, error codes, option bytes, OTP/eFuse fields, device-tree properties, shell/AT commands, macros, types, and enum values;
- dimensions, tolerances, angles, temperatures, voltages, currents, power, resistance, capacitance, inductance, frequency, data/sample/frame rate, timing limits, thermal values, and units;
- initialization, power, transaction, calibration, provisioning, and state-transition order;
- modal words such as must, shall, should, may, reserved, undefined, and prohibited;
- warning, caution, note, exception, prerequisite, and errata text.

Do not normalize `0x0A` to `0x0a`, `0x4000_0000` to `0x40000000`, `10 uA` to `10 µA`, `8 GiB` to `8 GB`, `nRESET` to `RESET`, or `[31:16]` to prose. Do not silently join hyphenated line endings when the result could be an identifier. Resolve each case against the page image.

Automated token recall detects omissions; token precision detects unsupported additions. Both compare against an extraction stream, which may itself be wrong. Replace visibly incorrect extraction evidence only through a complete, visually verified page override, and always verify high-risk tokens visually.

## 5. Tables

Choose the representation that loses the least information:

1. Use pipe Markdown only for a simple rectangular grid with no spans.
2. Use HTML `<table>` with `rowspan`, `colspan`, `<br>`, `<sub>`, and `<sup>` for complex tables.
3. Use an image or crop when geometry is semantically essential or transcription cannot be verified.
4. Optionally add an accessible transcription below an image, but label it as a transcription and verify it independently.

For every table verify:

- title, number, page, column count, row count, headers, units, notes, and footnotes;
- blank versus zero versus dash versus reserved values;
- bit ranges, reset values, access type, enumerations, minimum/typical/maximum columns;
- address/memory maps, pinmux matrices, command/opcode tables, interrupt/DMA IDs, timing tables, mode/state tables, API parameter tables, BOMs, and mechanical dimensions according to their content profile;
- merged-cell scope and repeated headers across page breaks.

Never infer missing cells or values from neighboring rows.

## 6. Images and vector content

- Extract embedded raster streams without recompression when the PDF encoding is supported.
- Preserve each image occurrence's page, bounding box, xref/identifier, encoding, dimensions, and SHA-256.
- A PDF image mask, transparency group, tiled image, or layered composite may not render correctly as one extracted stream. Retain the raw extraction for evidence and use a rendered crop for display.
- PDF vector diagrams have no original raster file. Render a tight crop at high DPI or preserve the entire page image; log the rasterization.
- Do not replace original diagrams with AI-generated versions.
- Do not OCR text inside a block diagram, schematic, state machine, timing chart, waveform, plot, pinout, package/footprint drawing, or PCB layout and then discard the original visual evidence.
- Treat logos, page backgrounds, and repeated icons as inventory items until reviewed; mark them decorative or duplicate with a reason rather than silently dropping them.

## 7. Equations and notation

- Preserve a native equation as text only when every symbol, operator, index, exponent, fraction, and delimiter is verified.
- Use KaTeX/LaTeX only when the target renderer supports it and the rendered result has been compared with the source.
- Otherwise embed a high-resolution crop and retain nearby definitions as source-faithful text.
- Watch for `I/l/1`, `O/0`, minus/hyphen, multiplication signs, Greek letters, subscripts, superscripts, overbars, and active-low signal bars.

## 8. OCR

- Detect scanned pages from missing or implausibly sparse embedded text, not from document-level assumptions.
- Record OCR engine, version, language data, DPI, and page list.
- Never mix OCR and embedded text silently. Mark the selected evidence stream per page.
- Compare OCR to the page image line by line for memory/register maps, pin and connector tables, command/state tables, formulas, numeric specifications, API/code, BOMs, schematics, and mechanical dimensions.
- When OCR or embedded extraction is visibly wrong, preserve its raw file and write the corrected, visually verified page transcription to `qa/verified_text/page_NNNN.txt`. Record the correction in the page inventory; never rewrite raw evidence to make an audit pass.
- Treat low confidence, missing language data, unusual fonts, rotated text, halftone backgrounds, or small type as unresolved risk.
- OCR success is not proof of correctness.

## 9. Cleaning

Create a clean/RAG variant only after exact reconstruction passes review.

Create a Chinese BookStack edition as a separate semantic derivative, never by
editing the exact artifact. Its explanatory prose may be translated and
reorganized only through full-source AI reading and review; deterministic tools
remain responsible for evidence, hashes, critical-token checks, table geometry,
image-path checks, and reverse gates. See
[bookstack-rewrite.md](bookstack-rewrite.md).

Safe candidates, after verification, include repeated running headers, repeated page numbers already represented by page anchors, and purely decorative separators. Unsafe default removals include front matter, legal text, safety notices, revision history, reserved rows, table notes, index entries, appendices, and repeated headers containing section or revision identity.

Record each cleaning action with page, original fingerprint, action, reason, and reviewer. Keep the exact version and source evidence unchanged.

Do not classify an image as a logo from its ordinal position or filename alone.
Use the reviewed image inventory and source render. Hidden `PDF_PAGE` comments
remain provenance and are not removable page furniture.

## 10. Review gates

A page is not verified until both text and visual status are marked `verified`. A table or image occurrence is not resolved until its inventory row is marked with an allowed disposition and any non-embedded disposition has a reason.

Assign and verify the page's embedded content profile using [embedded-manual-profiles.md](embedded-manual-profiles.md). Profile checks are additive for mixed pages. A profile assignment does not replace direct source-page inspection.

Inspect all contact sheets. Inspect at full resolution every page with OCR, tables, equations, multiple columns, rotated text, drawings, low token recall, critical-token loss, or extraction warnings. Re-run the audit after edits.

If source content is unreadable, contradictory, or malformed, preserve it visually and report the limitation. Do not invent a repair.

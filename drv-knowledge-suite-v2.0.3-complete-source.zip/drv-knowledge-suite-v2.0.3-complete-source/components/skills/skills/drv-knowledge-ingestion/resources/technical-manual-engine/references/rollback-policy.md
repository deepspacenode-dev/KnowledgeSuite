# Transaction and Rollback Policy

## Journal

Write a run manifest before the first remote mutation and update it after every
created object. Record:

- run ID, stage, timestamps, plan hash, source hash, BookStack base URL;
- resolved shelf, book, chapter, page, and image IDs;
- local and remote Markdown hashes;
- operation status, verification result, errors, and rollback result.

Never record token IDs, token secrets, or Authorization headers.

## Automatic transaction rollback

If a test or formal upload fails before verification:

1. delete images created by the current run in reverse order;
2. delete pages created by the current run in reverse order;
3. delete the chapter created by the current run;
4. leave pre-existing books and shelves untouched;
5. write every delete response or failure to the run manifest.

Do not delete an object that is absent from the current run manifest.

## Manual rollback

Require both the run-manifest path and exact run ID. Reject a plan file, a
different run, an already rolled-back run, or an unverified broad target.

BookStack delete operations normally move core content to the recycle bin.
Report that behavior without promising recovery when instance policy differs.

## Incomplete rollback

Mark `ROLLBACK_PARTIAL` when any deletion fails. Keep the manifest and list
remaining IDs. Do not retry against guessed IDs or delete a parent book to
compensate.

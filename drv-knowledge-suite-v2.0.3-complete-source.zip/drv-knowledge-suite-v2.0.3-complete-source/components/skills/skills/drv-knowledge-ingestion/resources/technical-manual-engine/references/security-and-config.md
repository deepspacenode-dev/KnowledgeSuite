# Security and Configuration

## Required environment variables

```text
BOOKSTACK_BASE_URL
BOOKSTACK_TOKEN_ID
BOOKSTACK_TOKEN_SECRET
```

Optional:

```text
BOOKSTACK_TIMEOUT_SECONDS=30
BOOKSTACK_CA_BUNDLE=/path/to/internal-ca.pem
```

Do not store these values in `SKILL.md`, scripts, plans, run manifests, shell
history examples, or reports. Never print the Authorization header.

The API token account needs `Access System API` plus only the content
permissions required for the selected test and formal routes.

## Transport

Prefer HTTPS. For an internal HTTP-only BookStack instance, report that the
token is transported without TLS and proceed only under the user's accepted
network policy. Never silently disable TLS certificate validation.

## Credential migration

If a prior Skill or conversation contains a plaintext token, remove it from the
new Skill and recommend revoking and replacing it. Do not repeat the exposed
value.

## Live-write safety

- `doctor`, `gate`, `plan`, and `verify` are read-only remotely.
- `upload-test` writes only to the resolved test book.
- `publish` requires a verified test run, exact plan hash, and explicit
  reviewed confirmation.
- `rollback` deletes only IDs journaled by one run.

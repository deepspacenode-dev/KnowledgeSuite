#!/usr/bin/env python3
"""Gate, plan, test, publish, verify, and roll back technical-manual BookStack ingestion."""

from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import json
import mimetypes
import os
import re
import shutil
import ssl
import sys
import uuid
from pathlib import Path
from typing import Any
from urllib import error, parse, request


VERSION = "1.0.8"
PAGE_MARKER_RE = re.compile(r"<!--\s*PDF_PAGE:(\d{4})\s*-->")
HEADING_RE = re.compile(r"^(#{1,6})[ \t]+(.+?)\s*$")
FENCE_RE = re.compile(r"^[ \t]{0,3}(`{3,}|~{3,})")
MD_IMAGE_RE = re.compile(
    r"!\[[^\]\n]*\]\(\s*(?P<dest><[^>\n]+>|[^)\s]+)"
    r"(?P<suffix>\s+(?:\"[^\"]*\"|'[^']*'|\([^)]*\)))?\s*\)"
)
HTML_IMAGE_RE = re.compile(r"(<img\b[^>]*?\bsrc=[\"'])(?P<dest>[^\"']+)([\"'][^>]*>)", re.I)
REMOTE_SCHEMES = {"http", "https"}
DISALLOWED_SCHEMES = {"data", "file", "javascript"}
BOOKSTACK_IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".avif"}


class PipelineError(RuntimeError):
    pass


class APIError(PipelineError):
    def __init__(self, method: str, path: str, status: int, body: str) -> None:
        super().__init__(f"{method} {path} failed with HTTP {status}: {body[:500]}")
        self.method = method
        self.path = path
        self.status = status
        self.body = body


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def safe_timestamp() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def normalize_markdown(value: str) -> str:
    return value.replace("\r\n", "\n").replace("\r", "\n").rstrip() + "\n"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_text(value: str) -> str:
    return sha256_bytes(normalize_markdown(value).encode("utf-8"))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json_atomic(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def canonical_plan_hash(plan_value: dict[str, Any]) -> str:
    value = copy.deepcopy(plan_value)
    value.pop("plan_sha256", None)
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256_bytes(payload)


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PipelineError(f"Cannot read JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise PipelineError(f"Expected a JSON object: {path}")
    return value


def resolve_within(base: Path, relative: str) -> Path:
    candidate = (base / relative).resolve()
    try:
        candidate.relative_to(base.resolve())
    except ValueError as exc:
        raise PipelineError(f"path escapes the frozen bundle: {relative}") from exc
    return candidate


def strip_destination(value: str) -> str:
    value = value.strip()
    if value.startswith("<") and value.endswith(">"):
        value = value[1:-1]
    return parse.unquote(value)


def image_references(markdown: str) -> list[str]:
    values = [strip_destination(match.group("dest")) for match in MD_IMAGE_RE.finditer(markdown)]
    values.extend(strip_destination(match.group("dest")) for match in HTML_IMAGE_RE.finditer(markdown))
    return values


def reference_kind(value: str) -> str:
    scheme = parse.urlparse(value).scheme.lower()
    if scheme in REMOTE_SCHEMES:
        return "remote"
    if scheme in DISALLOWED_SCHEMES:
        return "disallowed"
    if scheme:
        return "disallowed"
    return "local"


def rewrite_image_references(markdown: str, replacements: dict[str, str]) -> str:
    def replace_markdown(match: re.Match[str]) -> str:
        original = match.group(0)
        raw = strip_destination(match.group("dest"))
        if raw not in replacements:
            return original
        start = match.start("dest") - match.start()
        end = match.end("dest") - match.start()
        replacement = replacements[raw]
        if " " in replacement:
            replacement = f"<{replacement}>"
        return original[:start] + replacement + original[end:]

    def replace_html(match: re.Match[str]) -> str:
        raw = strip_destination(match.group("dest"))
        return match.group(1) + replacements.get(raw, match.group("dest")) + match.group(3)

    return HTML_IMAGE_RE.sub(replace_html, MD_IMAGE_RE.sub(replace_markdown, markdown))


def split_pipe_row(line: str) -> list[str]:
    value = line.strip()
    if value.startswith("|"):
        value = value[1:]
    if value.endswith("|") and not value.endswith("\\|"):
        value = value[:-1]
    cells: list[str] = []
    current: list[str] = []
    escaped = False
    for char in value:
        if escaped:
            current.append(char)
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == "|":
            cells.append("".join(current).strip())
            current = []
        else:
            current.append(char)
    cells.append("".join(current).strip())
    return cells


def validate_pipe_tables(lines: list[str]) -> list[str]:
    errors: list[str] = []
    index = 0
    while index < len(lines) - 1:
        if lines[index].lstrip().startswith("|") and re.match(
            r"^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$",
            lines[index + 1],
        ):
            width = len(split_pipe_row(lines[index]))
            cursor = index + 1
            while cursor < len(lines) and lines[cursor].lstrip().startswith("|"):
                current = len(split_pipe_row(lines[cursor]))
                if current != width:
                    errors.append(
                        f"pipe table near line {index + 1} has inconsistent columns "
                        f"({width} then {current} at line {cursor + 1})"
                    )
                cursor += 1
            index = cursor
        else:
            index += 1
    return errors


def parse_headings_and_fences(markdown: str) -> tuple[list[tuple[int, int, str]], list[str], list[str]]:
    headings: list[tuple[int, int, str]] = []
    errors: list[str] = []
    lines = markdown.splitlines(keepends=True)
    fence_char = ""
    fence_length = 0
    offset = 0
    for line_number, line in enumerate(lines, start=1):
        fence = FENCE_RE.match(line)
        if fence:
            token = fence.group(1)
            if not fence_char:
                fence_char, fence_length = token[0], len(token)
            elif token[0] == fence_char and len(token) >= fence_length:
                fence_char, fence_length = "", 0
            offset += len(line)
            continue
        if not fence_char:
            match = HEADING_RE.match(line.rstrip("\n\r"))
            if match:
                headings.append((offset, len(match.group(1)), match.group(2).strip()))
        offset += len(line)
    if fence_char:
        errors.append("fenced code block is not closed")
    previous = 0
    for _, level, title in headings:
        if previous and level > previous + 1:
            errors.append(f"heading level jumps from H{previous} to H{level}: {title}")
        previous = level
    return headings, errors, [line.rstrip("\n\r") for line in lines]


def run_gate(
    markdown_path: Path,
    conversion_work: Path | None,
    allow_remote_images: bool,
    rewrite_audit_path: Path | None = None,
) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        raw = markdown_path.read_bytes()
    except OSError as exc:
        return {"result": "FAIL", "errors": [str(exc)], "warnings": [], "metrics": {}}
    if raw.startswith(b"\xef\xbb\xbf"):
        errors.append("UTF-8 BOM is not allowed")
    try:
        markdown = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        return {"result": "FAIL", "errors": [f"not valid UTF-8: {exc}"], "warnings": [], "metrics": {}}
    headings, structural_errors, lines = parse_headings_and_fences(markdown)
    errors.extend(structural_errors)
    h1_count = sum(1 for _, level, _ in headings if level == 1)
    if h1_count != 1:
        errors.append(f"exactly one H1 is required; found {h1_count}")
    markers = [int(value) for value in PAGE_MARKER_RE.findall(markdown)]
    refs = image_references(markdown)
    local_refs: list[str] = []
    remote_refs: list[str] = []
    for ref in refs:
        kind = reference_kind(ref)
        if kind == "disallowed":
            errors.append(f"disallowed image URI: {ref}")
        elif kind == "remote":
            remote_refs.append(ref)
            if not allow_remote_images:
                errors.append(f"remote image is not durable for ingestion: {ref}")
        else:
            local_refs.append(ref)
            target = (markdown_path.parent / ref).resolve()
            if not target.is_file():
                errors.append(f"broken local image reference: {ref}")
            elif target.suffix.lower() not in BOOKSTACK_IMAGE_SUFFIXES:
                errors.append(
                    f"BookStack image-gallery does not accept {target.suffix or 'extensionless'} assets: {ref}"
                )
            elif target.stat().st_size > 50_000 * 1024:
                errors.append(f"image exceeds BookStack's 50000 KiB API limit: {ref}")
    errors.extend(validate_pipe_tables(lines))
    if len(re.findall(r"<table\b", markdown, re.I)) != len(re.findall(r"</table\s*>", markdown, re.I)):
        errors.append("HTML table start/end tag count differs")

    conversion_metrics: dict[str, Any] = {}
    exact_markdown_hash = ""
    if conversion_work:
        manifest_path = conversion_work / "manifest.json"
        audit_path = conversion_work / "qa/audit_report.json"
        table_audit_path = conversion_work / "qa/table_audit.json"
        for required in (manifest_path, audit_path, table_audit_path):
            if not required.is_file():
                errors.append(f"required conversion gate is missing: {required}")
        if manifest_path.is_file():
            manifest = load_json(manifest_path)
            expected_pages = int(manifest.get("source", {}).get("page_count") or 0)
            if markers != list(range(1, expected_pages + 1)):
                errors.append("PDF page markers do not match the conversion manifest")
            conversion_metrics["source_sha256"] = manifest.get("source", {}).get("sha256")
            conversion_metrics["source_pages"] = expected_pages
        if audit_path.is_file():
            audit = load_json(audit_path)
            if audit.get("result") != "PASS":
                errors.append("PDF-to-Markdown fidelity audit is not PASS")
            exact_markdown_hash = str(audit.get("markdown_sha256") or "")
            current_markdown_hash = sha256_file(markdown_path)
            if not exact_markdown_hash:
                errors.append("fidelity audit does not bind the exact Markdown SHA-256")
            elif current_markdown_hash == exact_markdown_hash:
                conversion_metrics["content_mode"] = "exact"
            else:
                conversion_metrics["content_mode"] = "bookstack-rewrite"
                if rewrite_audit_path is None or not rewrite_audit_path.is_file():
                    errors.append("derived BookStack Markdown requires a passing rewrite audit")
                else:
                    rewrite_audit = load_json(rewrite_audit_path)
                    if rewrite_audit.get("result") != "PASS":
                        errors.append("BookStack rewrite audit is not PASS")
                    if rewrite_audit.get("exact_markdown_sha256") != exact_markdown_hash:
                        errors.append("BookStack rewrite audit is bound to a different exact Markdown")
                    if rewrite_audit.get("bookstack_markdown_sha256") != current_markdown_hash:
                        errors.append("BookStack rewrite audit is bound to different derived Markdown")
                    if manifest_path.is_file() and rewrite_audit.get("source_pdf_sha256") != manifest.get("source", {}).get("sha256"):
                        errors.append("BookStack rewrite audit is bound to a different source PDF")
                    conversion_metrics["rewrite_audit_sha256"] = sha256_file(rewrite_audit_path)
            conversion_metrics["fidelity_audit_sha256"] = sha256_file(audit_path)
        if table_audit_path.is_file():
            table_audit = load_json(table_audit_path)
            if table_audit.get("result") != "PASS":
                errors.append("table fidelity audit is not PASS")
            if exact_markdown_hash and table_audit.get("markdown_sha256") != exact_markdown_hash:
                errors.append("table fidelity audit is bound to a different exact Markdown")
            conversion_metrics["table_audit_sha256"] = sha256_file(table_audit_path)
            conversion_metrics["real_tables"] = table_audit.get("real_tables")
    elif markers:
        warnings.append("PDF page markers exist but no conversion workspace was supplied")

    return {
        "schema_version": 1,
        "result": "PASS" if not errors else "FAIL",
        "markdown": str(markdown_path),
        "markdown_sha256": sha256_bytes(raw),
        "normalized_markdown_sha256": sha256_text(markdown),
        "errors": list(dict.fromkeys(errors)),
        "warnings": list(dict.fromkeys(warnings)),
        "metrics": {
            "bytes": len(raw),
            "headings": len(headings),
            "h1_count": h1_count,
            "page_markers": len(markers),
            "local_image_references": len(local_refs),
            "remote_image_references": len(remote_refs),
            **conversion_metrics,
        },
    }


def clean_heading_title(value: str) -> str:
    value = re.sub(r"<!--.*?-->", "", value)
    value = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", value)
    value = re.sub(r"<[^>]+>", "", value)
    value = re.sub(r"[`*_~]", "", value)
    return re.sub(r"\s+", " ", value).strip().strip("#")


def unique_page_name(value: str, used: set[str]) -> str:
    value = value or "Untitled"
    if len(value) > 255:
        value = value[:238].rstrip() + "-" + sha256_text(value)[:12]
    candidate = value
    index = 2
    while candidate in used:
        suffix = f" ({index})"
        candidate = value[: 255 - len(suffix)].rstrip() + suffix
        index += 1
    used.add(candidate)
    return candidate


def split_markdown(markdown: str, level: int, preamble_title: str) -> list[tuple[str, str]]:
    headings, errors, _ = parse_headings_and_fences(markdown)
    if errors:
        raise PipelineError("; ".join(errors))
    boundaries: list[tuple[int, str]] = []
    for offset, heading_level, title in headings:
        if heading_level != level or re.fullmatch(r"PDF\s+page\s+\d+", title.strip(), re.I):
            continue
        prefix = markdown[:offset]
        adjacent_marker = re.search(
            r"<!--\s*PDF_PAGE:\d{4}\s*-->\s*"
            r"(?:<a\s+id=[\"']pdf-page-\d{4}[\"']\s*></a>\s*)?$",
            prefix,
            re.I,
        )
        boundary = adjacent_marker.start() if adjacent_marker else offset
        boundaries.append((boundary, clean_heading_title(title)))
    if not boundaries:
        h1 = next((clean_heading_title(title) for _, heading_level, title in headings if heading_level == 1), "Manual")
        return [(h1, normalize_markdown(markdown))]
    segments: list[tuple[str, str]] = []
    first_offset = boundaries[0][0]
    if markdown[:first_offset].strip():
        segments.append((preamble_title, normalize_markdown(markdown[:first_offset])))
    for index, (offset, title) in enumerate(boundaries):
        end = boundaries[index + 1][0] if index + 1 < len(boundaries) else len(markdown)
        content = markdown[offset:end]
        if content.strip():
            segments.append((title, normalize_markdown(content)))
    return segments


def require_new_directory(path: Path) -> None:
    if path.exists():
        if not path.is_dir():
            raise PipelineError(f"bundle path exists and is not a directory: {path}")
        if any(path.iterdir()):
            raise PipelineError(f"refusing to overwrite non-empty bundle directory: {path}")
    path.mkdir(parents=True, exist_ok=True)


def copy_bundle_assets(markdown: str, source_dir: Path, bundle: Path) -> tuple[str, list[dict[str, Any]]]:
    replacements: dict[str, str] = {}
    assets_by_hash: dict[str, dict[str, Any]] = {}
    for ref in image_references(markdown):
        if reference_kind(ref) != "local":
            continue
        source = (source_dir / ref).resolve()
        digest = sha256_file(source)
        if digest in assets_by_hash:
            replacements[ref] = "../" + assets_by_hash[digest]["file"]
            continue
        suffix = source.suffix.lower()
        if not re.fullmatch(r"\.[a-z0-9]{1,10}", suffix):
            suffix = ".bin"
        name = f"{digest[:20]}{suffix}"
        destination = bundle / "assets" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            shutil.copy2(source, destination)
        replacements[ref] = f"../assets/{name}"
        assets_by_hash.setdefault(
            digest,
            {
                "file": f"assets/{name}",
                "sha256": digest,
                "size_bytes": destination.stat().st_size,
                "source_name": source.name,
            },
        )
    return rewrite_image_references(markdown, replacements), list(assets_by_hash.values())


def verify_plan_integrity(plan_path: Path) -> tuple[dict[str, Any], Path]:
    plan_value = load_json(plan_path)
    expected = plan_value.get("plan_sha256")
    actual = canonical_plan_hash(plan_value)
    if not expected or expected != actual:
        raise PipelineError("plan SHA-256 is missing or does not match plan content")
    bundle = plan_path.parent.resolve()
    for page in plan_value.get("pages", []):
        path = resolve_within(bundle, page["file"])
        if not path.is_file() or sha256_file(path) != page["file_sha256"]:
            raise PipelineError(f"page file changed after plan creation: {page.get('file')}")
        markdown = path.read_text(encoding="utf-8")
        if sha256_text(markdown) != page["content_sha256"]:
            raise PipelineError(f"normalized page content changed: {page.get('file')}")
    for asset in plan_value.get("assets", []):
        path = resolve_within(bundle, asset["file"])
        if not path.is_file() or sha256_file(path) != asset["sha256"]:
            raise PipelineError(f"asset changed after plan creation: {asset.get('file')}")
    return plan_value, bundle


class BookStackClient:
    def __init__(self, base_url: str, token_id: str, token_secret: str, timeout: float, ca_bundle: str | None):
        parsed = parse.urlparse(base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise PipelineError("BOOKSTACK_BASE_URL must be an absolute http(s) URL")
        self.base_url = base_url.rstrip("/")
        self.api_url = self.base_url + "/api"
        self.authorization = f"Token {token_id}:{token_secret}"
        self.timeout = timeout
        self.context = ssl.create_default_context(cafile=ca_bundle) if parsed.scheme == "https" else None

    @classmethod
    def from_env(cls) -> "BookStackClient":
        names = ("BOOKSTACK_BASE_URL", "BOOKSTACK_TOKEN_ID", "BOOKSTACK_TOKEN_SECRET")
        missing = [name for name in names if not os.environ.get(name)]
        if missing:
            raise PipelineError(f"missing required environment variables: {', '.join(missing)}")
        try:
            timeout = float(os.environ.get("BOOKSTACK_TIMEOUT_SECONDS", "30"))
        except ValueError as exc:
            raise PipelineError("BOOKSTACK_TIMEOUT_SECONDS must be numeric") from exc
        if timeout <= 0 or timeout > 300:
            raise PipelineError("BOOKSTACK_TIMEOUT_SECONDS must be in (0, 300]")
        return cls(
            os.environ["BOOKSTACK_BASE_URL"],
            os.environ["BOOKSTACK_TOKEN_ID"],
            os.environ["BOOKSTACK_TOKEN_SECRET"],
            timeout,
            os.environ.get("BOOKSTACK_CA_BUNDLE"),
        )

    def _open(self, req: request.Request, method: str, path: str) -> bytes:
        try:
            with request.urlopen(req, timeout=self.timeout, context=self.context) as response:
                return response.read()
        except error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise APIError(method, path, exc.code, body) from exc
        except error.URLError as exc:
            raise PipelineError(f"{method} {path} failed: {exc.reason}") from exc

    def request_json(self, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {
            "Authorization": self.authorization,
            "Accept": "application/json",
            "User-Agent": f"drv-knowledge-ingestion-manual/{VERSION}",
        }
        if body is not None:
            headers["Content-Type"] = "application/json; charset=utf-8"
        req = request.Request(self.api_url + path, data=body, headers=headers, method=method)
        raw = self._open(req, method, path)
        if not raw:
            return {}
        try:
            value = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise PipelineError(f"{method} {path} returned non-JSON data") from exc
        if not isinstance(value, dict):
            raise PipelineError(f"{method} {path} returned a non-object JSON value")
        return value

    def upload_image(self, image: Path, uploaded_to: int) -> dict[str, Any]:
        boundary = "----manual-" + uuid.uuid4().hex
        parts: list[bytes] = []

        def field(name: str, value: str) -> None:
            parts.extend(
                [
                    f"--{boundary}\r\n".encode(),
                    f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode(),
                    value.encode("utf-8"),
                    b"\r\n",
                ]
            )

        field("type", "gallery")
        field("uploaded_to", str(uploaded_to))
        field("name", image.name[:180])
        mime = mimetypes.guess_type(image.name)[0] or "application/octet-stream"
        parts.extend(
            [
                f"--{boundary}\r\n".encode(),
                f'Content-Disposition: form-data; name="image"; filename="{image.name}"\r\n'.encode(),
                f"Content-Type: {mime}\r\n\r\n".encode(),
                image.read_bytes(),
                b"\r\n",
                f"--{boundary}--\r\n".encode(),
            ]
        )
        body = b"".join(parts)
        path = "/image-gallery"
        headers = {
            "Authorization": self.authorization,
            "Accept": "application/json",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Content-Length": str(len(body)),
            "User-Agent": f"drv-knowledge-ingestion-manual/{VERSION}",
        }
        req = request.Request(self.api_url + path, data=body, headers=headers, method="POST")
        raw = self._open(req, "POST", path)
        value = json.loads(raw.decode("utf-8"))
        if not isinstance(value, dict):
            raise PipelineError("image upload returned a non-object JSON value")
        return value

    def list_all(self, resource: str) -> list[dict[str, Any]]:
        output: list[dict[str, Any]] = []
        offset = 0
        while True:
            value = self.request_json("GET", f"/{resource}?count=100&offset={offset}")
            batch = value.get("data") or []
            if not isinstance(batch, list):
                raise PipelineError(f"/{resource} list response has invalid data")
            output.extend(item for item in batch if isinstance(item, dict))
            total = int(value.get("total") or len(output))
            if not batch or len(output) >= total:
                return output
            offset += len(batch)

    def exact(self, resource: str, name: str) -> dict[str, Any]:
        matches = [item for item in self.list_all(resource) if item.get("name") == name]
        if len(matches) != 1:
            raise PipelineError(f"expected one exact {resource} match for {name!r}; found {len(matches)}")
        return matches[0]


def route_names(plan: dict[str, Any], stage: str) -> dict[str, str]:
    key = "test" if stage == "test" else "formal"
    value = plan["routing"][key]
    return {"shelf_name": value["shelf_name"], "book_name": value["book_name"]}


def actual_chapter_name(plan: dict[str, Any], stage: str) -> str:
    base = plan["chapter"]["name"]
    return f"【测试】{base} [{plan['plan_sha256'][:8]}]" if stage == "test" else base


def resolve_route(client: BookStackClient, plan: dict[str, Any], stage: str) -> dict[str, Any]:
    names = route_names(plan, stage)
    shelf = client.exact("shelves", names["shelf_name"])
    book = client.exact("books", names["book_name"])
    shelf_detail = client.request_json("GET", f"/shelves/{int(shelf['id'])}")
    shelf_books = {int(item["id"]) for item in shelf_detail.get("books", []) if isinstance(item, dict)}
    if int(book["id"]) not in shelf_books:
        raise PipelineError(f"book {book['name']!r} is not assigned to shelf {shelf['name']!r}")
    chapter_name = actual_chapter_name(plan, stage)
    duplicates = [
        chapter
        for chapter in client.list_all("chapters")
        if int(chapter.get("book_id") or 0) == int(book["id"]) and chapter.get("name") == chapter_name
    ]
    return {
        "shelf": {"id": int(shelf["id"]), "name": shelf["name"]},
        "book": {"id": int(book["id"]), "name": book["name"]},
        "chapter_name": chapter_name,
        "duplicate_chapter_ids": [int(item["id"]) for item in duplicates],
    }


def page_ui_url(client: BookStackClient, page: dict[str, Any]) -> str:
    if page.get("url"):
        return str(page["url"])
    book_slug = page.get("book_slug")
    slug = page.get("slug")
    if book_slug and slug:
        return f"{client.base_url}/books/{book_slug}/page/{slug}"
    return f"{client.base_url}/api/pages/{page.get('id')}"


def ensure_no_duplicate(route: dict[str, Any]) -> None:
    if route["duplicate_chapter_ids"]:
        raise PipelineError(
            f"duplicate chapter already exists in selected book: {route['duplicate_chapter_ids']}"
        )


def new_run_path(bundle: Path, stage: str, requested: str | None) -> Path:
    if requested:
        path = Path(requested).expanduser().resolve()
    else:
        path = bundle / "runs" / f"{stage}-{safe_timestamp()}-{uuid.uuid4().hex[:8]}.json"
    if path.exists():
        raise PipelineError(f"refusing to overwrite run manifest: {path}")
    return path


def verify_remote_run(client: BookStackClient, run: dict[str, Any]) -> tuple[bool, list[str]]:
    failures: list[str] = []
    chapter = run.get("objects", {}).get("chapter")
    if not chapter:
        return False, ["run has no chapter"]
    try:
        remote_chapter = client.request_json("GET", f"/chapters/{int(chapter['id'])}")
        if remote_chapter.get("name") != chapter.get("name"):
            failures.append("chapter name differs")
        if int(remote_chapter.get("book_id") or 0) != int(chapter.get("book_id") or 0):
            failures.append("chapter parent book differs")
    except PipelineError as exc:
        failures.append(str(exc))
    for page in run.get("objects", {}).get("pages", []):
        try:
            remote = client.request_json("GET", f"/pages/{int(page['id'])}")
            remote_markdown = normalize_markdown(str(remote.get("markdown") or ""))
            remote_hash = sha256_text(remote_markdown)
            if remote_hash != page.get("uploaded_content_sha256"):
                failures.append(f"page {page['id']} Markdown hash differs")
            if remote.get("name") != page.get("name"):
                failures.append(f"page {page['id']} name differs")
            if int(remote.get("chapter_id") or 0) != int(chapter["id"]):
                failures.append(f"page {page['id']} chapter differs")
            if int(remote.get("priority") or 0) != int(page.get("priority") or 0):
                failures.append(f"page {page['id']} priority differs")
        except PipelineError as exc:
            failures.append(str(exc))
    for image in run.get("objects", {}).get("images", []):
        try:
            remote = client.request_json("GET", f"/image-gallery/{int(image['id'])}")
            if int(remote.get("uploaded_to") or 0) != int(image.get("uploaded_to") or 0):
                failures.append(f"image {image['id']} parent page differs")
        except PipelineError as exc:
            failures.append(str(exc))
    return not failures, failures


def identity_checked_delete(
    client: BookStackClient,
    resource: str,
    item: dict[str, Any],
    expected: dict[str, Any],
) -> tuple[bool, str]:
    item_id = int(item["id"])
    try:
        remote = client.request_json("GET", f"/{resource}/{item_id}")
    except APIError as exc:
        if exc.status == 404:
            return True, f"{resource}/{item_id} already absent"
        return False, str(exc)
    except PipelineError as exc:
        return False, str(exc)
    for key, value in expected.items():
        remote_value = remote.get(key)
        if key.endswith("_id"):
            remote_value = int(remote_value or 0)
            value = int(value or 0)
        if remote_value != value:
            return False, f"{resource}/{item_id} identity mismatch for {key}"
    try:
        client.request_json("DELETE", f"/{resource}/{item_id}")
        return True, f"deleted {resource}/{item_id}"
    except PipelineError as exc:
        return False, str(exc)


def rollback_objects(client: BookStackClient, run: dict[str, Any], run_path: Path, automatic: bool) -> bool:
    operations: list[dict[str, Any]] = []
    success = True
    for image in reversed(run.get("objects", {}).get("images", [])):
        ok, message = identity_checked_delete(
            client,
            "image-gallery",
            image,
            {"uploaded_to": image.get("uploaded_to"), "name": image.get("name")},
        )
        operations.append({"resource": "image-gallery", "id": image.get("id"), "success": ok, "message": message})
        success &= ok
    for page in reversed(run.get("objects", {}).get("pages", [])):
        ok, message = identity_checked_delete(
            client,
            "pages",
            page,
            {"name": page.get("name"), "chapter_id": run["objects"]["chapter"]["id"]},
        )
        operations.append({"resource": "pages", "id": page.get("id"), "success": ok, "message": message})
        success &= ok
    chapter = run.get("objects", {}).get("chapter")
    if chapter:
        ok, message = identity_checked_delete(
            client,
            "chapters",
            chapter,
            {"name": chapter.get("name"), "book_id": chapter.get("book_id")},
        )
        operations.append({"resource": "chapters", "id": chapter.get("id"), "success": ok, "message": message})
        success &= ok
    run["rollback"] = {
        "attempted_utc": utc_now(),
        "automatic": automatic,
        "operations": operations,
        "result": "PASS" if success else "PARTIAL",
    }
    run["status"] = "ROLLED_BACK_AFTER_FAILURE" if automatic and success else (
        "ROLLED_BACK" if success else "ROLLBACK_PARTIAL"
    )
    write_json_atomic(run_path, run)
    return success


def perform_upload(
    client: BookStackClient,
    plan: dict[str, Any],
    bundle: Path,
    plan_path: Path,
    stage: str,
    requested_run_file: str | None,
) -> Path:
    route = resolve_route(client, plan, stage)
    ensure_no_duplicate(route)
    run_path = new_run_path(bundle, stage, requested_run_file)
    run_id = f"{stage}-{safe_timestamp()}-{uuid.uuid4().hex[:8]}"
    run: dict[str, Any] = {
        "schema_version": 1,
        "run_id": run_id,
        "stage": stage,
        "status": "INITIALIZED",
        "created_utc": utc_now(),
        "updated_utc": utc_now(),
        "bookstack_base_url": client.base_url,
        "plan_file": str(plan_path),
        "plan_sha256": plan["plan_sha256"],
        "source_sha256": plan["source"].get("pdf_sha256"),
        "route": route,
        "objects": {"chapter": None, "pages": [], "images": []},
        "verification": {},
        "errors": [],
        "rollback": None,
    }
    write_json_atomic(run_path, run)
    uploaded_by_asset_hash: dict[str, dict[str, Any]] = {}
    try:
        chapter_payload = {
            "book_id": route["book"]["id"],
            "name": route["chapter_name"],
            "description": (
                f"Source SHA-256: {plan['source'].get('pdf_sha256') or plan['source']['markdown_sha256']}; "
                f"ingest plan: {plan['plan_sha256']}"
            ),
            "tags": [
                {"name": "Ingest-Stage", "value": stage},
                {"name": "Ingest-Plan", "value": plan["plan_sha256"][:16]},
            ],
            "priority": int(plan["chapter"].get("priority") or 0),
        }
        chapter = client.request_json("POST", "/chapters", chapter_payload)
        run["objects"]["chapter"] = {
            "id": int(chapter["id"]),
            "name": chapter["name"],
            "book_id": int(chapter["book_id"]),
            "url": chapter.get("url"),
        }
        run["status"] = "UPLOADING"
        run["updated_utc"] = utc_now()
        write_json_atomic(run_path, run)

        for page_plan in plan["pages"]:
            local_path = resolve_within(bundle, page_plan["file"])
            local_markdown = normalize_markdown(local_path.read_text(encoding="utf-8"))
            created = client.request_json(
                "POST",
                "/pages",
                {
                    "chapter_id": int(chapter["id"]),
                    "name": page_plan["name"],
                    "markdown": local_markdown,
                    "priority": int(page_plan["priority"]),
                    "tags": [{"name": "Source-Page-Range", "value": page_plan["pdf_page_range"]}],
                },
            )
            page_record: dict[str, Any] = {
                "id": int(created["id"]),
                "name": page_plan["name"],
                "priority": int(page_plan["priority"]),
                "chapter_id": int(chapter["id"]),
                "bundle_file": page_plan["file"],
                "bundle_content_sha256": sha256_text(local_markdown),
                "uploaded_content_sha256": "",
                "url": page_ui_url(client, created),
            }
            run["objects"]["pages"].append(page_record)
            run["updated_utc"] = utc_now()
            write_json_atomic(run_path, run)

            replacements: dict[str, str] = {}
            for ref in image_references(local_markdown):
                if reference_kind(ref) != "local":
                    continue
                asset_path = (local_path.parent / ref).resolve()
                try:
                    asset_path.relative_to(bundle)
                except ValueError as exc:
                    raise PipelineError(f"page image escapes the frozen bundle: {ref}") from exc
                asset_hash = sha256_file(asset_path)
                image_record = uploaded_by_asset_hash.get(asset_hash)
                if image_record is None:
                    image = client.upload_image(asset_path, int(created["id"]))
                    image_record = {
                        "id": int(image["id"]),
                        "name": image.get("name") or asset_path.name,
                        "uploaded_to": int(created["id"]),
                        "asset_sha256": asset_hash,
                        "url": image.get("url"),
                    }
                    if not image_record["url"]:
                        raise PipelineError(f"image upload {image_record['id']} returned no URL")
                    uploaded_by_asset_hash[asset_hash] = image_record
                    run["objects"]["images"].append(image_record)
                    run["updated_utc"] = utc_now()
                    write_json_atomic(run_path, run)
                replacements[ref] = str(image_record["url"])

            upload_markdown = normalize_markdown(rewrite_image_references(local_markdown, replacements))
            if upload_markdown != local_markdown:
                client.request_json(
                    "PUT",
                    f"/pages/{int(created['id'])}",
                    {
                        "name": page_plan["name"],
                        "markdown": upload_markdown,
                        "priority": int(page_plan["priority"]),
                    },
                )
            page_record["uploaded_content_sha256"] = sha256_text(upload_markdown)
            remote = client.request_json("GET", f"/pages/{int(created['id'])}")
            remote_hash = sha256_text(str(remote.get("markdown") or ""))
            page_record["remote_content_sha256"] = remote_hash
            page_record["url"] = page_ui_url(client, remote)
            if remote_hash != page_record["uploaded_content_sha256"]:
                raise PipelineError(f"read-back Markdown hash mismatch for page {created['id']}")
            if remote.get("name") != page_plan["name"]:
                raise PipelineError(f"read-back name mismatch for page {created['id']}")
            if int(remote.get("chapter_id") or 0) != int(chapter["id"]):
                raise PipelineError(f"read-back parent mismatch for page {created['id']}")
            run["updated_utc"] = utc_now()
            write_json_atomic(run_path, run)

        verified, failures = verify_remote_run(client, run)
        run["verification"] = {"verified_utc": utc_now(), "result": "PASS" if verified else "FAIL", "failures": failures}
        run["status"] = "VERIFIED" if verified else "FAILED"
        run["updated_utc"] = utc_now()
        write_json_atomic(run_path, run)
        if not verified:
            raise PipelineError("post-upload read-back verification failed")
        print(f"{stage} upload VERIFIED; run manifest: {run_path}")
        return run_path
    except Exception as exc:
        run["errors"].append(str(exc))
        run["status"] = "FAILED"
        run["updated_utc"] = utc_now()
        write_json_atomic(run_path, run)
        rollback_objects(client, run, run_path, automatic=True)
        raise PipelineError(f"upload failed and automatic rollback was attempted; run manifest: {run_path}; {exc}") from exc


def command_gate(args: argparse.Namespace) -> int:
    markdown = Path(args.markdown).expanduser().resolve()
    work = Path(args.conversion_work).expanduser().resolve() if args.conversion_work else None
    rewrite_audit = Path(args.rewrite_audit).expanduser().resolve() if args.rewrite_audit else None
    report = run_gate(markdown, work, args.allow_remote_images, rewrite_audit)
    output = Path(args.output).expanduser().resolve() if args.output else markdown.with_suffix(".gate.json")
    write_json_atomic(output, report)
    print(f"Markdown gate: {report['result']}; report: {output}")
    if report["errors"]:
        for item in report["errors"]:
            print(f"- {item}", file=sys.stderr)
    return 0 if report["result"] == "PASS" else 2


def command_plan(args: argparse.Namespace) -> int:
    markdown_path = Path(args.markdown).expanduser().resolve()
    bundle = Path(args.bundle_dir).expanduser().resolve()
    work = Path(args.conversion_work).expanduser().resolve()
    if not args.chapter_name.strip():
        raise PipelineError("--chapter-name must not be blank")
    test_chapter_name = f"【测试】{args.chapter_name} [" + ("0" * 8) + "]"
    if len(args.chapter_name) > 255 or len(test_chapter_name) > 255:
        raise PipelineError("formal or decorated test chapter name exceeds 255 characters")
    route_values = (
        args.test_shelf_name,
        args.test_book_name,
        args.target_shelf_name,
        args.target_book_name,
    )
    if any(not value.strip() or len(value) > 255 for value in route_values):
        raise PipelineError("shelf and book names must be nonblank and at most 255 characters")
    if (
        args.test_shelf_name == args.target_shelf_name
        and args.test_book_name == args.target_book_name
    ):
        raise PipelineError("test and formal routes must not be the same shelf/book")
    rewrite_audit = Path(args.rewrite_audit).expanduser().resolve() if args.rewrite_audit else None
    gate = run_gate(markdown_path, work, args.allow_remote_images, rewrite_audit)
    if gate["result"] != "PASS":
        raise PipelineError("cannot build an ingest plan from a Markdown file that failed the gate")
    require_new_directory(bundle)
    source_markdown = normalize_markdown(markdown_path.read_text(encoding="utf-8"))
    bundled_markdown, assets = copy_bundle_assets(source_markdown, markdown_path.parent, bundle)
    segments = split_markdown(bundled_markdown, args.split_level, args.preamble_title)
    if not segments:
        raise PipelineError("split produced no BookStack pages")
    if len(segments) > args.max_pages:
        raise PipelineError(f"split produced {len(segments)} pages, above --max-pages {args.max_pages}")
    used: set[str] = set()
    pages: list[dict[str, Any]] = []
    page_dir = bundle / "pages"
    page_dir.mkdir(parents=True, exist_ok=True)
    all_markers: list[int] = []
    for index, (raw_name, content) in enumerate(segments, start=1):
        encoded = content.encode("utf-8")
        if len(encoded) > args.max_page_bytes:
            raise PipelineError(f"page {index} exceeds --max-page-bytes")
        name = unique_page_name(raw_name, used)
        file_name = f"{index:04d}.md"
        path = page_dir / file_name
        path.write_text(content, encoding="utf-8", newline="\n")
        markers = [int(value) for value in PAGE_MARKER_RE.findall(content)]
        all_markers.extend(markers)
        page_refs = image_references(content)
        pages.append(
            {
                "index": index,
                "name": name,
                "priority": index,
                "file": f"pages/{file_name}",
                "file_sha256": sha256_file(path),
                "content_sha256": sha256_text(content),
                "bytes": len(encoded),
                "pdf_pages": markers,
                "pdf_page_range": (
                    f"{min(markers)}-{max(markers)}" if markers else "none"
                ),
                "image_references": len(page_refs),
            }
        )
    expected_pages = int(gate["metrics"].get("source_pages") or 0)
    if expected_pages and all_markers != list(range(1, expected_pages + 1)):
        raise PipelineError("BookStack split lost, duplicated, or reordered PDF page markers")
    manifest = load_json(work / "manifest.json")
    plan: dict[str, Any] = {
        "schema_version": 1,
        "pipeline_version": VERSION,
        "created_utc": utc_now(),
        "source": {
            "markdown_name": markdown_path.name,
            "markdown_sha256": sha256_file(markdown_path),
            "normalized_markdown_sha256": sha256_text(source_markdown),
            "pdf_name": manifest.get("source", {}).get("filename"),
            "pdf_sha256": manifest.get("source", {}).get("sha256"),
            "pdf_pages": expected_pages,
            "document_kind": manifest.get("conversion", {}).get("document_kind"),
            "content_profiles": manifest.get("conversion", {}).get("content_profiles"),
        },
        "gates": {
            "markdown": gate,
            "fidelity_audit_file_sha256": sha256_file(work / "qa/audit_report.json"),
            "table_audit_file_sha256": sha256_file(work / "qa/table_audit.json"),
            "rewrite_audit_file_sha256": sha256_file(rewrite_audit) if rewrite_audit else None,
        },
        "routing": {
            "test": {"shelf_name": args.test_shelf_name, "book_name": args.test_book_name},
            "formal": {"shelf_name": args.target_shelf_name, "book_name": args.target_book_name},
        },
        "chapter": {"name": args.chapter_name, "priority": args.chapter_priority},
        "split": {
            "heading_level": args.split_level,
            "preamble_title": args.preamble_title,
            "page_count": len(pages),
        },
        "assets": assets,
        "pages": pages,
        "warnings": gate["warnings"],
    }
    plan["plan_sha256"] = canonical_plan_hash(plan)
    plan_path = bundle / "plan.json"
    write_json_atomic(plan_path, plan)
    (bundle / "runs").mkdir(parents=True, exist_ok=True)
    report = [
        "# BookStack Ingest Plan",
        "",
        f"- Plan SHA-256: `{plan['plan_sha256']}`",
        f"- Source PDF SHA-256: `{plan['source']['pdf_sha256']}`",
        f"- Chapter: `{args.chapter_name}`",
        f"- Test route: `{args.test_shelf_name} / {args.test_book_name}`",
        f"- Formal route: `{args.target_shelf_name} / {args.target_book_name}`",
        f"- Pages: {len(pages)}",
        f"- Assets: {len(assets)}",
        "",
        "| # | Page name | PDF pages | Bytes | SHA-256 |",
        "| ---: | --- | --- | ---: | --- |",
    ]
    report.extend(
        f"| {page['index']} | {page['name']} | {page['pdf_page_range']} | {page['bytes']} | `{page['content_sha256']}` |"
        for page in pages
    )
    if gate["warnings"]:
        report.extend(["", "## Warnings", ""])
        report.extend(f"- {warning}" for warning in gate["warnings"])
    (bundle / "plan_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    verify_plan_integrity(plan_path)
    print(f"Ingest plan created: {plan_path}")
    print(f"Plan SHA-256: {plan['plan_sha256']}")
    return 0


def command_doctor(args: argparse.Namespace) -> int:
    client = BookStackClient.from_env()
    result: dict[str, Any] = {
        "result": "PASS",
        "base_url": client.base_url,
        "transport": parse.urlparse(client.base_url).scheme,
        "transport_warning": parse.urlparse(client.base_url).scheme != "https",
        "routes": {},
        "errors": [],
    }
    try:
        client.request_json("GET", "/books?count=1")
        if args.plan:
            plan, _ = verify_plan_integrity(Path(args.plan).expanduser().resolve())
            for stage in ("test", "formal"):
                route = resolve_route(client, plan, stage)
                result["routes"][stage] = route
                if route["duplicate_chapter_ids"]:
                    result["errors"].append(
                        f"{stage} route has duplicate chapter IDs: {route['duplicate_chapter_ids']}"
                    )
    except PipelineError as exc:
        result["errors"].append(str(exc))
    if result["errors"]:
        result["result"] = "FAIL"
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["result"] == "PASS" else 2


def command_upload_test(args: argparse.Namespace) -> int:
    plan_path = Path(args.plan).expanduser().resolve()
    plan, bundle = verify_plan_integrity(plan_path)
    client = BookStackClient.from_env()
    perform_upload(client, plan, bundle, plan_path, "test", args.run_file)
    return 0


def command_publish(args: argparse.Namespace) -> int:
    if not args.confirm_reviewed:
        raise PipelineError("formal publish requires --confirm-reviewed after explicit user review")
    plan_path = Path(args.plan).expanduser().resolve()
    plan, bundle = verify_plan_integrity(plan_path)
    if args.confirm_plan_sha256 != plan["plan_sha256"]:
        raise PipelineError("--confirm-plan-sha256 does not match the frozen plan")
    test_run_path = Path(args.test_run).expanduser().resolve()
    test_run = load_json(test_run_path)
    if (
        test_run.get("stage") != "test"
        or test_run.get("status") != "VERIFIED"
        or test_run.get("plan_sha256") != plan["plan_sha256"]
    ):
        raise PipelineError("formal publish requires a VERIFIED test run for the same plan")
    client = BookStackClient.from_env()
    if test_run.get("bookstack_base_url") != client.base_url:
        raise PipelineError("test run belongs to a different BookStack base URL")
    test_verified, test_failures = verify_remote_run(client, test_run)
    if not test_verified:
        raise PipelineError(
            "test run no longer passes live read-back verification: " + "; ".join(test_failures)
        )
    perform_upload(client, plan, bundle, plan_path, "formal", args.run_file)
    return 0


def command_verify(args: argparse.Namespace) -> int:
    run_path = Path(args.run_manifest).expanduser().resolve()
    run = load_json(run_path)
    client = BookStackClient.from_env()
    if run.get("bookstack_base_url") != client.base_url:
        raise PipelineError("run manifest belongs to a different BookStack base URL")
    verified, failures = verify_remote_run(client, run)
    report = {
        "result": "PASS" if verified else "FAIL",
        "verified_utc": utc_now(),
        "run_id": run.get("run_id"),
        "stage": run.get("stage"),
        "plan_sha256": run.get("plan_sha256"),
        "failures": failures,
    }
    output = Path(args.output).expanduser().resolve() if args.output else run_path.with_suffix(".verify.json")
    write_json_atomic(output, report)
    print(f"Read-back verification: {report['result']}; report: {output}")
    return 0 if verified else 2


def command_rollback(args: argparse.Namespace) -> int:
    run_path = Path(args.run_manifest).expanduser().resolve()
    run = load_json(run_path)
    if args.confirm_run_id != run.get("run_id"):
        raise PipelineError("--confirm-run-id does not match the run manifest")
    if str(run.get("status", "")).startswith("ROLLED_BACK") or run.get("status") == "ROLLBACK_PARTIAL":
        raise PipelineError("run already has a rollback result")
    client = BookStackClient.from_env()
    if run.get("bookstack_base_url") != client.base_url:
        raise PipelineError("run manifest belongs to a different BookStack base URL")
    success = rollback_objects(client, run, run_path, automatic=False)
    print(f"Rollback {'PASS' if success else 'PARTIAL'}; run manifest: {run_path}")
    return 0 if success else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=VERSION)
    subparsers = parser.add_subparsers(dest="command", required=True)

    gate = subparsers.add_parser("gate", help="Run local Markdown and conversion gates")
    gate.add_argument("markdown")
    gate.add_argument("--conversion-work")
    gate.add_argument("--rewrite-audit")
    gate.add_argument("--allow-remote-images", action="store_true")
    gate.add_argument("--output")
    gate.set_defaults(func=command_gate)

    plan = subparsers.add_parser("plan", help="Create a frozen BookStack ingest bundle")
    plan.add_argument("markdown")
    plan.add_argument("bundle_dir")
    plan.add_argument("--conversion-work", required=True)
    plan.add_argument("--rewrite-audit")
    plan.add_argument("--chapter-name", required=True)
    plan.add_argument("--chapter-priority", type=int, default=0)
    plan.add_argument("--test-shelf-name", default="推送测试")
    plan.add_argument("--test-book-name", required=True)
    plan.add_argument("--target-shelf-name", default="【AI】手册资料")
    plan.add_argument("--target-book-name", required=True)
    plan.add_argument("--split-level", type=int, choices=range(2, 7), default=2)
    plan.add_argument("--preamble-title", default="文档信息与前言")
    plan.add_argument("--max-pages", type=int, default=300)
    plan.add_argument("--max-page-bytes", type=int, default=2 * 1024 * 1024)
    plan.add_argument("--allow-remote-images", action="store_true")
    plan.set_defaults(func=command_plan)

    doctor = subparsers.add_parser("doctor", help="Check API access and routes without writing")
    doctor.add_argument("--plan")
    doctor.set_defaults(func=command_doctor)

    upload_test = subparsers.add_parser("upload-test", help="Upload and verify the frozen plan in the test book")
    upload_test.add_argument("--plan", required=True)
    upload_test.add_argument("--run-file")
    upload_test.set_defaults(func=command_upload_test)

    publish = subparsers.add_parser("publish", help="Publish a reviewed test plan to the formal book")
    publish.add_argument("--plan", required=True)
    publish.add_argument("--test-run", required=True)
    publish.add_argument("--confirm-plan-sha256", required=True)
    publish.add_argument("--confirm-reviewed", action="store_true")
    publish.add_argument("--run-file")
    publish.set_defaults(func=command_publish)

    verify = subparsers.add_parser("verify", help="Read remote objects back and verify a run")
    verify.add_argument("--run-manifest", required=True)
    verify.add_argument("--output")
    verify.set_defaults(func=command_verify)

    rollback = subparsers.add_parser("rollback", help="Delete only the objects journaled by one run")
    rollback.add_argument("--run-manifest", required=True)
    rollback.add_argument("--confirm-run-id", required=True)
    rollback.set_defaults(func=command_rollback)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        return args.func(args)
    except PipelineError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

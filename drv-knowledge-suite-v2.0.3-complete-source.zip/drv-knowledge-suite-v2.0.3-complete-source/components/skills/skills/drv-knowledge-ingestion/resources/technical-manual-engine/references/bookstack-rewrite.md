# BookStack Semantic Rewrite Standard

## Contents

1. Purpose and artifact boundary
2. Responsibility boundary
3. Dynamic classification
4. Full-read rewrite method
5. Heading and anchor format
6. Page provenance and PDF furniture
7. Tables
8. Images
9. Code, commands, registers, and values
10. Chinese rewrite rules
11. Allowed and forbidden removal
12. Review and exception records
13. Required commands
14. Pass conditions

## 1. Purpose and artifact boundary

Create two independent artifacts:

| Artifact | Purpose | Content policy |
| --- | --- | --- |
| `manual_exact.md` | Source-faithful evidence, reverse audit, archival retrieval | Preserve source wording, pages, tables, images, notices, and revision identity |
| `manual_bookstack.md` | Human-readable BookStack reference manual | Reorganize and translate prose while preserving all engineering meaning and traceability |

Never rewrite `manual_exact.md` into a cleaner state. Generate
`manual_bookstack.md` only after the exact fidelity and exact table audits pass.
The source PDF, exact Markdown, and evidence workspace remain immutable.

Do not use a BookStack rewrite as evidence that PDF conversion is complete. Do
not use an exact-conversion PASS to claim that a rewritten derivative is safe.
Each artifact has its own audit and SHA-256 binding.

## 2. Responsibility boundary

Use deterministic tools for:

- PDF fingerprinting, page and object extraction;
- page, image, and table inventories;
- hash checks, local-path checks, heading structure, and BookStack limits;
- exact and translated table matrices;
- critical-token recall and precision;
- test upload, remote read-back, and rollback.

Use AI reading and judgment for:

- understanding every source section;
- choosing dynamic BookStack grouping and page titles;
- distinguishing meaningful diagrams from decorative content;
- Chinese semantic rewrite and terminology decisions;
- resolving cross-references after merge or split;
- reviewing whether a deletion is genuinely nontechnical.

Never use a bulk regex rewrite, machine-translation script, heading-only
summarizer, or table-flattening converter as the semantic rewrite. Scripts may
detect and audit; they must not approve or author the rewritten meaning.

## 3. Dynamic classification

Do not impose one fixed MCU directory template on every manual. Read the exact
artifact and classify from its actual publication kind and section structure.

Record in `qa/bookstack_rewrite_review.json`:

- component or family name;
- source publication kind;
- BookStack manual class, such as 数据手册、用户手册、编程指南、硬件设计指南、SDK/API、协议规范、勘误 or 应用笔记;
- target chapter name;
- every material merge or split decision.

Typical grouping cues:

- datasheet: overview, variants, pins, limits, timing, package, ordering, revision;
- reference/user manual: architecture, memory, clock/reset/power, interrupts,
  DMA, GPIO, timers, communication, analog, security, registers;
- SDK/API: lifecycle, modules, types, calls, errors, examples, compatibility;
- hardware guide: power, reset, clock, schematics, routing, layout, BOM,
  mechanical constraints;
- protocol document: frames, states, commands, timing, recovery, conformance.

Merge only small, coherent sections. Split only when a resulting BookStack page
would be too large or mixes unrelated topics. Preserve source order unless a
different order materially improves reference use and every cross-reference is
updated. Never merge separate source PDFs before each one has its own exact and
rewrite audit. The current ingest plan consumes one audited derivative at a
time.

Use BookStack page priority for ordering. Do not force `01_` prefixes into
visible page titles unless the user wants them; the frozen bundle already uses
internal `0001.md`, `0002.md`, and similar ordered filenames.

## 4. Full-read rewrite method

For each planned BookStack page:

1. Read the complete corresponding source section in `manual_exact.md`.
2. Check the source page renders for tables, images, waveforms, drawings,
   equations, multi-column order, and ambiguous text.
3. List the section's tables, figures, code blocks, commands, register names,
   values, units, warnings, prerequisites, and sequence constraints.
4. Rewrite the prose in clear Chinese without changing engineering claims.
5. Preserve and bind hidden page and table provenance markers.
6. Re-read source and output in both directions: source-to-output for omissions,
   output-to-source for invented facts.
7. Mark review attestations only after the complete file has been checked.

Do not treat reading the first 50 lines as sufficient for rewriting. A short
preview is only for the initial classification proposal.

## 5. Heading and anchor format

Use one H1 and nonjumping heading levels. Put one unique BookStack-compatible
anchor on every heading line:

```markdown
# 中文手册标题<a name="manual"></a>

## 复位与时钟<a name="reset-clock"></a>
```

Keep identifiers stable after a test upload. Do not put spaces in anchor names.
Avoid generated page headings such as `第 12 页` or `PDF page 12`.

Source chapter numbers are not removed blindly. Preserve them when cross-
references, register groups, standards, or external citations depend on them.
If numbers are removed from visible titles, keep stable anchors and update all
affected cross-references.

## 6. Page provenance and PDF furniture

Keep exactly one ordered hidden marker for every source page:

```html
<!-- PDF_PAGE:0012 -->
```

The marker is nonrendering evidence and is not PDF page furniture. Remove visible
artifacts such as `## 第12页`, `Page 12 of 82`, generated page-image alt text, and
repeated running page numbers after review.

Do not globally delete every `---` line. A horizontal rule can be meaningful in
Markdown, YAML frontmatter, examples, or command output. Remove it only when it
is verified as extraction furniture.

## 7. Tables

Use BookStack-compatible HTML tables in the Chinese derivative. Keep each
`SOURCE_TABLE` marker immediately before its table:

```html
<!-- SOURCE_TABLE:p0012-table003 -->
<table>
  <thead><tr><th>位</th><th>名称</th><th>复位值</th></tr></thead>
  <tbody><tr><td>[31:16]</td><td>RESERVED</td><td>0x0000</td></tr></tbody>
</table>
```

Translation may change prose cells and human-readable headers. It must not
change:

- row/column geometry or expanded merged-cell scope;
- blank, zero, dash, N/A, reserved, and undefined distinctions;
- addresses, offsets, values, ranges, units, signs, access types, symbols,
  identifiers, footnote markers, and continuation relationships;
- minimum/typical/maximum column meaning or test conditions.

Do not keep both a pipe-table copy and an HTML copy. Do not replace a complex
table with flattened prose. Run the translated table audit in cell-token mode;
an overall text-token PASS cannot replace it.

## 8. Images

Do not delete the first image merely because it appears first. `page1_img2.png`
is not a universal logo rule. Decide from the image inventory and source render.

Preserve every meaningful image occurrence, including:

- functional and architectural block diagrams;
- pin, package, board, connector, and layout diagrams;
- hardware connections, schematics, and reference circuits;
- state machines, flowcharts, timing charts, and waveforms;
- plots, coordinate systems, mechanical drawings, and annotated photographs.

Drop an image only after its inventory disposition is `decorative`, `duplicate`,
or `not-meaningful` with a reason. Keep its original relative path unchanged in
the rewrite. If meaningful vector content is only `covered-by-page-image`, create
and verify a tight display crop before BookStack ingestion. Do not silently use
a full-page screenshot as the final diagram.

Do not replace original figures with AI-generated figures. Do not delete a
timing diagram after translating OCR text around it.

## 9. Code, commands, registers, and values

Preserve fenced code blocks byte-for-byte apart from line-ending normalization,
including their language label. Preserve shell and AT commands, output, API
signatures, paths, device-tree properties, configuration fragments, macros,
types, enum values, and error codes.

Keep register names, field names, bit ranges, offsets, addresses, reset values,
access types, units, signal names, and protocol symbols exactly as verified.
Do not convert a numeral into a different radix, normalize case, change unit
spelling, or add an unsupported abbreviation during translation.

Register metadata may be presented compactly when every field remains exact:

```markdown
偏移: `0x04` | 复位值: `0x00000000` | 访问属性: `R/W`
```

## 10. Chinese rewrite rules

- Translate explanatory prose by meaning, not word order.
- Preserve normative strength: must/shall, should, may, prohibited, reserved,
  warning, and prerequisite are not interchangeable.
- Preserve procedure and initialization order.
- Keep product names, part numbers, register and API identifiers, symbols,
  parameter names, signal names, code, commands, and established acronyms in
  their source form.
- Introduce a Chinese explanation beside a retained English term when needed;
  do not invent a new acronym absent from the source.
- Translate table prose cell by cell while preserving every engineering token.
- Do not leave long untranslated English prose unless the user explicitly
  approves it and the review record explains why.
- Do not over-compress. De-duplication removes duplicate representation, not
  unique engineering information.

## 11. Allowed and forbidden removal

Allowed only after review and traceable exception recording when critical
tokens are affected:

- table-of-contents navigation entries duplicated by BookStack navigation;
- repeated page furniture already represented by hidden page markers;
- verified decorative logos or backgrounds;
- duplicate Markdown/HTML rendering of the same verified table;
- legal or confidentiality prose when redistribution policy allows removal;
- a shortened revision history that still preserves applicable revision
  identity and material changes.

Forbidden by default:

- warnings, cautions, prerequisites, errata, safety or irreversible-operation
  notices;
- reserved rows, table notes, footnotes, limits, conditions, enumerations, and
  variant applicability;
- any code, command, register metadata, value, unit, sequence step, or
  meaningful image;
- content whose meaning is unclear or whose source is unreadable.

When unsure, preserve the content and flag it. Never invent a repair.

## 12. Review and exception records

Initialize an unapproved review record only after the draft rewrite exists.
Complete classification, reviewer, timestamp, and every attestation manually.
The initializer never auto-approves them.

Use `qa/bookstack_rewrite_exceptions.csv` only for narrow critical-token changes
caused by approved removal or translated labels. Every row requires direction,
token, count, source pages, reason code, reason, and reviewer.

No exception may waive a missing high-risk source token such as a hexadecimal
value, bit range, identifier, active-low signal, all-uppercase access symbol,
or number-plus-unit token. A new high-risk token absent from the exact source is
always blocked. Repeating an existing high-risk token in a summary still
requires an explicit `repeated-summary` record.

## 13. Required commands

After authoring `manual_bookstack.md`, initialize its review record:

```bash
python3 scripts/rewrite_audit.py init \
  WORK_DIR/manual_exact.md WORK_DIR/manual_bookstack.md WORK_DIR \
  --target-language zh-CN --table-format html
```

Complete the generated review JSON and exception CSV, then verify the translated
tables:

```bash
python3 scripts/table_audit.py audit \
  WORK_DIR/manual_bookstack.md WORK_DIR \
  --representation html --mode translated \
  --output WORK_DIR/qa/bookstack_table_audit.json
```

If `manual_bookstack.md` changes after review initialization, refresh its hash
binding before reviewing it again:

```bash
python3 scripts/rewrite_audit.py refresh \
  WORK_DIR/manual_exact.md WORK_DIR/manual_bookstack.md WORK_DIR
```

Refresh resets every prior attestation and reviewer field to an unapproved
state. Re-read the affected sections, complete the review again, and rerun both
audits. Never edit only the stored hash while retaining stale approvals.

Run the semantic rewrite audit:

```bash
python3 scripts/rewrite_audit.py audit \
  WORK_DIR/manual_exact.md WORK_DIR/manual_bookstack.md WORK_DIR \
  --table-audit WORK_DIR/qa/bookstack_table_audit.json
```

Use the resulting report in the BookStack gate and frozen plan:

```bash
python3 scripts/bookstack_pipeline.py gate \
  WORK_DIR/manual_bookstack.md --conversion-work WORK_DIR \
  --rewrite-audit WORK_DIR/qa/bookstack_rewrite_audit.json
```

## 14. Pass conditions

Require all of the following:

- exact fidelity and exact table audits remain PASS and hash-bound;
- hidden source-page markers are complete and ordered;
- every heading has a unique anchor and visible PDF furniture is absent;
- code blocks are unchanged;
- every structured source table exists once, uses the selected format, and
  passes translated cell-token comparison;
- all meaningful image paths remain and no unsupported image is added;
- meaningful visuals do not rely solely on full-page screenshots unless the
  user explicitly accepts the limitation;
- critical-token recall and precision are 1.000000 after valid, narrow
  exceptions;
- no unsupported high-risk token is removed or introduced;
- classification and full-read review attestations are complete;
- the audit report is bound to the exact and rewritten file hashes.

Any failure blocks test upload.

#!/usr/bin/env python3
"""Offline regression test for table, Markdown, BookStack, and rollback gates."""

from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse


SCRIPT_DIR = Path(__file__).resolve().parent
TABLE_SCRIPT = SCRIPT_DIR / "table_audit.py"
BOOKSTACK_SCRIPT = SCRIPT_DIR / "bookstack_pipeline.py"
MANUAL_SCRIPT = SCRIPT_DIR / "manual_pipeline.py"
REWRITE_SCRIPT = SCRIPT_DIR / "rewrite_audit.py"


def run(arguments: list[str], env: dict[str, str] | None = None, expected: int = 0) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        [sys.executable, *arguments],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        env=env,
        check=False,
    )
    if result.returncode != expected:
        raise AssertionError(
            f"command returned {result.returncode}, expected {expected}: {arguments}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def update_csv(path: Path, updates: dict[str, str]) -> None:
    with path.open("r", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
        fields = list(rows[0].keys()) if rows else [
            "table_id", "page", "candidate_id", "title", "representation",
            "review_status", "continuation_of", "md_reference", "verified_table", "notes",
        ]
    for row in rows:
        row.update(updates)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def test_manual_pipeline(root: Path) -> None:
    import fitz

    source = root / "converter-source.pdf"
    document = fitz.open()
    page = document.new_page()
    page.insert_text((72, 72), "SYNTHETIC MANUAL\nRegister CTRL = 0x4000_0000")
    page = document.new_page()
    page.insert_text((72, 72), "RESET VALUE 0x0001\nIRQ_7")
    document.save(source)
    document.close()
    work = root / "converter-work"
    run(
        [
            str(MANUAL_SCRIPT),
            "prepare",
            str(source),
            str(work),
            "--document-kind",
            "datasheet",
            "--profiles",
            "general,soc-mcu-cpu",
        ]
    )
    shutil.copy2(work / "draft.md", work / "manual_exact.md")
    with (work / "qa/page_inventory.csv").open("r", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
        fields = list(rows[0].keys())
    for row in rows:
        row["text_review_status"] = "verified"
        row["visual_review_status"] = "verified"
        row["critical_review_status"] = "verified"
        row["risk_resolution"] = "self-test review" if row["risk_flags"] else ""
    with (work / "qa/page_inventory.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    run([str(MANUAL_SCRIPT), "audit", str(source), str(work / "manual_exact.md"), str(work)])
    run([str(TABLE_SCRIPT), "init", str(work)])
    meta = json.loads((work / "qa/table_census_meta.json").read_text(encoding="utf-8"))
    meta.update(
        {
            "all_pages_reviewed_against_pdf": True,
            "reviewer": "self-test",
            "reviewed_utc": "2026-01-01T00:00:00+00:00",
        }
    )
    write_json(work / "qa/table_census_meta.json", meta)
    run([str(TABLE_SCRIPT), "sync", str(work)])
    run([str(TABLE_SCRIPT), "audit", str(work / "manual_exact.md"), str(work)])


class FakeState:
    def __init__(self) -> None:
        self.next_chapter = 100
        self.next_page = 200
        self.next_image = 300
        self.shelves = {
            10: {"id": 10, "name": "推送测试", "books": [{"id": 20, "name": "推送测试"}]},
            11: {"id": 11, "name": "【AI】手册资料", "books": [{"id": 21, "name": "网络芯片"}]},
        }
        self.books = {
            20: {"id": 20, "name": "推送测试", "slug": "test-book"},
            21: {"id": 21, "name": "网络芯片", "slug": "network-chip"},
        }
        self.chapters: dict[int, dict[str, object]] = {}
        self.pages: dict[int, dict[str, object]] = {}
        self.images: dict[int, dict[str, object]] = {}
        self.corrupt_reads = False


class FakeHandler(BaseHTTPRequestHandler):
    state: FakeState
    server_base: str

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def _json(self, status: int, value: object) -> None:
        data = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _empty(self, status: int = 204) -> None:
        self.send_response(status)
        self.send_header("Content-Length", "0")
        self.send_header("Connection", "close")
        self.end_headers()

    def _payload(self) -> dict[str, object]:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8")) if raw else {}

    def _parts(self) -> tuple[int, str]:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        uploaded = re.search(br'name="uploaded_to"\r\n\r\n(\d+)', raw)
        filename = re.search(br'filename="([^"]+)"', raw)
        if not uploaded or not filename:
            raise AssertionError("invalid multipart test request")
        return int(uploaded.group(1)), filename.group(1).decode("utf-8", errors="replace")

    def _list(self, values: list[dict[str, object]]) -> None:
        self._json(200, {"data": values, "total": len(values)})

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if self.headers.get("Authorization") != "Token test-id:test-secret":
            self._json(401, {"error": "unauthorized"})
            return
        if path == "/api/books":
            self._list(list(self.state.books.values()))
        elif path == "/api/shelves":
            self._list([{"id": value["id"], "name": value["name"]} for value in self.state.shelves.values()])
        elif path == "/api/chapters":
            self._list(list(self.state.chapters.values()))
        elif path == "/api/pages":
            self._list(list(self.state.pages.values()))
        elif re.fullmatch(r"/api/shelves/\d+", path):
            item = self.state.shelves.get(int(path.rsplit("/", 1)[1]))
            self._json(200, item) if item else self._json(404, {"error": "missing"})
        elif re.fullmatch(r"/api/chapters/\d+", path):
            item = self.state.chapters.get(int(path.rsplit("/", 1)[1]))
            self._json(200, item) if item else self._json(404, {"error": "missing"})
        elif re.fullmatch(r"/api/pages/\d+", path):
            item = self.state.pages.get(int(path.rsplit("/", 1)[1]))
            if not item:
                self._json(404, {"error": "missing"})
            else:
                response = dict(item)
                if self.state.corrupt_reads:
                    response["markdown"] = str(response.get("markdown") or "") + "\nUNSUPPORTED_REG = 0xDEAD_BEEF\n"
                self._json(200, response)
        elif re.fullmatch(r"/api/image-gallery/\d+", path):
            item = self.state.images.get(int(path.rsplit("/", 1)[1]))
            self._json(200, item) if item else self._json(404, {"error": "missing"})
        else:
            self._json(404, {"error": f"unknown {path}"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if self.headers.get("Authorization") != "Token test-id:test-secret":
            self._json(401, {"error": "unauthorized"})
            return
        if path == "/api/chapters":
            payload = self._payload()
            item_id = self.state.next_chapter
            self.state.next_chapter += 1
            item = {
                "id": item_id,
                "book_id": int(payload["book_id"]),
                "name": payload["name"],
                "priority": int(payload.get("priority") or 0),
                "slug": f"chapter-{item_id}",
                "url": f"{self.server_base}/chapter/{item_id}",
            }
            self.state.chapters[item_id] = item
            self._json(200, item)
        elif path == "/api/pages":
            payload = self._payload()
            chapter_id = int(payload["chapter_id"])
            chapter = self.state.chapters[chapter_id]
            book = self.state.books[int(chapter["book_id"])]
            item_id = self.state.next_page
            self.state.next_page += 1
            item = {
                "id": item_id,
                "book_id": book["id"],
                "book_slug": book["slug"],
                "chapter_id": chapter_id,
                "name": payload["name"],
                "markdown": payload["markdown"],
                "priority": int(payload.get("priority") or 0),
                "slug": f"page-{item_id}",
                "url": f"{self.server_base}/books/{book['slug']}/page/page-{item_id}",
            }
            self.state.pages[item_id] = item
            self._json(200, item)
        elif path == "/api/image-gallery":
            uploaded_to, name = self._parts()
            item_id = self.state.next_image
            self.state.next_image += 1
            item = {
                "id": item_id,
                "name": name,
                "uploaded_to": uploaded_to,
                "url": f"{self.server_base}/uploads/{item_id}/{name}",
                "type": "gallery",
            }
            self.state.images[item_id] = item
            self._json(200, item)
        else:
            self._json(404, {"error": f"unknown {path}"})

    def do_PUT(self) -> None:
        path = urlparse(self.path).path
        if not re.fullmatch(r"/api/pages/\d+", path):
            self._json(404, {"error": f"unknown {path}"})
            return
        item_id = int(path.rsplit("/", 1)[1])
        item = self.state.pages.get(item_id)
        if not item:
            self._json(404, {"error": "missing"})
            return
        item.update(self._payload())
        self._json(200, item)

    def do_DELETE(self) -> None:
        path = urlparse(self.path).path
        matches = [
            (r"/api/image-gallery/(\d+)", self.state.images),
            (r"/api/pages/(\d+)", self.state.pages),
            (r"/api/chapters/(\d+)", self.state.chapters),
        ]
        for pattern, collection in matches:
            match = re.fullmatch(pattern, path)
            if match:
                collection.pop(int(match.group(1)), None)
                self._empty()
                return
        self._json(404, {"error": f"unknown {path}"})


def make_workspace(root: Path) -> tuple[Path, Path]:
    work = root / "work"
    (work / "qa").mkdir(parents=True)
    (work / "evidence/tables").mkdir(parents=True)
    (work / "assets").mkdir(parents=True)
    image = work / "assets/pin.png"
    image.write_bytes(b"\x89PNG\r\n\x1a\nsynthetic")
    markdown = work / "manual_exact.md"
    markdown.write_text(
        """# Synthetic Embedded Manual

<!-- PDF_PAGE:0001 -->
<a id="pdf-page-0001"></a>

## Overview

This register is located at `0x4000_0000`.

IRQ# is active-low. WARNING applies during reset.

![Pin diagram](assets/pin.png)

<!-- PDF_PAGE:0002 -->
<a id="pdf-page-0002"></a>

## Register Map

<!-- SOURCE_TABLE:p0002-table001 -->
| Bits | Name | Reset |
| --- | --- | --- |
| [31:16] | RESERVED | 0x0000 |
| [15:0] | CTRL_EN | 0x0001 |
""",
        encoding="utf-8",
    )
    write_json(
        work / "manifest.json",
        {
            "source": {"filename": "synthetic.pdf", "sha256": "a" * 64, "page_count": 2},
            "conversion": {"document_kind": "datasheet", "content_profiles": ["soc-mcu-cpu"]},
            "inventories": {"image_occurrence_ids": [], "table_candidate_ids": ["p0002-table001"]},
        },
    )
    write_json(
        work / "qa/audit_report.json",
        {"result": "PASS", "markdown_name": markdown.name, "markdown_sha256": sha256_file(markdown)},
    )
    with (work / "qa/table_inventory.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=[
                "table_id", "page", "bbox", "row_count", "column_count", "evidence",
                "review_status", "md_reference", "notes",
            ],
        )
        writer.writeheader()
        writer.writerow(
            {
                "table_id": "p0002-table001",
                "page": 2,
                "bbox": "[0,0,1,1]",
                "row_count": 3,
                "column_count": 3,
                "evidence": "evidence/tables/p0002-table001.json",
                "review_status": "",
                "md_reference": "",
                "notes": "",
            }
        )
    write_json(
        work / "evidence/tables/p0002-table001.json",
        {
            "table_id": "p0002-table001",
            "page": 2,
            "rows": [
                ["Bits", "Name", "Reset"],
                ["[31:16]", "RESERVED", "0x0000"],
                ["[15:0]", "CTRL_EN", "0x0001"],
            ],
        },
    )
    return work, markdown


def run_manifests(directory: Path, stage: str) -> list[Path]:
    return sorted(path for path in directory.glob(f"{stage}-*.json") if not path.name.endswith(".verify.json"))


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="ingest-manual-selftest-") as temporary:
        root = Path(temporary)
        test_manual_pipeline(root)
        work, markdown = make_workspace(root)

        run([str(TABLE_SCRIPT), "init", str(work)])
        update_csv(
            work / "qa/table_census.csv",
            {
                "title": "Register Map",
                "representation": "markdown",
                "review_status": "verified-markdown",
                "notes": "Synthetic table visually verified.",
            },
        )
        meta = json.loads((work / "qa/table_census_meta.json").read_text(encoding="utf-8"))
        meta.update(
            {
                "all_pages_reviewed_against_pdf": True,
                "reviewer": "self-test",
                "reviewed_utc": "2026-01-01T00:00:00+00:00",
            }
        )
        write_json(work / "qa/table_census_meta.json", meta)
        verified_path = work / "qa/verified_tables/p0002-table001.json"
        verified = json.loads(verified_path.read_text(encoding="utf-8"))
        verified.update(
            {
                "title": "Register Map",
                "representation": "markdown",
                "verified_against_pdf": True,
                "reviewer": "self-test",
                "notes": "",
            }
        )
        write_json(verified_path, verified)
        run([str(TABLE_SCRIPT), "sync", str(work)])
        run([str(TABLE_SCRIPT), "audit", str(markdown), str(work)])

        altered = markdown.read_text(encoding="utf-8").replace("0x0001 |", "0x0002 |")
        markdown.write_text(altered, encoding="utf-8")
        run([str(TABLE_SCRIPT), "audit", str(markdown), str(work)], expected=2)
        markdown.write_text(altered.replace("0x0002 |", "0x0001 |"), encoding="utf-8")
        run([str(TABLE_SCRIPT), "audit", str(markdown), str(work)])

        bookstack_markdown = work / "manual_bookstack.md"
        bookstack_markdown.write_text(
            """# 合成嵌入式手册<a name="manual"></a>

<!-- PDF_PAGE:0001 -->
<a id="pdf-page-0001"></a>

## 概述<a name="overview"></a>

该寄存器位于 `0x4000_0000`。

IRQ#触发时为低电平。WARNING：在复位期间适用。

![Pin diagram](assets/pin.png)

<!-- PDF_PAGE:0002 -->
<a id="pdf-page-0002"></a>

## 寄存器映射<a name="register-map"></a>

<!-- SOURCE_TABLE:p0002-table001 -->
<table>
<thead><tr><th>位</th><th>名称</th><th>复位值</th></tr></thead>
<tbody>
<tr><td>[31:16]</td><td>RESERVED</td><td>0x0000</td></tr>
<tr><td>[15:0]</td><td>CTRL_EN</td><td>0x0001</td></tr>
</tbody>
</table>
""",
            encoding="utf-8",
        )
        translated_table_report = work / "qa/bookstack_table_audit.json"
        run(
            [
                str(TABLE_SCRIPT),
                "audit",
                str(bookstack_markdown),
                str(work),
                "--representation",
                "html",
                "--mode",
                "translated",
                "--output",
                str(translated_table_report),
            ]
        )
        run(
            [
                str(REWRITE_SCRIPT),
                "init",
                str(markdown),
                str(bookstack_markdown),
                str(work),
            ]
        )
        review_path = work / "qa/bookstack_rewrite_review.json"
        review = json.loads(review_path.read_text(encoding="utf-8"))
        review["classification"].update(
            {
                "component_name": "SYNTH-CHIP",
                "manual_class": "数据手册",
                "target_chapter": "SYNTH-CHIP",
                "merge_split_notes": "按两个源章节组织。",
            }
        )
        review["attestations"] = {key: True for key in review["attestations"]}
        review["reviewer"] = "self-test"
        review["reviewed_utc"] = "2026-01-01T00:00:00+00:00"
        write_json(review_path, review)
        rewrite_report = work / "qa/bookstack_rewrite_audit.json"
        run(
            [
                str(REWRITE_SCRIPT),
                "audit",
                str(markdown),
                str(bookstack_markdown),
                str(work),
                "--table-audit",
                str(translated_table_report),
                "--output",
                str(rewrite_report),
            ]
        )

        run(
            [
                str(REWRITE_SCRIPT),
                "refresh",
                str(markdown),
                str(bookstack_markdown),
                str(work),
            ]
        )
        refreshed = json.loads(review_path.read_text(encoding="utf-8"))
        assert not any(refreshed["attestations"].values())
        run(
            [
                str(REWRITE_SCRIPT),
                "audit",
                str(markdown),
                str(bookstack_markdown),
                str(work),
                "--table-audit",
                str(translated_table_report),
                "--output",
                str(rewrite_report),
            ],
            expected=2,
        )
        refreshed["attestations"] = {key: True for key in refreshed["attestations"]}
        refreshed["reviewer"] = "self-test"
        refreshed["reviewed_utc"] = "2026-01-01T00:00:00+00:00"
        write_json(review_path, refreshed)
        review = refreshed
        run(
            [
                str(REWRITE_SCRIPT),
                "audit",
                str(markdown),
                str(bookstack_markdown),
                str(work),
                "--table-audit",
                str(translated_table_report),
                "--output",
                str(rewrite_report),
            ]
        )

        original_bookstack = bookstack_markdown.read_text(encoding="utf-8")
        tampered_bookstack = original_bookstack.replace("0x0001</td>", "0x0002</td>")
        bookstack_markdown.write_text(tampered_bookstack, encoding="utf-8")
        review["bookstack_markdown_sha256"] = sha256_file(bookstack_markdown)
        write_json(review_path, review)
        run(
            [
                str(TABLE_SCRIPT),
                "audit",
                str(bookstack_markdown),
                str(work),
                "--representation",
                "html",
                "--mode",
                "translated",
                "--output",
                str(translated_table_report),
            ],
            expected=2,
        )
        run(
            [
                str(REWRITE_SCRIPT),
                "audit",
                str(markdown),
                str(bookstack_markdown),
                str(work),
                "--table-audit",
                str(translated_table_report),
                "--output",
                str(rewrite_report),
            ],
            expected=2,
        )
        bookstack_markdown.write_text(original_bookstack, encoding="utf-8")
        review["bookstack_markdown_sha256"] = sha256_file(bookstack_markdown)
        write_json(review_path, review)
        run(
            [
                str(TABLE_SCRIPT),
                "audit",
                str(bookstack_markdown),
                str(work),
                "--representation",
                "html",
                "--mode",
                "translated",
                "--output",
                str(translated_table_report),
            ]
        )
        run(
            [
                str(REWRITE_SCRIPT),
                "audit",
                str(markdown),
                str(bookstack_markdown),
                str(work),
                "--table-audit",
                str(translated_table_report),
                "--output",
                str(rewrite_report),
            ]
        )

        invented_bookstack = original_bookstack + "\nUNSUPPORTED_REG = 0xDEAD_BEEF\n"
        bookstack_markdown.write_text(invented_bookstack, encoding="utf-8")
        review["bookstack_markdown_sha256"] = sha256_file(bookstack_markdown)
        write_json(review_path, review)
        run(
            [
                str(TABLE_SCRIPT),
                "audit",
                str(bookstack_markdown),
                str(work),
                "--representation",
                "html",
                "--mode",
                "translated",
                "--output",
                str(translated_table_report),
            ]
        )
        run(
            [
                str(REWRITE_SCRIPT),
                "audit",
                str(markdown),
                str(bookstack_markdown),
                str(work),
                "--table-audit",
                str(translated_table_report),
                "--output",
                str(rewrite_report),
            ],
            expected=2,
        )

        image_removed_bookstack = original_bookstack.replace("![Pin diagram](assets/pin.png)\n\n", "")
        bookstack_markdown.write_text(image_removed_bookstack, encoding="utf-8")
        review["bookstack_markdown_sha256"] = sha256_file(bookstack_markdown)
        write_json(review_path, review)
        run(
            [
                str(TABLE_SCRIPT),
                "audit",
                str(bookstack_markdown),
                str(work),
                "--representation",
                "html",
                "--mode",
                "translated",
                "--output",
                str(translated_table_report),
            ]
        )
        run(
            [
                str(REWRITE_SCRIPT),
                "audit",
                str(markdown),
                str(bookstack_markdown),
                str(work),
                "--table-audit",
                str(translated_table_report),
                "--output",
                str(rewrite_report),
            ],
            expected=2,
        )

        english_bookstack = original_bookstack.replace(
            "该寄存器位于 `0x4000_0000`。",
            "This section explains that the register is located at `0x4000_0000` and remains available for normal control operations.",
        )
        bookstack_markdown.write_text(english_bookstack, encoding="utf-8")
        review["bookstack_markdown_sha256"] = sha256_file(bookstack_markdown)
        write_json(review_path, review)
        run(
            [
                str(TABLE_SCRIPT),
                "audit",
                str(bookstack_markdown),
                str(work),
                "--representation",
                "html",
                "--mode",
                "translated",
                "--output",
                str(translated_table_report),
            ]
        )
        run(
            [
                str(REWRITE_SCRIPT),
                "audit",
                str(markdown),
                str(bookstack_markdown),
                str(work),
                "--table-audit",
                str(translated_table_report),
                "--output",
                str(rewrite_report),
            ],
            expected=2,
        )

        bookstack_markdown.write_text(original_bookstack, encoding="utf-8")
        review["bookstack_markdown_sha256"] = sha256_file(bookstack_markdown)
        write_json(review_path, review)
        run(
            [
                str(TABLE_SCRIPT),
                "audit",
                str(bookstack_markdown),
                str(work),
                "--representation",
                "html",
                "--mode",
                "translated",
                "--output",
                str(translated_table_report),
            ]
        )
        run(
            [
                str(REWRITE_SCRIPT),
                "audit",
                str(markdown),
                str(bookstack_markdown),
                str(work),
                "--table-audit",
                str(translated_table_report),
                "--output",
                str(rewrite_report),
            ]
        )

        run([str(BOOKSTACK_SCRIPT), "gate", str(markdown), "--conversion-work", str(work)])
        run(
            [str(BOOKSTACK_SCRIPT), "gate", str(bookstack_markdown), "--conversion-work", str(work)],
            expected=2,
        )
        run(
            [
                str(BOOKSTACK_SCRIPT),
                "gate",
                str(bookstack_markdown),
                "--conversion-work",
                str(work),
                "--rewrite-audit",
                str(rewrite_report),
            ]
        )
        bundle = root / "bundle"
        plan_result = run(
            [
                str(BOOKSTACK_SCRIPT),
                "plan",
                str(bookstack_markdown),
                str(bundle),
                "--conversion-work",
                str(work),
                "--rewrite-audit",
                str(rewrite_report),
                "--chapter-name",
                "SYNTH-CHIP",
                "--test-book-name",
                "推送测试",
                "--target-book-name",
                "网络芯片",
            ]
        )
        plan = json.loads((bundle / "plan.json").read_text(encoding="utf-8"))
        assert plan["plan_sha256"] in plan_result.stdout
        assert len(plan["pages"]) == 3
        assert len(plan["assets"]) == 1
        ranges = [page["pdf_page_range"] for page in plan["pages"]]
        assert ranges[1:] == ["1-1", "2-2"], ranges

        state = FakeState()
        server = ThreadingHTTPServer(("127.0.0.1", 0), FakeHandler)
        FakeHandler.state = state
        FakeHandler.server_base = f"http://127.0.0.1:{server.server_address[1]}"
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        env = os.environ.copy()
        env.update(
            {
                "BOOKSTACK_BASE_URL": FakeHandler.server_base,
                "BOOKSTACK_TOKEN_ID": "test-id",
                "BOOKSTACK_TOKEN_SECRET": "test-secret",
            }
        )
        try:
            run([str(BOOKSTACK_SCRIPT), "doctor", "--plan", str(bundle / "plan.json")], env=env)
            run([str(BOOKSTACK_SCRIPT), "upload-test", "--plan", str(bundle / "plan.json")], env=env)
            test_runs = run_manifests(bundle / "runs", "test")
            assert len(test_runs) == 1
            test_run = json.loads(test_runs[0].read_text(encoding="utf-8"))
            assert test_run["status"] == "VERIFIED"
            assert len(test_run["objects"]["pages"]) == 3
            assert len(test_run["objects"]["images"]) == 1
            run([str(BOOKSTACK_SCRIPT), "verify", "--run-manifest", str(test_runs[0])], env=env)

            run(
                [
                    str(BOOKSTACK_SCRIPT),
                    "publish",
                    "--plan",
                    str(bundle / "plan.json"),
                    "--test-run",
                    str(test_runs[0]),
                    "--confirm-plan-sha256",
                    plan["plan_sha256"],
                ],
                env=env,
                expected=2,
            )
            run(
                [
                    str(BOOKSTACK_SCRIPT),
                    "publish",
                    "--plan",
                    str(bundle / "plan.json"),
                    "--test-run",
                    str(test_runs[0]),
                    "--confirm-plan-sha256",
                    plan["plan_sha256"],
                    "--confirm-reviewed",
                ],
                env=env,
            )
            formal_runs = run_manifests(bundle / "runs", "formal")
            assert len(formal_runs) == 1
            formal_run = json.loads(formal_runs[0].read_text(encoding="utf-8"))
            assert formal_run["status"] == "VERIFIED"

            run(
                [
                    str(BOOKSTACK_SCRIPT),
                    "rollback",
                    "--run-manifest",
                    str(formal_runs[0]),
                    "--confirm-run-id",
                    formal_run["run_id"],
                ],
                env=env,
            )
            run(
                [
                    str(BOOKSTACK_SCRIPT),
                    "rollback",
                    "--run-manifest",
                    str(test_runs[0]),
                    "--confirm-run-id",
                    test_run["run_id"],
                ],
                env=env,
            )
            assert not state.chapters and not state.pages and not state.images

            state.corrupt_reads = True
            previous_test_paths = set(run_manifests(bundle / "runs", "test"))
            run(
                [str(BOOKSTACK_SCRIPT), "upload-test", "--plan", str(bundle / "plan.json")],
                env=env,
                expected=2,
            )
            failed_runs = run_manifests(bundle / "runs", "test")
            assert len(failed_runs) == 2
            new_paths = set(failed_runs) - previous_test_paths
            assert len(new_paths) == 1
            failed = json.loads(new_paths.pop().read_text(encoding="utf-8"))
            assert failed["status"] == "ROLLED_BACK_AFTER_FAILURE"
            assert not state.chapters and not state.pages and not state.images

            secret_scan = "\n".join(path.read_text(encoding="utf-8") for path in (bundle / "runs").glob("*.json"))
            assert "test-secret" not in secret_scan and "test-id" not in secret_scan
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)

    print(
        "SELF-TEST PASS: PDF prepare/audit, exact and translated table gates, AI rewrite audit, "
        "plan freeze, test/publish guard, read-back, and rollback"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

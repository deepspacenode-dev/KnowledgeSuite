# Markdown and Ingest Gate

Apply the common structural checks to every ingest artifact, then apply the
artifact-specific gate. An exact conversion and a semantic BookStack rewrite
are not interchangeable.

## Source-level checks

Require:

- UTF-8 without BOM;
- exactly one H1;
- balanced fenced code blocks;
- headings that do not jump levels outside fenced code;
- one ordered `PDF_PAGE` marker for every source page when a conversion
  manifest is present;
- no broken local image references;
- no `file:` or `data:` image URI;
- no remote image URL unless the user explicitly accepts non-durable assets;
- structurally consistent GFM pipe tables and balanced HTML table tags;
- a passing conversion audit and passing table audit.

Do not strip front matter, notices, warnings, revision history, reserved rows,
table notes, page markers, or technical identifiers to make a gate pass.

## Exact artifact gate

For `manual_exact.md`, require the supplied file SHA-256 to match the Markdown
hash recorded by the passing PDF fidelity audit and exact table audit. Preserve
source wording and all visible source content.

## BookStack rewrite gate

When the supplied Markdown hash differs from the audited exact artifact, require
a separate `bookstack_rewrite_audit.json` whose result is PASS and whose source
PDF, exact Markdown, derivative Markdown, and translated table audit hashes all
match.

Additionally require:

- every heading has one unique inline `<a name="..."></a>` anchor;
- hidden `PDF_PAGE` markers remain complete and ordered while visible PDF page
  furniture is absent;
- the `SOURCE_TABLE` marker set is unchanged;
- the selected BookStack table format and translated table audit agree;
- fenced code blocks are unchanged;
- meaningful image paths are retained and no unsupported images are added;
- critical engineering-token recall and precision pass in both directions;
- full-read classification and rewrite attestations are complete.

Do not let a modified or translated file borrow the exact artifact's PASS.

## BookStack split checks

- Split outside fenced code blocks only.
- Do not use generated headings such as `PDF page 12` as BookStack page
  boundaries.
- Keep the split heading inside its page.
- Keep every source page marker exactly once across the complete bundle.
- Give every BookStack page a non-empty, unique name no longer than 255
  characters.
- Preserve page order with explicit priorities.
- Fail on an empty page, excessive page count, or configured page-size limit.

## Asset checks

Copy local images into the frozen bundle by content hash. Do not depend on the
original working directory after the plan is created.

For BookStack image-gallery upload, use JPEG, PNG, GIF, WebP, or AVIF display
assets within the instance upload limit. Keep any unsupported original raster
or vector stream in the conversion evidence, and create a separately logged
display derivative instead of silently recompressing the source asset.

During upload:

1. create the BookStack page;
2. upload local assets to the image gallery against a created page;
3. replace local references with returned BookStack URLs;
4. update the page Markdown;
5. read the page back and compare its normalized Markdown hash.

Record every created image ID for rollback.

## Gate result

Any error blocks test upload. Any warning must appear in the plan report and be
shown before user confirmation.

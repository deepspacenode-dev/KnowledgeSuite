# BookStack Routing

## Correct hierarchy

```text
shelf -> book -> chapter -> pages
```

A shelf cannot directly receive a chapter or page. Resolve an exact test book
inside the test shelf and an exact formal book inside the formal shelf.

## Route

```text
verified exact artifact or independently audited BookStack rewrite
  -> 推送测试 shelf / selected test book
  -> API read-back verification
  -> user visual and classification confirmation
  -> 【AI】手册资料 shelf / selected formal book
  -> API read-back verification
```

## Organization policy

- Default to one audited source manual per frozen plan and chapter. A broader
  component or manual family may share a naming scheme, but separate PDFs keep
  separate source identities, exact audits, rewrite audits, and plans.
- Source manual sections map to pages.
- Derive page grouping dynamically from the source kind and actual section
  content; do not impose a fixed MCU template on sensors, storage, SDK, hardware,
  protocol, or errata documents.
- Record component, manual class, target chapter, and material merge/split
  decisions before freezing a rewritten plan.
- Keep datasheet, reference manual, programming guide, SDK/API, and errata
  identity visible in page titles when several documents share one component.
- Do not create a duplicate chapter with the same exact name in one book.
- Do not silently create a new shelf or formal book.
- Do not move test content into production. Re-publish from the frozen,
  approved local plan.

## Resolution policy

- Match shelf and book names exactly.
- Fail on zero or multiple matches.
- Read the shelf and verify the selected book is assigned to it.
- Re-resolve immediately before test and formal writes.
- Freeze the plan hash before test upload. Formal publish requires the same
  plan hash and a verified test-run manifest.
- When the ingest Markdown differs from the exact audited Markdown, require the
  matching rewrite-audit hash in the frozen plan.

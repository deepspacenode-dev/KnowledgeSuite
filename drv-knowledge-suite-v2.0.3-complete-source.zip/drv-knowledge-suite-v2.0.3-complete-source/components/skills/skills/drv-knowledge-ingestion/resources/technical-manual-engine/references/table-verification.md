# Table Verification Standard

## Purpose

Prevent a table from passing merely because all source words appear somewhere
in Markdown. Engineering tables are useful only when row, column, header, unit,
note, continuation, and merged-cell relationships remain correct. Audit the
source-faithful artifact and a translated BookStack derivative separately.

## Required evidence

For every PDF page, inspect the render for real tables. Do not rely only on
`pdfplumber` candidates.

Run `scripts/table_audit.py init WORK_DIR`. It creates:

- `qa/table_census.csv`: detected candidates plus rows that reviewers add for
  missed real tables;
- `qa/table_census_meta.json`: source/page identity and whole-manual review
  attestation;
- `qa/verified_tables/<table_id>.json`: editable cell-matrix templates.

Do not set `all_pages_reviewed_against_pdf` or
`verified_against_pdf` to true until direct visual review is complete.

## Census rules

- Keep every detected candidate in the census.
- Mark a false detection as `false-detection` and explain it.
- Add every missed real table with a stable ID such as
  `p0034-manual001`.
- Record cross-page continuation in `continuation_of`.
- Record the printed table number/title separately from its internal ID.
- Require one reviewer name and exact source SHA-256 in the census metadata.

## Matrix rules

Represent the verified table as a rectangular, expanded `rows` matrix.

- Include all header rows.
- Expand `rowspan` and `colspan` values into every covered cell.
- Preserve blank, zero, dash, N/A, reserved, and undefined as distinct values.
- Preserve line breaks inside a cell as `\n`.
- Preserve case, punctuation, symbols, units, signs, ranges, and footnote
  markers.
- Do not infer an unreadable cell from a neighboring row.
- Compare cross-page repeated headers and continuation notes explicitly.

Example:

```json
{
  "table_id": "p0012-table003",
  "page": 12,
  "title": "Table 8. Register Fields",
  "representation": "markdown",
  "verified_against_pdf": true,
  "reviewer": "reviewer-name",
  "continuation_of": "",
  "rows": [
    ["Bits", "Name", "Access", "Reset", "Description"],
    ["[31:16]", "RESERVED", "RO", "0x0000", "Reserved"]
  ],
  "notes": ""
}
```

## Markdown binding

Place exactly one source marker immediately before every structured table:

```html
<!-- SOURCE_TABLE:p0012-table003 -->
```

Use a GFM pipe table only for a rectangular grid without merges. Use a
BookStack-compatible HTML table for merged headers. The audit expands the
rendered structure and compares it cell by cell with the verified matrix.

The formal BookStack gate rejects `verified-image` tables by default because
they are not searchable or directly reusable. Allow visual-only tables only
when the user explicitly accepts that limitation and the run report lists each
one.

## Exact and translated modes

Use exact mode for `manual_exact.md`:

```bash
python3 scripts/table_audit.py audit manual_exact.md WORK_DIR \
  --representation source --mode exact
```

Exact mode requires every expanded cell string to equal the visually verified
matrix.

Use translated mode only for a separately reviewed semantic derivative:

```bash
python3 scripts/table_audit.py audit manual_bookstack.md WORK_DIR \
  --representation html --mode translated \
  --output WORK_DIR/qa/bookstack_table_audit.json
```

Translated mode still requires the identical expanded row/column matrix and the
same blank/nonblank state for every cell. It permits human-language prose to be
translated, but compares engineering-token multisets independently in every
cell. Addresses, bit ranges, identifiers, numbers, units, signs, access types,
symbols, and uppercase engineering abbreviations cannot be dropped, changed,
duplicated, or invented.

Translated mode does not prove the Chinese prose is semantically correct. The
AI must read the complete source table and attest cell-by-cell translation
review in the BookStack rewrite record. The separate rewrite audit binds the
translated table report to the derivative SHA-256.

## Hard failures

Fail when any of these is true:

- the whole manual has not been visually reviewed for missed tables;
- a candidate is missing from the census;
- a real table lacks a unique marker or verified matrix;
- row/column dimensions differ;
- any expanded cell differs;
- a table marker occurs on the wrong PDF page;
- an image-only table is not explicitly allowed;
- a continuation, note, unit, or footnote remains unresolved;
- translated mode changes matrix dimensions, blankness, or any cell-level
  engineering-token multiset;
- an audit report is reused for Markdown with a different SHA-256.

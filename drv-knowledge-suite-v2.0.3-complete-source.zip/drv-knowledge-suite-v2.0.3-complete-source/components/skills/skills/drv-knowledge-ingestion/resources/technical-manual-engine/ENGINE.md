# Technical Manual Fidelity Engine

> Internal engine of `drv-knowledge-ingestion`; do not install or trigger as a standalone Skill.

# Ingest Technical Manuals

Run one controlled pipeline:

```text
source PDF -> immutable evidence -> manual_exact.md -> reverse audit
-> exact table audit -> AI full-read classification and semantic rewrite
-> manual_bookstack.md -> translated table and rewrite audits
-> frozen BookStack bundle -> test upload -> user confirmation
-> formal upload -> remote read-back -> retained rollback record
```

Treat the PDF as authoritative. Never call Markdown “100% identical” to a PDF.
Report source, page, text, critical-token, table, image, rewrite, and remote-
storage fidelity separately.

## Load the stage references

- Before conversion, read
  [references/fidelity-standard.md](references/fidelity-standard.md) and
  [references/embedded-manual-profiles.md](references/embedded-manual-profiles.md).
- Before rebuilding source tables, read
  [references/table-verification.md](references/table-verification.md).
- Before classification or Chinese semantic rewrite, read
  [references/bookstack-rewrite.md](references/bookstack-rewrite.md).
- Before the BookStack gate or upload, read
  [references/markdown-gate.md](references/markdown-gate.md),
  [references/bookstack-routing.md](references/bookstack-routing.md), and
  [references/security-and-config.md](references/security-and-config.md).
- Before packaging or rollback, read
  [references/output-contract.md](references/output-contract.md) and
  [references/rollback-policy.md](references/rollback-policy.md).

## Non-negotiable rules

- Keep the source PDF, extracted evidence, and `manual_exact.md` immutable after
  their audits pass.
- Never clean, translate, summarize, or delete source content in
  `manual_exact.md`. Create `manual_bookstack.md` as a separate derivative.
- Do not mix SDK source trees, marketing pages, another revision, or a related
  component manual into an exact conversion.
- Use embedded PDF text and positioned objects first. Enable OCR only for pages
  whose native text is absent or demonstrably corrupt, then verify every OCR
  page against its render.
- Use deterministic scripts for extraction, inventory, hashes, gates, remote
  reads, and rollback. The AI must author semantic rewriting by fully reading
  the relevant source, not by a bulk rewrite or translation script.
- Do not infer that the first image is a logo. Preserve or drop images from
  their reviewed inventory disposition and source meaning.
- Do not auto-approve pages, tables, images, formulas, rewrite attestations, or
  risk flags. Do not lower audit thresholds to obtain PASS.
- Do not publish when any exact-conversion, exact-table, rewrite, translated-
  table, Markdown, test-upload, or read-back gate fails.
- Do not hard-code credentials or print authorization headers.
- Never create, move, update, or delete production BookStack content before
  explicit user confirmation of the test result.
- Never delete an existing target book or shelf during rollback.
- Never upload a Markdown manual that trips the large-manual RAGFlow preflight
  directly to RAGFlow. Run `scripts/ragflow_sanitize.py`, upload only its
  `ragflow/part-*.md`, and retain the source hash and audit artifacts.
- Never silently truncate an embedding input or globally delete `xxx` tokens.

## RAGFlow large-manual derivative

This is a separate derivative after the exact and BookStack artifacts have
been frozen; it is not a replacement for either fidelity artifact.

```bash
python3 scripts/ragflow_sanitize.py audit WORK_DIR/manual_bookstack.md

python3 scripts/ragflow_sanitize.py clean \
  WORK_DIR/manual_bookstack.md WORK_DIR/ragflow_sanitized

python3 scripts/ragflow_sanitize.py gate WORK_DIR/ragflow_sanitized
```

The preflight is blocking when the Markdown is larger than 2 MiB, contains a
line above 2,200 characters, references more than 100 images, contains private
or relative images, or has suspicious pseudo-HTML/unbalanced structures. The
cleaner preserves the source, creates a BookStack-readable derivative, creates
text-first RAGFlow shards, and records every transformation. Apply the
`sanitized-chip-manual-v1` profile to each uploaded shard at document level.

## Stage 1: Resolve and fingerprint the source

Confirm the exact document title, part number, revision, publication date,
language, package/stepping, and document kind. Confirm the user is authorized to
process restricted material.

Record the source SHA-256, byte size, PDF version, page count, metadata,
outline, permissions, and applicable embedded-content profiles.

For multiple PDFs, process and audit each source independently. Do not
concatenate sources merely because they describe the same component.

## Stage 2: Prepare evidence

Run the converter from this skill directory:

```bash
python3 scripts/manual_pipeline.py prepare INPUT.pdf WORK_DIR \
  --dpi 240 \
  --document-kind datasheet \
  --profiles general,interface-protocol
```

Inspect every contact sheet and every flagged page at full resolution. Classify
each page and complete page-specific profiles. Do not treat extractor order as
reading order for multi-column, rotated, drawing-heavy, or table-heavy pages.

## Stage 3: Reconstruct exact Markdown

Build `WORK_DIR/manual_exact.md` from the evidence:

- keep one ordered `<!-- PDF_PAGE:NNNN -->` marker per PDF page;
- preserve all printed text, capitalization, symbols, units, warnings, notes,
  reserved fields, code, API signatures, values, and sequence order;
- use verified text overrides only when native extraction is visibly wrong;
- keep conversion commentary under `qa/`, never in the source body;
- create a clean or translated derivative only after the exact version passes.

For every real table, insert a unique marker immediately before its Markdown or
HTML representation:

```html
<!-- SOURCE_TABLE:p0012-table003 -->
```

Initialize the table census, correct templates against the PDF, and mark
verification only after cell-by-cell review:

```bash
python3 scripts/table_audit.py init WORK_DIR
```

## Stage 4: Run exact and reverse gates

Run both audits:

```bash
python3 scripts/table_audit.py sync WORK_DIR

python3 scripts/manual_pipeline.py audit \
  INPUT.pdf WORK_DIR/manual_exact.md WORK_DIR

python3 scripts/table_audit.py audit \
  WORK_DIR/manual_exact.md WORK_DIR \
  --representation source --mode exact
```

The first audit checks source identity, pages, assets, review state, PDF-to-
Markdown recall, and Markdown-to-PDF precision. The second checks table census
completeness and exact expanded cell matrices. A detected table is not proof
that its column structure is correct.

Stop on any FAIL. Fix the exact Markdown or document a narrow, page-specific
source exception. Never use an exception for unsupported additions.

## Stage 5: Classify and create the BookStack edition

Read [references/bookstack-rewrite.md](references/bookstack-rewrite.md) in full.
Preview source sections to propose a dynamic classification, then read every
planned source section completely before rewriting it. For a material merge,
split, reordering, or multi-document choice, show the classification and source
mapping to the user before committing to that structure.

Author `WORK_DIR/manual_bookstack.md` directly from the verified exact artifact:

- use clear Chinese prose while retaining identifiers, symbols, code, commands,
  values, units, normative strength, and sequence order;
- keep hidden `PDF_PAGE` and `SOURCE_TABLE` evidence markers;
- remove visible PDF page furniture, not hidden provenance;
- add one unique `<a name="..."></a>` anchor to every heading;
- use HTML tables and translate prose cells without altering row/column meaning
  or engineering tokens;
- preserve every meaningful diagram and its original relative path;
- delete logos or duplicates only after reviewed inventory disposition;
- do not over-compress or leave duplicate table representations.

Initialize an unapproved review record after the derivative draft exists:

```bash
python3 scripts/rewrite_audit.py init \
  WORK_DIR/manual_exact.md WORK_DIR/manual_bookstack.md WORK_DIR \
  --target-language zh-CN --table-format html
```

Complete classification, reviewer, attestations, and any narrow exception rows.
Then run the translated table and semantic rewrite gates:

```bash
python3 scripts/table_audit.py audit \
  WORK_DIR/manual_bookstack.md WORK_DIR \
  --representation html --mode translated \
  --output WORK_DIR/qa/bookstack_table_audit.json

python3 scripts/rewrite_audit.py audit \
  WORK_DIR/manual_exact.md WORK_DIR/manual_bookstack.md WORK_DIR \
  --table-audit WORK_DIR/qa/bookstack_table_audit.json
```

If the derivative changes after initialization, run `rewrite_audit.py refresh`
to bind the new hash and invalidate every prior attestation, then re-read and
review the affected content before rerunning both audits.

Cell translation may change prose only. Cell shape, blankness, identifiers,
numbers, signs, units, ranges, access types, and other critical tokens must
remain exact. The rewrite audit also binds source, exact Markdown, derivative,
code blocks, table report, images, and review evidence by SHA-256.

If the user explicitly wants archival source wording in BookStack, skip this
stage and ingest `manual_exact.md`. Do not label that source-language artifact a
Chinese rewrite.

## Stage 6: Build the frozen BookStack bundle

For the rewritten edition, run the local gate and plan with its rewrite audit:

```bash
python3 scripts/bookstack_pipeline.py gate \
  WORK_DIR/manual_bookstack.md \
  --conversion-work WORK_DIR \
  --rewrite-audit WORK_DIR/qa/bookstack_rewrite_audit.json

python3 scripts/bookstack_pipeline.py plan \
  WORK_DIR/manual_bookstack.md BUNDLE_DIR \
  --conversion-work WORK_DIR \
  --rewrite-audit WORK_DIR/qa/bookstack_rewrite_audit.json \
  --chapter-name "COMPONENT_NAME" \
  --test-shelf-name "推送测试" \
  --test-book-name "推送测试" \
  --target-shelf-name "【AI】手册资料" \
  --target-book-name "TARGET_BOOK"
```

For exact-source ingestion, omit `--rewrite-audit` and use
`WORK_DIR/manual_exact.md`. The gate detects whether the supplied Markdown is
the hash-bound exact file or a separately audited derivative; an unaudited
modified file cannot borrow the exact PASS.

Use one source manual per frozen plan. Split source sections into BookStack
pages. Review `plan_report.md`; confirm page titles, order, split boundaries,
target names, source hash, rewrite hash when applicable, and plan hash.

Do not assume a shelf directly owns pages. The hierarchy is:

```text
shelf -> book -> chapter -> pages
```

## Stage 7: Check BookStack read-only

Load credentials from the environment and run:

```bash
python3 scripts/bookstack_pipeline.py doctor --plan BUNDLE_DIR/plan.json
```

Require exact, unique shelf and book name matches. Verify that the selected book
belongs to the selected shelf. Refuse ambiguous matches or a duplicate chapter.

## Stage 8: Upload to the test route

```bash
python3 scripts/bookstack_pipeline.py upload-test \
  --plan BUNDLE_DIR/plan.json
```

The command creates a test chapter, uploads pages and local images, rewrites
image references, reads every page back, compares normalized Markdown hashes,
checks titles/parents/order, and writes a run manifest. It automatically rolls
back objects created by the current failed transaction.

Show the user:

- test shelf, book, chapter, and URLs;
- plan hash, source hash, and rewrite audit hash when applicable;
- created page/image counts;
- local-versus-remote hash result for every page;
- all warnings and unresolved risks.

Pause for explicit confirmation. A successful API response is not confirmation.
Ask the user to inspect headings, anchors, dense tables, code, formulas, images,
symbols, Chinese prose, and representative pages in BookStack.

## Stage 9: Publish only after confirmation

After the user confirms the test rendering and classification, run:

```bash
python3 scripts/bookstack_pipeline.py publish \
  --plan BUNDLE_DIR/plan.json \
  --test-run BUNDLE_DIR/runs/TEST_RUN.json \
  --confirm-plan-sha256 PLAN_SHA256 \
  --confirm-reviewed
```

Publish from the frozen local bundle, not by moving test content. Re-resolve the
formal target and re-check membership and duplicate chapters immediately before
creation.

## Stage 10: Verify and retain rollback evidence

Re-run read-back verification when needed:

```bash
python3 scripts/bookstack_pipeline.py verify \
  --run-manifest BUNDLE_DIR/runs/FORMAL_RUN.json
```

Keep the exact audit, exact table audit, rewrite review, translated table audit,
rewrite audit, plan, test run, formal run, and ID journal together. Do not report
completion unless the formal run remains `VERIFIED`.

Rollback only the IDs recorded in one run:

```bash
python3 scripts/bookstack_pipeline.py rollback \
  --run-manifest BUNDLE_DIR/runs/RUN.json \
  --confirm-run-id RUN_ID
```

Deletion normally moves BookStack content to its recycle bin. Report exactly
which images, pages, and chapter were removed and which failures remain.

## Packaged scripts

- `scripts/manual_pipeline.py`: prepare evidence and run bidirectional exact
  PDF-to-Markdown fidelity audits.
- `scripts/table_audit.py`: enforce exact or translated table geometry and
  cell-level fidelity.
- `scripts/rewrite_audit.py`: initialize nonapproved rewrite records and audit
  AI-authored BookStack derivatives against the exact artifact.
- `scripts/bookstack_pipeline.py`: gate Markdown, freeze an ingest plan, perform
  read-only checks, test/publish, read back, and roll back.
- `scripts/self_test.py`: run offline regression tests against a simulated
  BookStack API; never touches a live instance.

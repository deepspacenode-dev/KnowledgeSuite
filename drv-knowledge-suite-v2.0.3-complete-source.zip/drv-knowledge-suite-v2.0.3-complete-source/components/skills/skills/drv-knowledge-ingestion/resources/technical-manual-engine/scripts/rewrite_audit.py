#!/usr/bin/env python3
"""Initialize and audit an AI-authored BookStack rewrite of an exact manual."""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

from manual_pipeline import PAGE_MARKER_RE, critical_tokens, image_references, markdown_to_plain
from table_audit import TABLE_MARKER_RE


VERSION = "1.0.8"
FENCE_RE = re.compile(r"^[ \t]{0,3}(`{3,}|~{3,})(.*)$")
HEADING_RE = re.compile(r"^(#{1,6})[ \t]+(.+?)\s*$")
HEADING_ANCHOR_RE = re.compile(
    r"^(#{1,6})[ \t]+(.+?)\s*<a\s+name=[\"']([^\"']+)[\"']\s*></a>\s*$",
    re.I,
)
VISIBLE_PAGE_PATTERNS = (
    re.compile(r"(?im)^\s{0,3}#{1,6}\s+(?:第\s*\d+\s*页|PDF\s+page\s+\d+|Page\s+\d+\s+(?:of|/)\s+\d+)\s*$"),
    re.compile(r"(?im)^\s*(?:第\s*\d+\s*页|PDF\s+page\s+\d+|Page\s+\d+\s+(?:of|/)\s+\d+)\s*$"),
    re.compile(r"(?im)^\s*>?\s*共\s*\d+\s*页\s*$"),
    re.compile(r"(?i)(?:第\s*\d+\s*页\s*[-—_:：]?\s*图片\s*\d*|Source\s+image\s+on\s+PDF\s+page\s+\d+)"),
)
PIPE_TABLE_RE = re.compile(
    r"(?m)^\s*\|.*\|\s*$\n^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$"
)
REQUIRED_ATTESTATIONS = (
    "classification_reviewed",
    "all_source_sections_read",
    "semantic_rewrite_reviewed",
    "technical_values_reviewed",
    "table_translation_reviewed",
    "valuable_images_reviewed",
    "deletion_scope_reviewed",
    "visible_pdf_artifacts_reviewed",
    "target_language_reviewed",
    "exceptions_reviewed",
)
MISSING_REASON_CODES = {
    "toc-navigation",
    "repeated-page-furniture",
    "decorative-content",
    "legal-notice",
    "revision-history-summary",
    "duplicate-representation",
}
ADDED_REASON_CODES = {
    "translated-heading",
    "terminology-translation",
    "clarifying-label",
    "repeated-summary",
}


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise SystemExit(f"Cannot read JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise SystemExit(f"Expected a JSON object: {path}")
    return value


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def split_pages(markdown: str) -> tuple[list[int], dict[int, str]]:
    matches = list(PAGE_MARKER_RE.finditer(markdown))
    markers = [int(match.group(1)) for match in matches]
    sections: dict[int, str] = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(markdown)
        sections[int(match.group(1))] = markdown[match.end() : end]
    return markers, sections


def fenced_blocks(markdown: str) -> tuple[list[str], bool]:
    blocks: list[str] = []
    fence_char = ""
    fence_length = 0
    info = ""
    body: list[str] = []
    for line in markdown.splitlines(keepends=True):
        match = FENCE_RE.match(line.rstrip("\r\n"))
        if not fence_char:
            if match:
                token = match.group(1)
                fence_char, fence_length = token[0], len(token)
                info = match.group(2).strip()
                body = []
            continue
        if match and match.group(1)[0] == fence_char and len(match.group(1)) >= fence_length:
            normalized = "".join(body).replace("\r\n", "\n").replace("\r", "\n").rstrip() + "\n"
            blocks.append(info + "\n" + normalized)
            fence_char, fence_length, info, body = "", 0, "", []
        else:
            body.append(line)
    return blocks, bool(fence_char)


def remove_fenced_blocks(markdown: str) -> str:
    output: list[str] = []
    fence_char = ""
    fence_length = 0
    for line in markdown.splitlines(keepends=True):
        match = FENCE_RE.match(line.rstrip("\r\n"))
        if not fence_char:
            if match:
                token = match.group(1)
                fence_char, fence_length = token[0], len(token)
                output.append("\n")
            else:
                output.append(line)
        elif match and match.group(1)[0] == fence_char and len(match.group(1)) >= fence_length:
            fence_char, fence_length = "", 0
            output.append("\n")
    return "".join(output)


def inspect_headings(markdown: str) -> tuple[list[dict[str, Any]], list[str]]:
    headings: list[dict[str, Any]] = []
    failures: list[str] = []
    fence_char = ""
    fence_length = 0
    previous_level = 0
    anchors: list[str] = []
    for line_number, line in enumerate(markdown.splitlines(), start=1):
        fence = FENCE_RE.match(line)
        if fence:
            token = fence.group(1)
            if not fence_char:
                fence_char, fence_length = token[0], len(token)
            elif token[0] == fence_char and len(token) >= fence_length:
                fence_char, fence_length = "", 0
            continue
        if fence_char:
            continue
        heading = HEADING_RE.match(line)
        if not heading:
            continue
        anchored = HEADING_ANCHOR_RE.match(line)
        level = len(heading.group(1))
        title = heading.group(2).strip()
        if not anchored:
            failures.append(f"heading at line {line_number} lacks an inline <a name=...></a> anchor")
            anchor = ""
        else:
            title = anchored.group(2).strip()
            anchor = anchored.group(3).strip()
            anchors.append(anchor)
            if not anchor or re.search(r"\s", anchor):
                failures.append(f"heading at line {line_number} has an empty or whitespace anchor")
        if previous_level and level > previous_level + 1:
            failures.append(f"heading level jumps from H{previous_level} to H{level} at line {line_number}")
        previous_level = level
        headings.append({"line": line_number, "level": level, "title": title, "anchor": anchor})
    if sum(1 for item in headings if item["level"] == 1) != 1:
        failures.append("BookStack rewrite must contain exactly one H1")
    duplicates = sorted(anchor for anchor, count in Counter(anchors).items() if count > 1)
    if duplicates:
        failures.append("duplicate heading anchors: " + ", ".join(duplicates))
    return headings, failures


def parse_page_spec(value: str, maximum: int) -> list[int]:
    pages: set[int] = set()
    for part in (item.strip() for item in value.split(",") if item.strip()):
        if re.fullmatch(r"\d+", part):
            pages.add(int(part))
        elif re.fullmatch(r"\d+-\d+", part):
            start, end = (int(item) for item in part.split("-", 1))
            if start > end:
                raise ValueError("descending page range")
            pages.update(range(start, end + 1))
        else:
            raise ValueError("invalid page expression")
    if not pages or min(pages) < 1 or max(pages) > maximum:
        raise ValueError("page expression is blank or outside the source")
    return sorted(pages)


def is_high_risk(token: str) -> bool:
    return bool(
        re.fullmatch(r"0[xX][0-9A-Fa-f_]+[uUlL]*", token)
        or re.fullmatch(r"0[bB][01_]+[uUlL]*", token)
        or re.fullmatch(r"(?:\[|<)\d+(?::\d+)?(?:\]|>)", token)
        or "_" in token
        or token.endswith("#")
        or (token.isupper() and len(token) > 1)
        or bool(re.search(r"[±≤≥≈≠×÷√∞∑∫∆ΔΩμµ°]", token))
        or (re.search(r"\d", token) and re.search(r"[A-Za-zΩμµ°%]", token))
    )


def english_prose_blocks(markdown: str) -> list[str]:
    value = remove_fenced_blocks(markdown)
    value = re.sub(r"<!--.*?-->", " ", value, flags=re.S)
    value = re.sub(r"!\[[^\]]*\]\([^)]+\)", " ", value)
    value = re.sub(r"<[^>]+>", " ", value)
    value = re.sub(r"https?://\S+", " ", value)
    findings: list[str] = []
    for block in re.split(r"\n\s*\n", value):
        words = re.findall(r"\b[A-Za-z]{3,}\b", block)
        natural_words = [word for word in words if not word.isupper()]
        cjk = len(re.findall(r"[\u3400-\u9fff]", block))
        if len(natural_words) >= 8 and cjk < max(4, len(natural_words) * 2):
            findings.append(re.sub(r"\s+", " ", block).strip()[:180])
    return findings


def init_review(args: argparse.Namespace) -> int:
    exact = Path(args.exact).expanduser().resolve()
    target = Path(args.bookstack).expanduser().resolve()
    work = Path(args.work_dir).expanduser().resolve()
    if not exact.is_file() or not target.is_file() or not (work / "manifest.json").is_file():
        raise SystemExit("init requires exact Markdown, BookStack Markdown, and WORK_DIR/manifest.json")
    review_path = (
        Path(args.review_file).expanduser().resolve()
        if args.review_file
        else work / "qa/bookstack_rewrite_review.json"
    )
    exceptions_path = (
        Path(args.exceptions_file).expanduser().resolve()
        if args.exceptions_file
        else work / "qa/bookstack_rewrite_exceptions.csv"
    )
    if review_path.exists() or exceptions_path.exists():
        raise SystemExit("Refusing to overwrite an existing rewrite review or exception ledger")
    manifest = load_json(work / "manifest.json")
    review = {
        "schema_version": 1,
        "initialized_utc": utc_now(),
        "source_pdf_sha256": manifest.get("source", {}).get("sha256"),
        "exact_markdown_name": exact.name,
        "exact_markdown_sha256": sha256_file(exact),
        "bookstack_markdown_name": target.name,
        "bookstack_markdown_sha256": sha256_file(target),
        "target_language": args.target_language,
        "table_format": args.table_format,
        "classification": {
            "component_name": "",
            "source_document_kind": manifest.get("conversion", {}).get("document_kind"),
            "manual_class": "",
            "target_chapter": "",
            "merge_split_notes": "",
        },
        "attestations": {name: False for name in REQUIRED_ATTESTATIONS},
        "allow_source_language_prose": False,
        "allow_page_image_only": False,
        "reviewer": "",
        "reviewed_utc": "",
        "notes": "",
    }
    write_json(review_path, review)
    exceptions_path.parent.mkdir(parents=True, exist_ok=True)
    with exceptions_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["direction", "token", "count", "source_pages", "reason_code", "reason", "reviewer"])
    print(f"Rewrite review initialized: {review_path}")
    print(f"Exception ledger initialized: {exceptions_path}")
    return 0


def refresh_review(args: argparse.Namespace) -> int:
    """Bind a revised derivative and invalidate every prior rewrite attestation."""
    exact = Path(args.exact).expanduser().resolve()
    target = Path(args.bookstack).expanduser().resolve()
    work = Path(args.work_dir).expanduser().resolve()
    review_path = (
        Path(args.review_file).expanduser().resolve()
        if args.review_file
        else work / "qa/bookstack_rewrite_review.json"
    )
    if not exact.is_file() or not target.is_file() or not review_path.is_file():
        raise SystemExit("refresh requires exact Markdown, revised BookStack Markdown, and an existing review file")
    review = load_json(review_path)
    if review.get("exact_markdown_sha256") != sha256_file(exact):
        raise SystemExit("Refusing to refresh a review bound to a different exact Markdown")
    review["bookstack_markdown_name"] = target.name
    review["bookstack_markdown_sha256"] = sha256_file(target)
    review["refreshed_utc"] = utc_now()
    review["attestations"] = {name: False for name in REQUIRED_ATTESTATIONS}
    review["reviewer"] = ""
    review["reviewed_utc"] = ""
    write_json(review_path, review)
    print(f"Rewrite review refreshed and all attestations invalidated: {review_path}")
    return 0


def audit(args: argparse.Namespace) -> int:
    exact_path = Path(args.exact).expanduser().resolve()
    target_path = Path(args.bookstack).expanduser().resolve()
    work = Path(args.work_dir).expanduser().resolve()
    review_path = (
        Path(args.review_file).expanduser().resolve()
        if args.review_file
        else work / "qa/bookstack_rewrite_review.json"
    )
    exceptions_path = (
        Path(args.exceptions_file).expanduser().resolve()
        if args.exceptions_file
        else work / "qa/bookstack_rewrite_exceptions.csv"
    )
    table_audit_path = (
        Path(args.table_audit).expanduser().resolve()
        if args.table_audit
        else work / "qa/bookstack_table_audit.json"
    )
    required = (
        exact_path,
        target_path,
        work / "manifest.json",
        work / "qa/audit_report.json",
        work / "qa/table_audit.json",
        review_path,
        exceptions_path,
        table_audit_path,
    )
    if not all(path.is_file() for path in required):
        missing = [str(path) for path in required if not path.is_file()]
        raise SystemExit("Rewrite audit is missing required files: " + ", ".join(missing))

    exact = exact_path.read_text(encoding="utf-8")
    target = target_path.read_text(encoding="utf-8")
    manifest = load_json(work / "manifest.json")
    fidelity = load_json(work / "qa/audit_report.json")
    exact_table_audit = load_json(work / "qa/table_audit.json")
    translated_table_audit = load_json(table_audit_path)
    review = load_json(review_path)
    failures: list[str] = []
    warnings: list[str] = []

    source_hash = str(manifest.get("source", {}).get("sha256") or "")
    exact_hash = sha256_file(exact_path)
    target_hash = sha256_file(target_path)
    if fidelity.get("result") != "PASS" or fidelity.get("markdown_sha256") != exact_hash:
        failures.append("exact Markdown is not bound to a passing fidelity audit")
    if exact_table_audit.get("result") != "PASS" or exact_table_audit.get("markdown_sha256") != exact_hash:
        failures.append("exact Markdown is not bound to a passing exact table audit")
    if review.get("source_pdf_sha256") != source_hash:
        failures.append("rewrite review source PDF hash differs from the conversion manifest")
    if review.get("exact_markdown_sha256") != exact_hash:
        failures.append("rewrite review exact Markdown hash differs")
    if review.get("bookstack_markdown_sha256") != target_hash:
        failures.append("rewrite review BookStack Markdown hash differs")
    if translated_table_audit.get("result") != "PASS":
        failures.append("translated BookStack table audit is not PASS")
    if translated_table_audit.get("markdown_sha256") != target_hash:
        failures.append("translated table audit is not bound to the BookStack Markdown")
    if translated_table_audit.get("source_sha256") != source_hash:
        failures.append("translated table audit source hash differs")
    if translated_table_audit.get("comparison_mode") != "translated":
        failures.append("BookStack table audit did not use translated comparison mode")
    if translated_table_audit.get("representation_mode") != review.get("table_format"):
        failures.append("BookStack table audit representation differs from the rewrite review")

    classification = review.get("classification") or {}
    for key in ("component_name", "manual_class", "target_chapter"):
        if not str(classification.get(key) or "").strip():
            failures.append(f"rewrite classification field is blank: {key}")
    attestations = review.get("attestations") or {}
    for name in REQUIRED_ATTESTATIONS:
        if attestations.get(name) is not True:
            failures.append(f"rewrite attestation is not complete: {name}")
    if not str(review.get("reviewer") or "").strip() or not str(review.get("reviewed_utc") or "").strip():
        failures.append("rewrite reviewer or review timestamp is blank")

    exact_markers, exact_sections = split_pages(exact)
    target_markers, _ = split_pages(target)
    if target_markers != exact_markers or target_markers != list(range(1, len(exact_markers) + 1)):
        failures.append("hidden PDF_PAGE provenance markers are missing, duplicated, or reordered")

    headings, heading_failures = inspect_headings(target)
    failures.extend(heading_failures)
    visible_target = remove_fenced_blocks(target)
    for pattern in VISIBLE_PAGE_PATTERNS:
        if pattern.search(re.sub(r"<!--.*?-->", " ", visible_target, flags=re.S)):
            failures.append("visible PDF pagination or generated image-alt text remains")
            break

    exact_tables = Counter(TABLE_MARKER_RE.findall(exact))
    target_tables = Counter(TABLE_MARKER_RE.findall(target))
    if exact_tables != target_tables or any(count != 1 for count in target_tables.values()):
        failures.append("SOURCE_TABLE marker set/count differs from the exact Markdown")
    if review.get("table_format") == "html":
        if PIPE_TABLE_RE.search(remove_fenced_blocks(target)):
            failures.append("GFM pipe table remains although the BookStack table format is html")
        html_table_count = len(re.findall(r"<table\b", remove_fenced_blocks(target), re.I))
        if html_table_count != len(target_tables):
            failures.append("HTML table count does not match structured SOURCE_TABLE markers")

    exact_code, exact_code_unclosed = fenced_blocks(exact)
    target_code, target_code_unclosed = fenced_blocks(target)
    if exact_code_unclosed or target_code_unclosed:
        failures.append("exact or BookStack Markdown has an unclosed fenced code block")
    if Counter(exact_code) != Counter(target_code):
        failures.append("fenced code blocks were removed, changed, duplicated, or invented")

    exact_refs = Counter(image_references(exact))
    target_refs = Counter(image_references(target))
    inventory = read_csv(work / "qa/image_inventory.csv")
    allowed_omissions: Counter[str] = Counter()
    required_refs: Counter[str] = Counter()
    covered_by_page_image: list[str] = []
    for row in inventory:
        status = row.get("review_status", "").strip()
        reference = row.get("md_reference", "").strip() or row.get("asset", "").strip()
        if status in {"verified-embedded", "verified-crop"} and reference:
            required_refs[reference] += 1
        elif status in {"decorative", "duplicate", "not-meaningful"} and reference:
            allowed_omissions[reference] += 1
        elif status == "covered-by-page-image":
            covered_by_page_image.append(row.get("image_id", "?"))
    if not inventory:
        required_refs = exact_refs.copy()
    missing_refs = (exact_refs - allowed_omissions) - target_refs
    missing_required = required_refs - target_refs
    extra_refs = target_refs - exact_refs
    if missing_refs or missing_required:
        failures.append(
            "valuable image references were removed or their paths changed: "
            + repr(dict(missing_refs + missing_required))
        )
    if extra_refs:
        failures.append("BookStack rewrite introduced unsupported image references: " + repr(dict(extra_refs)))
    if covered_by_page_image:
        message = "meaningful visuals still rely only on full-page evidence: " + ", ".join(covered_by_page_image[:20])
        if review.get("allow_page_image_only") is True:
            warnings.append(message)
        else:
            failures.append(message)
    for ref in target_refs:
        if re.match(r"^(?:https?:|data:|file:)", ref, re.I):
            continue
        if not (target_path.parent / ref).resolve().is_file():
            failures.append(f"broken local image reference in BookStack Markdown: {ref}")

    source_critical = Counter(critical_tokens(markdown_to_plain(exact)))
    target_critical = Counter(critical_tokens(markdown_to_plain(target)))
    raw_missing = source_critical - target_critical
    raw_unexpected = target_critical - source_critical
    allowed_missing: Counter[str] = Counter()
    allowed_added: Counter[str] = Counter()
    exception_failures: list[str] = []
    for row_number, row in enumerate(read_csv(exceptions_path), start=2):
        if not any(str(value or "").strip() for value in row.values()):
            continue
        direction = row.get("direction", "").strip()
        token = row.get("token", "")
        reason_code = row.get("reason_code", "").strip()
        reason = row.get("reason", "").strip()
        reviewer = row.get("reviewer", "").strip()
        try:
            count = int(row.get("count", ""))
            pages = parse_page_spec(row.get("source_pages", ""), len(exact_markers))
        except ValueError as exc:
            exception_failures.append(f"exception row {row_number}: {exc}")
            continue
        allowed_reasons = MISSING_REASON_CODES if direction == "missing" else ADDED_REASON_CODES
        if direction not in {"missing", "added"} or count <= 0 or not token:
            exception_failures.append(f"exception row {row_number}: invalid direction, token, or count")
            continue
        if reason_code not in allowed_reasons or not reason or not reviewer:
            exception_failures.append(f"exception row {row_number}: invalid reason code or blank review evidence")
            continue
        page_tokens = Counter()
        for page in pages:
            page_tokens.update(critical_tokens(markdown_to_plain(exact_sections.get(page, ""))))
        if direction == "missing" and page_tokens[token] < count:
            exception_failures.append(f"exception row {row_number}: token/count is not supported by cited source pages")
            continue
        if is_high_risk(token) and direction == "missing":
            exception_failures.append(f"exception row {row_number}: high-risk source token cannot be omitted")
            continue
        if is_high_risk(token) and direction == "added" and source_critical[token] == 0:
            exception_failures.append(f"exception row {row_number}: a new high-risk token cannot be introduced")
            continue
        (allowed_missing if direction == "missing" else allowed_added)[token] += count
    failures.extend(exception_failures)
    unresolved_missing = raw_missing - allowed_missing
    unresolved_unexpected = raw_unexpected - allowed_added
    if unresolved_missing:
        failures.append("unresolved missing critical tokens: " + repr(dict(unresolved_missing.most_common(40))))
    if unresolved_unexpected:
        failures.append("unresolved unexpected critical tokens: " + repr(dict(unresolved_unexpected.most_common(40))))

    prose_findings = english_prose_blocks(target) if review.get("target_language") == "zh-CN" else []
    if prose_findings and review.get("allow_source_language_prose") is not True:
        failures.append("untranslated English prose remains: " + " | ".join(prose_findings[:8]))
    elif prose_findings:
        warnings.append(f"source-language prose explicitly retained in {len(prose_findings)} block(s)")

    source_total = sum(source_critical.values())
    target_total = sum(target_critical.values())
    recall = 1.0 if source_total == 0 else (source_total - sum(unresolved_missing.values())) / source_total
    precision = 1.0 if target_total == 0 else (target_total - sum(unresolved_unexpected.values())) / target_total
    result = "PASS" if not failures else "FAIL"
    report = {
        "schema_version": 1,
        "result": result,
        "audited_utc": utc_now(),
        "rewrite_audit_version": VERSION,
        "source_pdf_sha256": source_hash,
        "exact_markdown_name": exact_path.name,
        "exact_markdown_sha256": exact_hash,
        "bookstack_markdown_name": target_path.name,
        "bookstack_markdown_sha256": target_hash,
        "review_file_sha256": sha256_file(review_path),
        "translated_table_audit_sha256": sha256_file(table_audit_path),
        "target_language": review.get("target_language"),
        "table_format": review.get("table_format"),
        "metrics": {
            "source_pages": len(exact_markers),
            "headings": len(headings),
            "tables": len(target_tables),
            "images": sum(target_refs.values()),
            "code_blocks": len(target_code),
            "critical_token_recall_after_exceptions": recall,
            "critical_token_precision_after_exceptions": precision,
            "exception_rows": len(read_csv(exceptions_path)),
        },
        "warnings": list(dict.fromkeys(warnings)),
        "failures": list(dict.fromkeys(failures)),
    }
    output_path = (
        Path(args.output).expanduser().resolve()
        if args.output
        else work / "qa/bookstack_rewrite_audit.json"
    )
    write_json(output_path, report)
    lines = [
        "# BookStack Rewrite Audit",
        "",
        f"**Result: {result}**",
        "",
        f"- Source pages: {len(exact_markers)}",
        f"- Tables: {len(target_tables)}",
        f"- Images: {sum(target_refs.values())}",
        f"- Code blocks: {len(target_code)}",
        f"- Critical-token recall: {recall:.6f}",
        f"- Critical-token precision: {precision:.6f}",
    ]
    if warnings:
        lines.extend(["", "## Warnings", ""])
        lines.extend(f"- {item}" for item in warnings)
    if failures:
        lines.extend(["", "## Failures", ""])
        lines.extend(f"- {item}" for item in failures[:500])
    output_path.with_suffix(".md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"BookStack rewrite audit: {result}; report: {output_path}")
    return 0 if result == "PASS" else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=VERSION)
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init", help="Create an unapproved rewrite review and exception ledger")
    init_parser.add_argument("exact")
    init_parser.add_argument("bookstack")
    init_parser.add_argument("work_dir")
    init_parser.add_argument("--target-language", default="zh-CN")
    init_parser.add_argument("--table-format", choices=("html", "markdown"), default="html")
    init_parser.add_argument("--review-file")
    init_parser.add_argument("--exceptions-file")
    init_parser.set_defaults(func=init_review)

    refresh_parser = subparsers.add_parser(
        "refresh",
        help="Bind revised BookStack Markdown and reset every prior attestation",
    )
    refresh_parser.add_argument("exact")
    refresh_parser.add_argument("bookstack")
    refresh_parser.add_argument("work_dir")
    refresh_parser.add_argument("--review-file")
    refresh_parser.set_defaults(func=refresh_review)

    audit_parser = subparsers.add_parser("audit", help="Audit a reviewed BookStack rewrite against exact Markdown")
    audit_parser.add_argument("exact")
    audit_parser.add_argument("bookstack")
    audit_parser.add_argument("work_dir")
    audit_parser.add_argument("--review-file")
    audit_parser.add_argument("--exceptions-file")
    audit_parser.add_argument("--table-audit")
    audit_parser.add_argument("--output")
    audit_parser.set_defaults(func=audit)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

# 异构格式知识导入

异构格式知识导入是指将 PDF、DOCX、Markdown、HTML、TXT、PPTX 等已有资料，通过格式识别、内容解析、知识类型判断、结构标准化和质量治理，转换为 DrvDocs 标准 Markdown，并提交 BookStack 审核。

格式不决定知识类型。例如 DOCX 可以是项目方案、技术专题或案例；PDF 可以是芯片手册、策略文档或专项方案。

PDF 若识别为 datasheet/reference manual/register/API/SDK 等高保真技术手册，应优先转入 `resources/technical-manual-engine/`；普通 PDF 走通用导入。

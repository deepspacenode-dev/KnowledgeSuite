# Unified Ingest Contract

知识类型与来源格式必须分离。

- `source_mode`: `ai_context | file_import | existing_markdown | manual_input`
- `source_format`: `conversation | md | txt | html | docx | pdf | pptx | text`
- `material_type`: `cases | manuals | tech_notes | project_docs | docs`

所有路径最终收敛到 Canonical Markdown：

- `content.md`
- `metadata.yaml`
- `source_manifest.json`
- `state.json`
- `preview.md`

提交到 BookStack 前强制：`status: draft`、`rag_enabled: false`。BookStack 提交仅代表待网站审批，不代表已进入 RAGFlow。

# Knowledge Commands

Use commands as the deterministic execution layer. Natural-language requests should be resolved to these operations internally.

| User intent | Standard command |
|---|---|
| 所有案例 / 案例有哪些 | `/kb:cases` |
| 网络相关案例 | `/kb:cases network` |
| Sensor 手册有哪些 | `/kb:manuals sensor` |
| 查资料 | `/kb:search <query>` |
| 结合知识库分析 | `/kb:recall <query>` |
| 知识库状态 | `/kb:status` |
| 某类知识在哪里 | `/kb:where <term>` |
| 知识缺口 | `/kb:gaps` |
| 知识图谱 | `/kb:graph <term>` |
| 第一次认识知识库 | `/kb bootstrap` |
| 更新知识目录 | `/kb refresh` |

Rules:

1. Never ask for a Dataset name when the logical domain is clear.
2. “所有/全部/有哪些/列出” uses Browse/Enumerate, never Top-K Recall.
3. If the configured Dataset profile does not match the live names, Catalog discovery may resolve another known profile automatically.
4. Explicit commands bypass natural-language intent guessing.

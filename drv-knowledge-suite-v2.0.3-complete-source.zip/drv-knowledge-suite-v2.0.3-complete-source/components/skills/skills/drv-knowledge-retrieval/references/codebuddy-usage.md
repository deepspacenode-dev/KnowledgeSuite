# CodeBuddy Usage

## Purpose

Use `drv-knowledge` as a portable knowledge Skill instead of installing the whole DrvAgent workflow system. It supports three daily tasks:

- ask real embedded-driver questions and get traceable Recall v2 results;
- record missing knowledge and produce closure todos;
- convert chip manuals or technical PDFs into local assets ready for BookStack and RAGFlow review.

## Install

Copy the `drv-knowledge` folder into the CodeBuddy skill directory used by the company environment. Keep the folder name unchanged:

```text
skills/drv-knowledge/
```

If legacy workflows still mention `rag-search` or `bookstack-fetch`, also copy those folders. They are compatibility documents and point back to `drv-knowledge`.

## Commands

Run a local self-check:

```bash
python -B -X utf8 skills/drv-knowledge/scripts/drvkb_entry.py doctor --json
```

Run fixture recall:

```bash
python -B -X utf8 skills/drv-knowledge/scripts/drvkb_entry.py recall --query "PHY up 但是无流量" --mode fixture --json
```

Run Knowledge Gap:

```bash
python -B -X utf8 skills/drv-knowledge/scripts/drvkb_entry.py gap --data-dir tmp/kg_demo analyze
```

Run Manual Ingest doctor:

```bash
python -B -X utf8 skills/drv-knowledge/scripts/drvkb_entry.py manual doctor --json
```

## Dependencies

Recall and Knowledge Gap use the Python standard library in fixture mode.

Manual PDF preparation requires:

```bash
异构格式依赖不在知识获取客户端安装；请使用独立知识入库环境。
```

OCR is optional and requires a local Tesseract installation. BookStack publishing is optional and uses only environment variables for credentials.

## Safe Defaults

The Skill defaults to local-only output:

- no automatic BookStack writes;
- no automatic RAGFlow writes;
- no copied API keys;
- no printed token values;
- no publishing before user-confirmed test upload.

## Acceptance Commands

Standalone package check:

```bash
python -B -X utf8 tests/drv_knowledge/run_unit_tests.py
python -B -X utf8 skills/drv-knowledge/scripts/drvkb_entry.py doctor --json
```

Full DrvAgent workspace regression, if the full repository is available:

```bash
python -B -X utf8 tests/recall/run_unit_tests.py
python -B -X utf8 tests/knowledge_gap/run_unit_tests.py
```

## Manual Asset Export

After a reviewed `manual_bookstack.md` or `manual_rag_clean.md` exists, generate a draft RAGFlow JSONL manifest:

```bash
python -B -X utf8 skills/drv-knowledge/scripts/drvkb_entry.py manual build-rag-manifest --markdown out/rtl8211/manual_bookstack.md --output out/rtl8211/ragflow_import_manifest.jsonl --vendor Realtek --chip RTL8211 --module network --source-url bookstack://manuals/rtl8211 --json
```

Keep the output in `draft` state until a reviewer marks useful chunks as `verified` and sets `rag_enabled=true` in the import pipeline.

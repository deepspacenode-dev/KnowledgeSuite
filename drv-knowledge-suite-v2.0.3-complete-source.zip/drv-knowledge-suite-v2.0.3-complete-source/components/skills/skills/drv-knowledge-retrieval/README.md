# drv-knowledge-retrieval v2.0.3

Drv Knowledge Suite 的知识获取 Skill。

职责：Browse / Search / Recall / Cases / Manuals / Graph / Gap Query / Status / Evaluate。

不负责：AI 生成知识、异构文件导入、BookStack 写入。

共享配置、Dataset Contract、BookStack/RAGFlow/Governance 客户端来自 `drv-knowledge-core`。


## Local Markdown manuals (V1.0.6)

Chip/platform manuals can be placed under `~/.drvknowledge/manuals/` (or the release `manuals/` directory before installation). The manuals domain is hybrid: RAGFlow manuals remain supported, while local Markdown is indexed with Python stdlib and participates in Recall V3 even when the RAGFlow manual dataset is empty or ingestion is unavailable. Public local-manual results include `file://` + `local_path`, or an HTTP(S) BookStack URL when supplied in Markdown front matter.

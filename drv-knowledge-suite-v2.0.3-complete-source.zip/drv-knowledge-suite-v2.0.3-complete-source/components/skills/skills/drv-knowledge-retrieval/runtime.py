"""Compatibility bridge to drv-knowledge-core."""
from __future__ import annotations
import sys
from pathlib import Path

# Priority is intentional:
# 1) the core shipped beside the current suite/staging tree;
# 2) the already-installed core as a compatibility fallback.
#
# IMPORTANT: stop after the first valid candidate. Inserting every candidate
# at sys.path[0] reverses priority and can make an upgrade load the old core.
_candidates = [
    Path(__file__).resolve().parents[2] / "lib",
    Path.home() / ".codebuddy" / "lib",
]
_selected_core_parent = None
for _p in _candidates:
    if (_p / "drv_knowledge_core").is_dir():
        if str(_p) not in sys.path:
            sys.path.insert(0, str(_p))
        _selected_core_parent = _p
        break

try:
    from drv_knowledge_core.runtime import *  # noqa: F401,F403
    from drv_knowledge_core.runtime import CONFIG_PATH as CORE_CONFIG_PATH
except Exception as exc:
    raise RuntimeError(
        "drv-knowledge-core not found or incompatible. Install the full drv-knowledge-suite."
    ) from exc

"""Normalize driver-development questions into Recall V3 structured queries."""
from __future__ import annotations
import re
from typing import Any
from .config_loader import load_shared_config

DIAGNOSIS_TERMS=["失败","异常","不通","没流量","无流量","不出图","timeout","panic","挂载失败","错误","丢包","不稳定","link up","link_up"]
REVIEW_TERMS=["review","审查","代码审查","patch","diff"]
MIGRATION_TERMS=["平台迁移","迁移","升级后","移植"]
DEVELOPMENT_TERMS=["开发","适配流程","驱动适配","新增驱动","实现"]
MANUAL_TERMS=["手册","寄存器","bit","是什么意思","怎么配置","标准流程","datasheet","reference manual"]

SYMPTOM_ALIASES={
    "link_up":["link up","link_up","链路已起","链路正常","phy up","link正常"],
    "no_traffic":["没流量","无流量","no traffic","ping不通","ping 不通","无报文","没有流量","网络不通"],
    "packet_loss":["丢包","packet loss","掉包"],
    "unstable":["不稳定","偶现","时好时坏","flap","抖动"],
    "probe_fail":["probe fail","probe失败","probe 失败","探测失败"],
    "no_video":["不出图","无图","黑屏","no image","no video"],
    "mount_fail":["挂载失败","mount failed","rootfs mount","unable to mount"],
    "panic":["kernel panic","panic"],
    "timeout":["timeout","超时"],
    "io_error":["i/o error","io error","读写错误","bad node","bad magic"],
}

STOPWORDS={"但是","但是没有","问题","怎么","如何","一下","目前","之前","有没有","相关","这个","那个","the","a","an","is","but","with","and","or"}


def _contains_any(text:str,terms:list[str])->bool:
    lower=text.lower(); return any(t.lower() in lower for t in terms)


def _detect_task_type(q:str)->str:
    if _contains_any(q,REVIEW_TERMS): return "review"
    if _contains_any(q,MIGRATION_TERMS) and not _contains_any(q,DIAGNOSIS_TERMS): return "platform_migration"
    if _contains_any(q,DEVELOPMENT_TERMS): return "driver_development"
    if _contains_any(q,DIAGNOSIS_TERMS): return "diagnosis"
    if _contains_any(q,MANUAL_TERMS): return "manual_lookup"
    return "diagnosis"


def _best_match(q:str, mapping:dict[str,list[str]])->str:
    lower=q.lower(); best="unknown"; score=0
    for key,terms in mapping.items():
        cur=sum(1 for t in terms if t.lower() in lower)
        if cur>score: best,score=key,cur
    return best


def _matched_aliases(q:str,mapping:dict[str,list[str]],selected:str)->list[str]:
    lower=q.lower(); out=[]
    for term in mapping.get(selected,[]):
        if term.lower() in lower and term not in out: out.append(term)
    return out


def _detect_symptoms(q:str)->list[str]:
    lower=q.lower(); out=[]
    for key,terms in SYMPTOM_ALIASES.items():
        if any(t.lower() in lower for t in terms): out.append(key)
    return out


def _keywords(q:str)->list[str]:
    # Preserve engineering identifiers and useful Chinese fragments; discard common filler.
    raw=re.findall(r"[A-Za-z][A-Za-z0-9_.+-]{1,}|[\u4e00-\u9fff]{2,8}",q)
    out=[]
    for token in raw:
        t=token.strip(); low=t.lower()
        if low in STOPWORDS or len(low)<2: continue
        if t not in out: out.append(t)
    return out[:16]


def _expanded_queries(q:str,task_type:str,module:str,entities:list[str],chip:str,symptoms:list[str])->list[dict[str,str]]:
    joined=" ".join([*entities, "" if chip=="unknown" else chip]).strip()
    variants=[{"kind":"raw","query":q}]
    if module=="network":
        standard=f"{joined} PHY MAC RGMII link up no traffic VLAN ARP".strip()
        symptom="以太网 PHY link up 无流量 MAC 无报文 RGMII delay 排查"
    elif module=="sensor":
        standard=f"{joined} sensor I2C probe reset gpio clock regulator DTS MIPI VI".strip()
        symptom="sensor probe 失败 或 probe 成功不出图 MIPI VI clock reset 排查"
    elif module=="boot":
        standard=f"{joined} rootfs mount failed bootargs UBIFS initramfs partition kernel panic".strip()
        symptom="启动 rootfs 挂载失败 kernel panic 分区 bootargs UBI UBIFS 排查"
    elif module=="storage":
        standard=f"{joined} flash nand nor emmc io error partition filesystem".strip()
        symptom="存储 flash 读写错误 分区 文件系统 启动异常 排查"
    elif module=="memory":
        standard=f"{joined} DDR CMA MMZ reserved-memory ramdisk memory corruption".strip()
        symptom="内存 reserved-memory CMA MMZ ramdisk 越界 踩内存 排查"
    else:
        standard=f"{q} {task_type} {joined}".strip()
        symptom=f"{joined} {' '.join(symptoms)} 历史案例 根因 解决方案".strip()
    for kind,text in (("engineering",standard),("symptom",symptom)):
        if text and all(text!=x["query"] for x in variants): variants.append({"kind":kind,"query":text})
    return variants[:3]


def normalize_query(query:str, aliases:dict[str,list[str]]|None=None)->dict[str,Any]:
    cfg=load_shared_config(); raw=query.strip(); modules=aliases or cfg.get("modules",{})
    module=_best_match(raw,modules); platform=_best_match(raw,cfg.get("platforms",{})); chip=_best_match(raw,cfg.get("chips",{})); project=_best_match(raw,cfg.get("projects",{}))
    module_entities=_matched_aliases(raw,modules,module)
    entities=list(module_entities)
    if chip!="unknown": entities.append(chip)
    task_type=_detect_task_type(raw); symptoms=_detect_symptoms(raw)
    variants=_expanded_queries(raw,task_type,module,entities,chip,symptoms)
    return {
        "raw_query":raw,"task_type":task_type,"module":module,"platform":platform,"chip":chip,"project":project,
        "entities":list(dict.fromkeys(entities)),"keywords":_keywords(raw),"symptoms":symptoms,
        "query_variants":variants,"expanded_queries":[x["query"] for x in variants]
    }

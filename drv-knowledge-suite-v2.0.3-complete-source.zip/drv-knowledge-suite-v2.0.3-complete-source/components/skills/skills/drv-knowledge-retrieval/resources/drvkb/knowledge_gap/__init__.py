"""Knowledge gap collection and closure loop for DrvAgent v1.0."""

from .gap_collector import collect_from_recall, collect_gap_event
from .gap_store import GapStore

__all__ = ["GapStore", "collect_gap_event", "collect_from_recall"]

"""Generate weekly Markdown and HTML reports for knowledge gaps."""

from __future__ import annotations

from datetime import datetime
from html import escape
from pathlib import Path
from typing import Any

from .gap_store import GapStore


def generate_report(
    *,
    store: GapStore,
    week: str = "current",
    formats: list[str] | None = None,
) -> dict[str, str]:
    formats = formats or ["md"]
    resolved_week = _resolve_week(week)
    events = store.load_events()
    gaps = store.load_gap_items()
    todos = store.load_todos()
    markdown = _render_markdown(resolved_week, events, gaps, todos)
    outputs: dict[str, str] = {}
    store.ensure_dirs()
    if "md" in formats:
        md_path = store.reports_dir / f"knowledge_gap_weekly_{resolved_week}.md"
        md_path.write_text(markdown, encoding="utf-8")
        outputs["md"] = str(md_path)
    if "html" in formats:
        html_path = store.reports_dir / f"knowledge_gap_weekly_{resolved_week}.html"
        html_path.write_text(_render_html(markdown), encoding="utf-8")
        outputs["html"] = str(html_path)
    return outputs


def _resolve_week(week: str) -> str:
    if week != "current":
        return week
    year, week_number, _ = datetime.now().isocalendar()
    return f"{year}-W{week_number:02d}"


def _render_markdown(
    week: str,
    events: list[dict[str, Any]],
    gaps: list[dict[str, Any]],
    todos: list[dict[str, Any]],
) -> str:
    high_priority = sorted(gaps, key=lambda gap: (-_priority_rank(gap.get("priority", "medium")), -gap.get("event_count", 0)))[:5]
    done_count = sum(1 for todo in todos if todo.get("status") == "done")
    lines = [
        f"# DrvAgent 知识缺口周报 {week}",
        "",
        "## 本周知识缺口概览",
        "",
        f"- 原始缺口事件: `{len(events)}`",
        f"- 聚合缺口主题: `{len(gaps)}`",
        f"- 待办总数: `{len(todos)}`",
        f"- 已完成待办: `{done_count}`",
        "",
        "## 高频缺口 Top 5",
        "",
    ]
    if not high_priority:
        lines.append("- 本周暂无已聚合缺口。")
    for index, gap in enumerate(high_priority, start=1):
        lines.extend([
            f"{index}. **{gap.get('title', '')}**",
            f"   - 模块: `{gap.get('module', 'unknown')}`",
            f"   - 优先级: `{gap.get('priority', 'medium')}`",
            f"   - 出现次数: `{gap.get('event_count', 0)}`",
            f"   - 背景: {gap.get('typical_background', '')}",
            f"   - 影响: {gap.get('impact', '')}",
            f"   - 建议补充: {_suggestion_text(gap)}",
            f"   - 验证问题: {'；'.join(gap.get('validation_questions', []))}",
        ])
    lines.extend([
        "",
        "## 按模块分类的缺口",
        "",
    ])
    for module in sorted({gap.get("module", "unknown") for gap in gaps}):
        module_gaps = [gap for gap in gaps if gap.get("module", "unknown") == module]
        lines.append(f"- `{module}`: {len(module_gaps)} 个缺口")
    lines.extend([
        "",
        "## 建议补充清单",
        "",
    ])
    for todo in todos:
        lines.append(f"- [{todo.get('status', 'todo')}] {todo.get('task_title', '')} -> {todo.get('target_dataset', '')}")
    lines.extend([
        "",
        "## 待办状态",
        "",
        _todo_status_summary(todos),
        "",
        "## 已补齐内容",
        "",
        _done_todo_summary(todos),
        "",
        "## 验证结果",
        "",
        _validation_summary(todos),
        "",
        "## 下周建议重点",
        "",
        _next_week_focus(high_priority),
        "",
    ])
    return "\n".join(lines)


def _render_html(markdown: str) -> str:
    body = "\n".join(_markdown_line_to_html(line) for line in markdown.splitlines())
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>Knowledge Gap Weekly Report</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 32px; line-height: 1.65; color: #172033; }}
h1, h2 {{ color: #0f3b57; }}
code {{ background: #eef3f7; padding: 2px 5px; border-radius: 4px; }}
li {{ margin: 4px 0; }}
.report {{ max-width: 1080px; margin: 0 auto; }}
</style>
</head>
<body><main class="report" aria-label="knowledge gap weekly report">{body}</main></body>
</html>
"""


def _markdown_line_to_html(line: str) -> str:
    if line.startswith("# "):
        return f"<h1>{escape(line[2:])}</h1>"
    if line.startswith("## "):
        return f"<h2>{escape(line[3:])}</h2>"
    if line.startswith("- "):
        return f"<li>{escape(line[2:])}</li>"
    if line.strip() == "":
        return ""
    return f"<p>{escape(line)}</p>"


def _priority_rank(priority: str) -> int:
    return {"low": 1, "medium": 2, "high": 3, "critical": 4}.get(priority, 1)


def _suggestion_text(gap: dict[str, Any]) -> str:
    return "；".join(content.get("title", "") for content in gap.get("suggested_contents", []))


def _todo_status_summary(todos: list[dict[str, Any]]) -> str:
    if not todos:
        return "暂无待办。"
    statuses = {}
    for todo in todos:
        statuses[todo.get("status", "todo")] = statuses.get(todo.get("status", "todo"), 0) + 1
    return "；".join(f"{status}: {count}" for status, count in sorted(statuses.items()))


def _done_todo_summary(todos: list[dict[str, Any]]) -> str:
    done = [todo.get("task_title", "") for todo in todos if todo.get("status") == "done"]
    return "；".join(done) if done else "本周暂无验证通过的补齐项。"


def _validation_summary(todos: list[dict[str, Any]]) -> str:
    if not todos:
        return "暂无验证结果。"
    return "；".join(
        f"{todo.get('task_title', '')}: {todo.get('validation_status', 'not_tested')}"
        for todo in todos
    )


def _next_week_focus(gaps: list[dict[str, Any]]) -> str:
    if not gaps:
        return "继续观察真实使用过程中的知识缺口。"
    modules = "、".join(dict.fromkeys(gap.get("module", "unknown") for gap in gaps[:3]))
    return f"优先补齐 {modules} 模块的高频缺口，并完成对应验证问题的 Top-3 命中验证。"

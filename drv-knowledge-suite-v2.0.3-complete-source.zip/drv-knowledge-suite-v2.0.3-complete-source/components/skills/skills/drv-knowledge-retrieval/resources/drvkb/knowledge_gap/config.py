"""Shared dataset helpers for Knowledge Gap."""
from recall.config_loader import canonical_dataset, dataset_map

def datasets_for_module(module: str) -> list[str]:
    m=dataset_map()
    if module in {"network","sensor","boot","storage","memory","usb","pcie","audio"}:
        return [m["cases"],m["manuals"],m["tech_notes"]]
    return [m["project_docs"],m["cases"]]

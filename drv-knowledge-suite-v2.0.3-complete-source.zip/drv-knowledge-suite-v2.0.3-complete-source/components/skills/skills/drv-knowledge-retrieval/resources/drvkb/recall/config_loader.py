"""Configuration helpers for drv-knowledge Recall."""
from __future__ import annotations
import json, os, sys
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = Path(__file__).resolve().parent / "configs"
SKILL_DIR = Path(__file__).resolve().parents[3]
if str(SKILL_DIR) not in sys.path:
    sys.path.insert(0, str(SKILL_DIR))
from runtime import load_config as load_shared_config, route_for, dataset_map, canonical_dataset, logical_dataset, load_dotenv

def load_jsonish(path: str | Path) -> Any:
    target=Path(path)
    if not target.is_absolute(): target=PROJECT_ROOT/target
    return json.loads(target.read_text(encoding="utf-8"))

def load_config(name: str) -> Any:
    return load_jsonish(CONFIG_DIR/name)

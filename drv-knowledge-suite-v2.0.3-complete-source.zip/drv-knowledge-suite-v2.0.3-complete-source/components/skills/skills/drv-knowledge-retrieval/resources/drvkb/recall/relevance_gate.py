"""Recall V4 conservative relevance and answer gates.

The gate operates after semantic reranking. It rejects only explicit conflicts,
keeps metadata-poor legacy documents as a scarcity fallback, and exposes a
small, auditable decision record without copying retrieved chunk content.
"""
from __future__ import annotations

from typing import Any

from .config_loader import load_config


UNKNOWN = {"", "unknown", "none", "null", "all"}


def _known(value: Any) -> bool:
    return str(value or "").strip().lower() not in UNKNOWN


def _profile(normalized_query: dict[str, Any]) -> tuple[str, dict[str, Any], dict[str, Any]]:
    config = load_config("relevance_profiles.yaml")
    name = str(normalized_query.get("task_type") or "diagnosis")
    profiles = config.get("profiles", {})
    return name, dict(profiles.get(name) or profiles["diagnosis"]), config


def _explicit_chip_conflict(normalized_query: dict[str, Any], candidate: dict[str, Any]) -> bool:
    requested = str(normalized_query.get("chip") or "").strip().lower()
    actual = str(candidate.get("chip") or "").strip().lower()
    return _known(requested) and _known(actual) and requested != actual


def _explicit_domain_conflict(normalized_query: dict[str, Any], candidate: dict[str, Any], config: dict[str, Any]) -> bool:
    requested = str(normalized_query.get("module") or "").strip().lower()
    actual = str(candidate.get("module") or "").strip().lower()
    if _known(requested) and _known(actual) and requested != actual:
        return True
    if not _known(requested) or _known(actual):
        return False
    # Text inference is intentionally limited to the title and a short leading
    # window. It catches clearly labelled cross-domain manuals without turning
    # incidental vocabulary deep in a document into a hard rejection.
    blob = (str(candidate.get("title") or "") + " " + str(candidate.get("content") or "")[:600]).lower()
    excluded = config.get("excluded_modules", {}).get(requested, [])
    terms = config.get("module_terms", {})
    return any(any(str(term).lower() in blob for term in terms.get(module, [])) for module in excluded)


def _missing_fields(candidate: dict[str, Any], required: list[str]) -> list[str]:
    return [field for field in required if not _known(candidate.get(field))]


def _rejection(candidate: dict[str, Any], reason: str, **extra: Any) -> dict[str, Any]:
    result = {
        "title": str(candidate.get("title") or ""),
        "document_key": str(candidate.get("document_key") or candidate.get("source_key") or candidate.get("document_id") or ""),
        "page_url": str(candidate.get("page_url") or ""),
        "score": round(float(candidate.get("final_score") or 0.0), 2),
        "reason": reason,
    }
    result.update(extra)
    return result


def _has_consensus(candidate: dict[str, Any]) -> bool:
    return (
        len(set(candidate.get("query_hits") or [])) >= 2
        or len(set(candidate.get("lane_hits") or [])) >= 2
        or int(candidate.get("supporting_chunk_count") or 0) >= 2
    )


def apply_relevance_gate(normalized_query: dict[str, Any], candidates: list[dict[str, Any]]) -> dict[str, Any]:
    profile_name, profile, config = _profile(normalized_query)
    minimum = float(profile.get("min_score", 45.0))
    required = [str(x) for x in profile.get("require_metadata_fields", [])]
    fallback_min = max(1, int(profile.get("fallback_min_documents", 3)))
    inspected: list[tuple[dict[str, Any], str | None, list[str]]] = []
    for candidate in candidates:
        reason = None
        if _explicit_chip_conflict(normalized_query, candidate):
            reason = "explicit_chip_conflict"
        elif _explicit_domain_conflict(normalized_query, candidate, config):
            reason = "explicit_domain_conflict"
        missing = _missing_fields(candidate, required)
        inspected.append((candidate, reason, missing))

    strict_count = sum(
        1 for candidate, reason, missing in inspected
        if reason is None and not missing and float(candidate.get("final_score") or 0.0) >= minimum
    )
    accepted: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    for candidate, reason, missing in inspected:
        score = float(candidate.get("final_score") or 0.0)
        if reason:
            rejected.append(_rejection(candidate, reason))
            continue
        if score < minimum:
            rejected.append(_rejection(candidate, "below_min_score", threshold=minimum))
            continue
        if missing and strict_count >= fallback_min:
            rejected.append(_rejection(candidate, "metadata_missing_strict", missing_fields=missing))
            continue
        item = dict(candidate)
        item["gate_mode"] = "fallback_metadata" if missing else "strict"
        item["missing_metadata_fields"] = missing
        accepted.append(item)

    accepted.sort(key=lambda item: float(item.get("final_score") or 0.0), reverse=True)
    if not accepted:
        answer_status = "no_match"
        margin = None
    elif len(accepted) == 1:
        answer_status = "ok"
        margin = None
    else:
        margin = round(float(accepted[0].get("final_score") or 0.0) - float(accepted[1].get("final_score") or 0.0), 2)
        answer_status = "ok" if margin >= float(profile.get("min_margin", 6.0)) or _has_consensus(accepted[0]) else "ambiguous_match"

    return {
        "profile": profile_name,
        "answer_status": answer_status,
        "accepted": accepted,
        "rejected": rejected,
        "strict_count": strict_count,
        "top_margin": margin,
        "thresholds": {
            "min_score": minimum,
            "min_margin": float(profile.get("min_margin", 6.0)),
            "fallback_min_documents": fallback_min,
            "require_metadata_fields": required,
        },
    }

"""Build Recall V3 downstream-agent consumable knowledge bundles."""
from __future__ import annotations
import hashlib
from typing import Any
from .evidence_extractor import extract_engineering_evidence

TYPE_MAP={"cases":"case","manuals":"manual","project_docs":"project_doc","tech_notes":"tech_note","docs":"doc","manual":"manual","case":"case"}


def _confidence_level(score:float)->str:
    return "high" if score>=72 else "medium" if score>=48 else "low"


def _confidence_value(score:float)->float:
    return round(min(max(score/100.0,0.0),1.0),4)


def _request_id(q:str)->str:
    return "KB-"+hashlib.sha1(q.encode("utf-8")).hexdigest()[:12]


def _missing_info(n:dict[str,Any])->list[str]:
    missing=[]
    if n.get("platform")=="unknown": missing.append("当前平台型号/产品代号")
    if n.get("chip")=="unknown": missing.append("相关芯片/器件型号")
    if n.get("task_type")=="diagnosis": missing.append("完整 dmesg/关键错误日志")
    m=n.get("module")
    if m=="network": missing += ["MAC/PHY 连接模式","ifconfig/ethtool/ARP/VLAN 信息"]
    elif m=="sensor": missing += ["DTS 节点","reset gpio 时序","clock/regulator 配置"]
    elif m=="boot": missing += ["bootargs","分区表","完整启动日志"]
    return list(dict.fromkeys(missing))


def _next_actions(n:dict[str,Any])->list[str]:
    m=n.get("module")
    if m=="network": return ["确认 RGMII tx/rx delay 与 MAC/PHY 连接模式","检查 VLAN/ARP 是否过滤或隔离异常","对比 MAC 侧收发计数与 PHY link 状态"]
    if m=="sensor": return ["核对 DTS compatible、clock、regulator 与 reset gpio","确认 sensor stream on、MIPI lane 与 VI 输入状态","补充 probe 前后的完整 dmesg 日志"]
    if m=="boot": return ["核对 bootargs root 参数与实际分区表","检查 UBI/UBIFS 或 initramfs 挂载日志","确认 rootfs 设备节点是否在内核启动阶段出现"]
    return ["补充平台、芯片、模块、日志和复现步骤后重新召回"]


def _is_clickable_link(value:Any)->bool:
    return str(value or "").startswith(("http://","https://","file://"))


def build_knowledge_bundle(normalized_query:dict[str,Any],dataset_route:list[str],reranked_results:list[dict[str,Any]],*,top_k:int=5)->dict[str,Any]:
    # Recall V3 public contract: every returned item must be directly clickable.
    linked=[r for r in reranked_results if _is_clickable_link(r.get("page_url"))]
    excluded_unlinked=len(reranked_results)-len(linked); items=[]
    for r in linked[:top_k]:
        mt=r.get("material_type","docs"); score=float(r.get("final_score",0.0)); evidence=extract_engineering_evidence(r,normalized_query)
        page_url=str(r.get("page_url") or "")
        items.append({
            "type":TYPE_MAP.get(mt,mt),"title":r.get("title",""),"source":page_url,"page_url":page_url,
            "source_key":r.get("source_key","") or r.get("document_key","") ,"page_id":r.get("page_id",""),"link_source":r.get("link_source","none"),
            "source_kind":r.get("source_kind","ragflow"),"local_path":r.get("local_path",""),"relative_path":r.get("relative_path",""),
            "section":r.get("section",""),"line_start":r.get("line_start"),"line_end":r.get("line_end"),
            "dataset":r.get("dataset",""),"material_type":mt,"status":r.get("status","unknown"),"platform":r.get("platform","unknown"),
            "module":r.get("module","unknown"),"chip":r.get("chip","unknown"),"project":r.get("project","unknown"),
            "confidence":_confidence_value(score),"confidence_level":_confidence_level(score),"score":round(score,2),
            "reason":evidence.get("relevance_reason","") ,"summary":evidence.get("overview","") ,"engineering_summary":{
                "overview":evidence.get("overview",""),"symptom":evidence.get("symptom",""),"root_cause":evidence.get("root_cause",""),
                "solution":evidence.get("solution",""),"verification":evidence.get("verification","")},
            "matched_entities":evidence.get("matched_entities",[]),"matched_symptoms":evidence.get("matched_symptoms",[]),
            "supporting_chunk_count":r.get("supporting_chunk_count",1),"supporting_chunks":r.get("supporting_chunks",[]),
            "query_hits":r.get("query_hits",[]),"lane_hits":r.get("lane_hits",[]),"debug_rank_reasons":r.get("rank_reasons",[])
        })
    top=float(items[0].get("score",0.0)) if items else 0.0
    unlinked=[{"title":r.get("title","") ,"dataset":r.get("dataset","") ,"page_id":r.get("page_id","") ,"source_key":r.get("source_key","")} for r in reranked_results if not _is_clickable_link(r.get("page_url"))][:10]
    governance_issues=[]
    if unlinked:
        governance_issues.append({"type":"missing_source_link","severity":"warning","count":excluded_unlinked,"message":"召回候选缺少可点击原文链接，已从公开 Top-K 排除；RAGFlow 知识应补齐 page_url/source_url，本地手册应保留可访问文件路径。","samples":unlinked})
    return {
        "contract_version":"knowledge-bundle-v3","request_id":_request_id(normalized_query["raw_query"]),"task_summary":normalized_query["raw_query"],
        "task_type":normalized_query.get("task_type","diagnosis"),"platform":normalized_query.get("platform","unknown"),"project":normalized_query.get("project","unknown"),
        "module":normalized_query.get("module","unknown"),"chip":normalized_query.get("chip","unknown"),"confidence":_confidence_value(top),"confidence_level":_confidence_level(top),
        "dataset_route":dataset_route,"items":items,"source_integrity":{"returned":len(items),"linked":len(items),"excluded_unlinked":excluded_unlinked,"source_url_rate":1.0 if items else 0.0},
        "governance_issues":governance_issues,"graph_neighbors":[],"conflicts":[],"missing_info":_missing_info(normalized_query),"suggested_next_action":_next_actions(normalized_query)
    }

"""Build actionable knowledge completion todos from gap items."""

from __future__ import annotations

from typing import Any
import os

from .models import TODO_STATUS_TODO, VALIDATION_NOT_TESTED, GapTodo, stable_id
from recall.config_loader import dataset_map


def build_todos(
    gap_items: list[dict[str, Any]],
    *,
    existing_todos: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    todos = []
    existing_todos = existing_todos or []
    existing_by_id = {todo.get("id"): todo for todo in existing_todos if todo.get("id")}
    existing_by_key = {_todo_key(todo): todo for todo in existing_todos}
    for gap in gap_items:
        contents = gap.get("suggested_contents") or [{
            "type": "case",
            "title": gap.get("title", "补充知识缺口资料"),
            "target_dataset": dataset_map()["cases"],
        }]
        if os.environ.get("DRVKB_GAP_TODO_MODE", "primary").strip().lower() != "all":
            contents = _primary_contents(gap, contents)
        for content in contents:
            task_type = content.get("type", "case")
            title = content.get("title", gap.get("title", "补充知识缺口资料"))
            target_dataset = content.get("target_dataset", dataset_map()["cases"])
            todo_id = stable_id(
                "KG-TODO",
                [gap["id"], task_type, title, target_dataset],
                discriminator=gap.get("module", "GAP"),
            )
            existing = existing_by_id.get(todo_id) or existing_by_key.get(
                (gap["id"], task_type, title, target_dataset)
            )
            todos.append(GapTodo(
                id=todo_id,
                gap_id=gap["id"],
                priority=gap.get("priority", "medium"),
                module=gap.get("module", "unknown"),
                task_title=title,
                task_type=task_type,
                target_dataset=target_dataset,
                suggested_bookstack_title=_bookstack_title(title, task_type),
                suggested_outline=_outline_for_type(task_type),
                acceptance_criteria=[
                    "BookStack 已新增或更新对应页面",
                    "metadata 包含 module/platform/material_type/status",
                    "RAGFlow 已完成入库或 fixture 已补充验证资料",
                    "验证问题 Top-3 命中目标资料",
                    "召回结果包含来源引用和有效建议",
                ],
                status=(existing or {}).get("status", TODO_STATUS_TODO),
                validation_status=(existing or {}).get("validation_status", VALIDATION_NOT_TESTED),
            ).to_dict())
    return todos


def _todo_key(todo: dict[str, Any]) -> tuple[str, str, str, str]:
    return (
        todo.get("gap_id", ""),
        todo.get("task_type", ""),
        todo.get("task_title", ""),
        todo.get("target_dataset", ""),
    )


def _bookstack_title(title: str, task_type: str) -> str:
    if task_type == "case" and "案例" not in title:
        return f"{title}案例"
    if task_type == "manual_summary" and "摘要" not in title:
        return f"{title}摘要"
    return title


def _outline_for_type(task_type: str) -> list[str]:
    if task_type == "manual_summary":
        return ["适用平台", "相关模块", "关键寄存器/配置", "初始化流程", "常见误区", "验证方式"]
    if task_type == "checklist":
        return ["适用场景", "检查项", "命令或日志", "预期结果", "异常处理", "关联资料"]
    return ["适用平台", "问题现象", "背景说明", "排查步骤", "关键日志和命令", "根因分析", "解决方案", "关联手册", "验证方式"]


def _primary_contents(gap: dict[str, Any], contents: list[dict[str, str]]) -> list[dict[str, str]]:
    """Default one actionable main task per gap; set DRVKB_GAP_TODO_MODE=all for legacy split mode."""
    if len(contents) <= 1:
        return contents
    text = " ".join([str(gap.get("title", "")), str(gap.get("typical_background", "")), " ".join(str(x) for x in gap.get("gap_type", []))]).lower()
    if "手册" in text or "manual" in text or "missing_document" in text:
        for content in contents:
            if content.get("type") == "manual_summary" or "manual" in content.get("target_dataset", ""):
                return [content]
    if "recall_strategy" in text:
        for content in contents:
            if content.get("type") in {"case", "checklist"}:
                return [content]
    return [contents[0]]

"""Local file storage for knowledge gap closure data."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


DEFAULT_DATA_DIR = Path("data") / "knowledge_gap"


class GapStore:
    """Read/write JSONL and JSON-compatible YAML files for v1.0."""

    def __init__(self, root: str | Path = DEFAULT_DATA_DIR) -> None:
        self.root = Path(root)
        self.events_path = self.root / "gap_events.jsonl"
        self.items_path = self.root / "gap_items.yaml"
        self.todos_path = self.root / "gap_todos.yaml"
        self.reports_dir = self.root / "reports"
        self.validation_dir = self.root / "validation"

    def ensure_dirs(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        self.validation_dir.mkdir(parents=True, exist_ok=True)

    def append_event(self, event: dict[str, Any]) -> None:
        self.ensure_dirs()
        with self.events_path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True))
            handle.write("\n")

    def load_events(self) -> list[dict[str, Any]]:
        if not self.events_path.exists():
            return []
        events = []
        for line in self.events_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                events.append(json.loads(line))
        return events

    def save_gap_items(self, items: list[dict[str, Any]]) -> None:
        self._write_jsonish(self.items_path, items)

    def load_gap_items(self) -> list[dict[str, Any]]:
        return self._read_jsonish(self.items_path)

    def save_todos(self, todos: list[dict[str, Any]]) -> None:
        self._write_jsonish(self.todos_path, todos)

    def load_todos(self) -> list[dict[str, Any]]:
        return self._read_jsonish(self.todos_path)

    def save_validation(self, gap_id: str, mode: str, result: dict[str, Any]) -> Path:
        self.ensure_dirs()
        path = self.validation_dir / f"validation_{gap_id}_{mode}.json"
        path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def _read_jsonish(self, path: Path) -> list[dict[str, Any]]:
        if not path.exists():
            return []
        content = path.read_text(encoding="utf-8").strip()
        if not content:
            return []
        return json.loads(content)

    def _write_jsonish(self, path: Path, data: list[dict[str, Any]]) -> None:
        self.ensure_dirs()
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

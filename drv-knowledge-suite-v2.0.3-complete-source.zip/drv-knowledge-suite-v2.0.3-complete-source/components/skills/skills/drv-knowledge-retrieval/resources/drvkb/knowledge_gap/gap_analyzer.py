"""Aggregate raw gap events into actionable gap items."""

from __future__ import annotations

from collections import defaultdict
import re
from typing import Any

from .models import GAP_STATUS_TODO, GapItem, highest_priority, stable_id
from recall.config_loader import dataset_map


NETWORK_KEYWORDS = {"phy", "rgmii", "mac", "vlan", "arp", "link", "无流量", "网口", "网络"}
SENSOR_KEYWORDS = {"sensor", "i2c", "probe", "mipi", "reset", "gpio", "clock", "regulator"}
BOOT_KEYWORDS = {"rootfs", "bootargs", "ubifs", "initramfs", "kernel panic", "挂载"}


def analyze_gap_events(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for event in events:
        grouped[_group_key(event)].append(event)

    gap_items = []
    for (module_key, platform_key, primary_gap_type, signature), group in sorted(grouped.items(), key=lambda pair: pair[0]):
        module = group[0].get("module", "unknown")
        platforms = _unique([event.get("platform", "unknown") for event in group])
        gap_type = _gap_types(group)
        priority = highest_priority([event.get("priority", "medium") for event in group])
        if len(group) >= 3 and priority != "critical":
            priority = "high"
        suggested_contents = _suggested_contents(group)
        validation_questions = _unique(
            question
            for event in group
            for question in event.get("validation_questions", [])
        )[:5]
        expected_sources = _expected_sources(module, suggested_contents)
        gap_items.append(GapItem(
            id=stable_id("KG-GAP", [module_key, platform_key, primary_gap_type, signature], discriminator=module),
            title=_title_for_group(module, group),
            module=module,
            platforms=platforms,
            gap_type=gap_type,
            event_count=len(group),
            priority=priority,
            typical_background=_join_field(group, "issue_background"),
            impact=_join_field(group, "impact"),
            suggested_contents=suggested_contents,
            validation_questions=validation_questions,
            status=GAP_STATUS_TODO,
            related_events=[
                event.get("id") or f"inline-event-{index + 1}"
                for index, event in enumerate(group)
            ],
            expected_sources=expected_sources,
        ).to_dict())
    return gap_items


def _group_key(event: dict[str, Any]) -> tuple[str, str, str, str]:
    module = _normalize_key(event.get("module", "unknown"))
    platform = _normalize_key(event.get("platform", "unknown") or "unknown")
    gap_type = _gap_types([event])[0]
    signature = _keyword_signature(event)
    return module, platform, gap_type, signature


def _gap_types(events: list[dict[str, Any]]) -> list[str]:
    types: list[str] = []
    for event in events:
        reasons = set(event.get("trigger_reason", []))
        has_hits = bool((event.get("recall_snapshot") or {}).get("hit_docs"))
        if "missing_source_or_metadata" in reasons or "missing_knowledge_info" in reasons:
            types.append("metadata_incomplete")
        if "top3_miss" in reasons or "top5_miss" in reasons or "low_confidence_recall" in reasons:
            types.append("recall_strategy" if has_hits else "missing_document")
        if "empty_recall" in reasons:
            types.append("missing_document")
        if any(x in reasons for x in {"not_related", "资料不对"}):
            types.append("question_coverage")
        if "relationship_missing" in reasons:
            types.append("relationship_missing")
        if "manual_collect" in reasons:
            detail = str(event.get("gap_detail", ""))
            types.append("missing_document" if any(k in detail for k in ["手册","资料","案例","文档"]) else "question_coverage")
    return _unique(types) or ["missing_document"]

def _keyword_signature(event: dict[str, Any]) -> str:
    text = " ".join([
        event.get("user_question", ""),
        event.get("problem_summary", ""),
        event.get("gap_detail", ""),
        " ".join(event.get("suggestion", [])),
    ]).lower()
    if any(keyword in text for keyword in NETWORK_KEYWORDS):
        return "phy-rgmii"
    if any(keyword in text for keyword in SENSOR_KEYWORDS):
        return "sensor-i2c"
    if any(keyword in text for keyword in BOOT_KEYWORDS):
        return "boot-rootfs"
    words = re.findall(r"[a-zA-Z0-9_\u4e00-\u9fff]+", text)
    return "-".join(sorted(set(words[:4]))) or "general"


def _title_for_group(module: str, group: list[dict[str, Any]]) -> str:
    signature = _keyword_signature(group[0])
    if signature == "phy-rgmii":
        return f"{module}：PHY/RGMII 网络链路排查资料不足"
    if signature == "sensor-i2c":
        return f"{module}：I2C/Sensor 适配排查资料不足"
    if signature == "boot-rootfs":
        return f"{module}：rootfs/bootargs 启动排查资料不足"
    return f"{module}：{group[0].get('problem_summary', '知识缺口')}资料不足"


def _suggested_contents(group: list[dict[str, Any]]) -> list[dict[str, str]]:
    contents = []
    seen = set()
    for event in group:
        suggestions = event.get("suggestion", []) or ["补充相关知识资料"]
        datasets = event.get("suggested_dataset", []) or [dataset_map()["cases"]]
        for index, suggestion in enumerate(suggestions):
            dataset = datasets[min(index, len(datasets) - 1)]
            content = {
                "type": _content_type(suggestion, dataset),
                "title": suggestion,
                "target_dataset": dataset,
            }
            key = (content["title"], content["target_dataset"])
            if key not in seen:
                seen.add(key)
                contents.append(content)
    return contents


def _expected_sources(module: str, contents: list[dict[str, str]]) -> list[str]:
    return _unique(_target_source_title(content["title"]) for content in contents)


def _target_source_title(title: str) -> str:
    title = re.sub(r"^补充", "", title).strip()
    return title or "补充相关知识资料"


def _content_type(suggestion: str, dataset: str) -> str:
    if "manual" in dataset or "手册" in suggestion:
        return "manual_summary"
    if "case" in dataset or "案例" in suggestion:
        return "case"
    if "checklist" in suggestion.lower() or "说明" in suggestion:
        return "checklist"
    return "doc"


def _join_field(group: list[dict[str, Any]], field: str) -> str:
    return "；".join(_unique(event.get(field, "") for event in group if event.get(field)))


def _unique(values) -> list:
    result = []
    for value in values:
        if value and value not in result:
            result.append(value)
    return result


def _normalize_key(value: str) -> str:
    return str(value or "unknown").strip().lower() or "unknown"

"""Command line interface for DrvAgent knowledge gap v1.0."""

from __future__ import annotations

import argparse
import json
from typing import Any

from .gap_analyzer import analyze_gap_events
from .gap_collector import collect_gap_event
from .gap_store import GapStore
from .gap_validator import validate_gaps
from .report_generator import generate_report
from .todo_builder import build_todos
from .config import datasets_for_module
from recall.config_loader import dataset_map


def main() -> int:
    parser = argparse.ArgumentParser(description="DrvAgent knowledge gap v1.0")
    parser.add_argument("--data-dir", default="data/knowledge_gap", help="知识缺口数据目录")
    subparsers = parser.add_subparsers(dest="command", required=True)

    collect = subparsers.add_parser("collect", help="收集一条知识缺口事件")
    collect.add_argument("--question", required=True)
    collect.add_argument("--module", required=True)
    collect.add_argument("--background", required=True)
    collect.add_argument("--gap", required=True)
    collect.add_argument("--impact", required=True)
    collect.add_argument("--priority", default="medium", choices=["low", "medium", "high", "critical"])
    collect.add_argument("--platform", default="unknown")
    collect.add_argument("--source-agent", default="manual")
    collect.add_argument("--workflow", default="manual_collect")
    collect.add_argument("--suggested-dataset", action="append")
    collect.add_argument("--validation-question", action="append")

    subparsers.add_parser("analyze", help="聚合缺口事件")
    subparsers.add_parser("build-todos", help="生成知识补齐待办")

    report = subparsers.add_parser("report", help="生成知识缺口周报")
    report.add_argument("--week", default="current")
    report.add_argument("--format", choices=["md", "html", "all"], default="md")

    validate = subparsers.add_parser("validate", help="验证补齐效果")
    validate.add_argument("--gap-id")
    validate.add_argument("--mode", choices=["fixture", "live"], default="fixture")

    args = parser.parse_args()
    store = GapStore(args.data_dir)

    if args.command == "collect":
        event = collect_gap_event(
            store=store,
            source_agent=args.source_agent,
            workflow=args.workflow,
            user_question=args.question,
            problem_summary=args.question[:60],
            project_context=args.background,
            module=args.module,
            platform=args.platform,
            issue_background=args.background,
            trigger_reason=["manual_collect"],
            recall_snapshot={"top3_hit": False, "top5_hit": False, "confidence": 0.0, "hit_docs": []},
            gap_detail=args.gap,
            impact=args.impact,
            suggestion=_suggestions(args.gap),
            suggested_dataset=args.suggested_dataset or _suggested_datasets(args.module, args.gap),
            priority=args.priority,
            validation_questions=args.validation_question or [_default_validation_question(args.question)],
        )
        print(json.dumps(event, ensure_ascii=False, indent=2))
        return 0
    if args.command == "analyze":
        gaps = analyze_gap_events(store.load_events())
        store.save_gap_items(gaps)
        print(json.dumps({"gap_items": len(gaps)}, ensure_ascii=False))
        return 0
    if args.command == "build-todos":
        todos = build_todos(store.load_gap_items(), existing_todos=store.load_todos())
        store.save_todos(todos)
        print(json.dumps({"todos": len(todos)}, ensure_ascii=False))
        return 0
    if args.command == "report":
        formats = ["md", "html"] if args.format == "all" else [args.format]
        outputs = generate_report(store=store, week=args.week, formats=formats)
        print(json.dumps(outputs, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate":
        try:
            results = validate_gaps(store=store, gap_id=args.gap_id, mode=args.mode)
        except ValueError as exc:
            print(json.dumps({"error": str(exc)}, ensure_ascii=False), flush=True)
            return 2
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return 0
    return 1


def _suggestions(gap: str) -> list[str]:
    suggestions = []
    if "RGMII" in gap or "PHY" in gap or "网卡" in gap:
        suggestions.extend(["补充 PHY link up 无流量排查案例", "补充 RGMII delay 配置说明"])
    if "手册" in gap:
        suggestions.append("补充相关手册摘要")
    return suggestions or [gap]


def _suggested_datasets(module: str, gap: str) -> list[str]:
    mapping = dataset_map()
    datasets = []
    if "案例" in gap or module in {"network", "sensor", "boot", "storage", "memory", "usb", "pcie", "audio"}:
        datasets.append(mapping["cases"])
    if "手册" in gap:
        datasets.append(mapping["manuals"])
    if "说明" in gap or "checklist" in gap.lower():
        datasets.append(mapping["tech_notes"])
    return datasets or datasets_for_module(module)[:1]

def _default_validation_question(question: str) -> str:
    if "PHY" in question and "无流量" in question:
        return "PHY link up 但是无流量怎么排查？"
    return question


if __name__ == "__main__":
    raise SystemExit(main())

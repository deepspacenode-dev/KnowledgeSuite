"""Validate whether knowledge gaps were filled by Recall v2 results."""

from __future__ import annotations

from typing import Any

from recall import run_recall

from .gap_store import GapStore


def validate_gaps(
    *,
    store: GapStore,
    gap_id: str | None = None,
    mode: str = "fixture",
    top_k: int = 5,
) -> dict[str, dict[str, Any]]:
    gaps = [
        gap for gap in store.load_gap_items()
        if gap_id is None or gap.get("id") == gap_id
    ]
    if gap_id is not None and not gaps:
        raise ValueError(f"gap_id not found: {gap_id}")
    todos = store.load_todos()
    results: dict[str, dict[str, Any]] = {}

    for gap in gaps:
        _mark_todos(todos, gap["id"], status="verifying", validation_status="not_tested")
        questions = gap.get("validation_questions") or [gap.get("title", "")]
        expected_sources = gap.get("expected_sources") or [
            content.get("title", "") for content in gap.get("suggested_contents", [])
        ]
        question_results = []
        passed_count = 0
        related_count = 0
        for question in questions:
            response = run_recall(question, mode=mode, top_k=top_k)
            bundle = response.get("knowledge_bundle", {})
            items = bundle.get("items", [])
            top3_hit = _hit_at(items, expected_sources, 3)
            related_hit = _related_hit(items, gap, question)
            has_sources = bool(items) and all(item.get("source") and item.get("page_url") for item in items)
            has_next_action = bool(bundle.get("suggested_next_action"))
            if top3_hit and has_sources and has_next_action:
                passed_count += 1
            elif related_hit:
                related_count += 1
            question_results.append({
                "question": question,
                "top3_hit": top3_hit,
                "top5_hit": _hit_at(items, expected_sources, 5),
                "related_hit": related_hit,
                "has_sources": has_sources,
                "has_next_action": has_next_action,
                "top_titles": [item.get("title", "") for item in items[:5]],
            })
        if passed_count == len(questions):
            validation_status = "passed"
            todo_status = "done"
        elif passed_count > 0 or related_count > 0:
            validation_status = "partial"
            todo_status = "verifying"
        else:
            validation_status = "failed"
            todo_status = "verifying_failed"
        result = {
            "gap_id": gap["id"],
            "mode": mode,
            "validation_status": validation_status,
            "questions": question_results,
            "failure_reasons": [] if validation_status == "passed" else _failure_reasons(question_results),
        }
        results[gap["id"]] = result
        store.save_validation(gap["id"], mode, result)
        _mark_todos(todos, gap["id"], status=todo_status, validation_status=validation_status)

    store.save_todos(todos)
    return results


def _hit_at(items: list[dict[str, Any]], expected_sources: list[str], limit: int) -> bool:
    needles = [source.lower() for source in expected_sources if source]
    if not needles:
        return False
    for item in items[:limit]:
        title = str(item.get("title", "")).lower()
        summary = str(item.get("summary", "")).lower()
        if any(needle in title or needle in summary for needle in needles):
            return True
    return False


def _mark_todos(todos: list[dict[str, Any]], gap_id: str, *, status: str, validation_status: str) -> None:
    for todo in todos:
        if todo.get("gap_id") == gap_id:
            todo["status"] = status
            todo["validation_status"] = validation_status


def _related_hit(items: list[dict[str, Any]], gap: dict[str, Any], question: str) -> bool:
    if not items:
        return False
    content_titles = [
        content.get("title", "")
        for content in gap.get("suggested_contents", [])
    ]
    terms = _keywords(" ".join([question, gap.get("title", ""), *content_titles]))
    if not terms:
        return False
    for item in items[:5]:
        blob = f"{item.get('title', '')} {item.get('summary', '')}".lower()
        matched = sum(1 for term in terms if term in blob)
        if matched >= min(2, len(terms)):
            return True
    return False


def _keywords(text: str) -> list[str]:
    candidates = [
        "rgmii",
        "phy",
        "rtl8211",
        "link",
        "无流量",
        "网卡",
        "网络",
        "i2c",
        "sensor",
        "probe",
        "mipi",
        "rootfs",
        "bootargs",
        "ubifs",
        "挂载",
    ]
    lower = text.lower()
    return [term for term in candidates if term in lower]


def _failure_reasons(question_results: list[dict[str, Any]]) -> list[str]:
    reasons = []
    if any(not result["top3_hit"] for result in question_results):
        reasons.append("目标资料未进入 Top-3，可能是 metadata、内容关键词、Dataset 路由或重排规则问题。")
    if any(not result["has_sources"] for result in question_results):
        reasons.append("召回结果缺少来源引用，可能是 page_url/source metadata 不完整。")
    if any(not result["has_next_action"] for result in question_results):
        reasons.append("knowledge_bundle 缺少有效下一步建议，可能是资料内容不够可执行。")
    if not reasons:
        reasons.append("验证未完全通过，请检查 RAGFlow 入库、索引刷新和 fixture 数据。")
    return reasons

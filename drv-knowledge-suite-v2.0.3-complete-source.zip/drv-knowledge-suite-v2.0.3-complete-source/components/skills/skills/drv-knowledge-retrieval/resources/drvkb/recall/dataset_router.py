"""Route normalized tasks to canonical datasets from the single shared contract."""
from __future__ import annotations
from .config_loader import route_for

def route_datasets(normalized_query: dict) -> list[str]:
    return route_for(normalized_query.get("task_type","diagnosis"))

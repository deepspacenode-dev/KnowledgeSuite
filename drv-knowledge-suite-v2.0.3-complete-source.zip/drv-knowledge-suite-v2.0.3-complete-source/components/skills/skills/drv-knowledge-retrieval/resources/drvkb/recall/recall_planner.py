"""Recall V3 planner: prioritize high-value knowledge lanes and keep generic docs as fallback."""
from __future__ import annotations
from typing import Any

LANE_RULES={
    "diagnosis":[
        {"name":"case","datasets":["cases"],"query_kinds":["raw","engineering","symptom"],"priority":1.0},
        {"name":"reference","datasets":["tech_notes","manuals","project_docs"],"query_kinds":["raw","engineering"],"priority":0.85},
    ],
    "driver_development":[
        {"name":"reference","datasets":["manuals","tech_notes","project_docs"],"query_kinds":["raw","engineering","symptom"],"priority":1.0},
        {"name":"case","datasets":["cases"],"query_kinds":["raw","engineering"],"priority":0.75},
    ],
    "platform_migration":[
        {"name":"project","datasets":["project_docs","cases"],"query_kinds":["raw","engineering","symptom"],"priority":1.0},
        {"name":"reference","datasets":["manuals","tech_notes"],"query_kinds":["raw","engineering"],"priority":0.8},
    ],
    "manual_lookup":[
        {"name":"reference","datasets":["manuals","tech_notes"],"query_kinds":["raw","engineering","symptom"],"priority":1.0},
    ],
    "review":[
        {"name":"case","datasets":["cases","tech_notes"],"query_kinds":["raw","engineering","symptom"],"priority":1.0},
        {"name":"reference","datasets":["manuals","project_docs"],"query_kinds":["raw","engineering"],"priority":0.8},
    ],
}


def build_recall_plan(normalized_query:dict[str,Any])->dict[str,Any]:
    task=normalized_query.get("task_type","diagnosis")
    variants={x.get("kind","raw"):x.get("query","") for x in normalized_query.get("query_variants",[])}
    lanes=[]
    for rule in LANE_RULES.get(task,LANE_RULES["diagnosis"]):
        queries=[{"kind":k,"query":variants[k]} for k in rule["query_kinds"] if variants.get(k)]
        lanes.append({**rule,"queries":queries})
    return {
        "version":"recall-v3",
        "task_type":task,
        "lanes":lanes,
        "fallback":{"name":"fallback","datasets":["docs"],"queries":[{"kind":"raw","query":normalized_query.get("raw_query","")}],"priority":0.35},
        "fallback_min_candidates":3,
    }


def primary_route(plan:dict[str,Any])->list[str]:
    out=[]
    for lane in plan.get("lanes",[]):
        for ds in lane.get("datasets",[]):
            if ds not in out: out.append(ds)
    return out

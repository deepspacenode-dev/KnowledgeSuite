"""Local, offline-safe Recall V4 trace and explicit user feedback storage."""
from __future__ import annotations

import datetime as dt
import json
import os
import re
from pathlib import Path
from typing import Any


ALLOWED_LABELS = {"relevant", "irrelevant", "missing_answer", "bad_link"}
SENSITIVE_KEY = re.compile(r"(?:api[_-]?key|authorization|password|secret|token|cookie|auth)$", re.I)


def runtime_root() -> Path:
    raw = os.environ.get("DRVKB_RUNTIME_DIR") or os.environ.get("DRVKNOWLEDGE_RUNTIME_DIR") or "~/.drvknowledge"
    return Path(raw).expanduser()


def _private_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    try:
        path.chmod(0o700)
    except OSError:
        pass


def _private_file(path: Path) -> None:
    try:
        path.chmod(0o600)
    except OSError:
        pass


def _clean_text(value: Any, limit: int = 600) -> str:
    text = str(value or "").replace("\x00", " ").strip()
    return text[:limit]


def _sanitize(value: Any, key: str = "") -> Any:
    if SENSITIVE_KEY.search(key):
        return "[REDACTED]"
    if isinstance(value, dict):
        return {str(k): _sanitize(v, str(k)) for k, v in value.items() if str(k).lower() != "content"}
    if isinstance(value, list):
        return [_sanitize(item, key) for item in value[:100]]
    if isinstance(value, str):
        return _clean_text(value, 1200)
    return value


class FeedbackStore:
    def __init__(self, root: str | Path | None = None) -> None:
        self.root = Path(root) if root is not None else runtime_root()
        self.recall_dir = self.root / "recall"
        self.traces_dir = self.recall_dir / "traces"
        self.feedback_path = self.recall_dir / "feedback.jsonl"

    def save_trace(self, trace: dict[str, Any]) -> Path:
        trace_id = _clean_text(trace.get("trace_id"), 96)
        if not trace_id.startswith("recall-"):
            raise ValueError("invalid trace_id")
        _private_dir(self.traces_dir)
        path = self.traces_dir / f"{trace_id}.json"
        path.write_text(json.dumps(_sanitize(trace), ensure_ascii=False, indent=2), encoding="utf-8")
        _private_file(path)
        return path

    def load_trace(self, trace_id: str) -> dict[str, Any] | None:
        clean = _clean_text(trace_id, 96)
        if not re.fullmatch(r"recall-[a-f0-9-]{8,80}", clean, re.I):
            return None
        path = self.traces_dir / f"{clean}.json"
        if not path.is_file():
            return None
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        return value if isinstance(value, dict) else None

    def append_feedback(self, record: dict[str, Any]) -> Path:
        _private_dir(self.recall_dir)
        with self.feedback_path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(_sanitize(record), ensure_ascii=False, sort_keys=True))
            handle.write("\n")
        _private_file(self.feedback_path)
        return self.feedback_path


def save_trace(trace: dict[str, Any]) -> str | None:
    try:
        return str(FeedbackStore().save_trace(trace))
    except (OSError, ValueError):
        return None


def _gap_from_feedback(trace: dict[str, Any], label: str, reason: str, expected: str) -> dict[str, Any] | None:
    if label not in {"irrelevant", "missing_answer"}:
        return None
    from knowledge_gap.gap_collector import collect_from_recall
    from knowledge_gap.gap_store import GapStore

    events = trace.get("rerank_events", [])
    items = [
        {
            "title": event.get("title", ""),
            "page_url": event.get("page_url", ""),
            "source": event.get("page_url", ""),
            "source_key": event.get("source_key", ""),
            "dataset": event.get("dataset", ""),
            "score": event.get("final_score", 0.0),
        }
        for event in events[:5]
    ]
    scores = [float(item.get("score") or 0.0) for item in items]
    feedback_marker = "没有资料" if label == "missing_answer" else "资料不对"
    response = {
        "normalized_query": {
            "module": trace.get("module", "unknown"),
            "platform": trace.get("platform", "unknown"),
        },
        "knowledge_bundle": {
            "items": items,
            "confidence": (max(scores) / 100.0) if scores else 0.0,
            "confidence_level": "low" if not scores or max(scores) < 55 else "medium",
            "missing_info": [],
        },
    }
    return collect_from_recall(
        query=_clean_text(trace.get("raw_query"), 500),
        recall_response=response,
        expected_sources=[expected] if expected else [],
        user_feedback=feedback_marker,
        store=GapStore(runtime_root() / "knowledge_gap"),
        issue_background=_clean_text(reason or "用户标记召回结果未解决问题", 500),
    )


def record_feedback(trace_id: str, label: str, *, reason: str = "", expected: str = "") -> dict[str, Any]:
    if label not in ALLOWED_LABELS:
        return {"ok": False, "error": "InvalidLabel", "allowed": sorted(ALLOWED_LABELS)}
    store = FeedbackStore()
    trace = store.load_trace(trace_id)
    if trace is None:
        return {"ok": False, "error": "TraceNotFound", "trace_id": _clean_text(trace_id, 96)}
    top = trace.get("rerank_events", [])[:5]
    record = {
        "recorded_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "trace_id": trace.get("trace_id"),
        "label": label,
        "reason": _clean_text(reason, 500),
        "expected": _clean_text(expected, 300),
        "query": _clean_text(trace.get("raw_query"), 500),
        "task_type": trace.get("task_type", ""),
        "module": trace.get("module", ""),
        "platform": trace.get("platform", ""),
        "answer_status": trace.get("answer_status", ""),
        "top_results": [
            {
                "title": _clean_text(item.get("title"), 200),
                "page_url": _clean_text(item.get("page_url"), 500),
                "source_key": _clean_text(item.get("source_key"), 120),
                "score": item.get("final_score", 0.0),
            }
            for item in top
        ],
        "rejected_reasons": [item.get("reason") for item in trace.get("rejected_candidates", [])[:20]],
    }
    path = store.append_feedback(record)
    gap = _gap_from_feedback(trace, label, reason, expected)
    return {
        "ok": True,
        "trace_id": trace.get("trace_id"),
        "label": label,
        "feedback_path": str(path),
        "gap_event_created": gap is not None,
        "gap_event_id": gap.get("id") if gap else None,
    }

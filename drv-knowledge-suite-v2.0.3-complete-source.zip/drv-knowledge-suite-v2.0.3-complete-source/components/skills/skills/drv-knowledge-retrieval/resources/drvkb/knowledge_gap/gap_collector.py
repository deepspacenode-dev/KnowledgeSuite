"""Collect knowledge gap events manually or from RecallResponse."""

from __future__ import annotations

from typing import Any

from .gap_store import GapStore
from .models import EVENT_STATUS_OPEN, GapEvent, make_id, now_text
from .config import datasets_for_module


NO_CONTENT_FEEDBACK = {"no_case", "no_manual", "not_related", "没有资料", "没有案例", "资料不对"}


def collect_gap_event(
    *,
    store: GapStore | None = None,
    source_agent: str,
    workflow: str,
    user_question: str,
    problem_summary: str,
    project_context: str,
    module: str,
    platform: str = "unknown",
    issue_background: str,
    trigger_reason: list[str],
    recall_snapshot: dict[str, Any],
    gap_detail: str,
    impact: str,
    suggestion: list[str] | str,
    suggested_dataset: list[str] | str,
    priority: str = "medium",
    validation_questions: list[str] | None = None,
    user_manual_addition: str = "",
) -> dict[str, Any]:
    event = GapEvent(
        id=make_id("KG-EVENT"),
        time=now_text(),
        source_agent=source_agent,
        workflow=workflow,
        project_context=project_context,
        user_question=user_question,
        problem_summary=problem_summary,
        module=module,
        platform=platform or "unknown",
        issue_background=issue_background,
        trigger_reason=list(dict.fromkeys(trigger_reason)),
        recall_snapshot=recall_snapshot,
        gap_detail=gap_detail,
        impact=impact,
        suggestion=_as_list(suggestion),
        suggested_dataset=_as_list(suggested_dataset),
        priority=priority,
        status=EVENT_STATUS_OPEN,
        validation_questions=validation_questions or [user_question],
        user_manual_addition=user_manual_addition,
    ).to_dict()
    if store is not None:
        store.append_event(event)
    return event


def collect_from_recall(
    *,
    query: str,
    recall_response: dict[str, Any],
    expected_sources: list[str] | None = None,
    user_feedback: str | None = None,
    store: GapStore | None = None,
    source_agent: str = "recall-agent",
    workflow: str = "recall",
    project_context: str = "unknown",
    issue_background: str = "",
) -> dict[str, Any] | None:
    bundle = recall_response.get("knowledge_bundle", {})
    normalized = recall_response.get("normalized_query", {})
    items = bundle.get("items", [])
    expected_sources = expected_sources or []
    trigger_reason: list[str] = []

    if not items:
        trigger_reason.append("empty_recall")
    if expected_sources and not _hit_at(items, expected_sources, 3):
        trigger_reason.append("top3_miss")
    if expected_sources and not _hit_at(items, expected_sources, 5):
        trigger_reason.append("top5_miss")
    if _is_low_confidence(bundle):
        trigger_reason.append("low_confidence_recall")
    if user_feedback and _feedback_indicates_gap(user_feedback):
        trigger_reason.append(user_feedback)
    if any(not item.get("source") or not item.get("page_url") for item in items):
        trigger_reason.append("missing_source_or_metadata")
    if _missing_info_points_to_knowledge(bundle.get("missing_info", [])):
        trigger_reason.append("missing_knowledge_info")

    if not trigger_reason:
        return None

    module = normalized.get("module", "unknown")
    platform = normalized.get("platform", "unknown")
    snapshot = {
        "top3_hit": _hit_at(items, expected_sources, 3) if expected_sources else bool(items[:3]),
        "top5_hit": _hit_at(items, expected_sources, 5) if expected_sources else bool(items[:5]),
        "confidence": bundle.get("confidence", 0.0),
        "confidence_level": bundle.get("confidence_level", "unknown"),
        "hit_docs": [
            {
                "title": item.get("title", ""),
                "dataset": item.get("dataset", ""),
                "score": item.get("score", 0.0),
                "page_url": item.get("page_url", ""),
            }
            for item in items[:5]
        ],
    }
    return collect_gap_event(
        store=store,
        source_agent=source_agent,
        workflow=workflow,
        user_question=query,
        problem_summary=_problem_summary(query, module),
        project_context=project_context,
        module=module,
        platform=platform,
        issue_background=issue_background or f"用户在 {module} 问题处理中需要知识库支撑",
        trigger_reason=trigger_reason,
        recall_snapshot=snapshot,
        gap_detail=_gap_detail(module, trigger_reason),
        impact="召回结果无法充分支撑当前问题定位，需要补齐知识库资料。",
        suggestion=_suggestions_for_module(module),
        suggested_dataset=_datasets_for_module(module),
        priority="high" if "top3_miss" in trigger_reason or not items else "medium",
        validation_questions=[query],
    )


def _as_list(value: list[str] | str) -> list[str]:
    if isinstance(value, list):
        return [item for item in value if item]
    return [value] if value else []


def _hit_at(items: list[dict[str, Any]], expected_sources: list[str], limit: int) -> bool:
    needles = [source.lower() for source in expected_sources if source]
    if not needles:
        return False
    for item in items[:limit]:
        title = str(item.get("title", "")).lower()
        summary = str(item.get("summary", "")).lower()
        if any(needle in title or needle in summary for needle in needles):
            return True
    return False


def _is_low_confidence(bundle: dict[str, Any]) -> bool:
    confidence = bundle.get("confidence", 0.0)
    try:
        return float(confidence) < 0.55 or bundle.get("confidence_level") == "low"
    except (TypeError, ValueError):
        return bundle.get("confidence") == "low"


def _feedback_indicates_gap(feedback: str) -> bool:
    normalized = feedback.lower()
    return any(item.lower() in normalized for item in NO_CONTENT_FEEDBACK)


def _missing_info_points_to_knowledge(missing_info: list[str]) -> bool:
    keywords = ["manual", "case", "project_doc", "手册", "案例", "资料", "文档"]
    return any(any(keyword in item for keyword in keywords) for item in missing_info)


def _problem_summary(query: str, module: str) -> str:
    if module == "network":
        return "网络链路或 PHY/RGMII 问题"
    if module == "sensor":
        return "Sensor/I2C 适配问题"
    if module == "boot":
        return "启动或 rootfs 挂载问题"
    return query[:60]


def _gap_detail(module: str, trigger_reason: list[str]) -> str:
    if module == "network":
        return "缺少当前平台网络链路、PHY/RGMII、MAC 计数或 VLAN/ARP 排查资料"
    if module == "sensor":
        return "缺少 sensor probe、DTS、reset gpio、clock/regulator 或 MIPI 链路排查资料"
    if module == "boot":
        return "缺少 bootargs、分区表、rootfs/UBIFS 挂载失败排查资料"
    return "缺少当前问题对应的案例、手册或项目资料"


def _suggestions_for_module(module: str) -> list[str]:
    if module == "network":
        return ["补充 PHY link up 无流量排查案例", "补充 RGMII delay 配置说明", "补充网卡/PHY 手册摘要"]
    if module == "sensor":
        return ["补充 I2C probe 失败案例", "补充 Sensor 上电时序 checklist", "补充 DTS 字段说明"]
    if module == "boot":
        return ["补充 rootfs 挂载失败案例", "补充 bootargs 分区参数说明", "补充 UBIFS 排查 checklist"]
    return ["补充当前模块案例", "补充相关手册摘要"]


def _datasets_for_module(module: str) -> list[str]:
    return datasets_for_module(module)

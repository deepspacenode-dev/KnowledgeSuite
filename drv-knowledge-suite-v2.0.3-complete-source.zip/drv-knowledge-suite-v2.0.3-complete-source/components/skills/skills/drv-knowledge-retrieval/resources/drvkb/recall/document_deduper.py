"""Collapse chunk-level candidates into document/page-level results."""
from __future__ import annotations
from typing import Any


def _key(item:dict[str,Any])->str:
    for k in ("source_key","page_id","page_url","document_id"):
        v=str(item.get(k) or "").strip()
        if v: return f"{k}:{v}"
    return f"chunk:{item.get('dataset','')}:{item.get('chunk_id','')}:{item.get('title','')}"


def deduplicate_documents(items:list[dict[str,Any]])->list[dict[str,Any]]:
    groups:dict[str,list[dict[str,Any]]]={}
    for item in items: groups.setdefault(_key(item),[]).append(item)
    out=[]
    for key,group in groups.items():
        group=sorted(group,key=lambda x:float(x.get("final_score",0.0)),reverse=True); best=dict(group[0])
        supporting=[]; query_hits=[]; lane_hits=[]
        for g in group:
            for q in g.get("query_hits",[]):
                if q not in query_hits: query_hits.append(q)
            for l in g.get("lane_hits",[]):
                if l not in lane_hits: lane_hits.append(l)
            excerpt=str(g.get("summary") or g.get("content") or "").strip()
            if excerpt and excerpt not in supporting: supporting.append(excerpt[:260])
        best["document_key"]=key; best["supporting_chunks"]=supporting[:3]; best["supporting_chunk_count"]=len(group)
        best["query_hits"]=query_hits; best["lane_hits"]=lane_hits
        bonus=min(3.0,max(0,len(group)-1)*1.0)+min(2.0,max(0,len(query_hits)-1)*0.5)
        best["final_score"]=round(float(best.get("final_score",0.0))+bonus,2)
        best.setdefault("score_breakdown",[]).append({"reason":"document evidence","score":round(bonus,2)})
        out.append(best)
    out.sort(key=lambda x:float(x.get("final_score",0.0)),reverse=True)
    return out

"""Recall V3 evaluation runner for fixture/live test sets."""
from __future__ import annotations
import json, statistics, time
from pathlib import Path
from typing import Any
from .pipeline import run_recall

DEFAULT_TESTSET=Path(__file__).resolve().parents[1]/'tests/recall/recall-testset.json'


def _item_match(item:dict[str,Any],case:dict[str,Any])->bool:
    expected=[str(x).lower() for x in case.get('expected',[]) if x]
    keys=[str(x).lower() for x in case.get('expected_source_keys',[]) if x]
    urls=[str(x).lower() for x in case.get('expected_page_urls',[]) if x]
    blob=(str(item.get('title',''))+' '+str(item.get('summary',''))+' '+str(item.get('source_key',''))+' '+str(item.get('page_url',''))).lower()
    return (bool(expected) and any(x in blob for x in expected)) or (bool(keys) and str(item.get('source_key','')).lower() in keys) or (bool(urls) and str(item.get('page_url','')).lower() in urls) or not (expected or keys or urls)


def _rank(items:list[dict[str,Any]],case:dict[str,Any],limit:int=5)->int|None:
    for i,item in enumerate(items[:limit],1):
        if _item_match(item,case): return i
    return None


def _percentile(values:list[float],p:float)->float:
    if not values: return 0.0
    s=sorted(values); idx=min(len(s)-1,max(0,int(round((len(s)-1)*p))))
    return round(s[idx],4)


def evaluate(mode:str='fixture',testset:Path|None=None,top_k:int=5)->dict[str,Any]:
    path=testset or DEFAULT_TESTSET; cases=json.loads(path.read_text(encoding='utf-8'))
    rows=[]; top1=top3=top5=source_uri=page_url=citation_ready=verified=0; dep_errors=0; reciprocal=[]; latencies=[]; duplicate_docs=0; total_docs=0; forbidden_violations=0; expected_status_hits=0
    for case in cases:
        start=time.perf_counter(); resp=run_recall(case['query'],mode=mode,top_k=max(top_k,5)); latencies.append(time.perf_counter()-start)
        items=resp.get('knowledge_bundle',{}).get('items',[]); rank=_rank(items,case,5); h1=rank==1; h3=bool(rank and rank<=3); h5=bool(rank and rank<=5)
        reciprocal.append(0.0 if not rank else 1.0/rank); sample=items[:min(5,len(items))]
        src=bool(sample) and all(bool(i.get('source')) for i in sample); page=bool(sample) and all(str(i.get('page_url','')).startswith(('http://','https://')) for i in sample)
        ver=bool(sample) and all(str(i.get('status','')).lower() in {'verified','reviewed','approved'} for i in sample); cite=page and ver
        keys=[str(i.get('source_key') or i.get('page_url') or i.get('title')) for i in sample]; total_docs+=len(keys); duplicate_docs+=len(keys)-len(set(keys))
        forbidden={str(x).lower() for x in case.get('forbidden_modules',[]) if x}; violated=any(str(i.get('module','')).lower() in forbidden for i in sample)
        expected_status=str(case.get('expected_status') or '').strip(); actual_status=str(resp.get('answer_status') or '')
        status_ok=not expected_status or actual_status==expected_status
        forbidden_violations+=int(violated); expected_status_hits+=int(status_ok)
        errs=[e for e in resp.get('trace',{}).get('external_dependency_errors',[]) if e.get('severity','error')=='error']; dep_errors+=len(errs)
        top1+=int(h1); top3+=int(h3); top5+=int(h5); source_uri+=int(src); page_url+=int(page); verified+=int(ver); citation_ready+=int(cite)
        rows.append({'id':case.get('id'),'query':case['query'],'rank':rank,'top1_hit':h1,'top3_hit':h3,'top5_hit':h5,'source_uri_ok':src,'page_url_ok':page,'verified_ok':ver,'citation_ready':cite,'answer_status':actual_status,'expected_answer_status':expected_status or None,'expected_answer_status_ok':status_ok,'forbidden_module_violation':violated,'latency_s':round(latencies[-1],4),'top_titles':[i.get('title','') for i in items[:5]],'errors':errs})
    total=len(cases) or 1
    metrics={'recall_at_1':round(top1/total,4),'top3_hit_rate':round(top3/total,4),'top5_hit_rate':round(top5/total,4),'mrr_at_5':round(sum(reciprocal)/total,4),'source_uri_rate':round(source_uri/total,4),'page_url_rate':round(page_url/total,4),'verified_rate':round(verified/total,4),'citation_ready_rate':round(citation_ready/total,4),'document_duplicate_rate':round(duplicate_docs/max(total_docs,1),4),'forbidden_module_violation_rate':round(forbidden_violations/total,4),'expected_answer_status_rate':round(expected_status_hits/total,4),'latency_p50_s':round(statistics.median(latencies),4) if latencies else 0.0,'latency_p95_s':_percentile(latencies,0.95)}
    metrics['source_rate']=metrics['source_uri_rate']
    return {'ok':dep_errors==0,'mode':mode,'testset':str(path),'total':len(cases),'dependency_error_count':dep_errors,'metrics':metrics,'cases':rows}

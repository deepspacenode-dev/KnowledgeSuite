"""Recall V3 orchestration pipeline."""
from __future__ import annotations
from typing import Any
from .config_loader import canonical_dataset
from .document_deduper import deduplicate_documents
from .knowledge_bundle_builder import build_knowledge_bundle
from .query_normalizer import normalize_query
from .ragflow_client import search_ragflow
from .recall_planner import build_recall_plan, primary_route
from .recall_reranker import rerank_results
from .recall_trace import build_trace
from .relevance_gate import apply_relevance_gate
from .feedback_store import save_trace
from drv_knowledge_core.governance_v2 import resolve_governance_statuses
from drv_knowledge_core.knowledge_bundle_v2 import bookstack_content_refs, convert_legacy_bundle


def run_recall(query:str,mode:str="live",top_k:int=5)->dict[str,Any]:
    normalized=normalize_query(query); plan=build_recall_plan(normalized)
    dataset_route=[canonical_dataset(x) for x in primary_route(plan)]; errors=[]
    raw_results=search_ragflow(normalized,dataset_route,mode=mode,top_k=top_k,diagnostics=errors,plan=plan)
    local_manual_results=[]
    if mode!='fixture':
        try:
            from navigator.local_manuals import search as search_local_manuals
            local_manual_results=search_local_manuals(normalized,top_k=max(20,top_k*4))
            raw_results.extend(local_manual_results)
        except Exception as exc:
            errors.append({'kind':'local_manuals','severity':'warning','message':str(exc)})
    reranked_chunks=rerank_results(normalized,raw_results)
    gate=apply_relevance_gate(normalized,reranked_chunks)
    reranked_results=deduplicate_documents(gate['accepted'])
    bundle=build_knowledge_bundle(normalized,dataset_route,reranked_results,top_k=top_k)
    trace=build_trace(mode=mode,normalized_query=normalized,dataset_route=dataset_route,raw_results=raw_results,reranked_results=reranked_results,external_dependency_errors=errors,recall_plan=plan,relevance_gate=gate)
    trace['local_manuals']={'candidate_count':len(local_manual_results),'active':bool(local_manual_results)}
    trace['trace_path']=save_trace(trace)
    hard_errors=[e for e in errors if e.get('severity','error')=='error']
    if hard_errors and bundle.get('items'): status='degraded'
    elif hard_errors: status='unavailable'
    elif bundle.get('items'): status='ok'
    elif reranked_results: status='no_linked_match'
    else: status='no_match'
    status_resolution=resolve_governance_statuses(bookstack_content_refs(bundle))
    external_count=max(0,len(raw_results)-len(local_manual_results))
    if mode=='fixture': recall_mode='fallback'
    elif local_manual_results and external_count: recall_mode='hybrid'
    elif local_manual_results: recall_mode='local'
    else: recall_mode='live'
    bundle_v2=convert_legacy_bundle(bundle,knowledge_status=status,recall_mode=recall_mode,governance_statuses=status_resolution['statuses'],trace_id=trace['trace_id'],cache_used=status_resolution['cache_used'],cache_as_of=status_resolution['cache_as_of'])
    return {'ok':not bool(hard_errors) or bool(bundle.get('items')),'knowledge_status':status,'answer_status':gate['answer_status'],'normalized_query':normalized,'recall_plan':plan,'dataset_route':dataset_route,'raw_results':raw_results,'reranked_results':reranked_results,'knowledge_bundle_v2':bundle_v2,'knowledge_bundle':bundle,'compatibility_warnings':['knowledge_bundle is deprecated during 2.0.x; consume knowledge_bundle_v2 (drvknowledge.knowledge-bundle.v2).'],'governance_status_resolution':status_resolution,'trace':trace}

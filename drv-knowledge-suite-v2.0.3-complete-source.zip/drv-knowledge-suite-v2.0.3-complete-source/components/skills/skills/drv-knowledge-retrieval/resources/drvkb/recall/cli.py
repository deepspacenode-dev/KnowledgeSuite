"""Command line entrypoint for Recall v2."""

from __future__ import annotations

import argparse
import json

from .pipeline import run_recall


def main() -> int:
    parser = argparse.ArgumentParser(description="Drv Knowledge Recall V3")
    parser.add_argument("--query", "-q", required=True, help="真实驱动问题或检索需求")
    parser.add_argument("--mode", choices=["fixture", "live"], default="fixture", help="召回模式")
    parser.add_argument("--top-k", type=int, default=5, help="返回 knowledge_bundle 条数")
    parser.add_argument("--json", action="store_true", help="输出完整 JSON")
    args = parser.parse_args()

    response = run_recall(args.query, mode=args.mode, top_k=args.top_k)
    if args.json:
        print(json.dumps(response, ensure_ascii=False, indent=2))
    else:
        bundle = response["knowledge_bundle"]
        print(f"任务: {bundle['task_type']} / 模块: {bundle['module']} / 置信度: {bundle['confidence']}")
        print("Dataset:", " -> ".join(response["dataset_route"]))
        for index, item in enumerate(bundle["items"], 1):
            print(f"[{index}] {item['title']} ({item['confidence_level']}, {item['score']})")
            print(f"    为什么相关: {item['reason']}")
            summary=item.get('engineering_summary',{})
            if summary.get('root_cause'): print(f"    根因: {summary['root_cause']}")
            if summary.get('solution'): print(f"    处理方案: {summary['solution']}")
            print(f"    查看原文: {item['page_url']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

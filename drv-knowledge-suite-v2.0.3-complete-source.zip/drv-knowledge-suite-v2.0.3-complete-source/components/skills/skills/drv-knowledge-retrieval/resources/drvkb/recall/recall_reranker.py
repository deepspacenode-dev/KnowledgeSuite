"""Engineering semantic reranker for Recall V3."""
from __future__ import annotations
import os, re
from typing import Any
from .config_loader import load_config
from .query_normalizer import SYMPTOM_ALIASES


def _task_material_weight(task_type:str,material_type:str,rules:dict[str,Any])->float:
    return float(rules.get("task_material_weights",{}).get(task_type,{}).get(material_type,0))


def _known(value:Any)->bool:
    return str(value or "").strip().lower() not in {"","unknown","none","null"}


def _blob(result:dict[str,Any])->str:
    return " ".join(str(result.get(k) or "") for k in ("title","content","summary","module","chip","platform","project")).lower()


def _query_terms(n:dict[str,Any])->list[str]:
    out=[]
    for x in [*n.get("entities",[]),*n.get("keywords",[])]:
        s=str(x).strip().lower()
        if len(s)>=2 and s not in out: out.append(s)
    chip=str(n.get("chip") or "").lower()
    if chip not in {"","unknown"} and chip not in out: out.append(chip)
    return out[:20]


def _ratio_score(matched:int,total:int,weight:float)->float:
    return 0.0 if total<=0 else min(weight,weight*matched/total)


def _title_tokens(text:str)->set[str]:
    return {x.lower() for x in re.findall(r"[A-Za-z][A-Za-z0-9_.+-]{1,}|[\u4e00-\u9fff]{2,8}",text or "") if len(x)>=2}


def _explicit_domain_mismatch(normalized_query:dict[str,Any],result:dict[str,Any])->bool:
    enabled=os.environ.get("DRVKB_STRICT_DOMAIN_GUARD","true").strip().lower() not in {"0","false","no","off","disabled"}
    if not enabled: return False
    for field in ("module","chip"):
        requested=str(normalized_query.get(field) or "").strip().lower()
        actual=str(result.get(field) or "").strip().lower()
        if _known(requested) and _known(actual) and requested!=actual: return True
    return False


def rerank_results(normalized_query:dict[str,Any],raw_results:list[dict[str,Any]])->list[dict[str,Any]]:
    rules=load_config("rerank_rules.yaml"); reranked=[]; terms=_query_terms(normalized_query); qtitle=_title_tokens(normalized_query.get("raw_query",""))
    for result in raw_results:
        if result.get("rag_enabled") is False or str(result.get("status",""))=="deprecated": continue
        final=0.0; reasons=[]; breakdown=[]; blob=_blob(result)

        semantic=float(result.get("confidence",0.0))*float(rules["semantic_weight"])
        final+=semantic; breakdown.append({"reason":"semantic similarity","score":round(semantic,2)})

        matched_entities=[t for t in terms if t in blob]
        entity=_ratio_score(len(matched_entities),max(1,min(len(terms),6)),float(rules["entity_match_weight"]))
        final+=entity; breakdown.append({"reason":"entity match","score":round(entity,2),"matched":matched_entities[:8]})
        if matched_entities: reasons.append("entities="+",".join(matched_entities[:6]))

        requested_symptoms=list(normalized_query.get("symptoms",[])); matched_symptoms=[]
        for symptom in requested_symptoms:
            if any(alias.lower() in blob for alias in SYMPTOM_ALIASES.get(symptom,[])): matched_symptoms.append(symptom)
        symptom_score=_ratio_score(len(matched_symptoms),len(requested_symptoms),float(rules["symptom_match_weight"])) if requested_symptoms else 0.0
        final+=symptom_score; breakdown.append({"reason":"symptom match","score":round(symptom_score,2),"matched":matched_symptoms})
        if matched_symptoms: reasons.append("symptoms="+",".join(matched_symptoms))

        title_tokens=_title_tokens(str(result.get("title", ""))); overlap=len(qtitle & title_tokens); title_score=_ratio_score(overlap,max(1,min(len(qtitle),5)),float(rules["title_match_weight"])) if qtitle else 0.0
        final+=title_score; breakdown.append({"reason":"title match","score":round(title_score,2)})

        module=normalized_query.get("module","unknown")
        if module!="unknown" and result.get("module")==module:
            w=float(rules["module_match_weight"]); final+=w; breakdown.append({"reason":"module match","score":w})
        elif module!="unknown" and result.get("module") not in ("unknown",module):
            w=float(rules["module_mismatch_penalty"]); final+=w; breakdown.append({"reason":"module mismatch","score":w})

        platform=normalized_query.get("platform","unknown")
        if platform!="unknown" and str(result.get("platform","unknown")).lower()==str(platform).lower():
            w=float(rules["platform_match_weight"]); final+=w; breakdown.append({"reason":"platform match","score":w})
        chip=normalized_query.get("chip","unknown")
        if chip!="unknown" and str(result.get("chip","unknown")).lower()==str(chip).lower():
            w=float(rules["chip_exact_bonus"]); final+=w; breakdown.append({"reason":"chip exact","score":w})
        project=normalized_query.get("project","unknown")
        if project!="unknown" and str(result.get("project","unknown")).lower()==str(project).lower():
            w=float(rules["project_match_weight"]); final+=w; breakdown.append({"reason":"project match","score":w})

        status=str(result.get("status","unknown")); sw=float(rules.get("status_weights",{}).get(status,0)); final+=sw
        if sw: breakdown.append({"reason":f"status {status}","score":sw})
        material=str(result.get("material_type","docs")); mw=_task_material_weight(normalized_query.get("task_type","diagnosis"),material,rules); final+=mw
        if mw: breakdown.append({"reason":"material priority","score":mw})

        qhits=len(result.get("query_hits",[])); mq=min(float(rules["multi_query_weight"]),max(0,qhits-1)*1.5); final+=mq
        if mq: breakdown.append({"reason":"multi query consensus","score":mq})
        rrf=min(float(rules["rrf_weight"]),float(result.get("rrf_score",0.0))*60.0); final+=rrf
        if rrf: breakdown.append({"reason":"RRF","score":round(rrf,2)})

        if str(result.get("page_url") or "").startswith(("http://","https://","file://")):
            w=float(rules["page_url_weight"]); final+=w; breakdown.append({"reason":"source url","score":w})
        if material=="docs":
            w=float(rules["generic_docs_penalty"]); final+=w; breakdown.append({"reason":"generic docs","score":w})
        if not all(_known(result.get(k)) for k in ("module","material_type","status")):
            w=float(rules["missing_metadata_penalty"]); final+=w; breakdown.append({"reason":"missing metadata","score":w})

        item=dict(result); item["final_score"]=round(final,2); item["rank_reasons"]=reasons; item["score_breakdown"]=breakdown
        item["reranker_domain_mismatch"]=_explicit_domain_mismatch(normalized_query,result)
        item["matched_entities"]=matched_entities[:8]; item["matched_symptoms"]=matched_symptoms
        reranked.append(item)
    reranked.sort(key=lambda x:float(x.get("final_score",0.0)),reverse=True)
    return reranked

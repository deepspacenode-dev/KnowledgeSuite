"""Extract source-grounded engineering descriptions from retrieved knowledge."""
from __future__ import annotations
import re
from typing import Any

SECTION_ALIASES={
    "symptom":["问题现象","问题描述","现象","故障现象","症状","symptom","problem"],
    "root_cause":["根因","根本原因","原因分析","问题原因","原因","root cause","cause"],
    "solution":["解决方案","处理方案","修复方案","解决方法","处理方法","整改方案","处理","solution","fix"],
    "verification":["验证","验证结果","测试结果","结果","回归验证","verification","verify"],
}
META_LINE=re.compile(r"^\s*>?\s*[A-Za-z_][\w-]*\s*:\s*.+$")
HEADING=re.compile(r"^\s{0,3}#{1,6}\s+(.+?)\s*$")


def _clean_text(text:str)->str:
    lines=[]; in_front=False
    for i,line in enumerate((text or '').splitlines()):
        if i==0 and line.strip()=='---': in_front=True; continue
        if in_front:
            if line.strip()=='---': in_front=False
            continue
        if META_LINE.match(line): continue
        line=re.sub(r"^\s*>\s?","",line)
        lines.append(line)
    return "\n".join(lines).strip()


def _norm_heading(value:str)->str:
    return re.sub(r"[\s:：0-9.、()（）_-]+","",value).lower()


def _section_key(title:str)->str|None:
    n=_norm_heading(title)
    for key,names in SECTION_ALIASES.items():
        if any(_norm_heading(x) in n or n in _norm_heading(x) for x in names): return key
    return None


def _sections(text:str)->dict[str,str]:
    clean=_clean_text(text); cur=None; buf=[]; out={}
    def flush():
        nonlocal buf
        if cur and buf:
            value=" ".join(x.strip() for x in buf if x.strip())
            value=re.sub(r"\s+"," ",value).strip()
            if value and cur not in out: out[cur]=value[:420]
        buf=[]
    for line in clean.splitlines():
        m=HEADING.match(line)
        if m:
            flush(); cur=_section_key(m.group(1)); continue
        if cur: buf.append(line)
    flush()
    # Also support prose prefixes such as “现象：...” when headings are absent.
    for key,names in SECTION_ALIASES.items():
        if out.get(key): continue
        for name in names:
            m=re.search(rf"(?:^|\n|[。；;])\s*{re.escape(name)}\s*[:：]\s*([^\n。；;]{{4,360}})",clean,re.I)
            if m: out[key]=re.sub(r"\s+"," ",m.group(1)).strip(); break
    # Historical case pages are not always sectioned. Extract only explicit source
    # statements; never invent a root cause/solution that the text does not state.
    prose_patterns={
        "root_cause":[
            r"(?:最终|最后)(?:定位|确认)(?:为|到|是)?\s*([^。；;\n]{4,300})",
            r"(?:根因|根本原因|原因)(?:是|为|在于)\s*[:：]?\s*([^。；;\n]{4,300})",
        ],
        "solution":[
            r"(?:解决方案|处理方案|修复方案|处理方法|解决方法)\s*[:：]\s*([^。；;\n]{4,300})",
            r"((?:调整|修正|修改|重新配置|更换|增加|删除)[^。；;\n]{4,260}(?:后|并)[^。；;\n]{0,120}(?:恢复|正常|解决|通过))",
        ],
        "verification":[
            r"(?:验证结果|测试结果|回归结果)\s*[:：]\s*([^。；;\n]{4,300})",
            r"((?:Ping|ping|业务流量|网络通信|图像|启动)[^。；;\n]{0,160}(?:恢复|正常|通过))",
        ],
    }
    for key,patterns in prose_patterns.items():
        if out.get(key): continue
        for pattern in patterns:
            m=re.search(pattern,clean,re.I)
            if m:
                out[key]=re.sub(r"\s+"," ",m.group(1)).strip(); break
    return out


def _sentences(text:str)->list[str]:
    clean=_clean_text(text)
    clean=re.sub(r"^\s{0,3}#{1,6}\s+.*$","",clean,flags=re.M)
    parts=re.split(r"(?<=[。！？!?；;])\s*|\n+",clean)
    return [re.sub(r"\s+"," ",p).strip(" -*\t") for p in parts if len(p.strip())>=8]


def _relevant_excerpt(text:str,normalized:dict[str,Any],limit:int=260)->str:
    terms=[str(x).lower() for x in [*normalized.get("entities",[]),*normalized.get("keywords",[])] if x]
    best=""; best_score=-1
    for sent in _sentences(text):
        low=sent.lower(); score=sum(2 for t in terms if t in low)
        score += sum(2 for s in normalized.get("symptoms",[]) if any(alias.lower() in low for alias in {
            "link_up":["link up","phy up"],"no_traffic":["无流量","没流量","no traffic","ping不通","ping 不通"],
            "packet_loss":["丢包","packet loss"],"probe_fail":["probe失败","probe 失败","probe fail"],"no_video":["不出图","no image"],
            "mount_fail":["挂载失败","mount failed"],"panic":["panic"],"timeout":["timeout","超时"],"unstable":["不稳定","偶现"]
        }.get(s,[])))
        if score>best_score: best_score=score; best=sent
    if not best:
        best=next(iter(_sentences(text)),"")
    return best[:limit]


def _matched_entities(result:dict[str,Any],normalized:dict[str,Any])->list[str]:
    blob=(str(result.get("title",""))+" "+str(result.get("content",""))).lower(); out=[]
    candidates=[*normalized.get("entities",[])]
    chip=normalized.get("chip");
    if chip and chip!="unknown": candidates.append(chip)
    for x in candidates:
        if str(x).lower() in blob and x not in out: out.append(str(x))
    return out[:6]


def _matched_symptoms(result:dict[str,Any],normalized:dict[str,Any])->list[str]:
    return list(result.get("matched_symptoms",[])) or list(normalized.get("symptoms",[]))[:4]

SYMPTOM_LABELS={
    "link_up":"PHY Link Up","no_traffic":"无流量","packet_loss":"丢包","unstable":"链路不稳定",
    "probe_fail":"Probe 失败","no_video":"不出图","mount_fail":"挂载失败","panic":"Kernel Panic",
    "timeout":"超时","io_error":"I/O 错误"
}

def extract_engineering_evidence(result:dict[str,Any],normalized:dict[str,Any])->dict[str,Any]:
    pieces_text=[str(result.get("content") or result.get("summary") or "")]
    pieces_text.extend(str(x) for x in result.get("supporting_chunks",[]) if x)
    text="\n\n".join(dict.fromkeys(x for x in pieces_text if x))
    sections=_sections(text); overview=_relevant_excerpt(text,normalized)
    entities=_matched_entities(result,normalized); symptoms=_matched_symptoms(result,normalized)
    pieces=[]
    if entities: pieces.append("实体匹配："+"、".join(entities))
    if symptoms: pieces.append("现象匹配："+"、".join(SYMPTOM_LABELS.get(x,x) for x in symptoms))
    mt=str(result.get("material_type") or "docs")
    type_label={"cases":"历史案例","manuals":"技术手册","tech_notes":"技术专题","project_docs":"项目资料","docs":"通用资料"}.get(mt,mt)
    pieces.append(f"来源类型：{type_label}")
    return {
        "overview":overview,
        "symptom":sections.get("symptom",""),
        "root_cause":sections.get("root_cause",""),
        "solution":sections.get("solution",""),
        "verification":sections.get("verification",""),
        "matched_entities":entities,
        "matched_symptoms":symptoms,
        "relevance_reason":"；".join(pieces),
    }

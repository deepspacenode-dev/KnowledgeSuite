"""Trace helpers for Recall V3 reporting."""
from __future__ import annotations
import uuid
from typing import Any


def build_trace(*,mode:str,normalized_query:dict[str,Any],dataset_route:list[str],raw_results:list[dict[str,Any]],reranked_results:list[dict[str,Any]],external_dependency_errors:list[dict[str,Any]]|None=None,recall_plan:dict[str,Any]|None=None,relevance_gate:dict[str,Any]|None=None)->dict[str,Any]:
    gate=relevance_gate or {}
    return {
        "version":"recall-v4","trace_id":"recall-"+uuid.uuid4().hex,"mode":mode,"raw_query":normalized_query.get("raw_query",""),"task_type":normalized_query.get("task_type",""),
        "module":normalized_query.get("module",""),"platform":normalized_query.get("platform",""),"symptoms":normalized_query.get("symptoms",[]),
        "query_variants":normalized_query.get("query_variants",[]),"expanded_queries":normalized_query.get("expanded_queries",[]),"dataset_route":dataset_route,"recall_plan":recall_plan or {},
        "external_dependency_errors":external_dependency_errors or [],
        "candidate_count":len(raw_results),"document_count":len(reranked_results),
        "answer_status":gate.get("answer_status","no_match"),"relevance_profile":gate.get("profile"),"relevance_thresholds":gate.get("thresholds",{}),"top_margin":gate.get("top_margin"),
        "rejected_candidates":gate.get("rejected",[]),
        "raw_top_k":[{"title":x.get("title",""),"dataset":x.get("dataset",""),"confidence":x.get("confidence",0.0),"query_hits":x.get("query_hits",[]),"lane_hits":x.get("lane_hits",[])} for x in raw_results],
        "rerank_events":[{"title":x.get("title",""),"document_key":x.get("document_key",""),"source_key":x.get("source_key",""),"page_url":x.get("page_url",""),"dataset":x.get("dataset",""),"module":x.get("module",""),"chip":x.get("chip",""),"material_type":x.get("material_type",""),"final_score":x.get("final_score",0.0),"reasons":x.get("rank_reasons",[]),"score_breakdown":x.get("score_breakdown",[])} for x in reranked_results]
    }

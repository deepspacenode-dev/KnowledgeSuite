"""Data models for knowledge gap events, items, and todos."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime
import hashlib
import re
from typing import Any
from uuid import uuid4


PRIORITY_ORDER = {"low": 1, "medium": 2, "high": 3, "critical": 4}
EVENT_STATUS_OPEN = "open"
GAP_STATUS_TODO = "todo"
TODO_STATUS_TODO = "todo"
VALIDATION_NOT_TESTED = "not_tested"


def now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def date_stamp() -> str:
    return datetime.now().strftime("%Y%m%d")


def make_id(prefix: str, discriminator: str | None = None) -> str:
    parts = [prefix, date_stamp()]
    if discriminator:
        parts.append(discriminator.upper())
    parts.append(uuid4().hex[:8].upper())
    return "-".join(parts)


def stable_id(prefix: str, parts: list[str], discriminator: str | None = None) -> str:
    normalized = "\x1f".join(_normalize_id_part(part) for part in parts)
    digest = hashlib.sha1(normalized.encode("utf-8")).hexdigest()[:8].upper()
    tokens = [prefix]
    if discriminator:
        tokens.append(_id_component(discriminator))
    tokens.append(digest)
    return "-".join(tokens)


def _normalize_id_part(value: str) -> str:
    return str(value or "").strip().lower()


def _id_component(value: str) -> str:
    component = re.sub(r"[^A-Za-z0-9]+", "-", str(value or "").strip().upper()).strip("-")
    return component or "GENERAL"


def priority_rank(priority: str) -> int:
    return PRIORITY_ORDER.get(priority, 1)


def highest_priority(priorities: list[str]) -> str:
    if not priorities:
        return "medium"
    return max(priorities, key=priority_rank)


@dataclass
class GapEvent:
    id: str
    time: str
    source_agent: str
    workflow: str
    project_context: str
    user_question: str
    problem_summary: str
    module: str
    platform: str
    issue_background: str
    trigger_reason: list[str]
    recall_snapshot: dict[str, Any]
    gap_detail: str
    impact: str
    suggestion: list[str]
    suggested_dataset: list[str]
    priority: str
    status: str
    validation_questions: list[str]
    user_manual_addition: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class GapItem:
    id: str
    title: str
    module: str
    platforms: list[str]
    gap_type: list[str]
    event_count: int
    priority: str
    typical_background: str
    impact: str
    suggested_contents: list[dict[str, str]]
    validation_questions: list[str]
    status: str
    related_events: list[str]
    expected_sources: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class GapTodo:
    id: str
    gap_id: str
    priority: str
    module: str
    task_title: str
    task_type: str
    target_dataset: str
    suggested_bookstack_title: str
    suggested_outline: list[str]
    acceptance_criteria: list[str]
    status: str
    validation_status: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

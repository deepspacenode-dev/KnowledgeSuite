"""RAGFlow client for Recall V3: multi-query, lane-based, parallel candidate retrieval."""
from __future__ import annotations
import json, os, urllib.error, urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any
from .config_loader import PROJECT_ROOT, load_jsonish, load_dotenv, dataset_map, logical_dataset, canonical_dataset
from drv_knowledge_core.source_metadata import extract_chunk_metadata, normalize_bookstack_url

FIXTURE_PATH=PROJECT_ROOT/"tests"/"recall"/"fixtures"/"recall_results.json"
REFERENCE_METADATA_FIELDS=[
    "page_id","bookstack_page_id","page_url","source_url","source_key","content_ref",
    "title","material_type","status","module","platform","chip","project","rag_enabled",
]


def _text_match_score(query:str,terms:list[str])->int:
    lower=query.lower(); return sum(1 for t in terms if t.lower() in lower)


def _http_link(value:str)->bool:
    return str(value or "").startswith(("http://","https://"))


def _fallback_page_link(page_id:str)->tuple[str,str]:
    """Construct a source link only when an operator provides a safe page-ID template.

    Standard BookStack human URLs require slugs, so page_id alone is insufficient.
    Recall must never issue a synchronous BookStack lookup merely to resolve links.
    """
    pid=str(page_id or "").strip()
    if not pid: return "","none"
    template=os.environ.get("BOOKSTACK_PAGE_URL_TEMPLATE","").strip()
    if template:
        try: return normalize_bookstack_url(template.format(page_id=pid,id=pid)),"page_id_template"
        except Exception: pass
    # Standard BookStack human-facing URLs contain book/page slugs and cannot be
    # safely reconstructed from page_id alone. Do not fabricate an API URL and call
    # it "original". Operators with a site-specific ID redirect may configure the
    # template above; otherwise the candidate is kept for diagnostics but excluded
    # from the public bundle until governance repairs its source metadata.
    return "","none"


def _source_identity(meta:dict[str,Any],did:str,document_id:str,chunk_id:str)->tuple[str,str,str,str]:
    page_id=str(meta.get("page_id") or meta.get("bookstack_page_id") or "").strip()
    page_url=normalize_bookstack_url(str(meta.get("page_url") or meta.get("source_url") or "").strip())
    link_source="ragflow_metadata" if _http_link(page_url) else "none"
    if not _http_link(page_url):
        page_url,link_source=_fallback_page_link(page_id)
    source_key=str(meta.get("source_key") or (f"bookstack_page:{page_id}" if page_id else "")).strip()
    source=page_url if _http_link(page_url) else f"ragflow://{did}/{document_id}#{chunk_id}"
    return source,page_url,source_key,link_source


def _fixture_results(n:dict[str,Any],route:list[str],top_k:int,plan:dict[str,Any]|None=None)->list[dict[str,Any]]:
    results=load_jsonish(FIXTURE_PATH); blob=" ".join([n["raw_query"],*n.get("expanded_queries",[])])
    ranked=[]
    lane_for={}
    if plan:
        for lane in plan.get("lanes",[]):
            for ds in lane.get("datasets",[]): lane_for[canonical_dataset(ds)]=lane.get("name","default")
    for item in results:
        it=dict(item); it["dataset"]=canonical_dataset(it.get("dataset",""))
        if it.get("dataset") not in route: continue
        match=_text_match_score(blob,it.get("match_terms",[])); module_match=it.get("module")==n.get("module")
        if match==0 and not module_match: continue
        it["confidence"]=min(0.99,float(it.get("confidence",0.0))+match*0.03); it["fixture_match_count"]=match
        it["query_hits"]=[x.get("kind","raw") for x in n.get("query_variants",[]) if _text_match_score(x.get("query",""),it.get("match_terms",[]))>0] or ["raw"]
        it["lane_hits"]=[lane_for.get(it["dataset"],"default")]
        it.setdefault("document_id",it.get("title","")); it.setdefault("chunk_id",it.get("title","")); it.setdefault("source_key","")
        ranked.append(it)
    ranked.sort(key=lambda x:(route.index(x["dataset"]) if x.get("dataset") in route else 99,-x["confidence"],x["title"]))
    return ranked[:max(top_k*8,30)]


def _diag(diag:list[dict[str,Any]]|None,message:str,kind:str,*,severity:str="error")->None:
    if diag is not None: diag.append({"component":"ragflow","mode":"live","kind":kind,"severity":severity,"message":message})


def _parse_names_json()->dict[str,str]:
    raw=os.environ.get("RAGFLOW_DATASET_NAMES_JSON","").strip()
    if not raw: return {}
    try: value=json.loads(raw)
    except json.JSONDecodeError: return {}
    if not isinstance(value,dict): return {}
    known=set(dataset_map().values())|set(dataset_map().keys()); out={}
    for k,v in value.items():
        ks,vs=str(k),str(v)
        if vs in known: out[ks]=canonical_dataset(vs)
        elif ks in known: out[vs]=canonical_dataset(ks)
        else: out[ks]=vs
    return out


def _discover_dataset_names(base:str,key:str,diag:list[dict[str,Any]]|None)->dict[str,str]:
    path=os.environ.get("RAGFLOW_DATASETS_PATH","/api/v1/datasets").strip() or "/api/v1/datasets"
    sep='&' if '?' in path else '?'; url=base.rstrip('/')+'/'+path.lstrip('/')+f"{sep}page=1&page_size=1000"
    req=urllib.request.Request(url,headers={"Authorization":"Bearer "+key,"Accept":"application/json"},method="GET")
    try:
        with urllib.request.urlopen(req,timeout=int(os.environ.get("RAGFLOW_TIMEOUT","30"))) as resp:
            payload=json.loads(resp.read().decode('utf-8'))
    except Exception as exc:
        _diag(diag,f"Dataset auto-discovery failed: {exc}","DatasetDiscoveryFailed",severity="warning"); return {}
    data=payload.get('data',payload) if isinstance(payload,dict) else payload
    rows=(data.get('datasets') or data.get('items') or data.get('data') or []) if isinstance(data,dict) else data
    out={}
    if not isinstance(rows,list): return out
    for row in rows:
        if not isinstance(row,dict): continue
        did=str(row.get('id') or row.get('dataset_id') or '').strip(); name=str(row.get('name') or row.get('dataset_name') or '').strip()
        if did and name: out[did]=canonical_dataset(name)
    return out


def _resolve_dataset_ids(route:list[str],base:str,key:str,diag:list[dict[str,Any]]|None)->tuple[list[str],dict[str,str]]:
    load_dotenv(); id_to_name=_parse_names_json(); wanted=[]
    for canonical in route:
        logical=logical_dataset(canonical); explicit=os.environ.get("RAGFLOW_DATASET_ID_"+logical.upper(),"").strip()
        if explicit: wanted.append(explicit); id_to_name[explicit]=canonical; continue
        for did,name in list(id_to_name.items()):
            if canonical_dataset(name)==canonical: wanted.append(did); break
    if len(set(wanted)) < len(route):
        for did,name in _discover_dataset_names(base,key,diag).items(): id_to_name.setdefault(did,name)
        for canonical in route:
            if any(canonical_dataset(id_to_name.get(did,''))==canonical for did in wanted): continue
            for did,name in id_to_name.items():
                if canonical_dataset(name)==canonical: wanted.append(did); break
    if not wanted:
        generic=[x.strip() for x in os.environ.get("RAGFLOW_DATASET_IDS","").split(",") if x.strip()]
        wanted.extend(generic)
        if len(generic)==len(route):
            for did,name in zip(generic,route): id_to_name.setdefault(did,name)
    wanted=list(dict.fromkeys(wanted)); unresolved=[name for name in route if not any(canonical_dataset(id_to_name.get(did,''))==name for did in wanted)]
    if not wanted: _diag(diag,"No dataset IDs resolved. Configure RAGFLOW_DATASET_ID_* / RAGFLOW_DATASET_NAMES_JSON, or allow /api/v1/datasets discovery.","MissingDatasetConfiguration")
    elif unresolved: _diag(diag,"Some routed datasets were not resolved: "+", ".join(unresolved),"PartialDatasetResolution",severity="warning")
    return wanted,id_to_name


def _bool(value:Any,default:bool=True)->bool:
    if value is None: return default
    if isinstance(value,bool): return value
    if isinstance(value,(int,float)): return bool(value)
    return str(value).strip().lower() not in {'0','false','no','off','disabled'}


def _extract_metadata(chunk:dict[str,Any],content:str)->dict[str,Any]:
    return extract_chunk_metadata(chunk,content)


def _int_env(name:str,default:int,minimum:int=1,maximum:int=4096)->int:
    try: value=int(os.environ.get(name,str(default)))
    except (TypeError,ValueError): value=default
    return max(minimum,min(value,maximum))


def _float_env(name:str,default:float)->float:
    try: value=float(os.environ.get(name,str(default)))
    except (TypeError,ValueError): value=default
    return max(0.0,min(value,1.0))


def _metadata_condition(normalized:dict[str,Any])->dict[str,Any]|None:
    strict=os.environ.get("DRVKB_RAGFLOW_METADATA_FILTER","true").strip().lower() not in {"0","false","no","off","disabled"}
    if not strict: return None
    conditions=[]
    for name in ("module","chip","project"):
        value=str(normalized.get(name) or "").strip().lower()
        if value and value not in {"unknown","none","all"}:
            conditions.append({"name":name,"comparison_operator":"=","value":value})
    return {"logic":"and","conditions":conditions} if conditions else None


def _request_once(base:str,key:str,path:str,question:str,dataset_ids:list[str],candidate_k:int,timeout:int,metadata_condition:dict[str,Any]|None=None)->tuple[list[dict[str,Any]],str|None]:
    page_size=max(candidate_k,_int_env("DRVKB_RAGFLOW_PAGE_SIZE",12,1,256))
    knn_top_k=max(page_size,_int_env("DRVKB_RAGFLOW_KNN_TOP_K",256,1,2048))
    knn_num_candidates=max(knn_top_k,_int_env("DRVKB_RAGFLOW_KNN_NUM_CANDIDATES",1024,1,4096))
    rerank_candidates=max(page_size,_int_env("DRVKB_RAGFLOW_RERANK_CANDIDATES",64,1,2048))
    payload={
        "question":question,"dataset_ids":dataset_ids,"page":1,"page_size":page_size,
        "similarity_threshold":_float_env("DRVKB_RAGFLOW_SIMILARITY_THRESHOLD",0.25),
        "vector_similarity_weight":_float_env("DRVKB_RAGFLOW_VECTOR_WEIGHT",0.35),
        "knn_top_k":knn_top_k,"knn_num_candidates":knn_num_candidates,
        "rerank_candidates_count":rerank_candidates,
        "keyword":os.environ.get("DRVKB_RAGFLOW_KEYWORD","true").strip().lower() not in {"0","false","no","off","disabled"},
        "highlight":False,
        "reference_metadata":{"include":True,"fields":REFERENCE_METADATA_FIELDS},
    }
    if metadata_condition: payload["metadata_condition"]=metadata_condition
    req=urllib.request.Request(base.rstrip("/")+"/"+path.lstrip("/"),data=json.dumps(payload).encode(),headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"},method="POST")
    try:
        with urllib.request.urlopen(req,timeout=timeout) as resp: data=json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body=exc.read().decode("utf-8",errors="ignore")[:500]; return [],f"HTTP {exc.code}: {body}"
    except Exception as exc: return [],str(exc)
    if isinstance(data,dict) and data.get("code",0) not in (0,None): return [],f"RAGFlow code={data.get('code')} message={data.get('message','')}"
    container=data.get("data",{}) or {} if isinstance(data,dict) else {}; chunks=container.get("chunks",[]) if isinstance(container,dict) else []
    return chunks if isinstance(chunks,list) else [],None


def _chunk_to_result(c:dict[str,Any],id_to_name:dict[str,str],*,query_kind:str,lane_name:str,rank:int)->dict[str,Any]:
    did=str(c.get("dataset_id","") or ""); dataset=canonical_dataset(id_to_name.get(did,did)); content=str(c.get("content","") or ""); meta=_extract_metadata(c,content)
    chunk_id=str(c.get('id') or c.get('chunk_id') or ''); document_id=str(c.get('document_id') or '')
    source,page_url,source_key,link_source=_source_identity(meta,did,document_id,chunk_id)
    material=str(meta.get('material_type') or logical_dataset(dataset) or 'docs')
    return {
        "title":c.get("document_keyword") or c.get("document_name") or meta.get("title") or "unknown",
        "summary":"","content":content,"source":source,"page_url":page_url,"page_id":str(meta.get("page_id") or meta.get("bookstack_page_id") or ""),
        "source_key":source_key,"link_source":link_source,"dataset":dataset,"material_type":material,"status":str(meta.get("status") or "unknown"),
        "module":str(meta.get("module") or "unknown"),"platform":str(meta.get("platform") or "unknown"),"chip":str(meta.get("chip") or "unknown"),"project":str(meta.get("project") or "unknown"),
        "rag_enabled":_bool(meta.get("rag_enabled"),True),"metadata_complete":all(str(meta.get(k) or '').lower() not in {'','unknown','none'} for k in ('material_type','status','module')),
        "confidence":float(c.get("similarity",c.get("vector_similarity",0.0)) or 0.0),"document_id":document_id,"chunk_id":chunk_id,
        "query_hits":[query_kind],"lane_hits":[lane_name],"retrieval_rank":rank,"rrf_score":1.0/(60.0+rank)
    }


def _merge_candidates(items:list[dict[str,Any]],cap:int)->list[dict[str,Any]]:
    merged={}
    for item in items:
        doc=str(item.get("document_id") or item.get("title") or "")
        chunk=str(item.get("chunk_id") or hash(str(item.get("content") or "")))
        key=(item.get("dataset"),doc,chunk)
        if key not in merged:
            merged[key]=dict(item); continue
        cur=merged[key]
        if float(item.get("confidence",0))>float(cur.get("confidence",0)):
            keep_queries=list(cur.get("query_hits",[])); keep_lanes=list(cur.get("lane_hits",[])); keep_rrf=float(cur.get("rrf_score",0))
            cur=dict(item); cur["query_hits"]=keep_queries; cur["lane_hits"]=keep_lanes; cur["rrf_score"]=keep_rrf
            merged[key]=cur
        for q in item.get("query_hits",[]):
            if q not in cur["query_hits"]: cur["query_hits"].append(q)
        for lane in item.get("lane_hits",[]):
            if lane not in cur["lane_hits"]: cur["lane_hits"].append(lane)
        cur["rrf_score"]=float(cur.get("rrf_score",0))+float(item.get("rrf_score",0))
    out=list(merged.values()); out.sort(key=lambda x:(float(x.get("confidence",0)),float(x.get("rrf_score",0))),reverse=True)
    return out[:cap]


def _live_results(n:dict[str,Any],route:list[str],top_k:int,diag:list[dict[str,Any]]|None,plan:dict[str,Any]|None)->list[dict[str,Any]]:
    load_dotenv(); base=os.environ.get("RAGFLOW_BASE_URL","").strip(); key=os.environ.get("RAGFLOW_API_KEY","").strip()
    if not base or not key:
        _diag(diag,"RAGFLOW_BASE_URL and RAGFLOW_API_KEY are required for live mode","MissingEnvironment"); return []
    all_route=list(dict.fromkeys([*route,canonical_dataset("docs")]))
    ids,id_to_name=_resolve_dataset_ids(all_route,base,key,diag)
    if not ids: return []
    by_dataset:dict[str,list[str]]={}
    for did in ids: by_dataset.setdefault(canonical_dataset(id_to_name.get(did,"")),[]).append(did)
    path=os.environ.get("RAGFLOW_RETRIEVAL_PATH","/api/v1/retrieval").strip() or "/api/v1/retrieval"
    timeout=int(os.environ.get("RAGFLOW_TIMEOUT","30")); candidate_k=max(int(os.environ.get("DRVKB_RECALL_PER_REQUEST","10")),top_k*2)
    pool_cap=max(int(os.environ.get("DRVKB_RECALL_POOL_CAP","50")),top_k*6); max_workers=max(1,min(int(os.environ.get("DRVKB_RECALL_WORKERS","6")),8))
    if not plan:
        plan={"lanes":[{"name":"default","datasets":[logical_dataset(x) for x in route],"queries":n.get("query_variants",[{"kind":"raw","query":n["raw_query"]}])}],"fallback":{"name":"fallback","datasets":["docs"],"queries":[{"kind":"raw","query":n["raw_query"]}]},"fallback_min_candidates":3}
    metadata_condition=_metadata_condition(n); tasks=[]
    for lane in plan.get("lanes",[]):
        lane_ids=[]
        for ds in lane.get("datasets",[]): lane_ids.extend(by_dataset.get(canonical_dataset(ds),[]))
        if not lane_ids: continue
        for q in lane.get("queries",[]):
            if q.get("query"): tasks.append((lane.get("name","default"),q.get("kind","raw"),q["query"],lane_ids))
    all_items=[]; successful_requests=0
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures={ex.submit(_request_once,base,key,path,qtext,dids,candidate_k,timeout,metadata_condition):(lane,qkind) for lane,qkind,qtext,dids in tasks}
        for fut in as_completed(futures):
            lane,qkind=futures[fut]; chunks,err=fut.result()
            if err:
                _diag(diag,f"lane={lane} query={qkind}: {err}","RetrievalRequestFailed",severity="warning"); continue
            successful_requests += 1
            for rank,c in enumerate(chunks[:candidate_k],1): all_items.append(_chunk_to_result(c,id_to_name,query_kind=qkind,lane_name=lane,rank=rank))
    merged=_merge_candidates(all_items,pool_cap)
    if tasks and successful_requests==0:
        _diag(diag,"All Recall V3 retrieval requests failed.","AllRetrievalRequestsFailed")
    if len(merged)<int(plan.get("fallback_min_candidates",3)):
        fb=plan.get("fallback",{}); fb_ids=[]
        for ds in fb.get("datasets",[]): fb_ids.extend(by_dataset.get(canonical_dataset(ds),[]))
        if fb_ids:
            for q in fb.get("queries",[])[:1]:
                chunks,err=_request_once(base,key,path,q.get("query") or n["raw_query"],fb_ids,candidate_k,timeout,metadata_condition)
                if err: _diag(diag,f"fallback: {err}","FallbackRetrievalFailed",severity="warning")
                else:
                    for rank,c in enumerate(chunks[:candidate_k],1): all_items.append(_chunk_to_result(c,id_to_name,query_kind=q.get("kind","raw"),lane_name="fallback",rank=rank))
            merged=_merge_candidates(all_items,pool_cap)
    return merged


def search_ragflow(n:dict[str,Any],route:list[str],*,mode:str="live",top_k:int=5,diagnostics:list[dict[str,Any]]|None=None,plan:dict[str,Any]|None=None)->list[dict[str,Any]]:
    if mode=="fixture": return _fixture_results(n,route,top_k,plan)
    if mode in {"live","auto"}: return _live_results(n,route,top_k,diagnostics,plan)
    raise ValueError(f"unsupported recall mode: {mode}")

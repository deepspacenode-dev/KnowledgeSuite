# Shared configuration

Dataset、别名和治理路径统一由 `drv-knowledge-core/config/knowledge.json` 维护。

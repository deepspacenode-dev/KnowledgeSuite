"""Deterministic domain browsing with bounded parallel enrichment and local cache."""
from __future__ import annotations
import json, os, re, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any
from clients import ragflow_admin
from .catalog import load_catalog, build_catalog, runtime_dir
from .source_resolver import resolve_sources
from drv_knowledge_core.source_metadata import parse_embedded_metadata, normalize_bookstack_url
from runtime import remote_cache_signature

def _summary(content:str)->str:
    text=(content or '').strip()
    if not text: return ''
    lines=[x.strip() for x in text.splitlines() if x.strip()]
    for i,line in enumerate(lines):
        if any(k in line for k in ('问题描述','问题现象','问题背景','现象：','背景：')):
            candidate=re.sub(r'^#+\s*','',line)
            if len(candidate)>12 and not candidate.strip().startswith('|'): return candidate[:220]
            if i+1<len(lines):
                nxt=re.sub(r'<[^>]+>','',lines[i+1]).strip()
                if nxt and not set(nxt) <= {'|','-',' ',':'}: return nxt[:220]
    for i,line in enumerate(lines[:-2]):
        if line.startswith('|') and ('问题描述' in line or '问题现象' in line):
            headers=[x.strip() for x in line.strip('|').split('|')]
            idx=next((j for j,h in enumerate(headers) if '问题描述' in h or '问题现象' in h),None)
            for row in lines[i+1:i+5]:
                if not row.startswith('|') or set(row.replace('|','').strip()) <= {'-',':',' '}: continue
                cells=[re.sub(r'<[^>]+>','',x).strip() for x in row.strip('|').split('|')]
                if idx is not None and idx < len(cells) and len(cells[idx])>=4: return cells[idx][:220]
    for line in lines:
        if line.startswith('>') or line.startswith('---'): continue
        clean=re.sub(r'<[^>]+>','',re.sub(r'^#+\s*','',line)).strip('| ')
        if len(clean)>=12: return clean[:220]
    return re.sub(r'\s+',' ',text)[:220]

def _title(doc,meta,content):
    value=doc.get('title') or doc.get('name') or doc.get('document_name') or meta.get('title')
    if value: return str(value)
    for line in (content or '').splitlines():
        if line.lstrip().startswith('#'): return line.lstrip('#').strip()[:160]
    return str(doc.get('id') or doc.get('document_id') or 'unknown')

def _matches(item,query):
    q=(query or '').strip().lower()
    if not q: return True
    blob=' '.join(str(item.get(k,'')) for k in ('title','summary','chapter','book','module','chip','platform','project')).lower()
    return all(term in blob for term in q.split() if term)

def _cache_path(dataset_id:str)->Path:
    p=runtime_dir()/'cache'/'browse'; p.mkdir(parents=True,exist_ok=True)
    return p/(re.sub(r'[^A-Za-z0-9_.-]','_',dataset_id)+'.json')

def _load_cache(dataset_id:str):
    p=_cache_path(dataset_id)
    if not p.is_file(): return None
    ttl=int(os.environ.get('DRVKB_BROWSE_CACHE_TTL_SECONDS','900'))
    try:
        obj=json.loads(p.read_text(encoding='utf-8'))
        if obj.get('source_signature')!=remote_cache_signature(): return None
        if time.time()-float(obj.get('generated_at',0)) <= ttl: return obj
    except Exception: pass
    return None

def _write_cache(dataset_id:str,items,attachments,total):
    obj={'generated_at':time.time(),'dataset_id':dataset_id,'source_signature':remote_cache_signature(),'items':items,'attachments':attachments,'total_documents':total}
    _cache_path(dataset_id).write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')

def _doc_meta(doc):
    out={}
    for key in ('meta_fields','metadata','document_metadata'):
        if isinstance(doc.get(key),dict): out.update(doc[key])
    return out

def _enrich_one(did,doc):
    docid=str(doc.get('id') or doc.get('document_id') or '').strip(); meta=_doc_meta(doc); content=''
    # New ingests should carry page_url/meta_fields. Only old docs need the chunk call.
    need_chunk=not (meta.get('page_url') or meta.get('source_url') or meta.get('original_url')) or not meta.get('title')
    if need_chunk and docid:
        cr=ragflow_admin.chunks(did,docid,page_size=1)
        chunks=cr.get('data',[]) if cr.get('ok') else []
        if chunks:
            content=str(chunks[0].get('content') or chunks[0].get('content_with_weight') or '')
            for k,v in parse_embedded_metadata(content).items(): meta.setdefault(k,v)
    item={'id':docid,'title':_title(doc,meta,content),'summary':_summary(content),
      'document_name':doc.get('name') or doc.get('document_name'),'chunk_count':doc.get('chunk_count'),'chunk_method':doc.get('chunk_method'),
      'page_id':meta.get('bookstack_page_id') or meta.get('page_id'),'chapter':meta.get('chapter',''),'book':meta.get('book',''),
      'module':meta.get('module',''),'chip':meta.get('chip',''),'platform':meta.get('platform',''),'project':meta.get('project',''),
      'original_url':meta.get('original_url') or meta.get('page_url') or meta.get('source_url') or ''}
    item['page_url']=normalize_bookstack_url(item['original_url'])
    return item

def _browse_ragflow(domain:str,*,query:str='',limit:int|None=None,enrich:bool=True,refresh_catalog:bool=False,include_attachments:bool=False,refresh_cache:bool=False)->dict[str,Any]:
    cat=build_catalog() if refresh_catalog else load_catalog(); sources=resolve_sources(domain); info=cat.get('domains',{}).get(domain,{})
    did=info.get('dataset_id')
    if not did:
        cat=build_catalog(); info=cat.get('domains',{}).get(domain,{}); did=info.get('dataset_id')
    if not did: return {'ok':False,'error':'KnowledgeSourceUnresolved','domain':domain,'message':f'No RAGFlow dataset ID resolved for {sources.get("dataset_name")}. Run `kb bootstrap` or configure RAGFlow.'}
    cached=None if refresh_cache else _load_cache(did)
    if cached:
        all_items=cached.get('items',[]); attachments=cached.get('attachments',[]); total=cached.get('total_documents',len(all_items)+len(attachments)); cache_hit=True
    else:
        docs=ragflow_admin.documents(did,all_items=True,page_size=100)
        if not docs.get('ok'): return {'ok':False,'error':'BrowseFailed','domain':domain,'detail':docs}
        knowledge=[]; attachments=[]
        for doc in docs.get('data',[]):
            name=str(doc.get('name') or doc.get('document_name') or ''); method=str(doc.get('chunk_method') or doc.get('parser_id') or '').lower()
            is_attachment=method=='picture' or name.lower().endswith(('.png','.jpg','.jpeg','.gif','.webp','.bmp'))
            if is_attachment: attachments.append({'id':str(doc.get('id') or doc.get('document_id') or ''),'name':name,'chunk_method':method})
            else: knowledge.append(doc)
        if enrich:
            workers=max(1,min(int(os.environ.get('DRVKB_BROWSE_WORKERS','8')),16))
            enriched=[None]*len(knowledge)
            with ThreadPoolExecutor(max_workers=workers) as ex:
                futs={ex.submit(_enrich_one,did,doc):i for i,doc in enumerate(knowledge)}
                for fut in as_completed(futs):
                    i=futs[fut]
                    try: enriched[i]=fut.result()
                    except Exception: enriched[i]=_enrich_one(did,{**knowledge[i],'id':knowledge[i].get('id')}) if False else {'id':str(knowledge[i].get('id') or ''),'title':str(knowledge[i].get('name') or 'unknown'),'summary':'','page_url':''}
            all_items=[x for x in enriched if x]
        else:
            all_items=[_enrich_one(did,{**doc,'meta_fields':_doc_meta(doc)}) if _doc_meta(doc) else {'id':str(doc.get('id') or ''),'title':str(doc.get('name') or ''),'summary':'','page_url':''} for doc in knowledge]
        total=docs.get('total',len(docs.get('data',[]))); _write_cache(did,all_items,attachments,total); cache_hit=False
    matched=[]
    for item in all_items:
        if _matches(item,query): matched.append(item)
        if limit and len(matched)>=limit: break
    return {'ok':True,'operation':'browse','domain':domain,'dataset':info.get('dataset_name') or sources.get('dataset_name'),'dataset_id':did,
      'total_documents':total,'matched':len(matched),'query':query,'items':matched,'attachments_count':len(attachments),
      'attachments':attachments if include_attachments else [],'catalog_path':cat.get('catalog_path'),'cache_hit':cache_hit}



def _manual_key(item:dict[str,Any])->str:
    title=re.sub(r'\.(md|markdown|txt)$','',str(item.get('title') or '')).strip().lower()
    title=re.sub(r'[^a-z0-9\u4e00-\u9fff]+','',title)
    return title or str(item.get('page_url') or item.get('id') or '')


def browse(domain:str,*,query:str='',limit:int|None=None,enrich:bool=True,refresh_catalog:bool=False,include_attachments:bool=False,refresh_cache:bool=False)->dict[str,Any]:
    """Browse RAGFlow domains, with a stdlib-only local Markdown fallback for manuals."""
    if domain!='manuals':
        return _browse_ragflow(domain,query=query,limit=limit,enrich=enrich,refresh_catalog=refresh_catalog,include_attachments=include_attachments,refresh_cache=refresh_cache)
    from .local_manuals import browse as browse_local
    local=browse_local(query=query,limit=None,refresh=refresh_cache)
    remote=_browse_ragflow(domain,query=query,limit=None,enrich=enrich,refresh_catalog=refresh_catalog,include_attachments=include_attachments,refresh_cache=refresh_cache)
    # Local manuals must remain usable even when RAGFlow manuals are empty/unavailable.
    if not remote.get('ok') and not local.get('items'):
        return remote
    merged=[]; seen=set()
    # Prefer remote entry when the same title exists because it normally carries the canonical BookStack URL.
    for item in (remote.get('items',[]) if remote.get('ok') else []):
        obj=dict(item); obj.setdefault('source_kind','ragflow'); k=_manual_key(obj); seen.add(k); merged.append(obj)
    for item in local.get('items',[]):
        obj=dict(item); k=_manual_key(obj)
        if k in seen: continue
        seen.add(k); merged.append(obj)
    if query:
        # local search already ranked; remote order is retained first, but exact query terms can move local hits upward.
        terms=[x for x in query.lower().split() if x]
        def rank(it):
            blob=' '.join(str(it.get(k,'') or '') for k in ('title','summary','chapter','relative_path')).lower()
            return sum(1 for t in terms if t in blob)
        merged.sort(key=rank,reverse=True)
    if limit: merged=merged[:limit]
    return {
        'ok':True,'operation':'browse','domain':'manuals','dataset':remote.get('dataset') if remote.get('ok') else 'local_manuals',
        'dataset_id':remote.get('dataset_id') if remote.get('ok') else None,
        'sources':['local_manuals']+(['ragflow'] if remote.get('ok') else []),
        'total_documents':(int(remote.get('total_documents') or 0) if remote.get('ok') else 0)+int(local.get('total_documents') or 0),
        'matched':len(merged),'query':query,'items':merged,'attachments_count':int(remote.get('attachments_count') or 0) if remote.get('ok') else 0,
        'attachments':remote.get('attachments',[]) if remote.get('ok') and include_attachments else [],
        'catalog_path':remote.get('catalog_path') if remote.get('ok') else None,
        'cache_hit':bool(remote.get('cache_hit')) and bool(local.get('cache_hit')),
        'local_manuals':{'root':local.get('root'),'documents':local.get('total_documents',0),'matched':local.get('matched',0),'index_path':local.get('index_path'),'chunk_count':local.get('chunk_count',0)},
        'ragflow_manuals':{'ok':bool(remote.get('ok')),'documents':remote.get('total_documents',0) if remote.get('ok') else 0,'error':None if remote.get('ok') else remote.get('error')},
    }

"""Parse /kb commands into deterministic actions."""
from __future__ import annotations
import shlex
from typing import Any
from .source_resolver import all_domains

ALIASES={'案例':'cases','手册':'manuals','资料':'docs','项目':'project_docs','专题':'tech_notes'}

def parse_command(text:str)->dict[str,Any]:
    raw=(text or '').strip(); tokens=shlex.split(raw)
    if tokens and tokens[0].lower() in {'/kb','kb','drvkb'}: tokens=tokens[1:]
    if not tokens: return {'operation':'help'}
    first=ALIASES.get(tokens[0],tokens[0].lower())
    domains=set(all_domains())
    if first in domains:
        args=tokens[1:]; query=' '.join(x for x in args if not x.startswith('--'))
        return {'operation':'browse','domain':first,'query':query,'all':'--all' in args,'refresh':'--refresh' in args,'include_attachments':'--include-attachments' in args}
    if first in {'search','recall','where'}: return {'operation':first,'query':' '.join(tokens[1:])}
    if first in {'status','gaps','graph'}: return {'operation':first,'query':' '.join(tokens[1:])}
    if first in {'refresh','bootstrap','doctor','help','catalog','evaluate'}: return {'operation':first,'query':' '.join(tokens[1:])}
    return {'operation':'search','query':' '.join(tokens)}

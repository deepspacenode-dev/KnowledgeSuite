"""Knowledge-domain and source resolution for drv-knowledge."""
from __future__ import annotations
from typing import Any
from runtime import load_config, dataset_map


def domain_config(domain: str) -> dict[str, Any]:
    cfg=load_config(); domains=cfg.get('knowledge_domains',{})
    return dict(domains.get(domain,{}) or {})


def all_domains() -> dict[str,dict[str,Any]]:
    cfg=load_config(); return {k:dict(v or {}) for k,v in cfg.get('knowledge_domains',{}).items()}


def resolve_domain(text: str) -> str | None:
    q=(text or '').strip().lower()
    if not q: return None
    for domain,info in all_domains().items():
        aliases=[domain,*info.get('aliases',[])]
        for alias in aliases:
            a=str(alias).strip().lower()
            if a and a in q: return domain
    return None


def resolve_sources(domain: str) -> dict[str,Any]:
    info=domain_config(domain); logical=info.get('dataset',domain)
    mapping=dataset_map()
    return {
        'domain': domain,
        'dataset_logical': logical,
        'dataset_name': mapping.get(logical,logical),
        'bookstack_shelf_aliases': info.get('bookstack_shelf_aliases',[]),
        'capabilities': info.get('capabilities',[]),
    }

"""BookStack URL compatibility wrapper."""
from drv_knowledge_core.source_metadata import normalize_bookstack_url
__all__=["normalize_bookstack_url"]

"""Local Markdown manual index/search for environments where RAGFlow parsing is unavailable.

Pure Python stdlib; no external packages.
"""
from __future__ import annotations
import gzip, hashlib, json, os, re, time
from pathlib import Path
from typing import Any
from urllib.parse import quote

from .catalog import runtime_dir

INDEX_VERSION = 1
SUPPORTED_SUFFIXES = {'.md', '.markdown', '.txt'}
IGNORE_NAMES = {'README.md', 'README.markdown', 'README.txt'}
HEADING_RE = re.compile(r'^\s{0,3}(#{1,6})\s+(.+?)\s*$')
FRONT_RE = re.compile(r'^---\s*$')
TOKEN_RE = re.compile(r'[A-Za-z][A-Za-z0-9_.+/-]{1,}|[\u4e00-\u9fff]{2,10}')


def _bool_env(name:str, default:bool=True)->bool:
    v=os.environ.get(name)
    if v is None: return default
    return v.strip().lower() not in {'0','false','no','off','disable','disabled'}


def enabled()->bool:
    return _bool_env('DRVKB_LOCAL_MANUALS_ENABLED', True)


def manual_root()->Path:
    configured=(os.environ.get('DRVKB_LOCAL_MANUALS_DIR') or '').strip()
    if configured:
        return Path(configured).expanduser().resolve()
    return (runtime_dir()/'manuals').expanduser().resolve()


def index_path()->Path:
    p=runtime_dir()/'cache'/'local_manuals_index.json.gz'; p.parent.mkdir(parents=True,exist_ok=True)
    return p


def _manual_files(root:Path)->list[Path]:
    if not root.is_dir(): return []
    out=[]
    for p in root.rglob('*'):
        if not p.is_file() or p.name in IGNORE_NAMES or p.name.startswith('.') or p.suffix.lower() not in SUPPORTED_SUFFIXES: continue
        out.append(p)
    return sorted(out,key=lambda p:str(p.relative_to(root)).lower())


def _signature(root:Path,files:list[Path])->str:
    h=hashlib.sha256()
    for p in files:
        st=p.stat(); rel=str(p.relative_to(root)).replace('\\','/')
        h.update(f'{rel}\0{st.st_size}\0{st.st_mtime_ns}\n'.encode('utf-8'))
    return h.hexdigest()


def _parse_front_matter(text:str)->tuple[dict[str,str],str]:
    lines=text.splitlines()
    if not lines or lines[0].strip()!='---': return {},text
    meta={}; end=None
    for i,line in enumerate(lines[1:],1):
        if line.strip()=='---': end=i; break
        if ':' in line:
            k,v=line.split(':',1); k=k.strip(); v=v.strip().strip('"\'')
            if k and v: meta[k]=v
    if end is None: return {},text
    return meta,'\n'.join(lines[end+1:])


def _title(text:str,meta:dict[str,str],fallback:str)->str:
    if meta.get('title'): return meta['title'].strip()
    for line in text.splitlines()[:80]:
        m=HEADING_RE.match(line)
        if m and len(m.group(1))==1: return m.group(2).strip()
    return fallback


def _safe_link(path:Path,meta:dict[str,str])->tuple[str,str]:
    for key in ('page_url','source_url','original_url'):
        v=(meta.get(key) or '').strip()
        if v.startswith(('http://','https://')): return v,key
    try: return path.resolve().as_uri(),'local_file'
    except ValueError:
        return 'file://'+quote(str(path.resolve())),'local_file'


def _split_long(title:str,heading:str,body:str,max_chars:int)->list[str]:
    prefix=(f'# {title}\n\n' if title else '')+(f'## {heading}\n\n' if heading and heading!=title else '')
    text=(body or '').strip()
    if len(prefix)+len(text)<=max_chars: return [(prefix+text).strip()] if text or prefix.strip() else []
    paras=[x.strip() for x in re.split(r'\n\s*\n',text) if x.strip()]
    out=[]; cur=prefix
    for para in paras:
        if len(cur)+len(para)+2>max_chars and len(cur.strip())>len(prefix.strip()):
            out.append(cur.strip()); cur=prefix
        if len(para)>max_chars-len(prefix)-20:
            remaining=para
            while remaining:
                room=max(200,max_chars-len(prefix)-2)
                piece=remaining[:room]; remaining=remaining[room:]
                if cur.strip()!=prefix.strip(): out.append(cur.strip()); cur=prefix
                out.append((prefix+piece).strip())
        else:
            cur += ('\n\n' if cur else '')+para
    if cur.strip() and cur.strip()!=prefix.strip(): out.append(cur.strip())
    return out


def _chunks(text:str,title:str,max_chars:int)->list[dict[str,Any]]:
    sections=[]; current_heading=title; buf=[]; line_start=1; current_start=1
    lines=text.splitlines()
    def flush(end_line:int):
        nonlocal buf
        body='\n'.join(buf).strip()
        if body:
            pieces=_split_long(title,current_heading,body,max_chars)
            for j,piece in enumerate(pieces):
                sections.append({'heading':current_heading,'content':piece,'line_start':current_start,'line_end':end_line,'piece':j})
        buf=[]
    for i,line in enumerate(lines,1):
        m=HEADING_RE.match(line)
        if m:
            flush(i-1); current_heading=m.group(2).strip(); current_start=i
        else:
            buf.append(line)
    flush(len(lines))
    if not sections and text.strip():
        for j,piece in enumerate(_split_long(title,title,text,max_chars)):
            sections.append({'heading':title,'content':piece,'line_start':1,'line_end':len(lines),'piece':j})
    return sections


def _summary(text:str,limit:int=240)->str:
    clean=[]
    for line in text.splitlines():
        line=re.sub(r'^\s{0,3}#{1,6}\s*','',line).strip()
        if not line or line.startswith('|') or set(line)<={'-','|',':',' '}: continue
        clean.append(line)
        if sum(len(x) for x in clean)>=limit: break
    return re.sub(r'\s+',' ',' '.join(clean))[:limit]


def build_index(*,force:bool=False)->dict[str,Any]:
    root=manual_root(); files=_manual_files(root); sig=_signature(root,files) if root.exists() else hashlib.sha256(b'').hexdigest(); cache=index_path()
    if not force and cache.is_file():
        try:
            with gzip.open(cache,'rt',encoding='utf-8') as f: obj=json.load(f)
            if obj.get('version')==INDEX_VERSION and obj.get('root')==str(root) and obj.get('signature')==sig:
                obj['cache_hit']=True; return obj
        except Exception: pass
    max_chars=max(800,min(int(os.environ.get('DRVKB_LOCAL_MANUAL_CHUNK_CHARS','1800')),6000))
    documents=[]; chunks=[]
    for p in files:
        try: raw=p.read_text(encoding='utf-8',errors='ignore')
        except OSError: continue
        meta,body=_parse_front_matter(raw); rel=str(p.relative_to(root)).replace('\\','/'); title=_title(body,meta,p.stem); link,link_source=_safe_link(p,meta)
        doc_chunks=_chunks(body,title,max_chars)
        doc={'document_id':'local:'+rel,'title':title,'relative_path':rel,'local_path':str(p.resolve()),'page_url':link,'link_source':link_source,
             'summary':_summary(body),'section_count':len(doc_chunks),'category':rel.split('/',1)[0] if '/' in rel else '',
             'chip':meta.get('chip','unknown'),'platform':meta.get('platform','unknown'),'module':meta.get('module','unknown'),'status':meta.get('status','local')}
        documents.append(doc)
        for idx,c in enumerate(doc_chunks):
            chunks.append({**doc,'chunk_id':f"local:{rel}#{idx}",'heading':c['heading'],'content':c['content'],'line_start':c['line_start'],'line_end':c['line_end']})
    obj={'version':INDEX_VERSION,'generated_at':time.time(),'root':str(root),'signature':sig,'document_count':len(documents),'chunk_count':len(chunks),'documents':documents,'chunks':chunks,'cache_hit':False}
    try:
        with gzip.open(cache,'wt',encoding='utf-8',compresslevel=6) as f: json.dump(obj,f,ensure_ascii=False,separators=(',',':'))
    except OSError: pass
    return obj


def status()->dict[str,Any]:
    root=manual_root(); files=_manual_files(root) if enabled() else []
    return {'enabled':enabled(),'root':str(root),'exists':root.is_dir(),'document_count':len(files),'index_path':str(index_path()),'index_exists':index_path().is_file()}


def _terms(query:str)->list[str]:
    out=[]
    for x in TOKEN_RE.findall(query or ''):
        low=x.lower().strip()
        if len(low)<2 or low in {'怎么','如何','手册','配置','问题','相关','查找','查看','the','and','with'}: continue
        if low not in out: out.append(low)
    return out[:24]


def _score_chunk(chunk:dict[str,Any],queries:list[str])->tuple[float,list[str]]:
    title=(chunk.get('title') or '').lower(); heading=(chunk.get('heading') or '').lower(); path=(chunk.get('relative_path') or '').lower(); content=(chunk.get('content') or '').lower()
    score=0.0; hits=[]
    for q in queries:
        ql=q.lower().strip(); terms=_terms(q)
        local=0.0
        if ql and len(ql)>=4 and ql in content: local+=12
        for t in terms:
            matched=False
            if t in title or t in path: local+=6; matched=True
            if t in heading: local+=4; matched=True
            if t in content: local+=1.5; matched=True
            if matched and t not in hits: hits.append(t)
        score=max(score,local)
    # prefer sections with multiple distinct query terms
    score += min(8.0,max(0,len(hits)-1)*1.5)
    return score,hits


def search(normalized:dict[str,Any],*,top_k:int=20,refresh:bool=False)->list[dict[str,Any]]:
    if not enabled(): return []
    idx=build_index(force=refresh); queries=[str(x.get('query') or '') for x in normalized.get('query_variants',[]) if x.get('query')]
    if not queries: queries=[str(normalized.get('raw_query') or '')]
    out=[]
    for c in idx.get('chunks',[]):
        score,hits=_score_chunk(c,queries)
        if score<=0: continue
        blob=(str(c.get('title',''))+' '+str(c.get('heading',''))+' '+str(c.get('content',''))).lower()
        chip=str(normalized.get('chip') or 'unknown'); platform=str(normalized.get('platform') or 'unknown'); module=str(normalized.get('module') or 'unknown')
        confidence=min(0.97,max(0.20,score/(score+12.0)))
        out.append({
            'title':c.get('title',''),'summary':_summary(c.get('content','')),'content':c.get('content',''),'dataset':'local_manuals','material_type':'manuals','status':c.get('status','local'),
            'platform': platform if platform!='unknown' and platform.lower() in blob else c.get('platform','unknown'),
            'module': module if module!='unknown' and any(t in blob for t in _terms(normalized.get('raw_query',''))) else c.get('module','unknown'),
            'chip': chip if chip!='unknown' and chip.lower() in blob else c.get('chip','unknown'),
            'project':'unknown','confidence':confidence,'document_id':c.get('document_id'),'chunk_id':c.get('chunk_id'),'source_key':'local_manual:'+c.get('relative_path',''),
            'page_url':c.get('page_url',''),'link_source':c.get('link_source','local_file'),'local_path':c.get('local_path',''),'relative_path':c.get('relative_path',''),
            'section':c.get('heading',''),'line_start':c.get('line_start'),'line_end':c.get('line_end'),'source_kind':'local_manual','rag_enabled':True,
            'query_hits':['local_manual:'+x for x in hits[:8]],'lane_hits':['local_manual'],'rrf_score':0.0,'local_manual_score':round(score,2)
        })
    out.sort(key=lambda x:(float(x.get('local_manual_score',0)),float(x.get('confidence',0))),reverse=True)
    return out[:max(1,top_k)]


def browse(*,query:str='',limit:int|None=None,refresh:bool=False)->dict[str,Any]:
    if not enabled(): return {'ok':True,'source':'local_manuals','root':str(manual_root()),'total_documents':0,'matched':0,'items':[],'disabled':True}
    idx=build_index(force=refresh); qterms=_terms(query); ranked=[]
    for doc in idx.get('documents',[]):
        if not qterms:
            score=1.0
        else:
            blob=' '.join(str(doc.get(k,'') or '') for k in ('title','relative_path','summary','chip','platform','module')).lower()
            score=sum(5.0 if t in (doc.get('title','') or '').lower() else 2.0 if t in blob else 0.0 for t in qterms)
            if score<=0:
                # fallback to section content search
                best=0.0
                for c in idx.get('chunks',[]):
                    if c.get('document_id')==doc.get('document_id'):
                        sc,_=_score_chunk(c,[query]); best=max(best,sc)
                score=best
        if score<=0: continue
        ranked.append((score,{
            'id':doc.get('document_id'),'title':doc.get('title'),'summary':doc.get('summary'),'chapter':doc.get('category'),'page_url':doc.get('page_url'),
            'source_kind':'local_manual','local_path':doc.get('local_path'),'relative_path':doc.get('relative_path'),'section_count':doc.get('section_count'),
            'chip':doc.get('chip'),'platform':doc.get('platform'),'module':doc.get('module')
        }))
    ranked.sort(key=lambda x:(x[0],str(x[1].get('title','')).lower()),reverse=True)
    items=[x[1] for x in ranked[:limit if limit else None]]
    return {'ok':True,'operation':'browse','domain':'manuals','source':'local_manuals','dataset':'local_manuals','dataset_id':None,'root':idx.get('root'),
            'total_documents':idx.get('document_count',0),'matched':len(items),'query':query,'items':items,'attachments_count':0,'attachments':[],
            'cache_hit':idx.get('cache_hit',False),'index_path':str(index_path()),'chunk_count':idx.get('chunk_count',0)}

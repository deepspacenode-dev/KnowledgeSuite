"""Discover and cache the current knowledge topology."""
from __future__ import annotations
import json, os, time
from pathlib import Path
from typing import Any
from runtime import load_config, dataset_map, dataset_profile_name, remote_cache_signature
from clients import bookstack
from clients import ragflow_admin
from .source_resolver import all_domains


def runtime_dir()->Path:
    raw=(os.environ.get('DRVKB_RUNTIME_DIR') or os.environ.get('DRVKNOWLEDGE_RUNTIME_DIR') or '').strip()
    p=Path(raw).expanduser() if raw else Path.home()/'.drvknowledge'
    p.mkdir(parents=True,exist_ok=True); return p

def catalog_path()->Path: return runtime_dir()/'knowledge_catalog.json'

def _rag_datasets()->list[dict[str,Any]]:
    r=ragflow_admin.datasets()
    if not r.get('ok'): return []
    out=[]
    for row in r.get('data',[]):
        did=str(row.get('id') or row.get('dataset_id') or '').strip(); name=str(row.get('name') or row.get('dataset_name') or '').strip()
        if did and name: out.append(ragflow_admin.dataset_index_state(row))
    return out

def build_catalog(*,include_bookstack:bool=True)->dict[str,Any]:
    cfg=load_config(); mapping=dataset_map(); datasets=_rag_datasets() if ragflow_admin.ready() else []
    # Fill missing document counts with a cheap one-page query when possible.
    for ds in datasets:
        if ds.get('document_count') in (None,'') and ds.get('id'):
            probe=ragflow_admin.documents(ds['id'],all_items=False,page_size=1)
            if probe.get('ok'): ds['document_count']=probe.get('total')
    by_name={x['name']:x for x in datasets}
    shelves=[]; books=[]
    if include_bookstack and bookstack.ready():
        sr=bookstack.shelves(100,True); br=bookstack.books(100,True)
        if sr.get('ok'): shelves=(sr.get('data',{}).get('data',[]) if isinstance(sr.get('data'),dict) else [])
        if br.get('ok'): books=(br.get('data',{}).get('data',[]) if isinstance(br.get('data'),dict) else [])
    domains={}
    profiles=cfg.get('dataset_profiles',{})
    for name,info in all_domains().items():
        logical=info.get('dataset',name); dsname=mapping.get(logical,logical); ds=by_name.get(dsname); resolved_profile=dataset_profile_name() if ds else None
        # Cognitive-usability fallback: if the configured profile is stale, locate the logical domain
        # in any known naming profile instead of forcing the user to know drvdocs_ai_* vs bookstack_ai_*.
        if not ds:
            for profile_name,profile_map in profiles.items():
                candidate=profile_map.get(logical)
                if candidate and candidate in by_name:
                    dsname=candidate; ds=by_name[candidate]; resolved_profile=profile_name; break
        domains[name]={
            'aliases':info.get('aliases',[]),'dataset_logical':logical,'dataset_name':dsname,
            'dataset_id':ds.get('id') if ds else None,'ragflow_document_count':ds.get('document_count') if ds else None,'resolved_profile':resolved_profile,
            'bookstack_shelf_aliases':info.get('bookstack_shelf_aliases',[]),'capabilities':info.get('capabilities',[])
        }
    payload={'schema_version':2,'generated_at':int(time.time()),'dataset_profile':dataset_profile_name(),'domains':domains,
             'source_signature':remote_cache_signature(),
             'ragflow':{'ready':ragflow_admin.ready(),'datasets':datasets},'bookstack':{'ready':bookstack.ready(),'shelves':shelves,'books':books},
             'governance':{'configured':bool(os.environ.get('GOVERNANCE_COOKIE'))}}
    path=catalog_path(); path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8'); payload['catalog_path']=str(path); return payload

def load_catalog(*,refresh_if_missing:bool=True)->dict[str,Any]:
    p=catalog_path()
    if not p.is_file(): return build_catalog() if refresh_if_missing else {}
    try:
        data=json.loads(p.read_text(encoding='utf-8'))
        if data.get('source_signature')!=remote_cache_signature():
            return build_catalog() if refresh_if_missing else {}
        data['catalog_path']=str(p); return data
    except Exception: return build_catalog() if refresh_if_missing else {}

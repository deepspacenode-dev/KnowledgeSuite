"""Deterministic natural-language intent -> standard knowledge command."""
from __future__ import annotations
from typing import Any
from runtime import load_config
from .source_resolver import resolve_domain

ALL_WORDS=('所有','全部','有哪些','清单','列出','一览','目前有多少','当前有多少')
GAP_WORDS=('知识缺口','缺口','缺哪些','缺什么','还缺')
STATUS_WORDS=('没入库','未入库','审核','解析失败','入库状态','知识状态')
RECALL_WORDS=('为什么','怎么排查','如何排查','分析','原因','之前有没有','是否有遇到','怎么解决')
SEARCH_WORDS=('查一下','查询','搜索','查找','在哪里','哪里有')

def _entity_hint(q:str)->str:
    cfg=load_config(); low=q.lower()
    # Prefer chips, then modules; return the canonical logical token so browse filtering is stable.
    for group in ('chips','modules','platforms','projects'):
        for name,aliases in cfg.get(group,{}).items():
            if any(str(a).lower() in low for a in [name,*aliases]): return name
    return ''

def resolve_natural(query:str)->dict[str,Any]:
    q=(query or '').strip(); domain=resolve_domain(q); hint=_entity_hint(q)
    if any(x in q for x in GAP_WORDS): return {'operation':'gaps','domain':domain,'query':hint or q,'command':'/kb gaps'+((' '+(hint or domain)) if (hint or domain) else '')}
    if any(x in q for x in STATUS_WORDS): return {'operation':'status','domain':domain,'query':hint or q,'command':'/kb status'+((' '+(hint or domain)) if (hint or domain) else '')}
    if domain and any(x in q for x in ALL_WORDS):
        filt=hint if hint and hint not in {domain} else ''
        return {'operation':'browse','domain':domain,'query':filt,'command':f'/kb {domain}'+((' '+filt) if filt else '')+' --all'}
    if any(x in q for x in RECALL_WORDS): return {'operation':'recall','domain':domain,'query':q,'command':'/kb recall '+q}
    if any(x in q for x in SEARCH_WORDS): return {'operation':'search','domain':domain,'query':q,'command':'/kb search '+q}
    if domain: return {'operation':'browse','domain':domain,'query':hint,'command':f'/kb {domain}'+((' '+hint) if hint else '')}
    return {'operation':'search','domain':None,'query':q,'command':'/kb search '+q}

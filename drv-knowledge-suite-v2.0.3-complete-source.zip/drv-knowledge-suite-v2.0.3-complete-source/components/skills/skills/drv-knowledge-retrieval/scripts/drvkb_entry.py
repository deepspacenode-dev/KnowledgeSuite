#!/usr/bin/env python3
"""Entry point for drv-knowledge-retrieval v2.0.3."""
from __future__ import annotations
import argparse, json, os, re, shutil, sys
from argparse import Namespace
from pathlib import Path
from typing import Any

SKILL_DIR=Path(__file__).resolve().parents[1]; SCRIPT_DIR=SKILL_DIR/'scripts'; RESOURCE_ROOT=SKILL_DIR/'resources'/'drvkb'
for item in (SKILL_DIR,RESOURCE_ROOT,SCRIPT_DIR):
    if str(item) not in sys.path: sys.path.insert(0,str(item))
from runtime import load_dotenv, dataset_map, dataset_profile_name, ragflow_credentials_ready, ragflow_dataset_mapping_present, CORE_CONFIG_PATH
load_dotenv(); SECRET_TOKEN_RE=re.compile(r"ragflow-[A-Za-z0-9]{24,}",re.I)
VERSION=(SKILL_DIR/'VERSION').read_text(encoding='utf-8').strip() if (SKILL_DIR/'VERSION').is_file() else 'dev'

def _json(obj:Any)->str: return json.dumps(obj,ensure_ascii=False,indent=2)
def _env_presence(names:list[str])->dict[str,dict[str,bool]]: return {n:{'present':bool(os.environ.get(n))} for n in names}
def _count_plaintext_ragflow_tokens(root:Path)->int:
    count=0
    for path in root.rglob('*'):
        if '__pycache__' in path.parts or path.is_dir() or path.name in {'.env','config.json'} or path.suffix.lower() in {'.pyc','.png','.jpg','.jpeg','.gif','.webp','.zip'}: continue
        try: text=path.read_text(encoding='utf-8',errors='ignore')
        except OSError: continue
        count += len(SECRET_TOKEN_RE.findall(text))
    return count

def _live_config_error()->dict[str,Any]:
    return {'ok':False,'knowledge_status':'unavailable','error':'LiveNotConfigured','message':'Live recall requires RAGFLOW_BASE_URL and RAGFLOW_API_KEY. Run `kb init` and configure ~/.drvknowledge/.env, or use --mode fixture only for selftest/demo.','hint':'kb doctor --live --json'}

def command_init(args):
    runtime_root=os.environ.get("DRVKB_RUNTIME_DIR") or os.environ.get("DRVKNOWLEDGE_RUNTIME_DIR") or "~/.drvknowledge"
    target=Path(runtime_root).expanduser()/'.env'
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists() and not args.force:
        print(_json({'ok':False,'error':'Exists','path':str(target),'message':'Shared env already exists. Edit it directly, or use --force to overwrite.'}) if args.json else f'Already exists: {target}'); return 2
    core_example=CORE_CONFIG_PATH.parent.parent/'.env.example'
    source=core_example if core_example.is_file() else SKILL_DIR/'.env.example'
    shutil.copy2(source,target)
    payload={'ok':True,'path':str(target),'shared':True,'dataset_profile':dataset_profile_name(),'next':['Edit '+str(target),'Run: kb bootstrap','Run: kb doctor --live','Run: kb cases']}
    print(_json(payload) if args.json else f'Created shared config: {target}\nNext: edit it, then run `kb bootstrap` and `kb doctor --live`.'); return 0

def command_doctor(args):
    from clients import bookstack, governance
    from clients import ragflow_admin
    from navigator.catalog import load_catalog
    fixture_path=RESOURCE_ROOT/'tests'/'recall'/'fixtures'/'recall_results.json'
    from navigator.local_manuals import status as local_manual_status
    local_manuals=local_manual_status()
    payload={'skill':'drv-knowledge-retrieval','version':VERSION,'python':sys.executable,'python_version':sys.version.split()[0],
      'resources':{'recall':(RESOURCE_ROOT/'recall/pipeline.py').is_file(),'knowledge_gap':(RESOURCE_ROOT/'knowledge_gap/gap_store.py').is_file(),'fixture':fixture_path.is_file(),'shared_config':True,'navigator':(SKILL_DIR/'navigator/catalog.py').is_file(),'local_manuals':True},
      'local_manuals':local_manuals,
      'datasets':{'profile':dataset_profile_name(),'map':dataset_map(),'explicit_mapping_present':ragflow_dataset_mapping_present()},
      'env':{'ragflow':_env_presence(['RAGFLOW_BASE_URL','RAGFLOW_API_KEY']),'bookstack':_env_presence(['BOOKSTACK_BASE_URL','BOOKSTACK_TOKEN_ID','BOOKSTACK_TOKEN_SECRET']),'governance':_env_presence(['GOVERNANCE_COOKIE'])},
      'configured':{'ragflow':ragflow_credentials_ready(),'bookstack':bookstack.ready(),'governance':governance.ready()},
      'readiness':{'local_fixture':True,'ragflow_live':None,'bookstack_live':None,'governance_live':None,'catalog_cached':bool(load_catalog(refresh_if_missing=False))},
      'ragflow_index':{'state':'not_checked','real_query_verified':False},
      'release_safety':{'plaintext_ragflow_tokens':_count_plaintext_ragflow_tokens(SKILL_DIR),'live_writes_enabled':False}}
    exit_code=0
    if args.live:
        probes={}
        if ragflow_credentials_ready():
            d=ragflow_admin.datasets(); probes['ragflow']={'ok':bool(d.get('ok')),'base_url':os.environ.get('RAGFLOW_BASE_URL',''),'status':d.get('status'),'dataset_count':len(d.get('data',[])) if d.get('ok') else 0,'error':d.get('error')}; exit_code=6 if not d.get('ok') else exit_code
            payload['ragflow_index']=ragflow_admin.index_status(d.get('data',[])) if d.get('ok') else {'state':'unavailable','real_query_verified':False}
        else: probes['ragflow']={'ok':False,'reason':'RAGFlow live credentials not configured'}; exit_code=6
        if bookstack.ready():
            b=bookstack.shelves(count=1); probes['bookstack']={'ok':bool(b.get('ok')),'status':b.get('status'),'error':b.get('error')}; exit_code=6 if not b.get('ok') else exit_code
        else: probes['bookstack']={'ok':False,'skipped':True,'reason':'not configured (optional)'}
        if governance.ready():
            g=governance.get('summary'); probes['governance']={'ok':bool(g.get('ok')),'status':g.get('status'),'error':g.get('error')}; exit_code=6 if not g.get('ok') else exit_code
        else: probes['governance']={'ok':False,'skipped':True,'reason':'not configured (optional)'}
        for service in ('ragflow','bookstack','governance'):
            payload['readiness'][service+'_live']=bool(probes[service].get('ok'))
        payload['live_probes']=probes; payload['live_ok']=exit_code==0
        payload['live_scope']='API connectivity; inspect ragflow_index and run a real recall separately'
    if args.json: print(_json(payload))
    else:
        print(f"Drv Knowledge Retrieval Doctor v{VERSION}\n- Dataset profile: {payload['datasets']['profile']}\n- Catalog cache: {'ready' if payload['readiness']['catalog_cached'] else 'not built / stale'}")
        for service in ('ragflow','bookstack','governance'):
            state=('API reachable' if payload['readiness'][service+'_live'] else 'not reachable / not configured') if args.live else ('configured, not probed' if payload['configured'][service] else 'not configured')
            print(f'- {service}: {state}')
        print(f"- RAGFlow index: {payload['ragflow_index']['state']} (dataset counters; real query not verified)\n- Plaintext token scan: {payload['release_safety']['plaintext_ragflow_tokens']}\n- Local manuals: {payload['local_manuals']['document_count']} file(s) / {payload['local_manuals']['root']}")
    return exit_code

def _resolved_mode(mode:str)->str:
    if mode=='fixture': return 'fixture'
    if mode in {'live','auto'}: return 'live'
    return mode

def command_recall(args):
    mode=_resolved_mode(args.mode)
    if mode=='live' and not ragflow_credentials_ready():
        from navigator.local_manuals import status as local_manual_status
        if int(local_manual_status().get('document_count',0))<=0:
            payload=_live_config_error(); payload.update({'requested_mode':args.mode,'resolved_mode':'live'})
            print(_json(payload) if args.json else payload['message']); return 6
    from recall import run_recall
    payload=run_recall(args.query,mode=mode,top_k=args.top_k); payload['requested_mode']=args.mode; payload['resolved_mode']=mode
    errs=[e for e in payload.get('trace',{}).get('external_dependency_errors',[]) if e.get('severity','error')=='error']
    if args.json: print(_json(payload))
    else:
        b=payload.get('knowledge_bundle',{}); print(f"Drv Knowledge Retrieval Recall V3 [{mode}] status={payload.get('knowledge_status')}"); print(f"- Task: {b.get('task_type')} / Module: {b.get('module')} / Chip: {b.get('chip')} / Platform: {b.get('platform')} / Project: {b.get('project')}")
        for i,item in enumerate(b.get('items',[]),1):
            print(f"\n[{i}] {item.get('title')}  relevance={item.get('confidence_level')}  score={item.get('score')}  type={item.get('material_type')}")
            if item.get('reason'): print(f"    为什么相关: {item.get('reason')}")
            es=item.get('engineering_summary',{})
            if es.get('symptom'): print(f"    问题现象: {es.get('symptom')}")
            if es.get('root_cause'): print(f"    根因: {es.get('root_cause')}")
            if es.get('solution'): print(f"    处理方案: {es.get('solution')}")
            if es.get('verification'): print(f"    验证: {es.get('verification')}")
            if es.get('overview') and not any(es.get(k) for k in ('symptom','root_cause','solution','verification')): print(f"    关键内容: {es.get('overview')}")
            print(f"    查看原文: {item.get('page_url')}")
        integrity=b.get('source_integrity',{})
        if integrity.get('excluded_unlinked'): print(f"\n- Source integrity: excluded {integrity.get('excluded_unlinked')} unlinked candidate(s); returned items remain 100% clickable.")
        for e in errs:
            level='WARN' if payload.get('knowledge_status')=='degraded' else 'ERROR'
            print(f"- {level} {e.get('kind')}: {e.get('message')}")
    return 6 if payload.get('knowledge_status')=='unavailable' else 0

def command_evaluate(args):
    mode=_resolved_mode(args.mode)
    if mode=='live' and not ragflow_credentials_ready():
        p=_live_config_error(); p.update({'requested_mode':args.mode,'resolved_mode':'live'}); print(_json(p) if args.json else p['message']); return 6
    from recall.evaluator import evaluate
    path=Path(args.testset).expanduser() if args.testset else None; result=evaluate(mode=mode,testset=path,top_k=args.top_k); result['requested_mode']=args.mode; result['resolved_mode']=mode
    print(_json(result) if args.json else f"Recall evaluate [{mode}] total={result['total']} top3={result['metrics']['top3_hit_rate']:.0%} top5={result['metrics']['top5_hit_rate']:.0%} page_url={result['metrics']['page_url_rate']:.0%} citation_ready={result['metrics']['citation_ready_rate']:.0%}")
    if not result.get('ok',True): return 6
    return 0 if result['metrics']['top3_hit_rate']>=args.min_top3 else 3

def command_feedback(args):
    from recall.feedback_store import record_feedback
    result=record_feedback(args.trace_id,args.label,reason=args.reason or '',expected=args.expected or '')
    print(_json(result) if args.json else (f"Feedback saved for {result.get('trace_id')}" if result.get('ok') else result.get('error')))
    return 0 if result.get('ok') else 4

def command_bookstack(args):
    from clients import bookstack
    if args.action=='shelves': result=bookstack.shelves(args.count,args.all)
    elif args.action=='books': result=bookstack.books(args.count,args.all)
    elif args.action=='chapters': result=bookstack.chapters(args.count,args.all)
    elif args.action=='pages': result=bookstack.pages(args.count,args.all)
    elif args.action=='page': result=bookstack.page(args.id)
    elif args.action=='search': result=bookstack.search(args.query,args.count)
    else: result={'ok':False,'error':'UnsupportedAction'}
    print(_json(result)); return 0 if result.get('ok') else 4

def command_governance(args):
    from clients import governance
    params={}
    for pair in args.param or []:
        if '=' in pair: k,v=pair.split('=',1); params[k]=v
    result=governance.get(args.resource,params=params)
    if args.resource=='graph' and args.query: result=governance.filter_graph(result,args.query,args.limit)
    print(_json(result)); return 0 if result.get('ok') else 4

def _print_browse(result:dict[str,Any])->None:
    print(f"Drv Knowledge Retrieval Browse domain={result.get('domain')} dataset={result.get('dataset')}")
    print(f"- total documents: {result.get('total_documents')} / matched knowledge: {result.get('matched')} / image attachments: {result.get('attachments_count',0)}")
    for i,item in enumerate(result.get('items',[]),1):
        print(f"[{i}] {item.get('title')}")
        if item.get('summary'): print(f"    {item.get('summary')}")
        if item.get('chapter'): print(f"    chapter: {item.get('chapter')}")
        if item.get('source_kind'): print(f"    source: {item.get('source_kind')}")
        if item.get('page_url'): print(f"    {item.get('page_url')}")
        if item.get('local_path'): print(f"    local: {item.get('local_path')}")

def command_browse(args):
    from navigator import browse
    q=' '.join(args.query) if isinstance(args.query,list) else (args.query or '')
    result=browse(args.domain,query=q,limit=(args.limit or None),enrich=not args.no_enrich,refresh_catalog=args.refresh,include_attachments=args.include_attachments,refresh_cache=args.refresh)
    if args.json:
        print(_json(result))
    elif result.get('ok'):
        _print_browse(result)
    else:
        print(result.get('message') or _json(result))
    return 0 if result.get('ok') else 4

def command_domain(args):
    args.domain=args.command; return command_browse(args)

def command_bootstrap(args):
    from navigator import build_catalog
    result=build_catalog(include_bookstack=not args.no_bookstack)
    from navigator.local_manuals import build_index as build_local_manual_index
    local_manuals=build_local_manual_index(force=True)
    domains=result.get('domains',{})
    payload={'ok':True,'version':VERSION,'catalog_path':result.get('catalog_path'),'dataset_profile':result.get('dataset_profile'),'ragflow_ready':result.get('ragflow',{}).get('ready'),'bookstack_ready':result.get('bookstack',{}).get('ready'),'domains':domains,'local_manuals':{'root':local_manuals.get('root'),'documents':local_manuals.get('document_count',0),'chunks':local_manuals.get('chunk_count',0)}}
    if args.json: print(_json(payload))
    else:
        print(f"Drv Knowledge Bootstrap v{VERSION}\nCatalog: {payload['catalog_path']}")
        for name,info in domains.items(): print(f"- {name:<12} dataset={info.get('dataset_name')} id={'OK' if info.get('dataset_id') else 'UNRESOLVED'} docs={info.get('ragflow_document_count')}")
        print(f"- local_manuals root={payload['local_manuals']['root']} docs={payload['local_manuals']['documents']} chunks={payload['local_manuals']['chunks']}")
    unresolved=[k for k,v in domains.items() if not v.get('dataset_id')]
    return 0 if payload['ragflow_ready'] and not unresolved else 4

def command_catalog(args):
    from navigator import load_catalog
    result=load_catalog(refresh_if_missing=not args.no_refresh)
    print(_json(result)); return 0 if result else 4

def command_status(args):
    from navigator import load_catalog
    from clients import governance
    cat=load_catalog(); q=(args.query or '').strip().lower(); domains=cat.get('domains',{})
    selected={k:v for k,v in domains.items() if not q or q in k.lower() or any(q in str(a).lower() for a in v.get('aliases',[]))}
    gov=None
    if governance.ready():
        gov=governance.get('summary')
    from navigator.local_manuals import status as local_manual_status
    payload={'ok':True,'local_manuals':local_manual_status(),'catalog_path':cat.get('catalog_path'),'dataset_profile':cat.get('dataset_profile'),'domains':selected or domains,
             'ragflow_ready':cat.get('ragflow',{}).get('ready'),'bookstack_ready':cat.get('bookstack',{}).get('ready'),'governance_ready':governance.ready(),'governance_summary':gov.get('data') if isinstance(gov,dict) and gov.get('ok') else None}
    if args.json: print(_json(payload))
    else:
        print('Drv Knowledge Status')
        print(f"- RAGFlow: {'OK' if payload['ragflow_ready'] else 'NOT READY'} / BookStack: {'OK' if payload['bookstack_ready'] else 'NOT READY'} / Governance: {'OK' if payload['governance_ready'] else 'OPTIONAL/NOT READY'}")
        for k,v in payload['domains'].items(): print(f"- {k:<12} {v.get('dataset_name')} docs={v.get('ragflow_document_count')} source={'OK' if v.get('dataset_id') else 'UNRESOLVED'}")
        lm=payload['local_manuals']; print(f"- local_manuals docs={lm.get('document_count')} root={lm.get('root')}")
    return 0

def command_where(args):
    from navigator import load_catalog, resolve_domain, resolve_sources
    from runtime import load_config
    q=(args.query or '').strip(); domain=resolve_domain(q); cfg=load_config(); entities=[]
    low=q.lower()
    for group in ('modules','chips','platforms','projects'):
        for name,aliases in cfg.get(group,{}).items():
            if any(str(x).lower() in low for x in [name,*aliases]): entities.append({'type':group[:-1],'name':name})
    cat=load_catalog(); domains=cat.get('domains',{})
    targets=[domain] if domain else list(domains)
    rows=[]
    for d in targets:
        info=domains.get(d,{}); src=resolve_sources(d)
        rows.append({'domain':d,'dataset':info.get('dataset_name') or src.get('dataset_name'),'dataset_id':info.get('dataset_id'),'document_count':info.get('ragflow_document_count'),'bookstack_shelf_aliases':src.get('bookstack_shelf_aliases'),'resolved_profile':info.get('resolved_profile')})
    if domain=='manuals' or domain is None:
        from navigator.local_manuals import status as local_manual_status
        lm=local_manual_status(); rows.append({'domain':'manuals_local','dataset':'local_manuals','dataset_id':None,'document_count':lm.get('document_count',0),'bookstack_shelf_aliases':[],'resolved_profile':'local','path':lm.get('root')})
    payload={'ok':True,'query':q,'resolved_domain':domain,'entities':entities,'sources':rows,'catalog_path':cat.get('catalog_path')}
    print(_json(payload) if args.json else '\n'.join([f"{r['domain']}: {r['dataset']} docs={r['document_count']} dataset_id={'OK' if r['dataset_id'] else 'UNRESOLVED'}" for r in rows])); return 0

def command_graph(args):
    from clients import governance
    result=governance.get('graph')
    if args.query: result=governance.filter_graph(result,args.query,args.limit)
    print(_json(result)); return 0 if result.get('ok') else 4

def command_gaps(args):
    from clients import governance
    if governance.ready():
        result=governance.get('gaps',params={'q':args.query} if args.query else None); print(_json(result)); return 0 if result.get('ok') else 4
    payload={'ok':False,'error':'GovernanceNotConfigured','message':'Remote gap browsing requires GOVERNANCE_COOKIE. Local gap workflow is still available via `drvkb gap ...`.','hint':'drvkb gap --help'}
    print(_json(payload)); return 4

def _dispatch_standard(spec:dict[str,Any],*,json_output:bool=False)->int:
    op=spec.get('operation')
    if op=='browse':
        return command_browse(Namespace(domain=spec.get('domain') or 'docs',query=spec.get('query',''),limit=0,no_enrich=False,refresh=bool(spec.get('refresh')),include_attachments=bool(spec.get('include_attachments')),json=json_output))
    if op in {'recall','search'}:
        return command_recall(Namespace(query=spec.get('query',''),mode='auto',top_k=5,json=json_output))
    if op=='status': return command_status(Namespace(query=spec.get('query',''),json=json_output))
    if op=='gaps': return command_gaps(Namespace(query=spec.get('query','')))
    if op=='where': return command_where(Namespace(query=spec.get('query',''),json=json_output))
    if op=='graph': return command_graph(Namespace(query=spec.get('query',''),limit=100))
    if op in {'bootstrap','refresh'}: return command_bootstrap(Namespace(no_bookstack=False,json=json_output))
    if op=='doctor': return command_doctor(Namespace(live=False,json=json_output))
    if op=='catalog': return command_catalog(Namespace(no_refresh=False))
    if op=='evaluate': return command_evaluate(Namespace(mode='auto',testset=None,top_k=5,min_top3=0.8,json=json_output))
    if op=='help': return command_kb_help(Namespace())
    return 2

def command_ask(args):
    from navigator import resolve_natural
    spec=resolve_natural(args.query)
    if args.resolve_only:
        print(_json({'ok':True,'resolved':spec})); return 0
    if args.json:
        # Emit resolution separately to stderr so stdout remains machine-readable command result.
        print(_json({'resolved_command':spec.get('command'),'operation':spec.get('operation'),'domain':spec.get('domain')}),file=sys.stderr)
    return _dispatch_standard(spec,json_output=args.json)

def command_slash(args):
    from navigator import parse_command
    spec=parse_command(args.text)
    if args.resolve_only:
        print(_json({'ok':True,'resolved':spec})); return 0
    return _dispatch_standard(spec,json_output=args.json)

def command_kb_help(args):
    print("""Drv Knowledge Retrieval public commands
CodeBuddy: /kb cases [filter]
           /kb manuals [filter]
           /kb search <keywords>
           /kb recall <question>
           /kb status [filter]
           /kb where <keyword>
           /kb gaps [filter]
           /kb graph <keyword>
           /kb bootstrap
           /kb doctor
           /kb help

Compact aliases such as `/kb:cases` and `/kb:recall` remain supported.

Terminal equivalents use `kb <action>`, e.g. `kb cases` or `kb recall -q "..."`.
Submit explicit recall feedback with `kb feedback --trace-id <id> --label relevant|irrelevant|missing_answer|bad_link`.
""")
    return 0

def command_gap(args):
    from knowledge_gap.cli import main as gap_main
    sys.argv=['knowledge_gap.cli',*args.args]; return gap_main()

def command_rag(args):
    from drv_knowledge_core import ragflow_control
    read_only_action=False
    if args.rag_action=='profiles':
        payload=ragflow_control.ingestion_profiles(); read_only_action=True
    elif args.rag_action=='migration-plan':
        payload=ragflow_control.non_destructive_migration_plan(); read_only_action=True
    elif not getattr(args,'confirm',False):
        payload={'ok':False,'error':'ConfirmationRequired','message':'Write action refused. Re-run with --confirm after reviewing dataset/document targets.'}
    elif args.rag_action=='parse':
        payload=ragflow_control.start_parsing(args.dataset_id,args.document_id)
    elif args.rag_action=='document' and args.document_action=='apply':
        payload=ragflow_control.apply_document_profile(args.dataset_id,args.document_id,args.profile,page_id=args.page_id,page_url=args.page_url,module=args.module,chip=args.chip,platform=args.platform,project=args.project,material_type=args.material_type)
    elif args.rag_action=='chat' and args.chat_action=='create':
        payload=ragflow_control.create_chat(args.dataset_id)
    elif args.rag_action=='chat' and args.chat_action=='sync':
        payload=ragflow_control.sync_chat(args.dataset_id,args.chat_id)
    else:
        payload={'ok':False,'error':'UnsupportedRagAction'}
    if getattr(args,'json',False): print(_json(payload))
    else: print(_json(payload))
    return 0 if read_only_action or payload.get('ok') else 7

def command_selftest(args):
    checks=[]; from recall import run_recall; r=run_recall('PHY up 但是无流量',mode='fixture',top_k=3); checks.append({'name':'fixture_recall','ok':bool(r.get('knowledge_bundle',{}).get('items'))})
    from recall.evaluator import evaluate; e=evaluate(mode='fixture',top_k=5); checks.append({'name':'fixture_evaluate','ok':e['metrics']['top3_hit_rate']>=0.8,'metrics':e['metrics']})
    try:
        import py_compile
        for f in [SKILL_DIR/'runtime.py',SCRIPT_DIR/'drvkb_entry.py',RESOURCE_ROOT/'recall/pipeline.py',RESOURCE_ROOT/'knowledge_gap/gap_store.py',SKILL_DIR/'navigator/catalog.py',SKILL_DIR/'navigator/browse_engine.py',SKILL_DIR/'navigator/local_manuals.py']: py_compile.compile(str(f),doraise=True)
        checks.append({'name':'compile','ok':True})
    except Exception as exc: checks.append({'name':'compile','ok':False,'error':str(exc)})
    from navigator.command_router import parse_command
    from navigator.intent_router import resolve_natural
    checks.append({'name':'command_router','ok':parse_command('/kb cases')['operation']=='browse' and parse_command('/kb manuals sensor')['query']=='sensor'})
    from navigator.local_manuals import status as _lm_status; checks.append({'name':'local_manual_engine','ok':'root' in _lm_status()})
    rr=resolve_natural('帮我找到目前库上所有案例内容'); checks.append({'name':'intent_router','ok':rr.get('operation')=='browse' and rr.get('domain')=='cases'})
    checks.append({'name':'secret_scan','ok':_count_plaintext_ragflow_tokens(SKILL_DIR)==0}); result={'version':VERSION,'ok':all(c['ok'] for c in checks),'checks':checks}; print(_json(result) if args.json else '\n'.join([f"{'PASS' if c['ok'] else 'FAIL'} {c['name']}" for c in checks])); return 0 if result['ok'] else 5

def _add_browse_args(p,domain:str|None=None):
    if domain is None: p.add_argument('domain',choices=['cases','manuals','tech_notes','project_docs','docs'])
    else: p.set_defaults(domain=domain)
    p.add_argument('query',nargs='*',default=[]); p.add_argument('--limit',type=int,default=0); p.add_argument('--no-enrich',action='store_true'); p.add_argument('--include-attachments',action='store_true'); p.add_argument('--refresh',action='store_true',help='refresh catalog and browse cache'); p.add_argument('--json',action='store_true')

def build_parser():
    parser=argparse.ArgumentParser(description=f'drv-knowledge-retrieval v{VERSION} CLI'); parser.add_argument('--version',action='version',version=VERSION); subs=parser.add_subparsers(dest='command',required=True)
    init=subs.add_parser('init'); init.add_argument('--force',action='store_true'); init.add_argument('--json',action='store_true'); init.set_defaults(func=command_init)
    doctor=subs.add_parser('doctor'); doctor.add_argument('--live',action='store_true'); doctor.add_argument('--json',action='store_true'); doctor.set_defaults(func=command_doctor)
    for name in ('recall','search'):
        p=subs.add_parser(name); p.add_argument('--query','-q',required=True); p.add_argument('--mode',choices=['auto','fixture','live'],default='auto'); p.add_argument('--top-k',type=int,default=5); p.add_argument('--json',action='store_true'); p.set_defaults(func=command_recall)
    feedback=subs.add_parser('feedback'); feedback.add_argument('--trace-id',required=True); feedback.add_argument('--label',choices=['relevant','irrelevant','missing_answer','bad_link'],required=True); feedback.add_argument('--reason'); feedback.add_argument('--expected'); feedback.add_argument('--json',action='store_true'); feedback.set_defaults(func=command_feedback)
    ev=subs.add_parser('evaluate'); ev.add_argument('--mode',choices=['auto','fixture','live'],default='auto'); ev.add_argument('--testset'); ev.add_argument('--top-k',type=int,default=5); ev.add_argument('--min-top3',type=float,default=0.8); ev.add_argument('--json',action='store_true'); ev.set_defaults(func=command_evaluate)
    browse=subs.add_parser('browse'); _add_browse_args(browse); browse.set_defaults(func=command_browse)
    for domain in ('cases','manuals'):
        p=subs.add_parser(domain); _add_browse_args(p,domain); p.set_defaults(func=command_domain)
    boot=subs.add_parser('bootstrap'); boot.add_argument('--no-bookstack',action='store_true'); boot.add_argument('--json',action='store_true'); boot.set_defaults(func=command_bootstrap)
    refresh=subs.add_parser('refresh'); refresh.add_argument('--no-bookstack',action='store_true'); refresh.add_argument('--json',action='store_true'); refresh.set_defaults(func=command_bootstrap)
    cat=subs.add_parser('catalog'); cat.add_argument('--no-refresh',action='store_true'); cat.set_defaults(func=command_catalog)
    status=subs.add_parser('status'); status.add_argument('query',nargs='?',default=''); status.add_argument('--json',action='store_true'); status.set_defaults(func=command_status)
    where=subs.add_parser('where'); where.add_argument('query'); where.add_argument('--json',action='store_true'); where.set_defaults(func=command_where)
    graph=subs.add_parser('graph'); graph.add_argument('query',nargs='?',default=''); graph.add_argument('--limit',type=int,default=100); graph.set_defaults(func=command_graph)
    gaps=subs.add_parser('gaps'); gaps.add_argument('query',nargs='?',default=''); gaps.set_defaults(func=command_gaps)
    ask=subs.add_parser('ask'); ask.add_argument('--query','-q',required=True); ask.add_argument('--resolve-only',action='store_true'); ask.add_argument('--json',action='store_true'); ask.set_defaults(func=command_ask)
    slash=subs.add_parser('command'); slash.add_argument('text'); slash.add_argument('--resolve-only',action='store_true'); slash.add_argument('--json',action='store_true'); slash.set_defaults(func=command_slash)
    kbhelp=subs.add_parser('kb-help'); kbhelp.set_defaults(func=command_kb_help)
    bs=subs.add_parser('bookstack'); bss=bs.add_subparsers(dest='action',required=True)
    for a in ('shelves','books','chapters','pages'):
        q=bss.add_parser(a); q.add_argument('--count',type=int,default=100); q.add_argument('--all',action='store_true',help='Follow BookStack offset pagination and return all items')
    q=bss.add_parser('page'); q.add_argument('--id',type=int,required=True); q=bss.add_parser('search'); q.add_argument('--query',required=True); q.add_argument('--count',type=int,default=20); bs.set_defaults(func=command_bookstack)
    gov=subs.add_parser('governance'); gov.add_argument('resource',choices=['summary','assets','contributions','quality','rag','gaps','graph','diagnosis']); gov.add_argument('--param',action='append'); gov.add_argument('--query'); gov.add_argument('--limit',type=int,default=100); gov.set_defaults(func=command_governance)
    gap=subs.add_parser('gap'); gap.add_argument('args',nargs=argparse.REMAINDER); gap.set_defaults(func=command_gap)
    rag=subs.add_parser('rag'); rag_actions=rag.add_subparsers(dest='rag_action',required=True)
    profiles=rag_actions.add_parser('profiles'); profiles.add_argument('--json',action='store_true'); profiles.set_defaults(func=command_rag)
    migration=rag_actions.add_parser('migration-plan'); migration.add_argument('--json',action='store_true'); migration.set_defaults(func=command_rag)
    parse=rag_actions.add_parser('parse'); parse.add_argument('--dataset-id',required=True); parse.add_argument('--document-id',action='append',required=True); parse.add_argument('--confirm',action='store_true'); parse.add_argument('--json',action='store_true'); parse.set_defaults(func=command_rag)
    document=rag_actions.add_parser('document'); document_actions=document.add_subparsers(dest='document_action',required=True)
    apply=document_actions.add_parser('apply'); apply.add_argument('--dataset-id',required=True); apply.add_argument('--document-id',required=True); apply.add_argument('--profile',required=True); apply.add_argument('--page-id',required=True); apply.add_argument('--page-url',required=True); apply.add_argument('--module',default='unknown'); apply.add_argument('--chip',default='unknown'); apply.add_argument('--platform',default='unknown'); apply.add_argument('--project',default='unknown'); apply.add_argument('--material-type',default='docs'); apply.add_argument('--confirm',action='store_true'); apply.add_argument('--json',action='store_true'); apply.set_defaults(func=command_rag)
    chat=rag_actions.add_parser('chat'); chat_actions=chat.add_subparsers(dest='chat_action',required=True)
    create=chat_actions.add_parser('create'); create.add_argument('--dataset-id',action='append',required=True); create.add_argument('--confirm',action='store_true'); create.add_argument('--json',action='store_true'); create.set_defaults(func=command_rag)
    sync=chat_actions.add_parser('sync'); sync.add_argument('--chat-id'); sync.add_argument('--dataset-id',action='append',required=True); sync.add_argument('--confirm',action='store_true'); sync.add_argument('--json',action='store_true'); sync.set_defaults(func=command_rag)
    st=subs.add_parser('selftest'); st.add_argument('--json',action='store_true'); st.set_defaults(func=command_selftest)
    return parser

def main()->int:
    if len(sys.argv)>1 and sys.argv[1]=='gap':
        from knowledge_gap.cli import main as gap_main
        sys.argv=['knowledge_gap.cli',*sys.argv[2:]]; return gap_main()
    args=build_parser().parse_args(); return args.func(args)
if __name__=='__main__': raise SystemExit(main())

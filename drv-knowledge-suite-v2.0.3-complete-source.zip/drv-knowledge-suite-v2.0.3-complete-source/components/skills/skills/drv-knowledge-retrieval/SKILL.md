---
name: drv-knowledge-retrieval
description: Drv Knowledge Suite 知识获取 Skill。用于浏览/搜索/召回案例、芯片与 SDK/Sensor 手册、技术专题、项目资料，以及查询 BookStack/RAGFlow/Governance 状态、知识缺口、知识图谱和召回评测。只读，不执行知识生产或入库。用户不需要知道 Dataset、RAGFlow、BookStack API 或底层来源。
---

# Drv Knowledge Retrieval v2.0.3

`drv-knowledge-retrieval` 是 Drv Knowledge Suite 的只读知识获取 Skill。

核心能力：**Browse / Search / Recall / BookStack Read / Governance Read / Knowledge Gap / Graph / Evaluate**。知识写入统一由 `drv-knowledge-ingestion` 负责。

## Core behavior: the user only says what they want

Do **not** ask the user whether to search BookStack or RAGFlow when the knowledge intent is already clear. Do **not** ask for Dataset names.

Resolve natural language to a standard operation first:

- “所有/全部/有哪些/清单/列出 + 案例/手册/项目资料/技术专题” → `browse`, not Top-K recall.
- “为什么/怎么排查/分析/之前有没有遇到” → `recall`.
- “查一下/搜索/在哪里” → `search`.
- “没入库/未入库/审核/解析失败” → governance `status`.
- “缺什么/知识缺口” → `gaps`.
- “案例” maps to the logical `cases` domain; the Source Resolver decides the actual Dataset (for example `drvdocs_ai_cases`).
- “手册/SDK/Sensor 手册” maps to the logical `manuals` domain.

The user should not need to know:

- RAGFlow
- BookStack internals
- Dataset IDs or names
- `drvdocs_ai_*` / `bookstack_ai_*`
- API paths

## Deterministic `/kb:*` command layer

Natural language and explicit commands share the same engine.

```text
/kb:cases [filter]
/kb:manuals [filter]
/kb:search <keywords>
/kb:recall <question>
/kb:status [filter]
/kb:where <keyword>
/kb:gaps [filter]
/kb:graph <keyword>
/kb:bootstrap
/kb:doctor
/kb:help
```

Examples:

```text
/kb:cases
/kb:cases network
/kb:manuals sensor
/kb:recall RTL8367S PHY link up 但是没有流量
```

CLI equivalents:

```bash
kb cases
kb cases network
kb manuals sensor
kb ask -q "帮我找到目前库上所有案例内容"
kb command "/kb:cases"
```

## Knowledge Navigator

The Skill contains four navigation layers:

1. Intent Router — understand browse/search/recall/status/gap.
2. Knowledge Catalog — discover current RAGFlow Datasets and BookStack structure.
3. Source Resolver — map logical knowledge domains to live sources.
4. Browse Engine — enumerate full knowledge collections instead of misusing Top-K recall.

The catalog is cached at `~/.drvknowledge/knowledge_catalog.json` by default and is auto-built on first browse. Use `DRVKB_RUNTIME_DIR` to override.

```bash
kb bootstrap
kb refresh
kb catalog
kb where sensor
```

## Case browsing behavior

“所有案例” must use the `cases` browse path and enumerate the full cases Dataset. Picture documents are counted as attachments and do not masquerade as independent text cases by default. Case page chunks are used to extract:

- title
- summary / problem description
- chapter
- BookStack page ID
- source link

Historical BookStack URLs are normalized to the configured current BookStack base URL.

## Recall/Search — Recall V3

Recall V3 is optimized for engineering accuracy and readable results:

```text
Query Understanding
  → raw / engineering / symptom query variants
  → Recall Planner
  → case lane + reference lane parallel RAGFlow retrieval
  → 30~50 candidate pool
  → engineering rerank (semantic/entity/symptom/title/material/quality)
  → document-level deduplication
  → source-grounded evidence extraction
  → knowledge_bundle-v3
```

Generic `docs` is fallback-only when primary lanes do not produce enough candidates. Query expansion is actually executed against RAGFlow; it is not merely generated for tracing.

Every public Top-K item **must contain a clickable HTTP(S) BookStack source link**. Link priority is `page_url` → `source_url` → historical `original_url` rewrite → optional operator `BOOKSTACK_PAGE_URL_TEMPLATE`. Unlinked candidates remain visible only in source-integrity/governance diagnostics and are not emitted as normal recall results. Retrieval never performs synchronous BookStack lookups just to resolve a hit URL.

The user-facing description is not `chunk[:220]`. It extracts source-grounded `问题现象 / 根因 / 解决方案 / 验证` sections when present, and falls back to the most relevant source excerpt without inventing missing facts.

Production `auto` means live. It never silently falls back to fixtures.

```bash
kb recall -q "PHY up 但是无流量"
kb search -q "Sensor reset gpio 手册"
```

## Configuration

```bash
kb init
kb bootstrap
kb doctor --live --json
```

Credentials belong only in `.env` / environment variables. Never place them in Skill source, patches, reports, or release archives.

## Knowledge bundle contract

Downstream agents consume `knowledge_bundle`; they do not call RAGFlow directly.

Key fields include `request_id`, `task_type`, `platform`, `project`, `module`, `chip`, `items`, `source_integrity`, `governance_issues`, `missing_info`, `conflicts`, `graph_neighbors`, `suggested_next_action`. Each item contains `page_url`, `reason`, `engineering_summary`, matched entities/symptoms, and supporting-chunk evidence.

`deprecated` and `rag_enabled=false` content must not enter effective recall results.

## Read-only boundary

本 Skill 不负责知识生产、文件转换、BookStack 页面创建或 RAGFlow 写入。收到“入库/沉淀/导入/提交知识库”等请求时交给 `drv-knowledge-router` 路由至 `drv-knowledge-ingestion`。

## Write safety

Remote writes are disabled. This Skill is read-only by design.


## Local Markdown manuals (V1.0.6)

Chip/platform manuals can be placed under `~/.drvknowledge/manuals/` (or the release `manuals/` directory before installation). The manuals domain is hybrid: RAGFlow manuals remain supported, while local Markdown is indexed with Python stdlib and participates in Recall V3 even when the RAGFlow manual dataset is empty or ingestion is unavailable. Public local-manual results include `file://` + `local_path`, or an HTTP(S) BookStack URL when supplied in Markdown front matter.

# 本地芯片手册库

此目录是 Drv Knowledge Suite 的**芯片手册内容注入区**。V1.0.6 起，本地 Markdown 手册会直接进入 `kb manuals` 和 Recall V3，不依赖 RAGFlow 解析。

## 使用方式

把已经转换好的 `.md` / `.markdown` / `.txt` 手册直接放到本目录或子目录，例如：

```text
manuals/
├── 01_主控SoC与平台芯片/
│   └── SS928V100_DDR配置.md
├── 02_网络与通信芯片/
│   └── RTL8367S_Datasheet.md
├── 03_单片机与协处理器/
└── 04_外设扩展与控制芯片/
```

然后执行：

```bash
./install.sh
kb manuals --refresh
kb recall -q "RTL8367S PHY 寄存器怎么配置"
```

安装器会把手册复制/合并到：

```text
~/.drvknowledge/manuals/
```

升级安装不会删除已存在的本地手册。

## 检索规则

- 只读取 Markdown/TXT，不需要 PyMuPDF、pdfplumber、python-docx 等第三方包；
- 本地手册与 RAGFlow Recall 并行参与候选召回；
- RAGFlow `manuals` 数据集为空、解析卡住或新手册尚未入 RAGFlow 时，本地手册仍然可召回；
- 返回结果带 `file://` 原文链接和本地路径，可直接定位原始 Markdown；
- 如果 Markdown front matter 中存在 `page_url` / `source_url` / `original_url`，优先返回 HTTP BookStack 链接。

## 发布包完整性

`manuals/` 是允许团队自行放入内容的目录。额外加入的手册文件不要求写入 `PACKAGE_MANIFEST.txt`；Manifest 只校验程序与发布基线文件，避免用户补充手册后导致安装器完整性检查失败。

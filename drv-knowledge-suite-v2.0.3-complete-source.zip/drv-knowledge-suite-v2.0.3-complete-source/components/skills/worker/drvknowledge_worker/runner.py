"""Single-task Worker runner with retry-safe outcomes."""
from __future__ import annotations

import time
from typing import Any

from .compiler import CompilerAdapter, build_draft_result


def retry_delay_seconds(attempt: int) -> int:
    return min(300, 2 ** min(max(1, attempt), 8))


def _unwrap_data(response: dict[str, Any]) -> Any:
    data = response.get("data")
    if isinstance(data, dict) and set(data) >= {"data"} and isinstance(data.get("data"), (dict, list, type(None))):
        return data["data"]
    return data


class WorkerRunner:
    def __init__(self, *, client: Any, compiler: CompilerAdapter) -> None:
        self.client = client
        self.compiler = compiler

    def run_once(self) -> dict[str, Any]:
        claimed = self.client.claim()
        if not claimed.get("ok"):
            return {"state": "claim_failed", "retryable": int(claimed.get("status") or 0) in {0, 429, 500, 502, 503, 504}, "response": claimed}
        data = _unwrap_data(claimed)
        task = data.get("task") if isinstance(data, dict) else None
        if not task:
            return {"state": "idle"}
        try:
            compiled = self.compiler.compile(task)
            result = build_draft_result(
                task,
                markdown=compiled["markdown"],
                workflow=compiled["workflow"],
                model=compiled.get("model"),
                quality_score=compiled.get("quality_score", 0),
                warnings=compiled.get("warnings", []),
            )
            submitted = self.client.submit_result(task["task_id"], result)
            if not submitted.get("ok"):
                return {"state": "submit_failed", "task_id": task["task_id"], "retryable": int(submitted.get("status") or 0) in {0, 409, 429, 500, 502, 503, 504}, "response": submitted}
            return {"state": "submitted", "task_id": task["task_id"], "result_id": result["result_id"]}
        except Exception as exc:
            event = {
                "schema_version": "drvknowledge.worker-event.v2",
                "trace_id": task.get("trace_id", "trace:unknown"),
                "event": "compile_failed",
                "task_id": task.get("task_id"),
                "error": {"type": type(exc).__name__, "message": str(exc)[:1000]},
            }
            try:
                self.client.event(event)
            except Exception:
                pass
            return {"state": "compile_failed", "task_id": task.get("task_id"), "retryable": True, "error": str(exc)}

    def run_forever(self, *, poll_seconds: int = 5) -> None:
        failures = 0
        while True:
            outcome = self.run_once()
            if outcome["state"] in {"claim_failed", "submit_failed", "compile_failed"}:
                failures += 1
                time.sleep(retry_delay_seconds(failures))
            else:
                failures = 0
                if outcome["state"] == "idle":
                    time.sleep(max(1, poll_seconds))

"""Drv Knowledge Worker V2."""

__version__ = "2.0.3"

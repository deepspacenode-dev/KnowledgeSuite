from __future__ import annotations

import os

from .client import WorkerApiClient
from .compiler import OfflineDraftCompiler, OpenAICompatibleCompiler, RagFlowWorkflowCompiler
from .runner import WorkerRunner


def _required(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise SystemExit(f"missing required environment variable: {name}")
    return value


def main() -> int:
    client = WorkerApiClient(
        base_url=_required("GOVERNANCE_BASE_URL"),
        worker_id=_required("GOVERNANCE_WORKER_ID"),
        worker_key=_required("GOVERNANCE_WORKER_KEY"),
        timeout=int(os.environ.get("GOVERNANCE_TIMEOUT_SECONDS", "30")),
    )
    adapter = os.environ.get("WORKER_COMPILER", "offline").strip()
    if adapter == "ragflow_workflow":
        compiler = RagFlowWorkflowCompiler(
            base_url=_required("RAGFLOW_BASE_URL"),
            api_key=_required("RAGFLOW_API_KEY"),
            workflow_id=_required("RAGFLOW_WORKFLOW_ID"),
        )
    elif adapter == "openai_compatible":
        compiler = OpenAICompatibleCompiler(
            base_url=_required("OPENAI_COMPATIBLE_BASE_URL"),
            api_key=_required("OPENAI_COMPATIBLE_API_KEY"),
            model=_required("OPENAI_COMPATIBLE_MODEL"),
        )
    elif adapter == "offline":
        compiler = OfflineDraftCompiler()
    else:
        raise SystemExit(f"unsupported WORKER_COMPILER: {adapter}")
    WorkerRunner(client=client, compiler=compiler).run_forever(poll_seconds=int(os.environ.get("WORKER_POLL_SECONDS", "5")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

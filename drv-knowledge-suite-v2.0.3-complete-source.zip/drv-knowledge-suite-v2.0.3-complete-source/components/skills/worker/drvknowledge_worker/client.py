"""HMAC-authenticated client for B's internal Worker API."""
from __future__ import annotations

import hashlib
import hmac
import json
import time
import urllib.error
import urllib.request
import uuid
from typing import Any, Callable


Transport = Callable[..., dict[str, Any]]


def sign_request(
    *,
    method: str,
    path: str,
    body: bytes,
    key: str,
    timestamp: str | None = None,
    nonce: str | None = None,
) -> dict[str, str]:
    timestamp = timestamp or str(int(time.time()))
    nonce = nonce or uuid.uuid4().hex
    canonical = "\n".join([
        method.upper(),
        "/" + path.lstrip("/"),
        timestamp,
        nonce,
        hashlib.sha256(body).hexdigest(),
    ])
    signature = hmac.new(key.encode("utf-8"), canonical.encode("utf-8"), hashlib.sha256).hexdigest()
    return {"X-AI-Timestamp": timestamp, "X-AI-Nonce": nonce, "X-AI-Signature": signature}


def _transport(url: str, *, method: str, headers: dict[str, str], data: bytes, timeout: int) -> dict[str, Any]:
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8", errors="replace")
            return {"ok": True, "status": getattr(response, "status", 200), "data": json.loads(raw) if raw.strip() else None}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")[:4000]
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            payload = {"raw": raw}
        return {"ok": False, "status": exc.code, "error": "HTTPError", "message": str(exc), "data": payload}
    except Exception as exc:
        return {"ok": False, "status": 0, "error": type(exc).__name__, "message": str(exc), "data": None}


class WorkerApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        worker_id: str,
        worker_key: str,
        timeout: int = 30,
        transport: Transport = _transport,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.worker_id = worker_id
        self.worker_key = worker_key
        self.timeout = timeout
        self.transport = transport

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Idempotency-Key": f"worker:{hashlib.sha256(body).hexdigest()[:32]}",
            "X-AI-Worker": self.worker_id,
            **sign_request(method="POST", path=path, body=body, key=self.worker_key),
        }
        return self.transport(
            self.base_url + path,
            method="POST",
            headers=headers,
            data=body,
            timeout=self.timeout,
        )

    def claim(self) -> dict[str, Any]:
        return self._post("/api/ai-governance/v2/internal/tasks/claim", {
            "schema_version": "drvknowledge.worker-claim.v2",
            "trace_id": f"trace:{uuid.uuid4().hex}",
            "worker_id": self.worker_id,
            "capabilities": ["wiki-task.v2", "wiki-result.v2"],
        })

    def heartbeat(self, task_id: str) -> dict[str, Any]:
        return self._post(f"/api/ai-governance/v2/internal/tasks/{task_id}/heartbeat", {
            "schema_version": "drvknowledge.worker-heartbeat.v2",
            "trace_id": f"trace:{uuid.uuid4().hex}",
            "task_id": task_id,
        })

    def submit_result(self, task_id: str, result: dict[str, Any]) -> dict[str, Any]:
        return self._post(f"/api/ai-governance/v2/internal/tasks/{task_id}/result", result)

    def event(self, event: dict[str, Any]) -> dict[str, Any]:
        return self._post("/api/ai-governance/v2/internal/events", event)

"""Compiler adapters with a mandatory draft-only result boundary."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
import urllib.error
import urllib.request
from typing import Any, Protocol


class CompilerError(RuntimeError):
    pass


class CompilerAdapter(Protocol):
    def compile(self, task: dict[str, Any]) -> dict[str, Any]: ...


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def _strip_front_matter(markdown: str) -> str:
    if markdown.startswith("---\n"):
        end = markdown.find("\n---", 4)
        if end >= 0:
            return markdown[end + 4:].lstrip("\r\n")
    return markdown


def build_draft_result(
    task: dict[str, Any],
    *,
    markdown: str,
    workflow: str,
    model: str | None,
    quality_score: float = 0,
    warnings: list[str] | None = None,
) -> dict[str, Any]:
    source = task["source"]
    title = str(source["title"])
    body = _strip_front_matter(markdown).strip()
    raw_domain = source.get("domain_metadata")
    raw_domain = raw_domain if isinstance(raw_domain, dict) else {}
    domain = {
        field: str(raw_domain[field]).strip().lower()
        if raw_domain.get(field) is not None and str(raw_domain[field]).strip()
        else None
        for field in ("owner", "module", "platform", "chip", "project")
    }
    canonical = "\n".join([
        "---",
        f"title: {json.dumps(title, ensure_ascii=False)}",
        "status: draft",
        "rag_enabled: false",
        f"source_key: {source['source_key']}",
        f"material_type: {source.get('material_type', 'docs')}",
        *(f"{field}: {json.dumps(value, ensure_ascii=False)}" for field, value in domain.items()),
        "---",
        "",
        body,
        "",
    ])
    fingerprint = hashlib.sha256(f"{task['task_id']}:{task['source_version']}:{canonical}".encode("utf-8")).hexdigest()[:24]
    return {
        "schema_version": "drvknowledge.wiki-result.v2",
        "trace_id": task["trace_id"],
        "task_id": task["task_id"],
        "result_id": f"result:{fingerprint}",
        "generated_at": _utc_now(),
        "source_key": source["source_key"],
        "source_version": task["source_version"],
        "compiler": {"system": "drvknowledge_worker", "workflow": workflow, "model": model},
        "status": "draft",
        "title": title,
        "markdown": canonical,
        "front_matter": {
            "title": title,
            "status": "draft",
            "rag_enabled": False,
            "source_key": source["source_key"],
            "material_type": source.get("material_type", "docs"),
            **domain,
        },
        "sources": [{
            "title": title,
            "url": source["canonical_url"],
            "source_key": source["source_key"],
            "section": None,
        }],
        "quality_report": {
            "score": min(100, max(0, float(quality_score))),
            "warnings": list(warnings or []),
            "reject_reasons": [],
        },
        "relations": [],
    }


def _post_json(url: str, payload: dict[str, Any], headers: dict[str, str], timeout: int) -> dict[str, Any]:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json", **headers}, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, json.JSONDecodeError) as exc:
        raise CompilerError(str(exc)) from exc


def _extract_markdown(payload: dict[str, Any]) -> str:
    candidates = [
        payload.get("markdown"),
        payload.get("output"),
        (payload.get("data") or {}).get("markdown") if isinstance(payload.get("data"), dict) else None,
        (payload.get("data") or {}).get("output") if isinstance(payload.get("data"), dict) else None,
    ]
    for value in candidates:
        if isinstance(value, str) and value.strip():
            return value
    raise CompilerError("compiler response did not contain markdown")


class RagFlowWorkflowCompiler:
    def __init__(self, *, base_url: str, api_key: str, workflow_id: str, timeout: int = 120) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.workflow_id = workflow_id
        self.timeout = timeout

    def compile(self, task: dict[str, Any]) -> dict[str, Any]:
        response = _post_json(
            f"{self.base_url}/api/v1/workflows/{self.workflow_id}/run",
            {"inputs": {"wiki_task": task}},
            {"Authorization": f"Bearer {self.api_key}"},
            self.timeout,
        )
        return {"markdown": _extract_markdown(response), "workflow": self.workflow_id, "model": None, "quality_score": 0, "warnings": []}


class OpenAICompatibleCompiler:
    def __init__(self, *, base_url: str, api_key: str, model: str, timeout: int = 120) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout = timeout

    def compile(self, task: dict[str, Any]) -> dict[str, Any]:
        source = task["source"]
        prompt = (
            "将以下内部知识整理成结构化 Markdown。不得补充无来源事实，不得标记已审核，不得请求发布。\n\n"
            f"标题：{source['title']}\n来源：{source['canonical_url']}\n\n{source['markdown']}"
        )
        response = _post_json(
            f"{self.base_url}/v1/chat/completions",
            {"model": self.model, "messages": [{"role": "user", "content": prompt}], "temperature": 0},
            {"Authorization": f"Bearer {self.api_key}"},
            self.timeout,
        )
        try:
            markdown = response["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise CompilerError("OpenAI-compatible response did not contain message content") from exc
        return {"markdown": markdown, "workflow": "openai-compatible", "model": self.model, "quality_score": 0, "warnings": []}


class OfflineDraftCompiler:
    """No-model fallback that keeps the source readable but never publishes it."""

    def compile(self, task: dict[str, Any]) -> dict[str, Any]:
        return {
            "markdown": task["source"]["markdown"],
            "workflow": "offline-source-preserving",
            "model": None,
            "quality_score": 0,
            "warnings": ["模型服务不可用；保留来源内容，等待人工整理。"],
        }

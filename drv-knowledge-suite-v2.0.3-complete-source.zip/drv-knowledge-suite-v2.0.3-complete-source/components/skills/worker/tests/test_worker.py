from __future__ import annotations

import hashlib
import hmac
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from drvknowledge_worker.client import WorkerApiClient, sign_request  # noqa: E402
from drvknowledge_worker.compiler import build_draft_result  # noqa: E402
from drvknowledge_worker.runner import WorkerRunner  # noqa: E402


TASK = {
    "schema_version": "drvknowledge.wiki-task.v2",
    "trace_id": "trace-worker-001",
    "task_id": "task:7",
    "source_version": 1,
    "source": {
        "page_id": 42,
        "canonical_url": "http://bookstack.local/books/ai/page/example",
        "title": "诊断案例",
        "source_key": "bookstack_page:42",
        "content_ref": "bookstack:page:42",
        "content_hash": "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
        "material_type": "cases",
        "markdown": "# 问题现象\n\n链路无流量。",
        "hierarchy": [],
        "tags": [],
        "domain_metadata": {
            "owner": "admin",
            "module": "network",
            "platform": "linux",
            "chip": "rtl8367s",
            "project": "switch-gateway",
        },
    },
    "target": {"wiki_type": "case", "language": "zh-CN", "review_required": True},
    "compile_policy": {
        "compiler": "ragflow_workflow",
        "allow_unsourced_claims": False,
        "default_status": "draft",
        "model": None,
    },
}


class WorkerTests(unittest.TestCase):
    def test_hmac_signature_matches_governance_canonical_form(self) -> None:
        body = b'{"worker_id":"worker-01"}'
        headers = sign_request(
            method="POST",
            path="/api/ai-governance/v2/internal/tasks/claim",
            body=body,
            key="shared-key",
            timestamp="1700000000",
            nonce="nonce-001",
        )
        canonical = "\n".join([
            "POST",
            "/api/ai-governance/v2/internal/tasks/claim",
            "1700000000",
            "nonce-001",
            hashlib.sha256(body).hexdigest(),
        ])
        expected = hmac.new(b"shared-key", canonical.encode(), hashlib.sha256).hexdigest()
        self.assertEqual(headers["X-AI-Signature"], expected)

    def test_client_claim_is_signed_and_uses_v2_post_endpoint(self) -> None:
        calls = []

        def transport(url, **kwargs):
            calls.append((url, kwargs))
            return {"ok": True, "status": 204, "data": None}

        client = WorkerApiClient(
            base_url="http://bookstack.local",
            worker_id="worker-01",
            worker_key="shared-key",
            transport=transport,
        )
        client.claim()
        url, request = calls[0]
        self.assertTrue(url.endswith("/api/ai-governance/v2/internal/tasks/claim"))
        self.assertEqual(request["method"], "POST")
        self.assertEqual(request["headers"]["X-AI-Worker"], "worker-01")
        self.assertRegex(request["headers"]["X-AI-Signature"], r"^[a-f0-9]{64}$")
        self.assertRegex(request["headers"]["Idempotency-Key"], r"^worker:[a-f0-9]{32}$")

    def test_result_builder_cannot_publish_or_mark_reviewed(self) -> None:
        result = build_draft_result(
            TASK,
            markdown="# 编译结果\n\n内容",
            workflow="test-compiler",
            model=None,
            quality_score=88,
        )
        self.assertEqual(result["status"], "draft")
        self.assertEqual(result["front_matter"]["status"], "draft")
        self.assertFalse(result["front_matter"]["rag_enabled"])
        self.assertEqual(result["source_key"], "bookstack_page:42")

    def test_result_builder_preserves_bookstack_domain_metadata(self) -> None:
        result = build_draft_result(
            TASK,
            markdown="# 编译结果\n\n内容",
            workflow="test-compiler",
            model=None,
        )
        for field, expected in TASK["source"]["domain_metadata"].items():
            self.assertEqual(result["front_matter"][field], expected)
            self.assertIn(f'{field}: {json.dumps(expected, ensure_ascii=False)}', result["markdown"])

    def test_runner_claims_compiles_and_submits_once(self) -> None:
        class FakeClient:
            def __init__(self):
                self.results = []
                self.events = []

            def claim(self):
                return {"ok": True, "status": 200, "data": {"task": TASK}}

            def submit_result(self, task_id, result):
                self.results.append((task_id, result))
                return {"ok": True, "status": 201, "data": {"accepted": True}}

            def event(self, event):
                self.events.append(event)
                return {"ok": True}

        class FakeCompiler:
            def compile(self, task):
                return {"markdown": "# 编译结果\n\n内容", "workflow": "fake", "model": None, "quality_score": 80}

        client = FakeClient()
        outcome = WorkerRunner(client=client, compiler=FakeCompiler()).run_once()
        self.assertEqual(outcome["state"], "submitted")
        self.assertEqual(client.results[0][0], "task:7")
        self.assertEqual(client.results[0][1]["status"], "draft")


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env bash
# Drv Knowledge Suite Linux installer (official entry point)
set -Eeuo pipefail

VERSION="2.0.3"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="${PYTHON:-python3}"
TARGET="${CODEBUDDY_HOME:-$HOME/.codebuddy}"
RUNTIME="${DRVKB_RUNTIME_DIR:-$HOME/.drvknowledge}"
BIN_DIR="${DRVKB_BIN_DIR:-$HOME/.local/bin}"
PROFILE="retrieval"
STRICT=0 STRICT_LIVE=0 PLAN=0 REPAIR=0 UNINSTALL=0 PURGE=0 FORCE=0
NO_BOOTSTRAP=0 DEVELOPER=0 NO_VERIFY=0 SITE_CONFIG="" MIGRATE_RAGFLOW=0
EXPECTED_COMMANDS=11
EXIT_LIVE_WARNING=10; EXIT_PREREQ=20; EXIT_CONFIG=30; EXIT_INSTALL=40; EXIT_STRICT_LIVE=50
STAGE="" BACKUP="" LOGFILE="" COMMIT_STARTED=0 SUCCESS=0

# Files installed by Drv Knowledge Suite. Unknown files in these namespaces are user-owned and preserved.
KB_COMMAND_FILES=(bootstrap.md cases.md doctor.md gaps.md graph.md help.md ingest.md manuals.md recall.md search.md status.md where.md)
LEGACY_KNOWLEDGE_FILES=(bootstrap.md cases.md doctor.md gaps.md graph.md help.md ingest-experience.md ingest-preview.md ingest-status.md ingest-submit.md ingest.md manual.md manuals.md query.md recall.md search.md status.md where.md)

usage(){ cat <<EOF
Drv Knowledge Suite v$VERSION Linux installer

Usage: ./install.sh [options]
  --full                            Enable knowledge ingestion (same as --profile full)
  --profile retrieval|full          Feature profile (default: retrieval)
  --developer                       Also install drvkr and full-only drvki developer CLIs
  --strict                          Fail on local readiness warnings
  --strict-live                     Require live RAGFlow + BookStack; rollback on failure
  --plan                            Show installation plan only; make no changes
  --repair                          Reinstall package files while preserving shared config
  --uninstall                       Remove installed Suite components, keep config/cache
  --purge                           With --uninstall, also remove ~/.drvknowledge runtime
  --site-config FILE                Private site .env used only to fill missing shared values
  --migrate-ragflow                 Replace RAGFlow using site config; reset old IDs/cache
  --no-bootstrap                    Do not auto-build Knowledge Catalog
  --target DIR                      CodeBuddy root (default: ~/.codebuddy)
  --runtime-dir DIR                 Shared runtime/config dir (default: ~/.drvknowledge)
  --bin-dir DIR                     CLI dir (default: ~/.local/bin)
  --force                           Allow downgrade/forced overwrite
  --no-verify                       Skip PACKAGE_MANIFEST verification (development only)
  --version                         Print version
  -h, --help                        Show help

Dependency policy:
  retrieval: no format-plugin requirement.
  full: the following 6 packages MUST already be installed; this installer only checks them and NEVER runs pip:
        beautifulsoup4, python-docx, python-pptx, PyMuPDF, pdfplumber, Pillow

Stable exit codes:
  0  installation and local validation successful
 10  installed successfully, but live service validation has warnings
 20  platform or mandatory full-ingestion dependency requirement not met
 30  invalid configuration
 40  file installation failed and rollback attempted
 50  --strict-live validation failed and rollback attempted
EOF
}

while (($#)); do
  case "$1" in
    --full) PROFILE="full"; shift;;
    --profile) PROFILE="${2:?missing profile}"; shift 2;;
    --developer) DEVELOPER=1; shift;;
    --strict) STRICT=1; shift;;
    --strict-live) STRICT_LIVE=1; shift;;
    --plan) PLAN=1; shift;;
    --repair) REPAIR=1; shift;;
    --uninstall) UNINSTALL=1; shift;;
    --purge) PURGE=1; shift;;
    --site-config) SITE_CONFIG="${2:?missing site config}"; shift 2;;
    --migrate-ragflow) MIGRATE_RAGFLOW=1; shift;;
    --no-bootstrap) NO_BOOTSTRAP=1; shift;;
    --target) TARGET="${2:?missing target}"; shift 2;;
    --runtime-dir) RUNTIME="${2:?missing runtime dir}"; shift 2;;
    --bin-dir) BIN_DIR="${2:?missing bin dir}"; shift 2;;
    --force) FORCE=1; shift;;
    --no-verify) NO_VERIFY=1; shift;;
    --version) echo "$VERSION"; exit 0;;
    -h|--help) usage; exit 0;;
    *) echo "ERROR: unknown option: $1" >&2; usage >&2; exit 2;;
  esac
done
[[ "$PROFILE" =~ ^(retrieval|full)$ ]] || { echo "ERROR: invalid profile $PROFILE" >&2; exit $EXIT_PREREQ; }
case "$PROFILE" in retrieval) EXPECTED_COMMANDS=11;; full) EXPECTED_COMMANDS=12;; esac

say(){ printf '%s\n' "$*"; }
section(){ printf '\n== %s ==\n' "$*"; }

manifest_verify(){
  [[ $NO_VERIFY -eq 1 ]] && { say "Package integrity: SKIPPED (--no-verify)"; return 0; }
  local mf="$ROOT/PACKAGE_MANIFEST.txt" bad=0 count=0 expected rel actual
  [[ -f "$mf" ]] || { echo "ERROR: PACKAGE_MANIFEST.txt missing" >&2; return 1; }
  command -v sha256sum >/dev/null || { echo "ERROR: sha256sum not available" >&2; return 1; }
  while read -r expected rel; do
    [[ -z "${expected:-}" ]] && continue
    [[ -f "$ROOT/$rel" ]] || { echo "MISSING: $rel" >&2; bad=1; continue; }
    actual="$(sha256sum "$ROOT/$rel" | awk '{print $1}')"; ((count+=1))
    [[ "$actual" == "$expected" ]] || { echo "SHA256 MISMATCH: $rel" >&2; bad=1; }
  done < "$mf"
  [[ $bad -eq 0 ]] || return 1
  say "Package integrity: PASS ($count files)"
}

version_gt(){ [[ "$(printf '%s\n%s\n' "$1" "$2" | sort -V | tail -1)" == "$1" && "$1" != "$2" ]]; }
installed_version(){
  local f="$TARGET/skills/drv-knowledge-router/VERSION"
  [[ -f "$f" ]] && tr -d '[:space:]' < "$f" || true
}

remove_known_commands(){
  local dir="$1"; shift
  [[ -d "$dir" ]] || return 0
  local f
  for f in "$@"; do rm -f "$dir/$f"; done
  rmdir "$dir" 2>/dev/null || true
}

backup_known_commands(){
  local src="$1" dst="$2"; shift 2
  [[ -d "$src" ]] || return 0
  local f
  mkdir -p "$dst"
  for f in "$@"; do [[ -f "$src/$f" ]] && cp -p "$src/$f" "$dst/$f" || true; done
  return 0
}

restore_known_commands(){
  local target_dir="$1" backup_dir="$2"; shift 2
  remove_known_commands "$target_dir" "$@"
  if [[ -d "$backup_dir" ]]; then
    mkdir -p "$target_dir"
    local f
    for f in "$@"; do [[ -f "$backup_dir/$f" ]] && cp -p "$backup_dir/$f" "$target_dir/$f" || true; done
  fi
  return 0
}

show_plan(){
  section "Installation plan"
  cat <<EOF
Suite version      $VERSION
Linux entry        $ROOT/install.sh
Target             $TARGET
Runtime            $RUNTIME
CLI                $BIN_DIR/kb
Profile            $PROFILE
Dependencies       check-only / never pip install
Developer CLI      $DEVELOPER
Site config        ${SITE_CONFIG:-<auto: config/site.env if present>}
RAGFlow migration  $MIGRATE_RAGFLOW (only RAGFlow site values are replaced)
Commands           /kb:* ($EXPECTED_COMMANDS expected)
Bootstrap          $((1-NO_BOOTSTRAP))
Transaction        stage -> validate -> backup -> switch -> doctor -> rollback on failure
Legacy migration   preserve unknown commands/knowledge files; remove Suite-known /knowledge:* files only
EOF
}

uninstall_suite(){
  section "Uninstall"
  for n in drv-knowledge-router drv-knowledge-retrieval drv-knowledge-ingestion; do rm -rf "$TARGET/skills/$n"; done
  rm -rf "$TARGET/lib/drv_knowledge_core"
  remove_known_commands "$TARGET/commands/kb" "${KB_COMMAND_FILES[@]}"
  remove_known_commands "$TARGET/commands/knowledge" "${LEGACY_KNOWLEDGE_FILES[@]}"
  rm -f "$BIN_DIR/kb" "$BIN_DIR/kb.cmd" "$BIN_DIR/drvkr" "$BIN_DIR/drvkr.cmd" "$BIN_DIR/drvki" "$BIN_DIR/drvki.cmd"
  if [[ $PURGE -eq 1 ]]; then rm -rf "$RUNTIME"; say "Runtime/config purged: $RUNTIME"; else say "Runtime/config preserved: $RUNTIME"; fi
  say "Drv Knowledge Suite uninstalled. Unknown/custom CodeBuddy command files were preserved."
}

rollback(){
  local rc="${1:-$EXIT_INSTALL}"
  [[ $SUCCESS -eq 1 ]] && return 0
  if [[ -n "$BACKUP" && -d "$BACKUP" ]]; then
    if [[ $COMMIT_STARTED -eq 1 ]]; then
      echo "Rollback: restoring previous installation from $BACKUP" >&2
      for n in drv-knowledge-router drv-knowledge-retrieval drv-knowledge-ingestion; do
        rm -rf "$TARGET/skills/$n"
        [[ -d "$BACKUP/skills/$n" ]] && mv "$BACKUP/skills/$n" "$TARGET/skills/$n"
      done
      rm -rf "$TARGET/lib/drv_knowledge_core"; [[ -d "$BACKUP/lib/drv_knowledge_core" ]] && mv "$BACKUP/lib/drv_knowledge_core" "$TARGET/lib/drv_knowledge_core"
      restore_known_commands "$TARGET/commands/kb" "$BACKUP/commands/kb" "${KB_COMMAND_FILES[@]}"
      restore_known_commands "$TARGET/commands/knowledge" "$BACKUP/commands/knowledge" "${LEGACY_KNOWLEDGE_FILES[@]}"
      for f in kb kb.cmd drvkr drvkr.cmd drvki drvki.cmd; do
        rm -f "$BIN_DIR/$f"; [[ -f "$BACKUP/bin/$f" ]] && mv "$BACKUP/bin/$f" "$BIN_DIR/$f"
      done
    fi
    if [[ -f "$BACKUP/runtime/.env" ]]; then mkdir -p "$RUNTIME"; cp -p "$BACKUP/runtime/.env" "$RUNTIME/.env"; elif [[ -f "$BACKUP/runtime/env_absent" ]]; then rm -f "$RUNTIME/.env"; fi
  fi
  [[ -n "$STAGE" ]] && rm -rf "$STAGE" || true
  return "$rc"
}
trap 'rc=$?; echo "ERROR: installer failed (rc=$rc)" >&2; rollback "$EXIT_INSTALL" || true; exit "$EXIT_INSTALL"' ERR INT TERM

if [[ $PLAN -eq 1 ]]; then show_plan; exit 0; fi
if [[ $UNINSTALL -eq 1 ]]; then uninstall_suite; exit 0; fi

section "Platform"
[[ "$(uname -s)" == "Linux" ]] || { echo "ERROR: install.sh supports Linux only; use install.cmd/install.py on Windows" >&2; exit $EXIT_PREREQ; }
command -v "$PYTHON" >/dev/null || { echo "ERROR: python3 not found" >&2; exit $EXIT_PREREQ; }
"$PYTHON" - <<'PY' || exit 20
import sys
assert sys.version_info >= (3,10), f"Python 3.10+ required; got {sys.version.split()[0]}"
PY
say "OS: $(uname -s) / arch: $(uname -m) / Python: $($PYTHON --version 2>&1) / Bash: ${BASH_VERSION%%(*}"

section "Package verification"
manifest_verify || exit $EXIT_INSTALL
INSTALLED="$(installed_version)"
if [[ -n "$INSTALLED" ]] && version_gt "$INSTALLED" "$VERSION" && [[ $FORCE -ne 1 ]]; then
  echo "ERROR: installed version $INSTALLED is newer than $VERSION; use --force to downgrade" >&2; exit $EXIT_INSTALL
fi
if [[ -n "$INSTALLED" ]]; then [[ $REPAIR -eq 1 ]] && say "Installed version detected: $INSTALLED (repair requested)" || say "Installed version detected: $INSTALLED"; fi

section "Environment preflight"
if "$PYTHON" "$ROOT/tools/install/dependency_check.py" --profile "$PROFILE" --json; then DEP_RC=0; else DEP_RC=$?; fi
if [[ $DEP_RC -ne 0 ]]; then
  echo "ERROR: mandatory ingestion environment is not ready; no Suite component was installed." >&2
  echo "The project does not bundle or install these packages. Ask the administrator to prepare the missing dependencies, then retry ./install.sh --full." >&2
  exit $EXIT_PREREQ
fi

mkdir -p "$RUNTIME/logs" "$TARGET" "$TARGET/skills" "$TARGET/lib" "$TARGET/commands" "$BIN_DIR"
LOGFILE="$RUNTIME/logs/install-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOGFILE") 2>&1
say "Install log: $LOGFILE"

section "Shared configuration"
SITE_ARGS=()
if [[ -n "$SITE_CONFIG" ]]; then SITE_ARGS=(--site-config "$SITE_CONFIG"); elif [[ -f "$ROOT/config/site.env" ]]; then SITE_ARGS=(--site-config "$ROOT/config/site.env"); fi
[[ $MIGRATE_RAGFLOW -eq 1 ]] && SITE_ARGS+=(--migrate-ragflow)
STAMP="$(date +%Y%m%d_%H%M%S)"; BACKUP="$TARGET/skills_backup/pre_drv_knowledge_suite_v${VERSION}_${STAMP}"
mkdir -p "$BACKUP/runtime"
if [[ -f "$RUNTIME/.env" ]]; then cp -p "$RUNTIME/.env" "$BACKUP/runtime/.env"; else : > "$BACKUP/runtime/env_absent"; fi
CONFIG_JSON="$BACKUP/config-migrate.json"
if "$PYTHON" "$ROOT/tools/install/config_migrate.py" --runtime "$RUNTIME" --target "$TARGET" --template "$ROOT/config/env.example" --profile "$PROFILE" --write --show-redacted --json "${SITE_ARGS[@]}" > "$CONFIG_JSON"; then CFG_RC=0; else CFG_RC=$?; fi
cat "$CONFIG_JSON"
if [[ $CFG_RC -ne 0 ]]; then echo "ERROR: shared configuration validation failed" >&2; rollback $EXIT_CONFIG || true; exit $EXIT_CONFIG; fi
chmod 0600 "$RUNTIME/.env" 2>/dev/null || true
if [[ $MIGRATE_RAGFLOW -eq 1 ]]; then
  while IFS= read -r key; do unset "$key"; done < <(compgen -v RAGFLOW_ || true)
  unset DRVKB_DATASET_PROFILE
fi
export DRVKB_ENV_FILE="$RUNTIME/.env" DRVKB_INSTALL_PROFILE="$PROFILE"

section "Local manuals"
mkdir -p "$RUNTIME/manuals"
if [[ -d "$ROOT/manuals" ]]; then cp -a "$ROOT/manuals/." "$RUNTIME/manuals/"; fi
MANUAL_COUNT="$(find "$RUNTIME/manuals" -type f \( -name '*.md' -o -name '*.markdown' -o -name '*.txt' \) ! -iname 'README.md' 2>/dev/null | wc -l | tr -d ' ')"
say "Local manuals: $MANUAL_COUNT file(s) -> $RUNTIME/manuals"

section "Stage package"
STAGE="$TARGET/.drvks-stage-${$}"
rm -rf "$STAGE"; mkdir -p "$STAGE/skills" "$STAGE/lib" "$STAGE/commands" "$STAGE/bin"
PROFILE_SKILLS=(drv-knowledge-router drv-knowledge-retrieval)
[[ $PROFILE == full ]] && PROFILE_SKILLS+=(drv-knowledge-ingestion)
for n in "${PROFILE_SKILLS[@]}"; do cp -a "$ROOT/skills/$n" "$STAGE/skills/$n"; done
cp -a "$ROOT/lib/drv_knowledge_core" "$STAGE/lib/drv_knowledge_core"
cp -a "$ROOT/commands/kb" "$STAGE/commands/kb"
[[ $PROFILE == retrieval ]] && rm -f "$STAGE/commands/kb/ingest.md"
"$PYTHON" "$ROOT/tools/install/validate_commands.py" "$STAGE/commands/kb" --expected "$EXPECTED_COMMANDS"

CLI_ARGS=()
[[ $DEVELOPER -eq 1 ]] && CLI_ARGS+=(--developer)
"$PYTHON" "$ROOT/tools/install/write_cli.py" --target "$TARGET" --runtime "$RUNTIME" --bin-dir "$STAGE/bin" --profile "$PROFILE" "${CLI_ARGS[@]}"

section "Pre-commit doctor"
if DRVKB_RUNTIME_DIR="$RUNTIME" DRVKNOWLEDGE_RUNTIME_DIR="$RUNTIME" PYTHONPATH="$STAGE/lib${PYTHONPATH:+:$PYTHONPATH}" "$PYTHON" "$STAGE/skills/drv-knowledge-router/scripts/router_cli.py" doctor --json > "$STAGE/doctor.json"; then DOCTOR_RC=0; else DOCTOR_RC=$?; fi
cat "$STAGE/doctor.json"
if [[ $DOCTOR_RC -ne 0 ]]; then echo "ERROR: staged local doctor failed; no installed files were replaced" >&2; rollback $EXIT_INSTALL || true; exit $EXIT_INSTALL; fi

section "Transactional switch"
mkdir -p "$BACKUP/skills" "$BACKUP/lib" "$BACKUP/commands/kb" "$BACKUP/commands/knowledge" "$BACKUP/bin"
COMMIT_STARTED=1
for n in drv-knowledge-router drv-knowledge-retrieval drv-knowledge-ingestion; do [[ -e "$TARGET/skills/$n" ]] && mv "$TARGET/skills/$n" "$BACKUP/skills/$n"; done
for n in "${PROFILE_SKILLS[@]}"; do mv "$STAGE/skills/$n" "$TARGET/skills/$n"; done
[[ -e "$TARGET/lib/drv_knowledge_core" ]] && mv "$TARGET/lib/drv_knowledge_core" "$BACKUP/lib/drv_knowledge_core"
mv "$STAGE/lib/drv_knowledge_core" "$TARGET/lib/drv_knowledge_core"

# Preserve unknown/custom command files. Only Suite-owned names are touched.
backup_known_commands "$TARGET/commands/kb" "$BACKUP/commands/kb" "${KB_COMMAND_FILES[@]}"
backup_known_commands "$TARGET/commands/knowledge" "$BACKUP/commands/knowledge" "${LEGACY_KNOWLEDGE_FILES[@]}"
remove_known_commands "$TARGET/commands/kb" "${KB_COMMAND_FILES[@]}"
mkdir -p "$TARGET/commands/kb"
for f in "$STAGE/commands/kb"/*.md; do install -m 0644 "$f" "$TARGET/commands/kb/$(basename "$f")"; done
remove_known_commands "$TARGET/commands/knowledge" "${LEGACY_KNOWLEDGE_FILES[@]}"

for f in kb kb.cmd drvkr drvkr.cmd drvki drvki.cmd; do [[ -e "$BIN_DIR/$f" ]] && mv "$BIN_DIR/$f" "$BACKUP/bin/$f"; done
mv "$STAGE/bin/kb" "$BIN_DIR/kb"; mv "$STAGE/bin/kb.cmd" "$BIN_DIR/kb.cmd"
if [[ $DEVELOPER -eq 1 ]]; then
  mv "$STAGE/bin/drvkr" "$BIN_DIR/drvkr"
  [[ $PROFILE == full ]] && mv "$STAGE/bin/drvki" "$BIN_DIR/drvki"
fi
rm -rf "$STAGE"; STAGE=""

# Remove obsolete scan-visible Skills only after new suite is committed.
for n in drv-knowledge drv-knowledge-ingest rag-search bookstack-fetch rag-search.bak bookstack-fetch.bak; do
  if [[ -e "$TARGET/skills/$n" ]]; then mv "$TARGET/skills/$n" "$BACKUP/skills/$n"; fi
done
[[ -e "$TARGET/skills/.backup" ]] && mv "$TARGET/skills/.backup" "$BACKUP/skills/legacy_dot_backup"

section "Post-install local validation"
if DRVKB_RUNTIME_DIR="$RUNTIME" "$BIN_DIR/kb" doctor --json > "$BACKUP/post-install-doctor.json"; then POST_RC=0; else POST_RC=$?; fi
cat "$BACKUP/post-install-doctor.json"
if [[ $POST_RC -ne 0 ]]; then echo "ERROR: post-install doctor failed" >&2; rollback $EXIT_INSTALL || true; exit $EXIT_INSTALL; fi

LIVE_RC=0; BOOT_RC=0
section "Live services"
if DRVKB_RUNTIME_DIR="$RUNTIME" "$BIN_DIR/kb" doctor --live --json > "$BACKUP/live-doctor.json"; then LIVE_RC=0; else LIVE_RC=$?; fi
cat "$BACKUP/live-doctor.json"
if [[ $NO_BOOTSTRAP -eq 0 && $LIVE_RC -eq 0 ]]; then
  if DRVKB_RUNTIME_DIR="$RUNTIME" "$BIN_DIR/kb" bootstrap --json > "$BACKUP/bootstrap.json"; then BOOT_RC=0; else BOOT_RC=$?; fi
  cat "$BACKUP/bootstrap.json"
fi
if [[ $STRICT_LIVE -eq 1 && $LIVE_RC -ne 0 ]]; then
  echo "ERROR: strict live validation failed; rolling back" >&2
  rollback $EXIT_STRICT_LIVE || true; exit $EXIT_STRICT_LIVE
fi

SUCCESS=1
trap - ERR INT TERM
section "Installation summary"
if [[ $PROFILE == full ]]; then
  SKILL_SUMMARY="Router / Retrieval / Ingestion"
  DEP_SUMMARY="6 / 6 required ingestion plugins PASS (check-only; no pip)"
  NEXT_SUMMARY='kb doctor; kb manuals; kb cases; kb recall -q "问题"; kb ingest analyze FILE'
else
  SKILL_SUMMARY="Router / Retrieval"
  DEP_SUMMARY="not required for retrieval"
  NEXT_SUMMARY='kb doctor; kb manuals; kb cases; kb recall -q "问题"'
fi
say "INSTALLATION READY"
say "  Profile          $PROFILE"
say "  Skills           OK ($SKILL_SUMMARY)"
say "  Commands         $EXPECTED_COMMANDS / $EXPECTED_COMMANDS PASS (/kb:*)"
say "  CLI              OK ($BIN_DIR/kb)"
say "  Dependencies     $DEP_SUMMARY"
say "CONFIGURATION READY"
say "  Shared env       OK ($RUNTIME/.env, mode 0600)"
say "  Install log      $LOGFILE"
say "  Local manuals    $MANUAL_COUNT file(s) ($RUNTIME/manuals)"
say "LIVE SERVICES"
say "  RAGFlow/BookStack  $([[ $LIVE_RC -eq 0 ]] && echo OK || echo 'WARN - run kb doctor --live')"
say "  Governance         OPTIONAL"
say "  Catalog            $([[ $BOOT_RC -eq 0 && $NO_BOOTSTRAP -eq 0 && $LIVE_RC -eq 0 ]] && echo READY || echo 'NOT BUILT/WARN')"
if [[ ":${PATH}:" != *":${BIN_DIR}:"* ]]; then say "PATH note: export PATH=\"$BIN_DIR:\$PATH\""; fi
say "Next: $NEXT_SUMMARY"

if [[ $LIVE_RC -ne 0 ]]; then exit $EXIT_LIVE_WARNING; fi
exit 0

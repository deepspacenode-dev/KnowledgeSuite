# V1.0.8 入库转换依赖要求

## 原则

V1.0.8 **不携带依赖 Wheel、不提供离线依赖包、不执行 pip install**。

知识检索安装不要求第三方格式插件；知识入库转换是可选的 full 能力，但启用 full 时以下 6 个插件是**必备条件**。安装器只做环境检查，缺任意一项即在修改 Suite 文件之前退出 20。

## 目标环境

```text
Ubuntu 22.04 LTS
x86_64 / AMD64
Python 3.10+
```

## 必需插件

```text
beautifulsoup4==4.14.3
python-docx==1.2.0
python-pptx==1.0.2
PyMuPDF==1.26.7
pdfplumber==0.11.7
Pillow==11.3.0
```

安装器通过对应 import (`bs4/docx/pptx/fitz/pdfplumber/PIL`) 判断环境是否满足要求，并报告实际版本。V1.0.8 不自动修复缺失依赖。

## full 安装

```bash
./install.sh --full
```

全部依赖存在：继续安装 Router / Retrieval / Ingestion，并注册 12 个 `/kb:*` 命令。

存在缺失：输出缺失包列表并退出 20，不修改已安装 Suite。管理员准备依赖后重新执行即可。

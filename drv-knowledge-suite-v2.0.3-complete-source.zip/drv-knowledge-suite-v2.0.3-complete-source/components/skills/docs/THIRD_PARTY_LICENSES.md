# Third-Party Dependency License Inventory

> Operational inventory for internal review; not legal advice. V1.0.8 does **not** bundle these third-party packages; the list documents the external ingestion runtime requirements.

| Package | Typical license / note |
|---|---|
| beautifulsoup4 | MIT |
| python-docx | MIT |
| python-pptx | MIT |
| PyMuPDF | AGPL-3.0 or Artifex commercial license |
| pdfplumber | MIT |
| Pillow | HPND |
| soupsieve | MIT |
| typing_extensions | PSF-2.0 |
| lxml | BSD-style |
| XlsxWriter | BSD-2-Clause |
| pdfminer.six | MIT |
| pypdfium2 | Apache-2.0 / BSD-3-Clause components |
| charset-normalizer | MIT |
| cryptography | Apache-2.0 OR BSD-3-Clause |
| cffi | MIT |
| pycparser | BSD-3-Clause |

For broad corporate rollout, review PyMuPDF's AGPL/commercial licensing position with the organization responsible for software licensing.

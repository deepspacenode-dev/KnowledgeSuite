# Drv Knowledge Suite V1.0.8 Architecture

~~~text
                              CodeBuddy / kb
                                   │
                                   ▼
                         drv-knowledge-router
                          profile-aware routing
                           │               │
                    retrieval          full only
                           │               │
                           ▼               ▼
              drv-knowledge-retrieval   drv-knowledge-ingestion
                    │    │    │           │
                    │    │    │           ├─ heterogeneous import
                    │    │    │           ├─ canonical Markdown
                    │    │    │           └─ controlled BookStack submit
                    │    │    │
                    ▼    ▼    ▼
                 RAGFlow BookStack Local Manuals
                    │    │    │
                    └────┼────┘
                         ▼
                      Recall V3
                         │
                  Engineering Rerank
                         │
                 Knowledge Bundle V3
~~~

## Profile Boundary

### retrieval

- 默认安装边界；
- Router、Retrieval、Shared Core；
- 11 个 `/kb:*` 命令；
- 本地 Markdown 手册；
- 不要求第三方格式解析包；
- 入库意图返回 ingestion_not_installed。

### full

- 仅在显式 --full 时启用；
- 增加 Ingestion Skill；
- 12 个 `/kb:*` 命令；
- 6 个直接格式处理依赖；
- 支持 DOCX/PPTX/HTML/PDF/图片生产链路；
- 仍需 Preview 和用户明确确认后才能提交 BookStack。

## Dependency Boundary

Retrieval 不依赖异构格式插件。full 模式的知识入库转换要求服务器**预先具备** 6 个插件：beautifulsoup4、python-docx、python-pptx、PyMuPDF、pdfplumber、Pillow。

```text
full install
  → check 6 required imports
  → all ready: continue
  → any missing: exit 20 before Suite component switch
```

V1.0.8 不携带 Wheelhouse，不执行 pip，也不提供跳过依赖检查的正式安装参数。

## Local Manuals

本地芯片手册默认运行目录：

~~~text
~/.drvknowledge/manuals/
~~~

发行包 manuals/ 是内容注入区。Local Manual Index 使用 Python 标准库按 Markdown 标题切分，缓存为：

~~~text
~/.drvknowledge/cache/local_manuals_index.json.gz
~~~

Local Manual Search 与 RAGFlow Search 并行，之后进入统一 rerank/dedup/bundle 流程，与 full 的异构格式入库能力互不绑定。

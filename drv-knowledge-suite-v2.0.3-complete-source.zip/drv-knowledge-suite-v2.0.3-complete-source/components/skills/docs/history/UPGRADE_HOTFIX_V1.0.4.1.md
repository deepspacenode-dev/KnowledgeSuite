# V1.0.6 Upgrade Hotfix Review

## 1. 问题现象

从已安装旧版本升级到 V1.0.4 时，Linux 安装器可能在 **pre-commit doctor** 阶段失败并返回 exit 40：

```text
ModuleNotFoundError: No module named 'drv_knowledge_core.source_metadata'
```

安装事务会按设计回滚，因此旧 Skills、CodeBuddy commands 和共享 `.env` 不会被破坏。

## 2. 根因

Retrieval 与 Ingestion 的 shared-core compatibility bridge 同时枚举：

1. 当前 Suite / staging 目录中的 `lib`
2. `~/.codebuddy/lib` 中已经安装的 `lib`

旧实现对每个候选都执行：

```python
sys.path.insert(0, candidate)
```

由于第二个候选后插入到索引 0，**旧安装目录反而覆盖了 staging 新 Core 的优先级**。

升级场景因此可能出现：

```text
stage/lib/drv_knowledge_core       V1.0.4，新 Core，包含 source_metadata.py
~/.codebuddy/lib/drv_knowledge_core 旧 Core，不包含 source_metadata.py
```

最终 Python 优先加载旧 Core，导致 Recall V3 新代码导入 `source_metadata` 失败。

全新安装通常没有旧 `~/.codebuddy/lib`，因此此前 Fresh Install 测试没有暴露该缺陷。

## 3. 修复

V1.0.6 将 Core 选择规则改成明确的 **first-valid-wins**：

```text
当前 Suite / staging Core
        ↓ 不存在才回退
已安装 ~/.codebuddy/lib Core
```

找到第一个有效 Core 后立即 `break`，不再把所有候选依次插入 `sys.path[0]`。

修复同时覆盖：

- `skills/drv-knowledge-retrieval/runtime.py`
- `skills/drv-knowledge-ingestion/scripts/ingest_cli.py`

因此 Retrieval 和 Ingestion 不再存在同类升级覆盖风险。

## 4. 新增回归测试

增加真实升级场景测试：

```text
HOME/.codebuddy/lib
  └── drv_knowledge_core        模拟旧 Core，无 source_metadata.py

安装 V1.0.6
  ↓
构建 staging 新 Core
  ↓
pre-commit doctor
  ↓
必须加载 staging Core
  ↓
安装成功
```

测试项：

```text
upgrade_old_core_does_not_shadow_stage  PASS
```

这项测试专门防止未来再次出现“Fresh Install 正常、Upgrade 失败”。

## 5. Review 结论

本次失败不是 Recall V3 算法本身的问题，也不是 `source_metadata.py` 漏打包。

根因属于 **升级安装时 Python Core 模块解析优先级错误**。

安装器的 staging / rollback 事务机制在本次现场故障中正确工作：pre-commit doctor 阻止错误版本提交，随后恢复旧版本和用户配置。因此事务框架无需推翻，只需要修复 Core compatibility bridge 并补充升级回归测试。

V1.0.6 是 V1.0.4 的安装兼容性 Hotfix，不改变 Recall V3、Router、Ingestion 的业务设计。

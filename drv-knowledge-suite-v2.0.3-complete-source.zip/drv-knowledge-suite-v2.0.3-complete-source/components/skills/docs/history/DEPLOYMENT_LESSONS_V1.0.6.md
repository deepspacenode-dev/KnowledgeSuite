# V1.0.6 部署教训与轻量化调整 Review

## 结论

正式部署模型收敛为：**默认且唯一的轻量知识获取安装**。安装器不再主动改变目标机 Python 环境。

## 现场教训

1. **Fresh Install 通过不等于 Upgrade 可用**：V1.0.4 暴露旧 Core 覆盖 staging 新 Core；V1.0.4.1 已用 first-valid-wins 修复。Release Gate 必须覆盖旧版升级、repair、回滚和 `.env` 保留。
2. **内网服务器不适合 pip 自动安装**：公网/源受限、权限受控、Python 由平台管理、二进制 Wheel 存在 ABI/架构风险，部分组件还有许可证治理要求。

## V1.0.6 调整

删除 `standard/full` Profile、`--deps`、`--offline` Wheel 安装、pip 调用、dependency checker/Wheelhouse 和默认异构格式入库命令。

保留 Router、Retrieval、shared Core、Recall V3、BookStack/RAGFlow、Catalog、12 个知识获取命令、事务安装/回滚和共享 `.env`。Ingestion 源码兼容层保留，但不作为默认用户入口且不安装第三方依赖。

## 默认安装契约

```text
./install.sh
 → Linux/Python 3.10+/Manifest
 → 安全合并 .env
 → lightweight stage
 → 12/12 commands
 → pre-commit doctor
 → transactional switch
 → post-install doctor
 → live RAGFlow/BookStack
```

整个安装流程不得执行 `pip install`。

## Release Gate

```text
Fresh lightweight install           PASS
Upgrade with old installed Core     PASS
Repair / idempotent install         PASS
Rollback                            PASS
Credential preservation             PASS
12 command validation               PASS
Recall V3 regression                PASS
Source URL contract                 PASS
No pip invocation in install.sh     PASS
No full/standard deployment path    PASS
```

# Historical implementation records

此目录保存旧版本安装重构、优化 Review 和 Hotfix 记录，仅用于追溯历史，不代表 V1.0.7 当前使用方式。

当前版本请优先阅读：

- `../QUICKSTART.md`
- `../ARCHITECTURE.md`
- `../DETAILED_DESIGN.md`
- `../LOCAL_MANUAL_RECALL_V1.0.6.md`
- `../TEST_REPORT.md`

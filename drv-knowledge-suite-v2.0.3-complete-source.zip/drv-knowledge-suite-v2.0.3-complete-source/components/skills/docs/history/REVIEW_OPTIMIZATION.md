# V1.0.4 Review 与优化说明

## 1. 召回与原文链接性能

旧路径的风险是 RAGFlow 负责召回，但命中项缺少稳定 `page_url` 时还需要再定位 BookStack 原文，造成额外网络等待。

V1.0.4 使用“链接随知识入库”作为主方案：

1. Ingestion 创建 BookStack Page；
2. 获得 BookStack `page_id` 和 canonical `page_url`；
3. 立即把 `bookstack_page_id/page_id/page_url/source_url/source_key` 写回页面 Front Matter；
4. 页面人工审批；
5. 现有 Governance/PHP Upsert 将页面 Markdown 送入 RAGFlow；
6. Recall 从 RAGFlow chunk metadata/front matter 直接得到 BookStack URL。

因此 Recall 主路径只需要一次 RAGFlow retrieval，不再为了“找链接”对每条结果访问 BookStack。

兼容历史数据：Recall 同时解析旧案例中的 blockquote metadata（`> original_url:` / `> bookstack_page_id:`），并进行旧地址 canonical rewrite。

全量 Browse 另外增加：
- 文档元数据优先，只有旧文档缺 metadata 时才取首 chunk；
- chunk enrichment 8 路并发（可通过 `DRVKB_BROWSE_WORKERS` 调整）；
- `~/.drvknowledge/cache/browse/` TTL 缓存，默认 900 秒；
- `kb cases --refresh` / `kb manuals --refresh` 强制刷新。

## 2. 安装/CodeBuddy 命令 Review

采纳修改报告中的 CodeBuddy 斜杠命令注册思路，发布包正式包含 `commands/knowledge/*.md` 18 个命令，安装器自动复制到 `~/.codebuddy/commands/knowledge/`。

安全调整：不采纳“真实 Token 直接写进发布包 `.env.default`”作为正式发布策略。真实凭证会使 ZIP、Git、IM 转发、备份都成为泄漏面。

V1.0.4 改为：
1. 已存在 `~/.drvknowledge/.env`：保持不动；
2. `--site-config PATH` 或包内私有 `config/site.env`：用于公司内网一键部署；
3. 迁移旧 Skill / shell 环境变量；
4. 最后从 `config/env.example` 生成空配置。

`config/site.env` 不随标准包提供，可由内网管理员在分发前注入，这样仍可一键安装，同时避免源代码包永久携带长期凭证。

## 3. 工程结构

根目录只保留 README、VERSION、安装入口和 Manifest。文档、CLI、配置、依赖、命令分别归档到固定目录，避免打开 ZIP 后看到大量 `.py/.sh/.cmd/.md` 平铺。

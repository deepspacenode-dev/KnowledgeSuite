# V1.0.6 本地芯片手册召回设计与 Review

## 1. 背景

V1.0.5 的轻量部署虽然保留了 `kb manuals` 和 Recall V3，但手册数据源仍然主要指向 RAGFlow `manuals` Dataset。现场环境中 RAGFlow 解析 Worker 出现任务堆积、解析失败后，新手册即使已经是 Markdown，也无法及时进入 RAGFlow，因此出现：

```text
本地已经有 Markdown 手册
        ↓
RAGFlow manuals Dataset 没有可用文档
        ↓
kb manuals = 0
        ↓
Recall 无法命中芯片手册
```

这说明只“预留一个 manuals 目录”还不够，必须把本地 Markdown 手册真正接入 Retrieval Pipeline。

## 2. V1.0.6 目标

V1.0.6 将芯片手册定义为双源检索：

```text
                    Recall V3
                        │
             ┌──────────┴──────────┐
             │                     │
             ▼                     ▼
       RAGFlow Recall        Local Manual Index
   cases/tech/manuals/...    ~/.drvknowledge/manuals
             │                     │
             └──────────┬──────────┘
                        ▼
                 Engineering Rerank
                        ▼
                 Document Dedup
                        ▼
                Knowledge Bundle V3
```

RAGFlow 仍负责已有知识的语义召回；本地手册是**芯片手册专项兜底和并行数据源**。

## 3. 手册放置位置

发布包明确预留：

```text
manuals/
├── README.md
├── 01_主控SoC与平台芯片/
├── 02_网络与通信芯片/
├── 03_单片机与协处理器/
└── 04_外设扩展与控制芯片/
```

团队可以在安装前直接把已经转换好的 Markdown 手册塞入上述目录。

安装器会增量合并到：

```text
~/.drvknowledge/manuals/
```

升级不会删除运行目录中已有手册；`--uninstall` 默认也保留，只有 `--purge` 才随整个 runtime 删除。

## 4. 无第三方依赖

本地手册引擎只支持：

```text
.md
.markdown
.txt
```

原因是团队手册已经提前转换成 Markdown。检索端不再承担 PDF/DOCX/PPTX 转换，因此：

- 不需要 PyMuPDF；
- 不需要 pdfplumber；
- 不需要 Pillow；
- 不需要 python-docx/python-pptx；
- 安装器不调用 pip。

## 5. Local Manual Index

实现文件：

```text
skills/drv-knowledge-retrieval/navigator/local_manuals.py
```

索引过程：

```text
扫描 Markdown/TXT
   ↓
解析 Front Matter
   ↓
提取 H1/H2/H3 标题
   ↓
按章节切分（默认约 1800 chars）
   ↓
生成轻量本地索引
   ↓
~/.drvknowledge/cache/local_manuals_index.json.gz
```

索引只使用 Python 标准库。索引缓存通过文件相对路径、size、mtime 生成签名；内容未变化时直接复用。

`kb manuals --refresh` 会强制重建索引。

## 6. Recall V3 集成

每次非 fixture Recall 都会额外执行：

```text
search_local_manuals(normalized_query)
```

本地候选会构造与 RAGFlow Candidate 相同的字段：

```yaml
dataset: local_manuals
material_type: manuals
source_kind: local_manual
source_key: local_manual:02_网络与通信芯片/RTL8367S.md
page_url: file:///home/user/.drvknowledge/manuals/...
local_path: /home/user/.drvknowledge/manuals/...
section: RGMII Delay
line_start: 120
line_end: 166
```

然后统一进入：

```text
Engineering Rerank → Document Dedup → Evidence Extractor → Knowledge Bundle V3
```

因此本地手册不是 CLI 特殊输出，而是真正参与 Recall V3 排序。

## 7. 原文链接契约

Recall V3 的“每条公开结果都可进入原文”契约继续保留。

优先级：

```text
Markdown front matter page_url/source_url/original_url
                         ↓ 没有
                   file:// 本地 Markdown
```

所以：

- BookStack 导出的手册可以直接返回 HTTP 原文；
- 纯本地芯片手册返回 `file://` 和 `local_path`；
- 不伪造不存在的 BookStack 页面。

## 8. RAGFlow 异常时的降级行为

如果 RAGFlow Recall 请求失败，但本地手册能命中：

```text
knowledge_status = degraded
ok = true
```

CLI 会显示 RAGFlow Warning，但仍返回本地手册结果。

如果 RAGFlow 未配置且本地手册存在，手册 Recall 同样可以执行。

## 9. `kb manuals` 行为

`kb manuals` 现在是 Hybrid Browse：

```text
RAGFlow manuals
+
Local Markdown manuals
```

当 RAGFlow manuals 为 0 或不可用时，本地手册仍会正常列出。

## 10. V1.0.6 同时修正的轻量部署边界

Review V1.0.5 发布包后发现：虽然安装文档宣称“轻量”，包中仍残留 Ingestion Skill 和第三方 requirements 文件，Linux 安装器也仍会复制 Ingestion Skill。

V1.0.6 将这一偏差修正为真正的 Retrieval-only 发布：

```text
skills/
├── drv-knowledge-router/
└── drv-knowledge-retrieval/
```

不再随正式轻量包分发：

```text
drv-knowledge-ingestion
requirements/full.txt
requirements/standard.txt
requirements/offline.lock.txt
第三方格式转换依赖清单
```

旧机器升级时，如果存在旧 `drv-knowledge-ingestion`，安装器会先备份后移除；安装失败回滚时仍可恢复旧版本。

## 11. 验收点

V1.0.6 Release Gate 新增：

```text
Local manual directory exists                   PASS
Install copies package manuals to runtime       PASS
Local manual browse without RAGFlow             PASS
Local manual recall without RAGFlow             PASS
Local manual file:// source contract            PASS
Local index cache created                       PASS
No ingestion payload in release                 PASS
No third-party requirements in release          PASS
```

## 10. 原文链接契约

本地手册的来源链接优先级：

```text
Markdown Front Matter page_url/source_url/original_url (HTTP/HTTPS)
        ↓ 如果没有
本地 Runtime 文件 file:// URI
```

因此如果同一手册后续在 BookStack 有正式页面，可在 Markdown Front Matter 中加入：

```yaml
---
title: RTL8367S Datasheet
chip: RTL8367S
page_url: http://bookstack.internal/books/manuals/page/rtl8367s
---
```

Recall 会优先返回 BookStack HTTP 链接；纯本地资料则返回 `file://` 和 `local_path`，方便 CodeBuddy/开发机直接定位原文。

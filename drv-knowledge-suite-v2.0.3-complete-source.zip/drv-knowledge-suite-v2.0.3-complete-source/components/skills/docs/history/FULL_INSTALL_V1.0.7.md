# V1.0.8 全量安装设计与验收

## 目标

在不破坏 V1.0.6 轻量部署边界的前提下，为专用知识入库/文档转换环境增加 full 安装选项。

核心规则：

- retrieval 仍是默认；
- full 必须显式选择；
- full 先检查环境，再安装 Suite；
- 已有依赖默认不重装；
- 只安装缺失依赖；
- 环境检查失败时不切换 Suite 组件。

## 安装入口

~~~bash
./install.sh --full
./install.sh --profile full
python3 install.py --full
~~~

三者选择的 profile 均为 full。Linux 正式入口优先使用 install.sh。

## 环境预检顺序

~~~text
Python/平台检查
  → PACKAGE_MANIFEST 校验
  → 6 项直接依赖探测
  → 全部存在：跳过 pip
  → 存在缺失：仅解析缺失项
  → 安装后再次探测
  → staging
  → pre-commit doctor
  → 事务切换
~~~

环境报告字段：

| 字段 | 含义 |
|---|---|
| dependencies.*.installed | 模块是否可导入 |
| dependencies.*.version | 当前环境实际版本 |
| dependencies.*.action | skip_existing / install_missing |
| missing_before | 补装前缺失包 |
| skipped_existing | 保留且不重装的包 |
| install.attempted | 是否真正调用 pip |
| install.packages | 本次仅补装的包 |
| missing_after | 补装后的剩余缺失 |

## 依赖集合

直接依赖 6 项：

~~~text
beautifulsoup4==4.14.3
python-docx==1.2.0
python-pptx==1.0.2
PyMuPDF==1.26.7
pdfplumber==0.11.7
Pillow==11.3.0
~~~

离线锁定闭包 16 项：

~~~text
beautifulsoup4  python-docx  python-pptx  PyMuPDF
pdfplumber      Pillow       soupsieve    typing_extensions
lxml            XlsxWriter   pdfminer.six pypdfium2
charset-normalizer cryptography cffi pycparser
~~~

完整版本见 requirements/offline.lock.txt。

## 自动与离线策略

### 依赖已齐全

无论是否指定 --offline，均立即通过：

~~~text
missing_before=[]
install.attempted=false
reason=all required dependencies are already installed; pip was not invoked
~~~

### 存在缺失且 offline/wheels 有内容

auto 模式自动采用离线 Wheelhouse：

~~~text
pip install --no-index --find-links offline/wheels <仅缺失的锁定依赖>
~~~

同时要求 offline/SHA256SUMS.txt，并执行 Wheel 标签与 pip dry-run 闭包验证。

### 存在缺失且没有 Wheelhouse

- 普通 auto：从当前 pip 配置的包索引只安装缺失项；
- --offline：直接退出 20，不回退在线索引；
- --deps check：直接退出 20，不执行安装。

## Profile 交付差异

| 项 | retrieval | full |
|---|---:|---:|
| Router | 是 | 是 |
| Retrieval | 是 | 是 |
| Ingestion | 否 | 是 |
| 本地 Markdown 手册 | 是 | 是 |
| Recall V3 | 是 | 是 |
| 异构格式导入 | 否 | 是 |
| knowledge 命令 | 12 | 18 |
| 默认 pip 调用 | 否 | 仅缺失依赖时 |

## 验收标准

1. ./install.sh --plan 不创建任何目录。
2. 默认安装不检查或安装 full 第三方依赖。
3. full 环境 6 项均存在时，install.attempted=false。
4. 只缺一项时，install.packages 只包含该项。
5. full 安装后 Ingestion Skill 存在，命令数为 18。
6. full 切回 retrieval 后 Ingestion 不再可扫描，命令数为 12。
7. kb doctor 在两种 profile 下均能正确识别组件和依赖。
8. PACKAGE_MANIFEST、发布 ZIP SHA-256 和明文 Token 扫描通过。

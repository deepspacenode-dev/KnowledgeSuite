# V1.0.4 安装层重构与 Review 记录

## 1. 结论

V1.0.4 将 Linux 正式安装入口从“Shell 仅转发 install.py”改为“Bash 主流程 + Python 小型辅助工具”。Router / Retrieval / Ingestion 核心架构不变。

## 2. 已落实

### P0
- `install.sh` 成为 Linux 正式安装入口，使用 `#!/usr/bin/env bash` 与 `set -Eeuo pipefail`。
- 安装前 staging，命令/依赖/Doctor 验证通过后再切换正式目录。
- 失败自动回滚；`--strict-live` 失败会恢复旧版本。
- `--offline` 依赖安装强制 `pip --no-index --find-links`，缺 Wheel 或哈希清单时失败，不回退公网。
- Wheelhouse 支持 SHA256 校验与目标 Python/架构文件名检查。
- 安装结果区分 `INSTALLATION READY / CONFIGURATION READY / LIVE SERVICES`。
- 修复 `/knowledge:manual` 参数无法透传：`kb ingest manual INPUT.pdf` 可直接进入高保真手册引擎。
- 修复 Browse `--refresh`：现在同时刷新 Knowledge Catalog 与 Browse Cache，并且 Slash Command 解析不会丢失该标志。

### P1
- 安装 Profile：`retrieval / standard / full`。
- 默认只暴露 `kb`；`--developer` 才安装 `drvkr / drvki`。
- `--plan / --repair / --uninstall / --purge / --force / --version`。
- `kb config validate` 与 `kb config show --redacted`。
- CodeBuddy 命令 Front Matter、重复命令与 `kb` 根命令引用检查。
- Profile 对应 CodeBuddy 命令数量：retrieval=12、standard=17、full=18。

### P2
- 安装日志：`~/.drvknowledge/logs/install-YYYYMMDD-HHMMSS.log`。
- 稳定退出码：0 / 10 / 20 / 30 / 40 / 50。
- 新增 release builder，生成 ZIP + `.sha256`；提供 GPG key 时可额外生成 detached signature。

## 3. Python 辅助工具边界

- `tools/install/config_migrate.py`：安全解析/合并 `.env`、旧 `rag-search/config.json`，不执行 `source`。
- `tools/install/dependency_check.py`：Python 模块、Profile、Wheelhouse、ABI/平台文件名、SHA256 与离线安装检查。
- `tools/install/validate_commands.py`：CodeBuddy `/knowledge:*` 命令定义校验。

Shell 不负责复杂 dotenv/JSON 解析，避免引号、空格、`#`、特殊字符与配置注入风险。

## 4. Profile

| Profile | 主要用途 | CodeBuddy 命令 | 格式依赖 |
|---|---|---:|---|
| retrieval | 纯检索客户端 | 12 | 无 |
| standard | 检索 + HTML/DOCX/PPTX/MD 入库 | 17 | bs4/python-docx/python-pptx |
| full | 完整知识入库与 PDF/手册能力 | 18 | standard + PyMuPDF/pdfplumber/Pillow |

所有 Profile 仍安装三 Skill 代码与 Shared Core，以保持 Router 契约一致；Profile 主要控制依赖与用户可见命令能力。

## 5. 安全与事务

- 共享配置只保存在 `~/.drvknowledge/.env`，权限 0600。
- 配置合并优先级：现有共享配置 > 私有 site config > 旧配置迁移 > 当前环境变量 > 示例模板。
- 日志与 `kb config show` 不输出完整 token/secret/cookie。
- 新组件 staged 后运行 local Doctor；正式切换后再次 Doctor。
- 旧 Skill、Core、commands、CLI 与 `.env` 均进入备份，异常时恢复。

## 6. Review 发现与修复

1. 原 Router 的 `manual` 子命令会把文档参数传给 Ingestion，但 Ingestion parser 不接受位置参数，现场会直接 argparse 失败：已修复。
2. `--refresh` 文档宣称刷新目录和缓存，但此前 `command_browse()` 仅传 `refresh_catalog`，未传 `refresh_cache`；Slash Command 解析也丢失该标志：已修复。
3. 原 Linux `install.sh` 只是 `exec python install.py`，无法体现安装步骤、事务边界和离线策略：已重构。
4. 默认安装 `drvkr/drvki` 增加普通用户认知负担：改为 `kb` 单入口，开发模式按需安装。
5. 安装成功与线上服务可用混用：已拆分并使用 exit code 10 表示“安装成功但线上告警”。

## 7. 仍保留的边界

- Windows 继续使用 `install.cmd / install.py` 兼容入口，本次未重写 Windows 安装事务。
- 发布签名需要企业内部 GPG/制品库密钥，项目只提供可选签名工具，不内置私钥。
- Offline Wheel 本身仍需按目标 Ubuntu 22.04/x86_64/Python 3.10 准备并放入 `offline/wheels/`。

# RAGFlow 服务器迁移与离线部署说明（Skills V2.0.1）

本说明适用于 RAGFlow 地址、API Key、数据集 ID 或容器网络发生变化，但 BookStack、Governance 和本地知识工作区需要保留的场景。发行物不包含真实内网地址、Token、证书或数据集 ID。

## 准备私有站点文件

在发行包外创建 `ragflow-site.env`：

```dotenv
DRVKB_DATASET_PROFILE=drvdocs
RAGFLOW_BASE_URL=http://<ragflow-host>:<port>
RAGFLOW_API_KEY=<replace-me>
```

`RAGFLOW_BASE_URL` 填写可达的主机根地址，不要追加 `/api/v1`。如果目标 RAGFlow 的 API 路径或数据集名称不同，可在私有文件中追加对应 `RAGFLOW_*` 配置。该文件不得加入源码仓库或发布 ZIP。

## 迁移已有安装

Linux：

```bash
chmod 600 ../ragflow-site.env
bash install.sh --migrate-ragflow --site-config ../ragflow-site.env
```

Python/Windows：

```text
python install.py --migrate-ragflow --site-config ..\ragflow-site.env
```

已有 full 安装需要继续保留入库能力时添加 `--full`。安装器不下载依赖、不执行 pip；离线环境应使用发行物内带哈希清单的 wheelhouse 预先准备 Python 环境。

## 数据保护边界

显式迁移会：

- 替换 RAGFlow URL、API Key、站点 profile 和站点文件明确提供的 RAGFlow 参数；
- 清空未重新提供的旧数据集 ID、ID 列表和名称映射；
- 将粘贴的 `/api/v1` 根地址规范化为主机根地址；
- 把旧 `.env` 备份到 runtime 的 `backups/`，再原子写入新配置；
- 失效 `knowledge_catalog.json` 和 `cache/browse/` 远程派生缓存。

显式迁移不会删除或覆盖：

- BookStack 地址、个人 Token 和页面内容；
- Governance V2 地址、个人 Token、审核状态缓存；
- 本地 Markdown 手册及其索引；
- 入库 Draft、转换工作区和提交会话；
- SQLite outbox、dead letter 与待同步请求；
- Worker、Contracts、Governance 组件版本。

站点文件缺少 URL/Key、URL 非法或服务配置不完整时，安装器返回配置错误，原 `.env`、备份目录和缓存保持不变。

## 验收顺序

```text
kb config show --redacted
kb doctor --json
kb doctor --live --json
kb bootstrap --json
kb recall -q "<库中已知问题>" --mode live --json
```

状态解释：

| 字段 | 含义 |
|---|---|
| `configured.ragflow` | URL 与 Key 已加载，但不代表网络可达 |
| `services_checked` | 本次是否执行了 live API 探测 |
| `services.ragflow` | 数据集 API 是否可连接 |
| `ragflow_index.state=empty` | 已匹配库为空 |
| `ragflow_index.state=pending_parse` | 有文档但明确为 0 分块 |
| `ragflow_index.state=indexed` | 至少一个默认库有分块，不代表全部解析完成 |
| `ragflow_index.state=unknown` | API 未提供足够计数 |
| `ragflow_index.state=unmapped` | 默认 profile 没有匹配到数据集 |
| `ragflow_index.real_query_verified` | doctor 始终为 false，必须另跑真实 recall |

真实验收必须确认命中新服务器数据集、返回有效分块、治理状态允许使用，并且原文链接可打开。仅 API 返回 200 或文档数大于 0，不能证明解析和召回链路可用。

## 回滚

停止使用新配置后，将 runtime `backups/before-ragflow-migration-*.env` 中确认正确的一份恢复为 `.env`，然后执行 `kb bootstrap --json` 重建远程目录缓存。回滚配置不会回滚 RAGFlow 服务器内的数据、解析任务或 BookStack 页面。

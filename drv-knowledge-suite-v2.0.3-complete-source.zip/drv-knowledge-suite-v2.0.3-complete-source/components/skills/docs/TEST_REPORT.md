# Drv Knowledge Suite V1.0.8 Test Report

## Scope

V1.0.8 focuses on:

- public command namespace unification to `/kb:*`;
- command count reduction (retrieval 11 / full 12);
- `/knowledge:*` migration compatibility;
- safe cleanup of Suite-owned legacy CodeBuddy commands only;
- check-only mandatory ingestion dependencies;
- no bundled Wheelhouse / no automatic pip install;
- preservation of Recall V3 and local manual recall.

## Executed regression suites

| Suite | Result |
|---|---:|
| Suite / Router / Python installer | 16 / 16 PASS |
| Shell installer / upgrade migration | 8 / 8 PASS |
| Dependency checker | 5 / 5 PASS |
| Ingestion | 13 / 13 PASS |
| Local Markdown manuals | 4 / 4 PASS |
| Retrieval selftest | PASS |

The five numbered suites total **46 / 46 PASS**. Retrieval selftest is additionally executed inside the Suite tests and independently verified.

## Naming migration checks

```text
/kb:cases                         PASS
/kb cases                         PASS (router compatibility form)
/knowledge:cases                  PASS + deprecated warning metadata
/knowledge:query                  maps to /kb:search
/knowledge:ingest-preview         maps to /kb:ingest preview
```

Installed CodeBuddy commands:

```text
retrieval: 11 / 11 PASS
full:      12 / 12 PASS
```

The release source contains `commands/kb/` only. The old `commands/knowledge/` namespace is not shipped as a current command source.

## Upgrade safety

Regression verifies a pre-existing `~/.codebuddy/commands/knowledge/` containing both:

```text
cases.md       Suite-owned legacy command
my-custom.md   user-owned command
```

After V1.0.8 installation:

```text
legacy cases.md removed        PASS
user my-custom.md preserved    PASS
new commands/kb installed      PASS
```

The previous staged-Core upgrade regression also remains PASS:

```text
upgrade_old_core_does_not_shadow_stage  PASS
```

## Dependency policy checks

full mode requires these six packages to be importable:

```text
beautifulsoup4
python-docx
python-pptx
PyMuPDF
pdfplumber
Pillow
```

Validated behavior:

```text
retrieval requires no format plugins             PASS
full with 6/6 dependencies                        PASS
missing dependencies detected                     PASS
dependency checker has no --install mode          PASS
installer has no --deps/--offline/--wheel-dir     PASS
release contains no offline/ Wheelhouse            PASS
requirements/offline.lock.txt absent               PASS
```

The Suite does **not** run pip. Missing full-mode dependencies are an administrator/environment prerequisite and cause exit 20 before Suite component switching.

## Recall / manual regression

Independent Retrieval selftest result:

```text
fixture_recall          PASS
fixture_evaluate        PASS
compile                 PASS
command_router          PASS
local_manual_engine     PASS
intent_router           PASS
secret_scan             PASS
```

Fixture metrics include:

```text
Recall@1                1.0
Top3 hit rate           1.0
Top5 hit rate           1.0
MRR@5                   1.0
page_url_rate           1.0
document_duplicate_rate 0.0
```

Local manual tests:

```text
browse without RAGFlow             PASS
recall without RAGFlow             PASS
local index generation             PASS
clickable source contract          PASS
```

## Release conclusion

V1.0.8 is ready for packaging after final `PACKAGE_MANIFEST.txt` regeneration and fresh archive verification.

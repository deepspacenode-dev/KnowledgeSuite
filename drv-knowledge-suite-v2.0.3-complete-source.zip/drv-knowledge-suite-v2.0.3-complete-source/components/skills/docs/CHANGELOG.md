# Changelog

## V2.0.3 — Recall V4 Relevance Gates and Feedback Closure

- Added explicit domain/chip conflict rejection, score/margin answer gates and scarcity-only metadata fallback.
- Added secret-free Recall V4 trace storage and explicit `kb feedback` capture linked to knowledge-gap events.
- Expanded the regression corpus to 12 cases with forbidden-module and expected-answer-status assertions.
- Added the official RAGFlow Chat Profile V2 dry-run/apply tooling shared with the BookStack Widget rollout.

## V2.0.2 — RAGFlow v0.27.1 Retrieval, Parsing and Chat Profiles

- 使用 `page/page_size/knn_top_k/knn_num_candidates/rerank_candidates_count`，不再发送废弃的 Retrieval `top_k`。
- 召回请求读取 RAGFlow 文档元数据并返回可迁移的 BookStack 原文链接；显式芯片/模块启用强过滤与本地防漂移。
- 新增 `kb rag profiles|document apply|parse|chat sync|migration-plan`，写操作必须显式 `--confirm`。
- 固化 Markdown、PDF、技术笔记和图片解析 Profile，并提供 BookStack 助手 Chat Prompt 配置。

## V2.0.1 — RAGFlow Server Migration Compatibility

- 新增显式 `--migrate-ragflow --site-config FILE`，只替换 RAGFlow URL、Key、数据集映射和 API 路径。
- 迁移前以 0600 权限备份旧 `.env`，校验成功后原子替换；非法配置不写文件、不清缓存。
- 迁移时仅失效远程 Catalog/Browse 缓存，保留 BookStack、Governance、本地手册、入库会话与 SQLite outbox。
- 远程缓存绑定服务地址、账号、数据集路由和 BookStack 链接策略，避免迁移后读取旧服务器结果。
- `kb doctor` 区分配置存在、API 可连接、数据集存在分块与真实召回验证，不再把文档数量当成解析成功。
- `drvdocs` 成为新安装默认数据集 profile，`bookstack_ai_*` profile 继续兼容。
- CLI 启动器固定安装时的 Python/venv 与 runtime，新终端无需重复导出运行目录。
- 修复 `/kb:doctor --live --json` 参数转发；保持 Intake、Governance V2、Knowledge Bundle V2 与 Worker contracts 不变。

## V1.0.8 — kb Namespace & Dependency Boundary

- 用户入口统一为 `kb`：CodeBuddy `/kb:*`、终端 `kb ...`。
- CodeBuddy 命令从 full 18 个精简为 12 个；retrieval 为 11 个。
- `query` 合并到 `search`，所有入库子操作收口到 `/kb:ingest`。
- `commands/knowledge/` 改为 `commands/kb/`；升级仅删除旧 namespace 中 Suite 已知文件，保护用户自定义命令。
- Router 暂时兼容 `/knowledge:*` 并返回弃用提示。
- full 的 6 个入库转换插件改为强制 check-only：项目不附带 Wheel、不自动 pip 安装。
- 删除 `offline/` 与 `requirements/offline.lock.txt`。

## V1.0.8 — Optional Full Install + Missing-Only Dependencies

- 以 V1.0.6 为主线，保留 Recall V3 和本地 Markdown 手册召回。
- 默认 profile 仍为 retrieval，继续保持 12 命令、无 pip 的轻量部署。
- 新增 --full / --profile full，安装 Router + Retrieval + Ingestion 和 18 个命令。
- full 在 Suite 文件切换前检查 6 个直接依赖。
- 已安装依赖标记 skip_existing，不重装、不降级，不调用 pip。
- 仅对 missing_before 中的包执行补装，并在补装后再次检查。
- 恢复严格离线 Wheelhouse、SHA-256、CPython 3.10/x86_64 标签和依赖闭包检查。
- Linux 和 Python/Windows 安装入口均支持 retrieval/full。
- Router 改为 profile-aware：retrieval 明确拒绝入库，full 正常路由 Ingestion。
- 新增依赖跳过、单项补装、双 Profile 安装、full→retrieval 切换回归测试。

## V1.0.6 — Local Manual Recall + True Lightweight Distribution

- 新增发行包 `manuals/` 芯片手册内容注入区。
- 安装器增量同步 Markdown 手册到 `~/.drvknowledge/manuals/`。
- 新增纯标准库 Local Manual Index，无需任何 pip/第三方解析器。
- `kb manuals` 升级为 RAGFlow + Local Manual Hybrid Browse。
- Recall V3 并行合入本地手册候选；RAGFlow 异常时可降级返回本地手册。
- 本地手册返回 `file://` + `local_path` 原文入口；有 BookStack URL 时优先 HTTP。
- 正式包移除 Ingestion Skill 和第三方 requirements，真正实现 Retrieval-only 轻量部署。
- 保留 V1.0.4.1 的旧 Core 升级优先级修复和事务回滚。

## V1.0.6 — Upgrade Core Resolution Hotfix

- 修复旧版本升级时 staging 新 Core 被 `~/.codebuddy/lib` 旧 Core 覆盖的问题。
- Retrieval / Ingestion compatibility bridge 改为 first-valid-wins，当前 Suite/staging Core 永远优先。
- 新增 `upgrade_old_core_does_not_shadow_stage` 升级回归测试。
- 保留并验证 pre-commit doctor、事务回滚和 `.env` 保留机制。
- Recall V3 算法、原文链接硬契约和入库主流程不变。

## V1.0.4 — Recall V3

- Query Expansion 从“只生成”改为 raw / engineering / symptom 多 Query 真正提交 RAGFlow。
- 新增 Recall Planner：Case Lane 与 Reference Lane 分路并行召回，generic docs 改为候选不足时 fallback。
- 候选池默认扩大到 50，并支持并发数/单请求 Top-K 配置。
- 新增 Engineering Rerank：semantic、entity、symptom、title、module/chip/platform/project、material、status、multi-query consensus。
- 新增 Document-level Dedup，避免同一 BookStack 页面多个 chunk 占用 Top-K。
- 新增 Evidence Extractor，从原文提取问题现象、根因、解决方案、验证；不再使用 `content[:220]` 作为用户描述。
- Knowledge Bundle 升级为 `knowledge-bundle-v3`。
- 原文链接升级为硬契约：公开 Top-K 每条必须有 HTTP(S) BookStack 链接；无链接候选从公开结果排除并进入治理告警。
- Recall 链接继续直接读取 RAGFlow metadata/front matter，不引入 BookStack 二次同步查询。
- Evaluator 新增 Recall@1、MRR@5、Document Duplicate Rate、Source URL Rate、p50/p95 latency。
- 新增 Live Recall Benchmark 模板和 Recall V3 实施 Review。

## V1.0.3 — Installation Refactor

- Linux 正式安装入口改为 Bash 主流程 + Python 小型辅助工具。
- 新增 staged installation、事务切换、失败回滚、strict-live rollback。
- 新增严格离线依赖模式、Wheel SHA256 校验、Profile 依赖。
- 新增 `retrieval / standard / full` 安装 Profile。
- 默认只安装 `kb` CLI；`--developer` 才暴露 `drvkr / drvki`。
- 新增 `--plan / --repair / --uninstall / --purge / --force / --version`。
- 新增 `kb config validate`、`kb config show --redacted`。
- 新增 CodeBuddy command 定义完整性校验。
- 修复 `/knowledge:manual` 参数透传与 Browse `--refresh`。
- 新增安装日志、稳定退出码、release ZIP/SHA256 构建器和第三方依赖许可证清单。

# Drv Knowledge Suite V1.0.4 — Recall V3 实施与 Review

## 1. 版本目标

V1.0.4 冻结安装器与入库主架构，专项优化 Retrieval 的两个现场痛点：

1. **找得不够准**：旧实现只真正提交了原始 Query，多个 Dataset 同池竞争，Top-K 候选过窄，精排偏 Metadata。
2. **结果不好读**：旧 `summary = content[:220]`，`reason` 主要是机器评分说明，用户无法快速判断“现象、根因、处理、验证”。

同时保留 V1.0.2 起已经验证的性能原则：**Recall 不为每条命中同步访问 BookStack 获取链接**。

## 2. Recall V3 数据流

```text
用户问题
  │
  ▼
Query Understanding
  ├─ raw query
  ├─ engineering query
  └─ symptom query
  │
  ▼
Recall Planner
  ├─ Case Lane       : cases
  └─ Reference Lane  : tech_notes / manuals / project_docs
         │
         └─ docs 仅在主候选不足时 fallback
  │
  ▼
RAGFlow 并行多路召回
  │
  ▼
Candidate Pool（默认上限 50）
  │
  ▼
Engineering Rerank
  ├─ RAGFlow semantic similarity
  ├─ entity match
  ├─ symptom match
  ├─ title match
  ├─ module/chip/platform/project
  ├─ material priority
  └─ review/status/source quality
  │
  ▼
Document-level Dedup
  │
  ▼
Evidence Extractor
  ├─ 问题现象
  ├─ 根因
  ├─ 解决方案
  └─ 验证
  │
  ▼
Knowledge Bundle V3
  └─ 每条公开结果必须包含 HTTP(S) 原文链接
```

## 3. Query Expansion 从“生成”改为“真正执行”

旧实现虽然生成 `expanded_queries`，但 RAGFlow payload 实际固定使用 `[0]`，即原始问题。

V1.0.4 每个问题最多生成三种 Query：

- `raw`：用户原话；
- `engineering`：工程标准化词汇，如 PHY / MAC / RGMII / VLAN / ARP；
- `symptom`：现象与排查语言，如 Link Up / 无流量 / MAC 无报文。

这些 Query 会按照 Recall Planner 进入不同 Lane，并通过线程池并行提交 RAGFlow，而不是只用于 trace。

默认参数：

```text
DRVKB_RECALL_PER_REQUEST=10
DRVKB_RECALL_POOL_CAP=50
DRVKB_RECALL_WORKERS=6
```

## 4. Dataset Lane

以 diagnosis 为例：

```text
Case Lane
  cases
  query = raw + engineering + symptom

Reference Lane
  tech_notes + manuals + project_docs
  query = raw + engineering

Fallback Lane
  docs
  仅主候选不足时触发
```

目的不是把 Dataset 永久隔离，而是避免通用资料在第一轮与历史案例平权竞争。

## 5. Engineering Rerank

V1.0.4 不再只依赖 module/chip/status Metadata。

当前评分因素包括：

| 因素 | 目的 |
|---|---|
| RAGFlow semantic similarity | 保留向量/混合检索主体能力 |
| Exact entity match | 芯片、PHY、RGMII 等实体 |
| Symptom match | Link Up、无流量、丢包、Probe 失败等工程现象 |
| Title match | 让标题直接命中的案例优先 |
| Module/Chip/Platform/Project | 工程上下文约束 |
| Material priority | diagnosis 优先 cases，开发优先 manuals/tech notes |
| Status/Quality | verified/approved/reviewed 优先 |
| Multi-query consensus / RRF | 多个 Query 同时命中的候选适当加分 |
| Source URL | 有可靠原文链接的正式知识优先 |

所有机器评分仍保存在 `trace.score_breakdown`，但不再作为默认用户描述。

## 6. Document-level 去重

RAGFlow 返回的是 chunk。V1.0.4 按以下优先级归并为文档：

```text
source_key
  → page_id
  → page_url
  → document_id
```

最终 Top-K 默认不会出现同一个 BookStack 页面占用 2~3 个位置。

被归并的 chunk 保存在：

```text
supporting_chunks
supporting_chunk_count
```

Evidence Extractor 可以综合这些证据，而不是只看最佳 chunk。

## 7. 工程描述优化

旧实现：

```text
summary = chunk 前 220 字
reason  = base similarity + module match + ...
```

V1.0.4 改为从原始知识文本抽取：

```yaml
engineering_summary:
  overview: "..."
  symptom: "..."
  root_cause: "..."
  solution: "..."
  verification: "..."
```

优先识别 Markdown 标题：

- 问题现象 / 问题描述 / 现象
- 根因 / 原因分析
- 解决方案 / 处理方案 / 修复方案
- 验证 / 测试结果 / 回归结果

历史文章没有标准标题时，只对“最终定位… / 根因是… / 修正…后恢复”等**原文明确陈述**做保守提取；不存在的信息保持为空，不能由 AI/规则编造。

用户默认看到的 `reason` 改为：

```text
实体匹配：RTL8367S、PHY
现象匹配：PHY Link Up、无流量
来源类型：历史案例
```

## 8. 原文链接硬契约

这是 V1.0.4 的强制约束：

> **所有公开 Top-K Recall item 必须包含可点击 HTTP(S) 来源链接。**

解析优先级：

```text
page_url
  → source_url
  → historical original_url + BookStack alias rewrite
  → BOOKSTACK_PAGE_URL_TEMPLATE（仅站点明确提供 ID redirect 时）
```

重要边界：标准 BookStack Web URL 包含 book/page slug，**不能仅凭 page_id 安全构造**。V1.0.4 不伪造 `/api/pages/{id}` 为“原文页面”，也不会因此对 BookStack 发同步查询。

缺失链接的候选：

- 仍保留在内部 rerank/trace，便于治理；
- 默认从公开 Top-K 排除；
- `knowledge_bundle.source_integrity` 统计数量；
- `knowledge_bundle.governance_issues` 输出 `missing_source_link` 告警。

因此只要 `knowledge_bundle.items` 非空，其 `source_url_rate` 为 100%。

新知识在 Ingestion 提交 BookStack 后已经通过 `inject_page_identity()` 写回：

```yaml
bookstack_page_id: ...
page_id: ...
page_url: ...
source_url: ...
source_key: bookstack:page:...
```

历史知识应通过治理逐步补齐来源 Metadata。

## 9. Knowledge Bundle V3

新增/强化字段：

```text
contract_version = knowledge-bundle-v3
items[].page_url
items[].source_key
items[].reason
items[].engineering_summary
items[].matched_entities
items[].matched_symptoms
items[].supporting_chunks
items[].query_hits
items[].lane_hits
source_integrity
governance_issues
```

## 10. Benchmark

Evaluator 现在除旧 Top-3/Top-5 指标外，增加：

```text
Recall@1
MRR@5
Document Duplicate Rate
Source URL Rate
p50 latency
p95 latency
```

`resources/drvkb/tests/recall/live-recall-testset.template.json` 提供真实库评测模板。正式效果结论必须基于你们现场真实问题和明确 BookStack `source_key/page_url` 标注，不使用 fixture 成绩代替 Live 效果。

## 11. 本次 Review 结论

实现层已经完成此前讨论的六个核心改动：

1. Query Expansion 真正执行；
2. Case/Reference 分 Lane 并行召回；
3. 候选池扩大；
4. 工程语义重排；
5. Document 级去重；
6. 结构化工程描述 + 原文链接硬契约。

V1.0.4 后续最重要的工作不应继续盲调固定权重，而是用现场 30~50 个真实问题建立 Live Benchmark，根据 Recall@1/3/5、MRR、无关结果率和 p95 延迟逐步调优。

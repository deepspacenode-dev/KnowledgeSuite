# Drv Knowledge Suite V1.0.8 详细设计

## 1. 设计目标

V1.0.8 面向受控内网 CodeBuddy/嵌入式驱动研发环境，目标是同时提供**默认无 pip 的轻量知识获取**与**显式可选、先检查后补缺的全量知识入库**。

当前发行包含两种安装边界：

```text
retrieval = Router + Retrieval + Shared Core
full      = Router + Retrieval + Ingestion + Shared Core
```

知识入库、PDF/DOCX/PPTX 转换等能力只在显式 full Profile 中部署，不改变普通检索客户端的默认行为。

## 2. 总体架构

```text
CodeBuddy / kb
      │
      ▼
drv-knowledge-router
      │
      ▼
drv-knowledge-retrieval
      │
      ├──────────────┬─────────────────┐
      ▼              ▼                 ▼
   RAGFlow        BookStack       Local Manuals
语义候选召回      原文/目录         Markdown stdlib index
      │              │                 │
      └──────────────┴─────────────────┘
                     │
                     ▼
                  Recall V3
                     │
            Engineering Rerank
                     │
              Document Dedup
                     │
             Knowledge Bundle V3
```

### 2.1 数据源职责

- **RAGFlow**：案例、技术专题、项目资料和已正常入库手册的语义检索。
- **BookStack**：权威原文、页面 URL、目录与治理入口。
- **Local Manuals**：仅用于芯片/平台 Markdown 手册，在 RAGFlow 手册解析不可用时提供独立召回通道。

其他知识域不改成本地文件检索。

full Profile 时 Router 还可分流到 Ingestion；Ingestion 负责异构格式生产、Canonical Markdown、Preview 和受控 BookStack 提交，不参与 Retrieval 的正常查询路径。

## 3. 目录设计

```text
drv-knowledge-suite-v1.0.8/
├── README.md
├── VERSION
├── install.sh                  # Linux 正式入口
├── install.cmd / install.py    # Windows/兼容入口
├── PACKAGE_MANIFEST.txt
├── config/
├── commands/kb/         # 源包 12 个；retrieval 安装时去掉 ingest.md 后为 11 个
├── manuals/                    # 芯片 Markdown 内容注入区
│   ├── README.md
│   ├── 01_主控SoC与平台芯片/
│   ├── 02_网络与通信芯片/
│   ├── 03_单片机与协处理器/
│   └── 04_外设扩展与控制芯片/
├── skills/
│   ├── drv-knowledge-router/
│   ├── drv-knowledge-retrieval/
│   └── drv-knowledge-ingestion/
├── requirements/               # retrieval + full required package declarations (no bundles)
├── lib/drv_knowledge_core/
├── tools/
├── docs/
└── tests/
```

`manuals/` 是 **content injection zone**。发布后可直接添加 `.md/.markdown/.txt`，这些新增内容无需修改 `PACKAGE_MANIFEST.txt`。

## 4. Router 设计

Router 提供唯一公开 CLI `kb` 和自然语言意图路由。

支持：

```text
kb doctor / status / cases / manuals / search / recall / gaps / graph / where / bootstrap
```

Router 根据 DRVKB_INSTALL_PROFILE 和 Ingestion Skill 是否存在决定路由。retrieval 下“入库/提交/导入”返回 `ingestion_not_installed`；full 下同类意图路由到 Ingestion。

## 5. Retrieval 设计

### 5.1 Knowledge Catalog

Catalog 记录语义域与 RAGFlow Dataset/BookStack 来源关系。核心域：

```text
cases / manuals / tech_notes / project_docs / docs
```

本地手册不取代 `manuals` 逻辑域，而是作为 `manuals` 的第二数据源：

```text
manuals = RAGFlow manuals + local_manuals
```

### 5.2 Browse

`kb cases` 保持原 RAGFlow/BookStack Browse。

`kb manuals` 使用 Hybrid Browse：

```text
RAGFlow manuals
      +
Local Markdown index
      ↓
merge / filter / output
```

本地手册项返回：

```text
source_kind=local_manual
local_path
relative_path
page_url
```

## 6. Local Manuals 详细设计

### 6.1 Runtime 路径

安装时：

```text
<release>/manuals/
       ↓ merge
~/.drvknowledge/manuals/
```

安装后也可以直接维护 Runtime，不需要重新安装 Suite。

配置：

```env
DRVKB_LOCAL_MANUALS_ENABLED=true
DRVKB_LOCAL_MANUALS_DIR=
DRVKB_LOCAL_MANUAL_CHUNK_CHARS=1800
```

`DRVKB_LOCAL_MANUALS_DIR` 为空时使用 `~/.drvknowledge/manuals/`。

### 6.2 依赖

实现只使用 Python 3.10+ 标准库：

```text
pathlib / re / json / gzip / hashlib / urllib
```

不需要 Markdown parser、PyMuPDF 或向量数据库。

### 6.3 Index

索引缓存：

```text
~/.drvknowledge/cache/local_manuals_index.json.gz
```

索引签名由以下信息组成：

```text
relative_path + file_size + mtime_ns
```

文件变化后自动重建；`kb manuals --refresh` 强制重建。

### 6.4 Chunk

优先按 Markdown Heading 切分：

```text
# / ## / ### ...
```

过长 Section 再按段落切分，默认目标 1800 字符。

每个 Chunk 保存：

```text
title / heading / content
relative_path / local_path
line_start / line_end
chip / platform / module
page_url
```

### 6.5 Search

Local Manual Search 使用工程关键词、标题、路径、Heading、正文的加权匹配，不依赖第三方 embedding。

Query 来源直接复用 Recall V3 normalizer 的：

```text
raw / engineering / symptom
```

所以 `RTL8367S PHY link up 无流量 RGMII delay` 可以同时命中芯片名、RGMII、PHY、Link 等手册内容。

## 7. Recall V3

### 7.1 Query Understanding

```text
raw query
engineering query
symptom query
```

同时识别：task_type、module、chip、platform、project、symptoms、engineering entities。

### 7.2 RAGFlow Lane

典型 diagnosis：

```text
Case Lane      → cases
Reference Lane → tech_notes / manuals / project_docs
Fallback       → docs
```

### 7.3 Local Manual Lane

非 fixture 模式下，本地手册候选加入同一个 Candidate Pool：

```text
RAGFlow candidates
       +
Local manual candidates
       ↓
Engineering Rerank
```

因此 RAGFlow `drvdocs_ai_manuals` 为 0 并不阻止本地手册进入 Top-K。

若 RAGFlow 调用失败但本地手册产生有效结果，Knowledge Status 可为 `degraded`，但结果仍可返回。

### 7.4 Engineering Rerank

排序综合：

- RAGFlow/local semantic confidence；
- engineering entity match；
- symptom match；
- title match；
- module/chip/platform/project；
- material priority；
- multi-query consensus；
- source link availability。

### 7.5 Document Dedup

同一知识文档多个 Chunk 不重复占用 Top-K。Local manual 使用相对路径构造稳定 `source_key`：

```text
local_manual:<relative_path>
```

## 8. 工程描述输出

Knowledge Bundle V3 对结果抽取：

```text
overview
symptom
root_cause
solution
verification
```

只依据实际命中的原文内容提取，不把 AI 推断伪装成已确认根因。

## 9. 原文链接契约

### 9.1 RAGFlow/BookStack

优先：

```text
page_url → source_url → original_url rewrite
```

正常 Recall 不为了获取链接逐条访问 BookStack。

### 9.2 Local Manual

优先：

```text
Front Matter HTTP(S) page_url/source_url/original_url
        ↓ 没有
file:// URI + local_path
```

因此每个公开结果仍具备可定位原文的来源。

## 10. 安装设计

Linux 正式入口：

```bash
./install.sh
```

默认是 retrieval；显式 `--full` 或 `--profile full` 启用全量模式。不恢复 standard Profile。

流程：

```text
Platform/Manifest
 → dependency environment probe
 → retrieval: no format-plugin gate
 → full: 6/6 required; missing any item exits 20
 → shared env safe merge
 → manuals merge
 → stage selected Skills/Core/Commands
 → pre-commit doctor
 → transactional switch
 → post-install doctor
 → optional live check/bootstrap
```

V1.0.8 的安装器在 retrieval/full 两种模式都不执行 pip。full 只检查 6 个必需插件；缺失时在组件切换前失败。依赖由管理员在目标环境预先准备。

## 11. 升级与回滚

升级场景必须优先加载 staged Core，禁止旧 `~/.codebuddy/lib` 覆盖新 Core。

安装失败时恢复：

- Router / Retrieval / 可选 Ingestion；
- Shared Core；
- CodeBuddy Commands；
- `kb` CLI；
- `.env`。

切换到 retrieval 时旧 Ingestion Skill 会移入备份；full 时则安装当前版本 Ingestion。

## 12. 安全设计

- `.env` 权限 0600；
- 安装日志仅输出脱敏 token；
- Release 包不内置真实凭证；
- PACKAGE_MANIFEST 校验程序文件；
- 用户新增手册是显式内容区，不纳入程序 Manifest；
- 本地手册解析不执行 Markdown 内容，只读取文本。

## 13. 可观测性

```text
kb doctor
kb doctor --live
kb status
kb where manuals
kb bootstrap
```

Doctor 输出 Local Manuals：root、document count、index 状态，并区分本地安装就绪与 Live 服务状态。

## 14. 验收重点

```text
./install.sh                         retrieval 成功 / 11 个 /kb:* 命令
./install.sh --full                  full 成功 / 12 个 /kb:* 命令
full 依赖已齐全                     6/6 PASS，继续安装
full 缺任一项                       exit 20，Suite 组件不切换
kb doctor                            LOCAL READY
kb manuals --refresh                能看到本地手册
kb manuals RTL8367S                  命中 RTL8367S Markdown
kb recall -q "..."                  Local Manual 可进入 Recall V3 Top-K
每条公开结果                         有 HTTP(S) 或 file:// 来源
RAGFlow manuals=0                    不影响本地手册召回
旧版本升级                           staged Core 优先
retrieval 安装器                     无 pip
```

## 15. 当前边界

retrieval 的本地手册方案仍只处理已转成 Markdown/TXT 的芯片/平台手册。PDF OCR、PDF 表格恢复或 DOCX/PPTX 解析由 full Profile 的专用 Ingestion 环境承担，再产出 Markdown 给本地手册库或 BookStack/RAGFlow。

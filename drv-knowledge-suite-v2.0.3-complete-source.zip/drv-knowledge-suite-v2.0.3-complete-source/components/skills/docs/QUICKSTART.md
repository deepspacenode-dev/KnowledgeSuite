# Skills/CLI V2.0.3 Quickstart

## 默认安装

```bash
chmod +x install.sh
./install.sh
```

安装后常用：

```bash
kb doctor
kb doctor --live
kb cases
kb manuals RTL8367S
kb search -q "VLAN ACL"
kb recall -q "RTL8367S 无流量"
```

CodeBuddy 对应：

```text
/kb:cases
/kb:manuals
/kb:search
/kb:recall
/kb:status
/kb:where
/kb:gaps
/kb:graph
/kb:bootstrap
/kb:doctor
/kb:help
```

## RAGFlow 已迁移

把新地址和 Key 写入发行包外的私有 `ragflow-site.env`，然后显式迁移：

```bash
./install.sh --migrate-ragflow --site-config ../ragflow-site.env
kb doctor --live --json
```

已有 full 安装使用 `./install.sh --full --migrate-ragflow ...`。迁移不会覆盖 BookStack、Governance、本地手册、入库会话或 SQLite outbox。完整说明见 `docs/RAGFLOW_MIGRATION_V2.0.1.md`。

## 入库环境

管理员预先准备 6 个必需插件后：

```bash
./install.sh --full
```

full 成功后增加 `/kb:ingest`：

```text
/kb:ingest analyze file.docx
/kb:ingest import file.docx
/kb:ingest preview SESSION
/kb:ingest submit SESSION
/kb:ingest status SESSION
/kb:ingest experience
/kb:ingest manual chip.pdf
/kb:ingest sanitize-manual chip.md output/chip
```

项目包不会下载或安装这些插件。缺失时安装器直接报告并退出 20。

## 超长 Markdown 芯片手册

超过 2 MiB、图片超过 100 个、包含内网/相对图片、超长表格或单行超过 2,200
字符时，不要直接上传 RAGFlow：

```bash
drvki sanitize-manual chip.md output/chip
```

仅把 `output/chip/ragflow/part-*.md` 上传 RAGFlow，并对每个文档应用
`sanitized-chip-manual-v1`。原文、BookStack 清洗版、图片清单和审计报告都会保留。
完整规则见项目级 `docs/RAGFLOW_MANUAL_SANITIZATION_V1.md`。

## 开发者入口

```bash
./install.sh --developer
./install.sh --full --developer
```

前者额外安装 `drvkr`，后者额外安装 `drvkr` + `drvki`。普通用户无需使用。

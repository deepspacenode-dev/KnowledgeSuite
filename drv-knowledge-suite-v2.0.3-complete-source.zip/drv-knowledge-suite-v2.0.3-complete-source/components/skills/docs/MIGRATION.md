# Skills/CLI Migration

## V2.0.1：RAGFlow 服务器迁移

普通升级继续保留已有非空配置。只有显式执行以下命令时才替换 RAGFlow 站点：

```bash
bash install.sh --migrate-ragflow --site-config ../ragflow-site.env
```

Windows/Python 安装入口使用相同规则：

```text
python install.py --migrate-ragflow --site-config ..\ragflow-site.env
```

迁移文件必须提供新的 `RAGFLOW_BASE_URL` 与 `RAGFLOW_API_KEY`。迁移器会保留 BookStack、Governance、安装 profile、超时参数和用户自定义配置；清空旧数据集 ID 后按 `drvdocs_ai_*` 名称重新发现。详细边界见 [RAGFlow V2.0.1 迁移说明](RAGFLOW_MIGRATION_V2.0.1.md)。

# V1.0.8 Migration

## 从 V1.0.7 升级

直接执行：

```bash
./install.sh
```

若服务器已经满足 6 个入库插件并需要 Ingestion：

```bash
./install.sh --full
```

## 命令命名迁移

正式命名空间从 `/knowledge:*` 改为 `/kb:*`：

```text
/knowledge:cases     → /kb:cases
/knowledge:query     → /kb:search
/knowledge:manual    → /kb:ingest manual
/knowledge:ingest-preview → /kb:ingest preview
/knowledge:ingest-submit  → /kb:ingest submit
/knowledge:ingest-status  → /kb:ingest status
/knowledge:ingest-experience → /kb:ingest experience
```

Router 在 V1.0.8 暂时兼容旧格式并给出弃用提醒。

## 安全清理旧命令

升级不会直接删除整个 `~/.codebuddy/commands/knowledge/`。安装器仅删除 Drv Knowledge Suite 历史发布过的已知文件名，用户自行添加的文件保持不变。

新命令安装到：

```text
~/.codebuddy/commands/kb/
```

## 依赖策略变化

V1.0.7 的依赖自动补装/离线 Wheelhouse 逻辑已移除。V1.0.8 full 模式只检查 6 个必需插件；项目不携带 Wheel，不执行 pip。

@echo off
python "%~dp0drvkr.py" %*

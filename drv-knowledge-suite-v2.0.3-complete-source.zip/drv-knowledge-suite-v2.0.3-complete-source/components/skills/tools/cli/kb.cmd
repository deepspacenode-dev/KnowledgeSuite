@echo off
python "%~dp0kb.py" %*

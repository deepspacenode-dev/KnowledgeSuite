@echo off
python "%~dp0drvki.py" %*

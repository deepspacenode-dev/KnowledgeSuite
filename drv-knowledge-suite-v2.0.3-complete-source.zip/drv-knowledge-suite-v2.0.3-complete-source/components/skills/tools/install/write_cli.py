#!/usr/bin/env python3
"""Generate launchers bound to the selected interpreter and runtime directory."""
from __future__ import annotations

import argparse
import os
import shlex
import sys
from pathlib import Path


def write_cli(bin_dir:Path, target:Path, runtime:Path, profile:str, developer:bool, python:str|None=None)->list[str]:
    bin_dir.mkdir(parents=True,exist_ok=True)
    # Do not resolve symlinks: resolving a virtualenv interpreter can lose its environment.
    executable=os.path.abspath(python or sys.executable)
    entries={"kb":target/"skills/drv-knowledge-router/scripts/router_cli.py"}
    if developer:
        entries["drvkr"]=target/"skills/drv-knowledge-retrieval/scripts/drvkb_entry.py"
        if profile=="full": entries["drvki"]=target/"skills/drv-knowledge-ingestion/scripts/ingest_cli.py"
    installed=[]
    for name,entry in entries.items():
        launcher=bin_dir/name
        launcher.write_text(
            '#!/bin/sh\n'
            'if [ -z "${DRVKB_RUNTIME_DIR:-}" ]; then\n'
            f'  DRVKB_RUNTIME_DIR={shlex.quote(str(runtime))}\nfi\n'
            'export DRVKB_RUNTIME_DIR\n'
            'if [ -z "${DRVKB_ENV_FILE:-}" ]; then DRVKB_ENV_FILE="$DRVKB_RUNTIME_DIR/.env"; fi\n'
            'export DRVKB_ENV_FILE\n'
            f'exec {shlex.quote(executable)} {shlex.quote(str(entry))} "$@"\n',encoding="utf-8")
        launcher.chmod(0o755)
        batch=bin_dir/(name+".cmd")
        batch.write_text(
            '@echo off\nsetlocal\n'
            f'if not defined DRVKB_RUNTIME_DIR set "DRVKB_RUNTIME_DIR={str(runtime).replace("%", "%%")}"\n'
            'if not defined DRVKB_ENV_FILE set "DRVKB_ENV_FILE=%DRVKB_RUNTIME_DIR%\\.env"\n'
            f'"{executable.replace("%", "%%")}" "{str(entry).replace("%", "%%")}" %*\n',
            encoding="utf-8",newline="\r\n")
        installed.extend([str(launcher),str(batch)])
    return installed


def main()->None:
    parser=argparse.ArgumentParser()
    parser.add_argument("--target",type=Path,required=True)
    parser.add_argument("--runtime",type=Path,required=True)
    parser.add_argument("--bin-dir",type=Path,required=True)
    parser.add_argument("--profile",choices=("retrieval","full"),default="retrieval")
    parser.add_argument("--developer",action="store_true")
    args=parser.parse_args()
    write_cli(args.bin_dir.resolve(),args.target.resolve(),args.runtime.resolve(),args.profile,args.developer)


if __name__=="__main__": main()

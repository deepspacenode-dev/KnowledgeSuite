#!/usr/bin/env python3
"""Safe .env migration/merge helper for Drv Knowledge Suite.

Never sources shell syntax. Existing shared values win unless an explicit
RAGFlow migration selects a new site. Other V2 service settings are preserved.
Priority for missing keys:
  existing shared env > site config > legacy skill env/json > current process env > template defaults
"""
from __future__ import annotations
import argparse, json, os, re, shutil, tempfile, time
from pathlib import Path
from urllib.parse import urlsplit

SECRET_HINTS=("KEY","TOKEN","SECRET","COOKIE","PASSWORD","PASSWD")
RAGFLOW_PATH_KEYS=("RAGFLOW_RETRIEVAL_PATH", "RAGFLOW_DATASETS_PATH", "RAGFLOW_DOCUMENTS_PATH", "RAGFLOW_CHUNKS_PATH")
RAGFLOW_ID_KEYS=("RAGFLOW_DATASET_IDS", "RAGFLOW_DATASET_NAMES_JSON", *(
    "RAGFLOW_DATASET_ID_"+name for name in ("CASES", "MANUALS", "TECH_NOTES", "PROJECT_DOCS", "DOCS")))


def parse_env(path:Path)->dict[str,str]:
    out={}
    if not path.is_file(): return out
    for raw in path.read_text(encoding="utf-8",errors="ignore").splitlines():
        line=raw.strip()
        if not line or line.startswith("#") or "=" not in line: continue
        key,val=line.split("=",1); key=key.strip(); val=val.strip()
        if not key: continue
        if len(val)>=2 and val[0] in "\"'" and val[-1]==val[0]:
            val=val[1:-1]
        out[key]=val
    return out


def legacy_ragflow_config(path:Path)->dict[str,str]:
    if not path.is_file(): return {}
    try: obj=json.loads(path.read_text(encoding="utf-8"))
    except Exception: return {}
    out={}
    if obj.get("base_url"): out["RAGFLOW_BASE_URL"]=str(obj["base_url"])
    if obj.get("api_key"): out["RAGFLOW_API_KEY"]=str(obj["api_key"])
    if obj.get("timeout"): out["RAGFLOW_TIMEOUT"]=str(obj["timeout"])
    logical={"cases":"CASES","manuals":"MANUALS","tech_notes":"TECH_NOTES","project_docs":"PROJECT_DOCS","docs":"DOCS"}
    ids=obj.get("dataset_ids") or {}; names=obj.get("dataset_names") or {}
    if isinstance(ids,dict):
        for k,suffix in logical.items():
            if ids.get(k): out[f"RAGFLOW_DATASET_ID_{suffix}"]=str(ids[k])
    elif isinstance(ids,list) and isinstance(names,dict):
        for did in ids:
            name=str(names.get(did) or "")
            for k,suffix in logical.items():
                if k in name: out[f"RAGFLOW_DATASET_ID_{suffix}"]=str(did)
    all_names=" ".join(str(x) for x in (names.values() if isinstance(names,dict) else []))
    if "drvdocs_ai_" in all_names: out["DRVKB_DATASET_PROFILE"]="drvdocs"
    elif "bookstack_ai_" in all_names: out["DRVKB_DATASET_PROFILE"]="bookstack"
    return out


def template_keys(path:Path)->list[str]:
    return list(parse_env(path).keys())


def merged_values(existing:dict[str,str], site:dict[str,str], legacy:dict[str,str], environ:dict[str,str], template:dict[str,str], profile:str)->dict[str,str]:
    keys=[]
    for source in (template,site,legacy,environ,existing):
        for k in source:
            if k not in keys: keys.append(k)
    out={}
    for k in keys:
        for src in (existing,site,legacy,environ,template):
            v=src.get(k)
            if v not in (None,""):
                out[k]=v; break
        else:
            out[k]=""
    out["DRVKB_INSTALL_PROFILE"]=profile
    return out


def migrate_ragflow(values:dict[str,str], site:dict[str,str], template:dict[str,str])->None:
    """Replace only RAGFlow-scoped settings across an explicit site migration."""
    for key in RAGFLOW_ID_KEYS:
        values[key]=site.get(key, "")
    for key in RAGFLOW_PATH_KEYS:
        values[key]=site.get(key) or template.get(key, "")
    for key,value in site.items():
        if key.startswith("RAGFLOW_"):
            values[key]=value
    values["DRVKB_DATASET_PROFILE"]=site.get("DRVKB_DATASET_PROFILE") or "drvdocs"


def normalize_ragflow_url(value:str)->str:
    value=value.strip().rstrip("/")
    if value.endswith("/api/v1"):
        value=value[:-len("/api/v1")]
    return value


def write_shared_env(envfile:Path, content:str, *, backup:bool)->str|None:
    envfile.parent.mkdir(parents=True,exist_ok=True)
    backup_path=None
    if backup and envfile.is_file():
        directory=envfile.parent/"backups"
        directory.mkdir(parents=True,exist_ok=True)
        path=directory/f"before-ragflow-migration-{time.time_ns()}.env"
        with path.open("xb") as stream:
            os.chmod(path,0o600)
            stream.write(envfile.read_bytes())
        backup_path=str(path)
    with tempfile.NamedTemporaryFile(mode="w",encoding="utf-8",dir=envfile.parent,prefix=".env-",delete=False) as stream:
        temporary=Path(stream.name)
        try:
            os.chmod(temporary,0o600)
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    try:
        os.replace(temporary,envfile)
    finally:
        temporary.unlink(missing_ok=True)
    return backup_path


def invalidate_ragflow_cache(runtime:Path)->list[str]:
    """Remove only derived remote caches, never local manuals or intake state."""
    removed=[]
    for path in (runtime/"knowledge_catalog.json",runtime/"cache"/"browse"):
        if path.is_symlink() or path.is_file(): path.unlink()
        elif path.is_dir(): shutil.rmtree(path)
        else: continue
        removed.append(str(path))
    return removed


def render(template_path:Path, values:dict[str,str])->str:
    base=template_path.read_text(encoding="utf-8") if template_path.is_file() else ""
    seen=set(); lines=[]
    for raw in base.splitlines():
        if raw.lstrip().startswith("#") or "=" not in raw:
            lines.append(raw); continue
        k=raw.split("=",1)[0].strip()
        if k in values:
            lines.append(f"{k}={values[k]}"); seen.add(k)
        else: lines.append(raw)
    for k,v in values.items():
        if k not in seen: lines.append(f"{k}={v}")
    return "\n".join(lines).rstrip()+"\n"


def redact(k:str,v:str)->str:
    if not v: return "<empty>"
    if any(h in k.upper() for h in SECRET_HINTS):
        return "configured:"+("****"+v[-4:] if len(v)>4 else "****")
    return v


def validate(values:dict[str,str])->dict:
    problems=[]; warnings=[]
    profile=values.get("DRVKB_INSTALL_PROFILE","retrieval")
    if profile not in {"retrieval","full"}: problems.append("DRVKB_INSTALL_PROFILE must be retrieval|full")
    if values.get("DRVKB_DATASET_PROFILE") not in {"bookstack","drvdocs"}: problems.append("DRVKB_DATASET_PROFILE must be bookstack|drvdocs")
    if values.get("RAGFLOW_BASE_URL") and not re.match(r"^https?://",values["RAGFLOW_BASE_URL"]): problems.append("RAGFLOW_BASE_URL must be http(s) URL")
    if values.get("RAGFLOW_BASE_URL"):
        try:
            url=urlsplit(values["RAGFLOW_BASE_URL"])
            if not url.hostname or url.username or url.password or url.query or url.fragment:
                problems.append("RAGFLOW_BASE_URL must be a host URL without credentials, query or fragment")
            url.port
        except ValueError:
            problems.append("RAGFLOW_BASE_URL is invalid")
    if values.get("BOOKSTACK_BASE_URL") and not re.match(r"^https?://",values["BOOKSTACK_BASE_URL"]): problems.append("BOOKSTACK_BASE_URL must be http(s) URL")
    if values.get("RAGFLOW_API_KEY") and not values.get("RAGFLOW_BASE_URL"):
        problems.append("RAGFLOW_API_KEY requires RAGFLOW_BASE_URL")
    if values.get("RAGFLOW_BASE_URL") and not values.get("RAGFLOW_API_KEY"):
        warnings.append("RAGFlow endpoint is staged; live retrieval remains disabled until RAGFLOW_API_KEY is configured")
    bs_fields=[values.get("BOOKSTACK_BASE_URL"),values.get("BOOKSTACK_TOKEN_ID"),values.get("BOOKSTACK_TOKEN_SECRET")]
    if any(bs_fields) and not all(bs_fields): problems.append("BookStack BASE_URL/TOKEN_ID/TOKEN_SECRET must be configured together")
    if not all(bs_fields): warnings.append("BookStack live write/browse is not fully configured")
    if not values.get("RAGFLOW_BASE_URL"): warnings.append("RAGFlow live retrieval is not configured")
    return {"ok":not problems,"problems":problems,"warnings":warnings,"profile":profile}


def collect_legacy(target:Path)->dict[str,str]:
    out={}
    candidates=[
        target/"skills"/"drv-knowledge"/".env",
        target/"skills"/"drv-knowledge-retrieval"/".env",
        target/"skills"/"drv-knowledge-ingest"/".env",
        target/"skills"/"drv-knowledge-ingestion"/".env",
    ]
    for p in candidates:
        for k,v in parse_env(p).items(): out.setdefault(k,v)
    cfgs=[target/"skills"/"rag-search"/"config.json",target/"skills"/"rag-search.bak"/"config.json"]
    for p in cfgs:
        for k,v in legacy_ragflow_config(p).items(): out.setdefault(k,v)
    return out


def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--runtime",required=True)
    ap.add_argument("--target",required=True)
    ap.add_argument("--template",required=True)
    ap.add_argument("--site-config")
    ap.add_argument("--migrate-ragflow",action="store_true",help="replace RAGFlow site credentials, reset old dataset IDs and invalidate remote caches")
    ap.add_argument("--profile",choices=["retrieval","full"],default="retrieval")
    ap.add_argument("--write",action="store_true")
    ap.add_argument("--show-redacted",action="store_true")
    ap.add_argument("--json",action="store_true")
    args=ap.parse_args()
    runtime=Path(args.runtime).expanduser(); target=Path(args.target).expanduser(); template=Path(args.template)
    envfile=runtime/".env"
    existed=envfile.exists()
    existing=parse_env(envfile)
    sitepath=Path(args.site_config).expanduser() if args.site_config else None
    site=parse_env(sitepath) if sitepath else {}
    legacy=collect_legacy(target)
    envkeys=set(parse_env(template).keys()) | set(site) | set(legacy) | set(existing)
    environ={k:os.environ.get(k,"") for k in envkeys if os.environ.get(k) is not None}
    defaults=parse_env(template)
    values=merged_values(existing,site,legacy,environ,defaults,args.profile)
    if args.migrate_ragflow:
        migrate_ragflow(values,site,defaults)
    values["RAGFLOW_BASE_URL"]=normalize_ragflow_url(values.get("RAGFLOW_BASE_URL",""))
    report=validate(values)
    if sitepath and not sitepath.is_file(): report["problems"].append("--site-config file does not exist")
    if args.migrate_ragflow and not all(site.get(key) for key in ("RAGFLOW_BASE_URL","RAGFLOW_API_KEY")):
        report["problems"].append("--migrate-ragflow requires --site-config with the NEW RAGFLOW_BASE_URL and RAGFLOW_API_KEY")
    report["ok"]=not report["problems"]
    conflicts=sorted(key for key in values if (key.startswith("RAGFLOW_") or key=="DRVKB_DATASET_PROFILE")
                     and key in os.environ and os.environ[key]!=values[key])
    if conflicts:
        report["warnings"].append("Current shell exports override runtime configuration; unset or update: "+", ".join(conflicts))
    written=bool(args.write and report["ok"])
    backup_path=None; removed=[]
    if written:
        backup_path=write_shared_env(envfile,render(template,values),backup=args.migrate_ragflow)
        if args.migrate_ragflow: removed=invalidate_ragflow_cache(runtime)
    result={"path":str(envfile),"exists_before":existed,"written":written,"validation":report,
            "ragflow_migration":args.migrate_ragflow,"backup_path":backup_path,"invalidated_caches":removed,
            "sources":{"existing":len(existing),"site":len(site),"legacy":len(legacy),"environment":len(environ)}}
    if args.show_redacted: result["values"]={k:redact(k,v) for k,v in sorted(values.items())}
    print(json.dumps(result,ensure_ascii=False,indent=2) if args.json or True else result)
    return 0 if report["ok"] else 30

if __name__=="__main__": raise SystemExit(main())

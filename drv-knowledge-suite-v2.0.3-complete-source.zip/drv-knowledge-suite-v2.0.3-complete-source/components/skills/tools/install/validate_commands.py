#!/usr/bin/env python3
"""Validate CodeBuddy /kb:* command definitions."""
from __future__ import annotations
import argparse, json, re
from pathlib import Path

KNOWN_ROOT={"cases","manuals","search","recall","status","gaps","where","graph","bootstrap","doctor","ingest","help"}


def parse_frontmatter(text:str):
    if not text.startswith("---\n"): return {}
    end=text.find("\n---",4)
    if end<0: return {}
    out={}
    for line in text[4:end].splitlines():
        if ":" in line:
            k,v=line.split(":",1); out[k.strip()]=v.strip()
    return out


def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("--expected",type=int,default=12); a=ap.parse_args()
    root=Path(a.path); files=sorted(root.glob("*.md")) if root.is_dir() else []
    names={}; errors=[]; refs=[]
    for p in files:
        text=p.read_text(encoding="utf-8",errors="ignore"); fm=parse_frontmatter(text); name=fm.get("name","")
        if not name.startswith("kb:"): errors.append(f"{p.name}: missing/invalid frontmatter name")
        if name in names: errors.append(f"duplicate command name: {name}")
        names[name]=p.name
        for cmd in re.findall(r"`(kb\s+[^`\n]+)`",text):
            parts=cmd.split(); rootcmd=parts[1] if len(parts)>1 else ""
            refs.append({"file":p.name,"command":cmd,"root":rootcmd})
            if rootcmd not in KNOWN_ROOT: errors.append(f"{p.name}: references unknown kb root command {rootcmd!r}")
    if len(files)!=a.expected: errors.append(f"expected {a.expected} command files, found {len(files)}")
    result={"ok":not errors,"count":len(files),"expected":a.expected,"names":sorted(names),"references":refs,"errors":errors}
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0 if result["ok"] else 40


if __name__=="__main__": raise SystemExit(main())

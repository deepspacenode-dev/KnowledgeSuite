#!/usr/bin/env python3
"""Check mandatory knowledge-ingestion dependencies. Never installs packages."""
from __future__ import annotations

import argparse
import importlib.metadata
import importlib.util
import json
import platform
import sys

DEPENDENCIES = {
    "beautifulsoup4": {"import": "bs4", "requirement": "beautifulsoup4==4.14.3"},
    "python-docx": {"import": "docx", "requirement": "python-docx==1.2.0"},
    "python-pptx": {"import": "pptx", "requirement": "python-pptx==1.0.2"},
    "PyMuPDF": {"import": "fitz", "requirement": "PyMuPDF==1.26.7"},
    "pdfplumber": {"import": "pdfplumber", "requirement": "pdfplumber==0.11.7"},
    "Pillow": {"import": "PIL", "requirement": "Pillow==11.3.0"},
}


def required(profile: str) -> list[str]:
    return list(DEPENDENCIES) if profile == "full" else []


def probe(profile: str) -> tuple[dict[str, dict], list[str]]:
    rows: dict[str, dict] = {}
    missing: list[str] = []
    required_packages = set(required(profile))
    for package, spec in DEPENDENCIES.items():
        installed = importlib.util.find_spec(spec["import"]) is not None
        version = None
        if installed:
            try:
                version = importlib.metadata.version(package)
            except importlib.metadata.PackageNotFoundError:
                version = "unknown"
        is_required = package in required_packages
        rows[package] = {
            "import": spec["import"],
            "requirement": spec["requirement"],
            "required": is_required,
            "installed": installed,
            "version": version,
            "action": "ready" if installed and is_required else ("missing" if is_required else "not_required"),
        }
        if is_required and not installed:
            missing.append(package)
    return rows, missing


def main() -> int:
    parser = argparse.ArgumentParser(description="Check Drv Knowledge Suite ingestion dependencies")
    parser.add_argument("--profile", choices=["retrieval", "full"], default="retrieval")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    rows, missing = probe(args.profile)
    result = {
        "ok": not missing,
        "profile": args.profile,
        "environment": {
            "python": platform.python_version(),
            "implementation": platform.python_implementation(),
            "os": platform.system(),
            "platform": platform.platform(),
            "arch": platform.machine(),
            "python_supported": sys.version_info >= (3, 10),
            "target_baseline": "Ubuntu 22.04 / x86_64 / CPython 3.10+",
        },
        "policy": "check-only; V1.0.8 never downloads or installs Python packages",
        "required": required(args.profile),
        "dependencies": rows,
        "missing_packages": missing,
    }
    if sys.version_info < (3, 10):
        result.update(ok=False, error="PythonVersionUnsupported")
    elif missing:
        result.update(
            error="DependenciesMissing",
            message=(
                "Knowledge ingestion conversion is not ready. Required packages must be prepared by the administrator; "
                "Drv Knowledge Suite will not run pip automatically."
            ),
        )

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 20


if __name__ == "__main__":
    raise SystemExit(main())

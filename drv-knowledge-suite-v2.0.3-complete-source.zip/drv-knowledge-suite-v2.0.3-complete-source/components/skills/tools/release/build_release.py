#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()


def release_file(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    if not path.is_file():
        return False
    if "__pycache__" in relative.parts or path.suffix == ".pyc" or path.name == ".DS_Store":
        return False
    if path.name == ".env" or relative.as_posix() == "config/site.env":
        return False
    if path.suffix in {".zip", ".sha256", ".asc"}:
        return False
    return True


def manifest_file(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    if not release_file(path) or relative.as_posix() == "PACKAGE_MANIFEST.txt":
        return False
    if relative.parts and relative.parts[0] == "manuals" and path.name not in {"README.md", ".gitkeep"}:
        return False
    return True


def write_manifest() -> int:
    files = sorted((path for path in ROOT.rglob("*") if manifest_file(path)), key=lambda p: p.relative_to(ROOT).as_posix())
    lines = [f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(ROOT).as_posix()}" for path in files]
    (ROOT / "PACKAGE_MANIFEST.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return len(files)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default=str(ROOT.parent))
    parser.add_argument("--gpg-key")
    args = parser.parse_args()

    manifest_count = write_manifest()
    output = Path(args.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    archive = output / f"drv-knowledge-suite-v{VERSION}.zip"
    if archive.exists():
        archive.unlink()
    files = sorted((path for path in ROOT.rglob("*") if release_file(path)), key=lambda p: p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
        for path in files:
            bundle.write(path, path.relative_to(ROOT.parent))
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    checksum = output / (archive.name + ".sha256")
    checksum.write_text(f"{digest}  {archive.name}\n", encoding="utf-8", newline="\n")
    signed = False
    if args.gpg_key and shutil.which("gpg"):
        subprocess.run(
            ["gpg", "--batch", "--yes", "--local-user", args.gpg_key, "--detach-sign", "--armor", str(archive)],
            check=True,
        )
        signed = True
    print(
        f"ZIP={archive}\nSHA256={digest}\nFILES={len(files)}\n"
        f"MANIFEST_FILES={manifest_count}\nDEPENDENCY_BUNDLE=NONE\nSIGNED={signed}"
    )


if __name__ == "__main__":
    main()
